import { createRouter, createWebHashHistory, createWebHistory } from "vue-router"
import library from "@/library.js"

// 存放解密后的参数；缓存新开窗口，防止回退会再次打开；获取全部vue文件
var [ToData, NotOpen, File] = [undefined, undefined, require.context("@/views", true, /^(?!.*\_component).*index\.vue$/), 'lazy']

// 生成扁平化的路由
var routes = File.keys()
  .map(key => {
    // 直接覆盖，省略声明步骤
    let $ = {
      component: File(key).default, // 实例化页面
      path: key.toLowerCase().replace(new RegExp("/index\.vue", "g"), "").replace(".", "") // 路径小写转换并清除文件名和开头的点
    }

    $.path = $.path == "" ? "/" : $.path // 根节点会被删完，补充一个斜杠
    $.meta = $.component.meta || Object({}) // 获取参数

    // 配置路由名称，没有就自动生成（首字母大写）
    $.name = $.meta.name || ($.path === "/" ? "Index" : $.path.split("/").map(
      item => item.charAt(0).toUpperCase() + item.slice(1)
    ).join(""))

    return $ // 回参
  })

// 递归转换成树状结构
const tree = (pid) => routes.reduce((acc, cur) => {
  var id = cur.path.split("/") // 把路由名称拆散成数组
  id.pop() // 删除掉最后一个，剩下的拼起来就是父级的名称

  if (id.join("/") === pid) {
    cur.children = tree(cur.path) // 这里递归
    cur.children.length === 0 && delete cur.children // 清理空项
    acc.push(cur) // 写入项
  }

  return [
    // 抽出有index的进行排序重新排序
    ...acc.filter($ => $.meta.index !== undefined).sort((a, b) => {
      var n = a.meta.index - b.meta.index // 比较大小
      return isNaN(n) ? 0 : Number(n) // 检查参数
    }),
    // 拼接不需要排序的部分
    ...acc.filter($ => $.meta.index === undefined)
  ]
}, Array())

// 获取路由树
routes = tree(String())

// 把默认路由移动到第一条
routes.unshift(routes.find(
  (item, index) => item.path == "/" ? routes.splice(index, 1) && true : false
))

// 实例化路由
const router = createRouter({
  routes, // 装载路由
  history: createWebHistory(),
  // history: createWebHistory(process.env.VUE_APP_PATH)
})

// 路由拦截器
router.beforeEach((to, from, next) => {
  document.title = to?.meta?.title || process.env.VUE_APP_TITLE // 配置页面标题

  // 自动解密覆盖
  if (!!to.query.V) {
    to.query = library.AES.decrypt(to.query.V)
    to.query = JSON.parse(to.query)
  }

  to.meta.open && from.path === "/" && (NotOpen = to.path)  // 记录当前界面时新开窗口
  ToData = to.query // 覆盖参数缓存

  // 使用页面配置的私有拦截器
  if (to.meta.RouterBeforeEach) {
    to.meta.RouterBeforeEach(to, from, next)
  }

  // 处理需要登录界面，强制要求登录后再跳转
  else if (to.meta.token && new Date().getTime() > (window.$TOKEN$?.expire || 0)) {
    var url = window.location.protocol + "//" + window.location.host + "/" + to.href // 拼接链接
    url = JSON.stringify({ url })
    next({ path: "/login/account", query: { V: library.AES.encrypt(url) } })
  }

  // 处理需要新建窗口的页面
  else if (to.meta.open && from.path !== "/" && to.path !== NotOpen) {
    WindowOpen({ path: to.path, query: to.query })
  }

  // 正常跳转
  else next()
})

// 强制新窗口中打开页面
export const WindowOpen = ({ path, query, data }) => {
  if (path) {
    data = (query || data) // 获取参数
    data = data && JSON.stringify(data) // 获取参数
    data = data && library.AES.encrypt(data) // 加密
    window.open(router.resolve({ path, query: { V: data } }).href, '_blank') // 整合路由参数在新窗口打开
  }
}

// 深度拷贝路由树
export const CopyTree = (tree = router.options.routes) => tree.map(item => {
  const $ = { ...item } // 拷贝一次防止更新原本的树
  delete $.component // 删除携带组件节省内存
  $.children && ($.children = CopyTree($.children)) // 递归子路由
  return { ...$ } // 再拷贝一次
})

// 导出路由树（此处没有拷贝，不要进行危险操作）
export const RouterTree = router.options.routes

/**
 * 自定义加密路由跳转
 * @param {*} path // 跳转的路径
 * @param {*} query // 传递的参数（主要）
 * @param {*} data // 传递的参数（次要）
 * @param {*} open // 在新窗口中打开
 */
export const GO = ({ path, name, query, data }, open = false) => {
  if (open) {
    WindowOpen({ path, query, data }) // 调用新窗口打开
  } else {
    data = (query || data) // 获取参数
    data = data && JSON.stringify(data) // 获取参数
    data = data && library.AES.encrypt(data) // 加密
    if (path) { router.push({ path, query: { V: data } }) } // 跳转路由
    else if (name) { router.push({ name, query: { V: data } }) } // 跳转路由
  }
}

/**
 * 自定义无历史加密路由跳转
 * @param {*} path // 跳转的路径
 * @param {*} query // 传递的参数（主要）
 * @param {*} data // 传递的参数（次要）
 * @param {*} open // 在新窗口中打开
 */
export const Replace = ({ path, name, query, data }) => {
  data = (query || data) // 获取参数
  data = data && JSON.stringify(data) // 获取参数
  data = data && library.AES.encrypt(data) // 加密
  if (path) { router.replace({ path, query: { V: data } }) } // 跳转路由
  else if (name) { router.replace({ name, query: { V: data } }) } // 跳转路由
}

// 跳转获取解密后的参数，也可以去this.route.query里面拿，同样是解密的
export const QUERY = () => ToData

/**
 * 通过路径寻找子路由
 * @param {*} path // 父级路径
 */
export const GetChildren = (path) => {
  // 递归寻找子路由
  var Get = (array) => array.forEach(item => {
    // 匹配路径
    if (item.path === path) {
      throw item.children // 命中后直接中断
    } else if (item.children) {
      Get(item.children) // 递归
    }
  })

  // 中断的方式减少递归次数
  try { Get(CopyTree()) } catch (children) { return children }
}

// 导出默认
export default Object({
  // 导出安装方法
  install: (vue) => {
    router.to = GO
    vue.use(router) // 安装路由
    vue.config.globalProperties.$GO = GO // 自定义加密路由跳转
    vue.config.globalProperties.$QUERY = QUERY // 跳转获取解密后的参数
    vue.config.globalProperties.$Replace = Replace // 跳转获取解密后的参数
  }
})