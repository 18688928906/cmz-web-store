// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
    }

    // 外部初始化
    init($) {
        this._init()
        Object.keys(this._Params).forEach(key => $?.[key] && (this._Params[key] = $?.[key])) // 写入参数
        return this
    }

    // 内部初始化
    _init() {
        // 定义参数
        this._Params = [
            "Page", // 页码
            "Limit", // 每页数量
        ].reduce((total, key) => (total[key] = undefined, total), Object({}))
        this._Params.Page = 1 // 默认页码
        this._Params.Limit = 10 // 默认数量
        this._Data = Array(0) // 内部缓存
        this._Max = Boolean(false) // 是否达到获取上限
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams($ = this._Params) {
        var Params = {} // 创建覆盖用的变量
        Params.page = Number($.Page)
        Params.limit = Number($.Limit)
        return Params // 回参
    }

    /**
     * 获取列表
     * @param {*} Update // 更新获取
     */
    GetData(Update = !this._Max, params = this._GetParams()) {
        // 没有缓存从服务器获取
        if (Update || !this._Data) {
            return this._api({
                label: "获取列表",  // 接口标题
                method: "get", // 接口方法
                url: "", // 访问地址
                params, // 地址携参
                data: undefined // 传递参数
            }).then(data => {
                this._Max = (data?.list?.length || 0) < params.limit // 数据触底
                if (data._code === 200 && data?.list?.length > 0) {
                    var Data = data.list // 创建储存
                    try {
                        Data = Data.map($ => {
                            Data = $
                            return Data
                        })
                        this._Data.push(Data)
                        this._Params.Page++ // 预翻页
                        return this._UseUpdate(this._Data) // 回参
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) {
                    throw data._msg
                }
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this.List))) // 回参
        }
    }
}