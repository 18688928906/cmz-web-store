<template>
  <div class="view">
    <!-- 账号 -->
    <ElInput
      v-model="Phone"
      oninput="this.value=this.value.replace(/[^0-9]/g,'')"
      placeholder="请输入手机号"
      maxlength="11"
      size="large"
      show-word-limit
    />

    <!-- 验证码 -->
    <div class="vaild-box">
      <ElInput v-model="Vaild" placeholder="请输入验证码" size="large" />
      <div v-if="time > 0" class="vaild active">{{ `（${time}s）` }}</div>
      <div
        v-else
        :class="{ 'active-hover': !Disabled }"
        class="vaild"
        @click="valid()"
      >
        获取验证码
      </div>
    </div>
  </div>
</template>

<script>
import close from "../_components/close.png";
import Protocol from "../_components/Protocol.vue";
import LoginButton from "../_components/LoginButton.vue";

export default {
  // 自动路由参数
  meta: {
    title: "短信登录", // 写入浏览器页签
    index: 1, // 用于排序
    label: "短信登录", // 显示用的路由名称
    name: "LoginValid", // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(false), // 控制是否需要登录
  },

  // 组件
  components: { Protocol, LoginButton },

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
    bus: undefined, // 局域订阅
  },

  // 计算属性
  computed: {
    // 账号
    Phone: {
      get() {
        return this.phone;
      },
      set(value) {
        this.Api.UserLogin.Account = value;
        this.phone = value;
        this.bus.setPhone(value);
      },
    },

    Vaild: {
      get() {
        return this.vaild;
      },
      set(value) {
        this.vaild = value;
        this.bus.setVaild(value);
      },
    },

    // 禁用
    Disabled: {
      get() {
        return !/^1[3456789]\d{9}$/.test(this.phone);
      },
    },
  },

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    phone: String(""), // 手机号
    vaild: String(""), // 验证码

    timeout: Number(0), // 倒计时目标时间
    time: Number(0), // 倒计时

    tips: undefined, // 提示

    protocol: false,
    close,
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 发布订阅
    this.BUS.SetMode(this.$options.meta.index);

    // 清空账号
    this.Phone = this.phone;
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 登录
    login() {
      if (this.protocol) {
        this.tips = undefined;
        this.Api.UserLogin.GetToken(this.vaild)
          .then((_) => {
            if (this.orx) {
              this.$emit("login");
            } else if (this.query?.url) {
              window.location.replace(this.query.url);
            } else this.$router.push({ name: "Home" });
          })
          .catch(($) => {
            this.tips = $;
          })
          .finally((_) => {
            this.BUS.Loading(false);
          });
      } else {
        this.tips = "请先同意协议";
      }
    },

    // 验证码
    valid() {
      if (!this.Disabled) {
        this.bus.setTips(undefined);
        this.timeout = new Date().getTime() + 120 * 1000;
        this.usetimeout();
        this.Api.UserLogin.SendValidCode().catch(($) => {
          this.bus.setTips($);
          this.timeout = this.time = 0;
          delete this.QUEUE.Valid; // 销毁订阅
        });
      }
    },

    // 使用倒计时
    usetimeout() {
      // 订阅心跳
      this.QUEUE.Valid = (unix) => {
        this.time = Math.floor((this.timeout - unix) / 1000);
        if (this.time <= 0) {
          this.timeout = this.time = 0;
          delete this.QUEUE.Valid; // 销毁订阅
        }
      };
    },
  },
};
</script>

<style lang="scss" scoped>
.view {
  // 容器
  justify-content: flex-start;
  flex-direction: column;
  align-items: stretch;
  padding-top: 50px;
  flex-wrap: nowrap;
  display: flex;
  // height: 100%;
  width: 100%;

  .el-input {
    // 替换颜色
    --el-input-focus-border-color: rgba(249, 104, 40, 1);
    flex-shrink: 0;
  }

  .vaild-box {
    // 验证码容器
    justify-content: flex-start;
    flex-direction: row;
    align-items: center;
    flex-wrap: nowrap;
    margin-top: 16px;
    display: flex;

    .el-input {
      width: calc(100% - 8px - 86px);
    }

    .vaild {
      // 发送验证码
      border-radius: var(--el-border-radius-base);
      background-color: rgba(242, 243, 245, 1);
      transition: var(--el-transition-all);
      color: rgba(192, 196, 204, 1);
      justify-content: center;
      align-items: center;
      cursor: not-allowed;
      margin-left: 8px;
      font-size: 14px;
      flex-shrink: 0;
      display: flex;
      height: 40px;
      width: 86px;
    }

    .active,
    .active-hover {
      background-color: rgba(249, 104, 40, 1);
      color: white;
    }

    .active-hover {
      cursor: pointer;
      &:hover {
        background-color: rgba(249, 104, 40, 0.8);
      }
    }
  }
}
</style>