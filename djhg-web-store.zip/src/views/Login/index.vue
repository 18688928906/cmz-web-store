<template>
  <ScrollBar pb="0px">
    <TopBox />
    <PageBox>
      <LoginBox :query="query" @setActive="setName">
        <RouterView v-slot="{ Component }">
          <transition :name="name" mode="out-in">
            <component :is="Component" :query="$route.query" :bus="bus" />
          </transition>
        </RouterView>

        <!-- 提示容器 -->
        <div class="tips-box">
          <img v-if="tips" class="close" :src="close" />
          <div v-if="tips" class="tips">{{ tips }}</div>
        </div>

        <!-- 协议 -->
        <!-- <Protocol v-model="protocol" :bus="bus" /> -->

        <!-- 登录按钮 -->
        <LoginButton :disabled="Disabled" @click="login()" />

        <!-- 底部容器 -->
        <div class="bottom-box">
          <!-- <transition :name="name" mode="out-in">
            <div v-if="name === 'fade0'" class="A" @click="GoRetrieve">
              忘记密码
            </div>
          </transition> -->
          <div class="A" @click="GoRetrieve">忘记密码</div>
          <div style="flex-grow: 1" />
          <div class="B" @click="GoRegistration">注册账号</div>
        </div>
      </LoginBox>
    </PageBox>
  </ScrollBar>
</template>

<script>
import close from "./_components/close.png";

import { Components } from "@/library.js";
import bus from "@/tool-library/_modules/busFunction.js";

export default {
  // 自动路由参数
  meta: {
    title: undefined, // 写入浏览器页签
    index: undefined, // 用于排序
    label: "登录", // 显示用的路由名称
    name: undefined, // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(false), // 控制是否需要登录
  },

  // 组件
  components: Components(require.context("./_components", false, /\.vue$/)),

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {
    Disabled: {
      get() {
        return !(
          !!this.phone &&
          // this.protocol &&
          (this.name === "fade0" ? !!this.password : !!this.vaild)
        );
      },
    },
  },

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    close,
    name: undefined,
    tips: undefined,
    phone: undefined,
    password: undefined,
    vaild: undefined,
    bus: bus(),
    protocol: false,
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.bus.setTips = ($) => (this.tips = $);
    this.bus.setPhone = ($) => (this.phone = $);
    this.bus.setPassword = ($) => (this.password = $);
    this.bus.setVaild = ($) => (this.vaild = $);
    this.bus.setProtocol = ($) => (this.protocol = $);
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    setName(index) {
      this.name = "fade" + index;
      this.protocol = false;
    },

    // 登录
    login() {
      if (!this.Disabled) {
        if (this.name === "fade0") {
          this.tips = undefined;
          this.Api.UserLogin.GetToken()
            .then((_) => this.$router.push({ name: "Home" }))
            .catch(($) => {
              this.tips = $;
            });
        } else if (this.name === "fade1") {
          this.tips = undefined;
          this.Api.UserLogin.GetToken(this.vaild)
            .then((_) => this.$router.push({ name: "Home" }))
            .catch(($) => {
              this.tips = $;
            });
        }
      }
    },

    // 跳转注册界面
    GoRegistration() {
      this.$GO({ path: "/menu/registration/valid" }, true);
    },

    // 找回密码
    GoRetrieve() {
      this.$GO({ path: "/menu/retrieve/password/account" }, true);
    },
  },
};
</script>

<style lang="scss" scoped>
.tips-box {
  // 提示容器
  justify-content: flex-start;
  align-items: flex-start;
  flex-direction: row;
  flex-wrap: nowrap;
  margin-top: 9px;
  display: flex;
  flex-grow: 1;
  width: 100%;

  .close {
    margin-right: 5px;
    flex-shrink: 0;
    height: 14px;
    width: 14px;
  }

  .tips {
    color: rgba(245, 63, 63, 1);
    line-height: 14px;
    font-size: 12px;
    flex-grow: 1;
  }
}

.bottom-box {
  // 底部容器
  justify-content: flex-start;
  flex-direction: row;
  align-items: center;
  flex-wrap: nowrap;
  margin-top: 28px;
  flex-shrink: 0;
  display: flex;

  div {
    transition: var(--el-transition-all);
    align-items: center;
    font-size: 12px;
    display: flex;
    height: 17px;

    &:hover {
      color: rgba(249, 104, 40, 1);
    }
  }

  .A {
    color: rgba(192, 196, 204, 1);
    cursor: pointer;
  }

  .B {
    color: rgba(96, 98, 102, 1);
    cursor: pointer;
  }
}

/* ---------- * ---------- */

.fade1-enter-active,
.fade1-leave-active,
.fade0-enter-active,
.fade0-leave-active {
  transition: all 0.2s var(--el-transition-function-ease-in-out-bezier);
}

/* ---------- * ---------- */

.fade0-leave-from {
  transform: translateX(0%);
}

.fade0-leave-to {
  transform: translateX(100%);
}

.fade0-enter-from {
  transform: translateX(-100%);
}

.fade0-enter-to {
  transform: translateX(0%);
}

/* ---------- * ---------- */

.fade1-leave-from {
  transform: translateX(0%);
}

.fade1-leave-to {
  transform: translateX(-100%);
}

.fade1-enter-from {
  transform: translateX(100%);
}

.fade1-enter-to {
  transform: translateX(0%);
}
</style>