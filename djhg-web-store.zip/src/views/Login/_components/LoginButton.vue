<template>
  <div class="button">
    <img v-if="disabled" :src="src[0]" class="shadow" />
    <template v-else
      ><div class="trigger" />
      <img :src="src[1]" class="shadow s1" />
      <img :src="src[2]" class="shadow s2" />
    </template>
  </div>
</template>

<script>
import bt1 from "./bt1.png";
import bt2 from "./bt2.png";
import bt3 from "./bt3.png";

export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    disabled: undefined,
  },

  // 抛出事件名称
  emits: [],

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    src: [bt1, bt2, bt3],
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.button {
  // 主容器
  position: relative;
  user-select: none;
  height: 40px;
  width: 100%;

  .shadow {
    cursor: not-allowed;
    width: 100%;
    left: 0;
    top: 0;
  }

  .s1 {
    display: block;
  }

  .s2 {
    display: none;
  }

  .trigger {
    position: absolute;
    cursor: pointer;
    height: 100%;
    width: 100%;
    left: 0;
    top: 0;
  }

  .trigger:hover ~ .s1 {
    display: none;
  }

  .trigger:hover ~ .s2 {
    display: block;
  }

  .button-in {
    background: linear-gradient(
      90deg,
      rgba(255, 199, 0, 1) 0%,
      rgba(249, 104, 40, 1) 100%
    );
    transition: var(--el-transition-all);
    justify-content: center;
    align-items: center;
    border-radius: 8px;
    cursor: pointer;
    color: white;
    flex-shrink: 0;
    display: flex;
    opacity: 0.6;
    height: 100%;
    width: 100%;
  }
}
</style>