<template>
  <div class="box">
    <div class="box-in">
      <img :src="newLogo" class="logo" />
    </div>
  </div>
</template>

<script>
import newLogo from "./newLogo.png";

export default {
  // 禁止透传
  inheritAttrs: false,

  // 组件
  components: {},

  // 接收参数
  props: {},

  // 抛出事件名称
  emits: [],

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    newLogo,
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.box {
  // 主容器
  background-color: white;
  justify-content: center;
  align-items: stretch;
  flex-direction: row;
  flex-wrap: nowrap;
  display: flex;
  height: 120px;
  width: 100%;

  .box-in {
    // 内部容器
    justify-content: flex-start;
    flex-direction: row;
    align-items: center;
    flex-wrap: nowrap;
    display: flex;
    width: 1200px;

    .logo {
      height: 40px;
    }
  }
}
</style>