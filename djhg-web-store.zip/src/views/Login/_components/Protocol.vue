<template>
  <div class="box">
    <div :class="{ active: modelValue }" class="button" @click="update" />
    <span>请阅读并同意</span>
    <span class="bp" @click="go(2)">《用户协议》</span>
    <span>与</span>
    <span class="bp" @click="go(5)">《隐私协议》</span>
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    modelValue: {
      type: Boolean,
      default: false,
    },

    bus: undefined, // 局域订阅
  },

  // 抛出事件名称
  emits: [],

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    update() {
      // this.$emit("update:modelValue", !this.modelValue);
      this.bus.setProtocol(!this.modelValue);
    },

    // 打开用户协议
    go(Id) {
      this.$router.push({ path: "/protocol", query: { Id } });
    },
  },
};
</script>

<style lang="scss" scoped>
.box {
  // 主容器
  justify-content: flex-start;
  flex-direction: row;
  margin-bottom: 16px;
  align-items: center;
  flex-wrap: nowrap;
  flex-shrink: 0;
  display: flex;
  width: 100%;

  .button {
    border: 1px solid rgba(220, 223, 230, 1);
    transition: var(--el-transition-all);
    box-sizing: border-box;
    border-radius: 14px;
    margin-right: 9px;
    cursor: pointer;
    height: 14px;
    width: 14px;

    &:hover {
      border-color: rgba(249, 104, 40, 1);
    }
  }

  .active {
    border-color: rgba(249, 104, 40, 1);
    border-width: 4px;
  }

  span {
    color: rgba(192, 196, 204, 1);
    font-size: 12px;
  }

  .bp {
    color: rgba(16, 16, 16, 1);
    cursor: pointer;
  }
}
</style>