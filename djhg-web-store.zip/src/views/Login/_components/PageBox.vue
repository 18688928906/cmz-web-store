<template>
  <div :style="style" class="box">
    <div class="box-in"><slot /></div>
  </div>
</template>

<script>
import background from "./background.png";

export default {
  // 禁止透传
  inheritAttrs: false,

  // 组件
  components: {},

  // 接收参数
  props: {},

  // 抛出事件名称
  emits: [],

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    background,
    style: "",
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.style = `background-image:url('${this.background}')`;
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.box {
  // 主容器
  background-position: 50% 50%;
  background-repeat: no-repeat;
  background-size: cover;
  justify-content: center;
  flex-direction: row;
  align-items: stretch;
  min-height: 725px;
  flex-wrap: nowrap;
  display: flex;
  flex-grow: 1;
  height: 100%;
  width: 100%;

  .box-in {
    justify-content: flex-end;
    flex-direction: row;
    align-items: center;
    flex-wrap: nowrap;
    display: flex;
    width: 1200px;
  }
}
</style>