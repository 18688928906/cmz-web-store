<template>
  <div class="box">
    <div class="type-box">
      <template v-for="(item, index) in list" :key="index">
        <div
          :class="{ active: active === index }"
          class="type"
          ref="$"
          @click="SetPage(index)"
        >
          {{ item.label }}
        </div>
      </template>
      <div :style="lineStyle" class="line" />
    </div>
    <div class="page-box"><slot /></div>
  </div>
</template>

<script>
export default {
  // 禁止透传
  inheritAttrs: false,

  // 组件
  components: {},

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 抛出事件名称
  emits: ["setActive"],

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    list: [
      {
        label: "密码登录",
        path: "/login/account",
      },
      {
        label: "短信登录",
        path: "/login/valid",
      },
    ],

    active: undefined, // 激活的模式
    lineStyle: undefined, // 下滑线样式
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.active = this.list.findIndex((item) => item.path === this.$route.path);
  },

  // 生命周期函数：挂载后调用
  mounted() {
    if (this.active < 0) {
      this.SetPage(0);
    } else {
      this.SetLine();
    }
  },

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 设置横线
    SetLine(index = this.active) {
      let { offsetWidth: width, offsetLeft: left } = this.$refs.$[index];
      this.lineStyle = `width:${width}px;left:${left}px`;
      this.active = index;
      this.$emit("setActive", index);
    },

    // 跳转界面
    SetPage(index = this.active) {
      this.SetLine(index);
      this.$GO({ path: this.list[index]?.path, data: this.query });
    },
  },
};
</script>

<style lang="scss" scoped>
.box {
  // 主容器
  --active-color: rgba(249, 104, 40, 1);
  justify-content: flex-start;
  background-color: white;
  padding: 49px 32px 59px;
  flex-direction: column;
  align-items: stretch;
  border-radius: 6px;
  flex-wrap: nowrap;
  display: flex;
  height: 416px;
  width: 360px;

  .type-box {
    // 类型容器
    justify-content: center;
    align-items: stretch;
    flex-direction: row;
    position: relative;
    flex-wrap: nowrap;
    flex-shrink: 0;
    display: flex;
    height: 28px;
    width: 100%;

    .type {
      // 类型选项
      transition: var(--el-transition-all);
      color: rgba(96, 98, 102, 1);
      justify-content: center;
      flex-direction: row;
      align-items: center;
      flex-wrap: nowrap;
      font-weight: 600;
      font-size: 14px;
      cursor: pointer;
      display: flex;
    }

    .type + .type {
      margin-left: 64px;
    }

    .type:hover,
    .active {
      color: var(--active-color);
    }

    .line {
      // 下滑线
      background-color: var(--active-color);
      transition: var(--el-transition-all);
      position: absolute;
      height: 1px;
      bottom: 0;
    }
  }

  .page-box {
    justify-content: flex-start;
    flex-direction: column;
    align-items: stretch;
    position: relative;
    flex-wrap: nowrap;
    overflow: hidden;
    display: flex;
    flex-grow: 1;
    width: 100%;
  }
}
</style>