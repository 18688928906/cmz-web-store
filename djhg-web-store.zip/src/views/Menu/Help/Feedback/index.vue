<template>
  <ScrollBar>
    <!-- 表单 -->
    <ElForm :model="form" :rules="rules" label-position="top" ref="$">
      <div class="title">参谋者产品反馈调研</div>

      <div class="title-lite">亲爱的用户您好：</div>

      <div class="tips">
        感谢您使用参谋者，为了给您提供更好的产品体验，请在此页面提出您的宝贵建议，我们将会关注您的反馈信息，不断优化产品，在此对您表示衷心的感谢。
      </div>

      <ElFormItem
        label="1.在使用参谋者时，有什么体验不好或功能缺失的地方， 请在此留言，留言越详细越更有利于我们改进产品，为您提供更好的产品体验"
        style="margin-top: 5px"
        prop="Content"
      >
        <ElRow class="item-box">
          <div class="item-tips">
            请尽量详细的描述需要改进的地方和板块，以便我们改进问题和解决问题
          </div>

          <div v-if="!contentTips" class="content-tips">
            请填写您的建议和反馈6-200个字哦
          </div>

          <ElInput
            v-model="form.Content"
            :maxlength="200"
            :rows="6"
            placeholder="请在此输入您的宝贵建议和反馈"
            type="textarea"
            resize="none"
            show-word-limit
          />

          <Upload v-model:file="form.File" />
        </ElRow>
      </ElFormItem>

      <ElFormItem label="2.您是否愿意更进一步协助我们改进产品">
        <ElRadioGroup v-model="form.Radio" class="ml-4">
          <ElRadio label="1">我愿意</ElRadio>
          <ElRadio label="2">我不愿意</ElRadio>
        </ElRadioGroup>
      </ElFormItem>

      <ElFormItem
        v-if="form.Radio === '1'"
        label="3.为给您带来更好的体用体验，请在下面满意度进行打分"
      >
        <table>
          <tr v-for="(item, index) in form.Rate" :key="index">
            <td style="width: 150px; text-align: left">{{ item.title }}</td>
            <td style="text-align: right">
              <ElRate v-model="item.value" />
            </td>
            <td style="width: 35px">
              {{ rateTips[item.value] }}
            </td>
          </tr>
        </table>
      </ElFormItem>

      <ElFormItem
        :label="
          (form.Radio === '1' ? '4' : '3') +
          '.为了方便与您进行联系，可输入联系电话'
        "
      >
        <ElInput
          v-model="form.Phone"
          :maxlength="11"
          placeholder="请输入联系电话"
          style="width: 296px; margin-left: 12px"
          show-word-limit
        />
      </ElFormItem>

      <img :src="btimg" class="uploadbt" @click="upload()" />
      <!-- <ElButton type="primary" size="large" class="upload" @click="upload()">
        提交反馈
      </ElButton> -->
    </ElForm>
  </ScrollBar>
</template>

<script>
import Upload from "./_components/Upload.vue";
import start1 from "./_components/Star1.png";
import start2 from "./_components/Star2.png";
import btimg from "./_components/button.png";

export default {
  // 自动路由参数
  meta: {
    title: undefined, // 写入浏览器页签
    index: Number(0), // 用于排序
    label: "意见反馈", // 显示用的路由名称
    name: undefined, // 路由名称

    open: Boolean(true), // 是否在新页面中打开
    token: Boolean(true), // 控制是否需要登录
  },

  // 组件
  components: { Upload },

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    rateTips: ["", "极差", "失望", "一般", "满意", "极好"],
    start: [start1, start1, start2],

    form: {
      Content: "", // 反馈内容
      File: Array(0), // 上传的图片文件
      Radio: "1", // 改进意愿
      Rate: [
        { title: "界面设计美观", value: 0 },
        { title: "操作是否方便", value: 0 },
        { title: "界面表达清晰", value: 0 },
        { title: "功能是否清晰明了", value: 0 },
        { title: "推荐商品满意程度", value: 0 },
        { title: "内容是否具有吸引力", value: 0 },
        { title: "产品新颖程度", value: 0 },
      ],
      Phone: "",
    },

    rules: {
      Content: [],
    },

    contentTips: true,

    btimg,
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.rules.Content.push({
      required: true,
      validator: (rule, value, callback) => {
        this.contentTips = !!value;
        callback(this.contentTips ? undefined : new Error(""));
      },
    });
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    upload() {
      this.$refs.$.validate().then(($) => {
        if ($) {
          var form = { ...this.form };
          form.Img = form.File.map((item) => item.response.data.url).join(","); // 拼接图片链接
          form.Rate = form.Rate.map(($) => $.value);
          this.Api.UserFeedback.init(form)
            .SetData()
            .then(($) => {
              this.$GO({ path: "/menu/help/feedbackfin" });
            });
        }
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.el-form {
  // 表单覆盖
  --el-color-primary: rgba(249, 104, 40, 1);
  background-color: white;
  padding: 20px 120px;
  border-radius: 6px;
  margin-top: 20px;
  width: 1200px;

  .title {
    // 标题
    text-align: center;
    line-height: 22px;
    font-weight: 600;
    margin-top: 10px;
    font-size: 16px;
  }

  .title-lite {
    // 副标题
    line-height: 20px;
    font-weight: 600;
    margin-top: 30px;
    font-size: 14px;
  }

  .tips {
    // 提示
    line-height: calc(1em + 10px);
    text-indent: 2em;
    margin-top: 5px;
    font-size: 14px;
  }

  .el-form-item {
    // 单项覆盖
    width: 100%;

    :deep(.el-form-item__label) {
      color: rgba(16, 16, 16, 1);
      font-weight: 600;
      font-size: 12px;
    }

    :deep(.el-form-item__content) {
      line-height: normal;
    }

    .item-box {
      // 行容器
      flex-direction: column;
      padding-left: 12px;
      width: 100%;

      .item-tips {
        // 提示
        color: rgba(187, 187, 187, 1);
        line-height: 14px;
        font-size: 12px;
      }

      .content-tips {
        color: rgba(239, 68, 68, 1);
        margin-top: 16px;
        line-height: 14px;
        font-size: 12px;
      }

      .el-textarea {
        // 文本域
        margin: 16px 0;
        width: 860px;
      }
    }

    .ml-4 {
      padding-left: 12px;
    }

    table {
      padding-left: 12px;
      height: 240px;
      width: 340px;

      tr {
        td {
          background-color: rgba(255, 255, 255, 1);
          text-align: center;
          font-size: 14px;
        }

        .el-rate {
          --el-rate-fill-color: rgba(239, 68, 68, 1);

          :deep(.is-active) {
            svg {
              transform: scale(1.2);
            }
          }
        }
      }
    }
  }
}

.uploadbt {
  // 上传按钮
  margin-left: calc(452px - 120px);
  cursor: pointer;
  width: 296px;
}
</style>