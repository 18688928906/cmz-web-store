<template>
  <ScrollBar>
    <!-- 顶栏 -->
    <TopBar :label="$options.meta.label" />

    <!-- 容器 -->
    <div class="card">
      <!-- 标题 -->
      <div class="label">{{ title }}{{ $options.meta.label }}</div>

      <!-- 内容 -->
      <div class="info">
        <!-- 邮箱地址 -->
        <div class="email">{{ email }}</div>

        <!-- 提示内容 -->
        <div class="tips">
          可以通过此邮箱对我们进行问题反馈，我们工作人员将尽快回复您，感谢您对{{
            title
          }}的支持。
        </div>

        <!-- 按钮容器 -->
        <ElRow class="button-box">
          <ElButton type="primary" @click="$GO({ name: 'Home' })">
            我已知悉
          </ElButton>
        </ElRow>
      </div>
    </div>
  </ScrollBar>
</template>

<script>
export default {
  // 自动路由参数
  meta: {
    title: undefined, // 写入浏览器页签
    index: Number(1), // 用于排序
    label: "客服邮箱", // 显示用的路由名称
    name: undefined, // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(false), // 控制是否需要登录
  },

  // 组件
  components: {},

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    title: process.env.VUE_APP_TITLE, // 映射项目标题

    email: "service@cmzmzm.com", // 客服邮箱
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {
    this.BUS.SetMenuLabel(this.$options.meta.label); // 发布菜单选中
  },

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.card {
  // 主容器
  box-shadow: var(--base-shadow);
  background-color: white;
  border-radius: 4px;
  margin-top: 32px;
  overflow: hidden;
  width: 400px;

  .label {
    // 标题
    background-color: rgba(244, 244, 244, 1);
    color: rgba(16, 16, 16, 1);
    box-sizing: border-box;
    line-height: 20px;
    font-size: 14px;
    padding: 10px;
  }

  .info {
    // 内容
    background-color: rgba(255, 255, 255, 1);
    flex-direction: column;
    align-items: center;
    display: flex;
    padding: 24px;

    .email {
      // 邮箱地址
      color: rgba(16, 16, 16, 1);
      font-size: 24px;
    }

    .tips {
      // 提示文字
      color: rgba(153, 153, 153, 1);
      line-height: 16px;
      margin-top: 24px;
      font-size: 12px;
    }

    .button-box {
      justify-content: center;
      margin-top: 24px;
      width: 100%;
    }
  }
}
</style>