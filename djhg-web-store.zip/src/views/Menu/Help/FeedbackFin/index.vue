<template>
  <ScrollBar>
    <div class="box">
      <img :src="src" alt="" />
      <div class="title">提交成功</div>
      <div class="tips">感谢您为我们提出的宝贵建议和反馈</div>
    </div>
  </ScrollBar>
</template>

<script>
import src from "./_components/Frame.png";
export default {
  // 自动路由参数
  meta: {
    title: undefined, // 写入浏览器页签
    index: undefined, // 用于排序
    label: undefined, // 显示用的路由名称
    name: undefined, // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(false), // 控制是否需要登录
  },

  // 组件
  components: {},

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({ src }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.box {
  box-shadow: 0px 4px 8px 0px rgba(0, 0, 0, 0.1);
  justify-content: center;
  flex-direction: column;
  background: white;
  align-items: center;
  border-radius: 4px;
  flex-wrap: nowrap;
  margin-top: 16px;
  display: flex;
  height: 673px;
  width: 1200px;

  img {
    height: 133px;
    width: 133px;
  }

  .title {
    font-weight: 500;
    margin-top: 15px;
    font-size: 16px;
  }

  .tips {
    color: rgba(96, 98, 102, 1);
    margin-top: 15px;
    font-size: 12px;
  }
}
</style>