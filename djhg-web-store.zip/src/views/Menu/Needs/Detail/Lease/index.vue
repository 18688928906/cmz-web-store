<template>
  <template v-if="!!item">
    <!-- 用户信息 -->
    <ElRow class="user-box">
      <ElAvatar :size="30" :src="item?.User?.Avatar">
        {{ item?.User?.Name?.[0] }}
      </ElAvatar>
      <div class="name">{{ item?.User?.Name }}</div>
    </ElRow>

    <!-- 标题 -->
    <div class="label">{{ item?.Label }}</div>

    <ElRow class="lease-box">
      <div>租借时间：{{ item?.Lease }}</div>
      <div>商品租金：{{ item?.Rent }}元</div>
      <div>租借地点：{{ item?.Region + " " + item?.Address }}</div>
    </ElRow>

    <!-- 内容 -->
    <div class="content">{{ item?.Content }}</div>

    <div class="img-box">
      <ElImage
        v-for="(item, index) in item?.Imgs"
        :key="index"
        :src="item"
        fit="contain"
      />
    </div>

    <!-- 时间容器 -->
    <ElRow class="time-box">
      <div class="tiem">{{ item.Time }}</div>
    </ElRow>

    <div class="hr" />
  </template>
</template>

<script>
import { GUID } from "@/library.js";

export default {
  // 自动路由参数
  meta: {
    title: undefined, // 写入浏览器页签
    index: Number(0), // 用于排序
    label: "租赁需求", // 显示用的路由名称
    name: undefined, // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(false), // 控制是否需要登录
  },

  // 组件
  components: {},

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    key: GUID(),
    item: undefined,
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 获取详情
    this.Api.NeedsDetailLease.init({
      Id: this.query.Id,
    })
      .GetData()
      .then(($) => {
        this.item = $;
      });
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.user-box {
  // 用户信息
  align-items: center;
  margin-top: 28px;
  width: 1200px;

  .name {
    // 用户姓名
    margin-left: 18px;
    font-size: 14px;
  }
}

.label {
  // 标题
  margin-top: 20px;
  line-height: 1em;
  font-size: 18px;
  width: 1200px;
}

.lease-box {
  // 租赁容器
  margin-top: 20px;
  width: 1200px;

  div {
    font-size: 14px;
  }

  div + div {
    margin-left: 40px;
  }
}

.content {
  // 内容
  // word-break: break-all;
  line-height: 20px;
  margin-top: 20px;
  font-size: 14px;
  width: 1200px;
}

.img-box {
  // 图片容器
  grid-template-columns: repeat(auto-fill, 120px);
  grid-gap: 8px 8px;
  margin-top: 20px;
  display: grid;
  width: 1200px;

  .el-image {
    height: 120px;
    width: 120px;
  }
}

.time-box {
  // 时间容器
  align-items: center;
  width: 1200px;

  .tiem {
    color: rgba(153, 153, 153, 1);
    margin-top: 20px;
    line-height: 1em;
    font-size: 12px;
  }
}

.hr {
  background-color: rgba(244, 244, 244, 1);
  margin-top: 20px;
  width: 1200px;
  height: 1px;
}

.hr + .user-box {
  margin-top: 20px;
}
</style>