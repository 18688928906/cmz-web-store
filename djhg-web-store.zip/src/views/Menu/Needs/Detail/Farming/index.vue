<template>
  <TabBox />
  <template v-for="(item, index) in list" :key="index">
    <!-- 用户信息 -->
    <ElRow class="user-box">
      <ElAvatar :size="30" :src="item?.User?.Avatar">
        {{ item?.User?.Name?.[0] }}
      </ElAvatar>
      <div class="name">{{ item?.User?.Name }}</div>
    </ElRow>

    <!-- 标题 -->
    <div class="label">{{ item.Label }}</div>

    <!-- 内容 -->
    <div class="content">{{ item.Content }}</div>

    <!-- 时间容器 -->
    <ElRow class="time-box">
      <div class="tiem">{{ item.Time }}</div>
    </ElRow>

    <div class="hr" />
  </template>
</template>

<script>
import { GUID } from "@/library.js";
import TabBox from "./_components/TbaBox.vue";

export default {
  // 自动路由参数
  meta: {
    title: undefined, // 写入浏览器页签
    index: Number(5), // 用于排序
    label: "助农需求", // 显示用的路由名称
    name: undefined, // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(false), // 控制是否需要登录
  },

  // 组件
  components: { TabBox },

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    key: GUID(),
    list: undefined,
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.Api.NeedsList.init({ Type: this.$options.meta.index }).AddUpdate(
      this.key,
      (list) => {
        this.list = undefined;
        this.list = list;
      }
    ); // 订阅数据

    this.BUS.NeedsMore = () => this.Api.NeedsList.GetData();
  },

  // 生命周期函数：挂载后调用
  mounted() {
    this.BUS.NeedsLitType(this.$options.meta.index);
  },

  // 生命周期函数：离开前调用
  beforeUnmount() {
    this.Api.NeedsList.DelUpdate(this.key); // 取消订阅
    delete this.BUS.NeedsMore;
  },

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.user-box {
  // 用户信息
  align-items: center;
  width: 1200px;

  .name {
    // 用户姓名
    margin-left: 18px;
    font-size: 14px;
  }
}

.label {
  // 标题
  font-weight: bold;
  margin-top: 20px;
  line-height: 1em;
  font-size: 14px;
  cursor: pointer;
  width: 1200px;

  &:hover {
    color: red;
  }
}

.content {
  // 内容
  word-break: break-all;
  line-height: 20px;
  margin-top: 20px;
  font-size: 14px;
  width: 1200px;
}

.time-box {
  // 时间容器
  align-items: center;
  width: 1200px;

  .tiem {
    color: rgba(153, 153, 153, 1);
    margin-top: 20px;
    line-height: 1em;
    font-size: 12px;
  }
}

.hr {
  background-color: rgba(244, 244, 244, 1);
  margin-top: 20px;
  width: 1200px;
  height: 1px;
}

.hr + .user-box {
  margin-top: 20px;
}
</style>