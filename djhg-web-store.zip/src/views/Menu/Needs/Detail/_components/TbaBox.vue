<template>
  <ElRow class="tab-box">
    <!-- 页签容器 -->
    <div class="tab-box-in" ref="tab-box">
      <!-- 页签选项 -->
      <template v-for="(item, index) in list" :key="index">
        <div
          v-if="!!item?.meta?.label"
          :class="{ act: page === index }"
          class="tab"
          ref="tab"
          @click="click(index)"
        >
          {{ item?.meta?.label }}
        </div>
      </template>

      <!-- 站位框 -->
      <div style="flex-grow: 1" />

      <!-- 移动下划线 -->
      <div v-if="!!style" :style="style" class="hrx" />
    </div>
  </ElRow>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    list: {
      type: Array,
      default: () => Array(0),
    },
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    page: undefined, // 配置被选中的项目
    style: undefined, // 下划线样式
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.BUS.NeedsLitType = ($) => this.click($); // 订阅页面切换
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    delete this.BUS.NeedsLitType; // 取消订阅
  },

  // 组件方法
  methods: {
    // 点击事件
    click(index) {
      this.page = index; // 记录选中的页签
      const box = this.$refs["tab-box"].getBoundingClientRect();
      const tab = this.$refs["tab"][index].getBoundingClientRect();

      // 拼接样式
      this.style = {
        left: tab.x - box.x - 4 + "px",
        width: tab.width + 8 + "px",
      };

      this.$GO({ path: this.list[index].path }); // 跳转页面
    },
  },
};
</script>

<style lang="scss" scoped>
.tab-box {
  // 居中功能
  border: 1px solid rgba(244, 244, 244, 1);
  background-color: white;
  justify-content: center;
  border-right: none;
  border-left: none;
  width: 100%;

  .tab-box-in {
    // 内部容器
    align-items: center;
    position: relative;
    display: flex;
    width: 1200px;
    height: 50px;

    .tab {
      // 页签
      color: rgba(169, 169, 169, 1);
      text-align: center;
      margin-left: 8px;
      line-height: 1em;
      font-size: 16px;
      cursor: pointer;
    }

    .tab + .tab {
      margin-left: 68px;
    }

    .act,
    .tab:hover {
      color: var(--base-color);
      font-weight: bold;
    }

    .hrx {
      // 移动下划线
      transition: width var(--base-transition), left var(--base-transition);
      background-color: var(--base-color);
      position: absolute;
      height: 2px;
      bottom: -1px;
    }
  }
}
</style>