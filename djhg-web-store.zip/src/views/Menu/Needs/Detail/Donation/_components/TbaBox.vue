<template>
  <!-- 页签容器 -->
  <div class="tab-box-in" ref="tab-box">
    <!-- 页签选项 -->
    <ElRow
      :class="{ act: page === 0 }"
      class="tab"
      ref="tab0"
      @click="UseComprehensive()"
    >
      <span>综合</span>
    </ElRow>
    <ElRow
      :class="{ act: page === 1 }"
      class="tab"
      ref="tab1"
      @click="SetHeat()"
    >
      <span>热度</span>
      <template v-if="page === 1">
        <img v-if="type" :src="$svg['i-0041-FF0000-A']" />
        <img v-else :src="$svg['i-0041-FF0000-B']" />
      </template>
      <img v-else :src="$svg['i-0041-A9A9A9']" />
    </ElRow>
    <ElRow
      :class="{ act: page === 2 }"
      class="tab"
      ref="tab2"
      @click="SetTime()"
    >
      <span>时间</span>
      <template v-if="page === 2">
        <img v-if="type" :src="$svg['i-0041-FF0000-A']" />
        <img v-else :src="$svg['i-0041-FF0000-B']" />
      </template>
      <img v-else :src="$svg['i-0041-A9A9A9']" />
    </ElRow>

    <!-- 站位框 -->
    <div style="flex-grow: 1" />

    <!-- 移动下划线 -->
    <div v-if="!!style" :style="style" class="hrx" />
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    page: undefined, // 配置被选中的项目
    style: undefined, // 下划线样式
    type: undefined,
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {
    this.UseComprehensive();
  },

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 点击事件
    click(index) {
      this.page = index; // 记录选中的页签
      const box = this.$refs["tab-box"].getBoundingClientRect();
      const tab = this.$refs["tab" + index].$el.getBoundingClientRect();

      // 拼接样式
      this.style = {
        left: tab.x - box.x - 4 + "px",
        width: tab.width + 8 + "px",
      };
    },

    // 默认
    UseComprehensive() {
      this.Api.NeedsList.UseComprehensive().then((_) => {
        this.type = undefined;
        this.click(0);
      });
    },

    // 热度
    SetHeat() {
      this.type = this.page === 1 ? !this.type : true;
      this.Api.NeedsList.SetHeat(this.type).then((_) => {
        this.click(1);
      });
    },

    // 时间
    SetTime() {
      this.type = this.page === 2 ? !this.type : true;
      this.Api.NeedsList.SetTime(this.type).then((_) => {
        this.click(2);
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.tab-box-in {
  // 内部容器
  position: relative;
  margin: 20px 0;
  display: flex;
  width: 1200px;
  height: 24px;

  .tab {
    // 页签
    color: rgba(169, 169, 169, 1);
    align-items: center;
    margin-left: 8px;
    font-size: 14px;
    cursor: pointer;

    img {
      height: 1em;
      width: 1em;
    }
  }

  .tab + .tab {
    margin-left: 68px;
  }

  .act,
  .tab:hover {
    font-weight: bold;
    color: red;
  }

  .hrx {
    // 移动下划线
    transition: width var(--base-transition), left var(--base-transition);
    background-color: red;
    position: absolute;
    height: 2px;
    bottom: 0;
  }
}
</style>