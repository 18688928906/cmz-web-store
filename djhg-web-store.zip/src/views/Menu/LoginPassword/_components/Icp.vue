<template>
  <ElRow class="icp">
    <div>增值电信业务经营许可证：粤B2-20220737</div>
    <div>© {{ $hostname }} 版权所有</div>
    <div>粤ICP备2021084699号-5</div>
  </ElRow>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.icp {
  align-items: center;
  position: absolute;
  bottom: 20px;

  div {
    color: rgba(199, 199, 199, 1);
    line-height: 12px;
    font-size: 12px;
  }

  div + div {
    margin-left: 20px;
  }
}
</style>