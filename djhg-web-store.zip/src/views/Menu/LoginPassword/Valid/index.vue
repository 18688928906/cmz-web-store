<template>
  <ElRow class="page-box">
    <!-- 图标 -->
    <Logo style="font-size: 60px" />

    <!-- 标题 -->
    <div class="label">参谋者身份验证</div>

    <!-- 提示 -->
    <div class="tips1">短信验证码发送至{{ phone }}</div>

    <!-- 提示 -->
    <div class="tips2">请输入收到的短信验证码进行身份验证</div>

    <!-- 按钮容器 -->
    <ElRow class="valid-box">
      <ElInput v-model="valid" placeholder="请输入验证码" />
      <ElButton
        :disabled="!phone || time > 0"
        type="primary"
        @click="GetCode()"
      >
        {{ time > 0 ? `${time}s` : "获取验证码" }}
      </ElButton>
    </ElRow>

    <!-- 原密码 -->
    <ElInput
      v-model="password"
      placeholder="原密码"
      class="password"
      type="password"
      show-password
    />

    <!-- 下一步按钮 -->
    <ElButton type="primary" class="next" :disabled="!valid" @click="next()">
      下一步
    </ElButton>

    <!-- 提示 -->
    <ElRow class="tips3">
      <div>问</div>
      <div>为什么收不到短信验证码？</div>
    </ElRow>

    <!-- 提示 -->
    <ElRow class="tips4">
      <div>答</div>
      <div>
        请检查手机网络通讯是否正常并核实手机是否屏蔽系统短信，都正常还请重新获取或稍后再试
      </div>
    </ElRow>

    <!-- 备案信息 -->
    <Icp />
  </ElRow>
</template>

<script>
import Icp from "../_components/Icp.vue";

export default {
  // 自动路由参数
  meta: {
    title: undefined, // 写入浏览器页签
    index: undefined, // 用于排序
    label: "验证码", // 显示用的路由名称
    name: undefined, // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(true), // 控制页面是否需要登录
  },

  // 组件
  components: { Icp },

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    phone: "", // 手机号
    valid: "", // 验证码
    password: "", // 原密码

    timeout: Number(0), // 倒计时目标时间
    time: Number(0), // 倒计时
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.phone = this.Api.UserInfo.HideUserPhone(window?.$USER$?.Phone);
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 获取验证码
    GetCode() {
      this.timeout = new Date().getTime() + 120 * 1000;
      this.Api.UserPasswordValid.GetDate();
      this.QUEUE.Valid = (unix) => {
        this.time = Math.floor((this.timeout - unix) / 1000);
        if (this.time <= 0) {
          this.timeout = this.time = 0;
          delete this.QUEUE.Valid; // 销毁订阅
        }
      };
    },

    // 校验验证码
    next() {
      let data = { Password: this.password, Code: this.valid };
      this.Api.UserPasswordCheck.init(data)
        .GetCode()
        .then((_) => this.$GO({ path: "/menu/loginpassword/set", data }));
    },
  },
};
</script>

<style lang="scss" scoped>
.page-box {
  // 页面容器
  justify-content: center;
  flex-direction: column;
  align-items: center;
  flex-wrap: nowrap;
  height: 100%;
  width: 100%;

  .label {
    // 标题
    line-height: 26px;
    margin-top: 10px;
    font-size: 18px;
  }

  .tips1 {
    // 提示1
    color: rgba(206, 206, 206, 1);
    line-height: 16px;
    margin-top: 30px;
    font-size: 12px;
  }

  .tips2 {
    // 提示2
    color: rgba(206, 206, 206, 1);
    line-height: 16px;
    margin-top: 4px;
    font-size: 12px;
  }

  .valid-box {
    // 按钮容器
    flex-wrap: nowrap;
    margin-top: 32px;
    width: 310px;

    .el-input {
      // 输入框覆盖
      height: 36px;
      flex-grow: 1;
    }

    .el-button {
      // 按钮覆盖
      margin-left: 10px;
      flex-shrink: 0;
      height: 36px;
      width: 100px;
    }
  }

  .password {
    // 原密码
    margin-top: 20px;
    height: 36px;
    width: 310px;
  }

  .next {
    // 下一步
    --el-color-primary-light-5: rgba(187, 187, 187, 1);
    margin-top: 30px;
    height: 36px;
    width: 310px;
  }

  .tips3 {
    // 提示3
    flex-wrap: nowrap;
    margin-top: 20px;
    width: 310px;

    div {
      color: rgba(206, 206, 206, 1);
      line-height: 16px;
      font-size: 12px;
      flex-shrink: 0;
    }

    div + div {
      margin-left: 4px;
      flex-grow: 1;
    }
  }

  .tips4 {
    // 提示4
    flex-wrap: nowrap;
    margin-top: 10px;
    width: 310px;

    div {
      color: rgba(206, 206, 206, 1);
      line-height: 16px;
      font-size: 12px;
      flex-shrink: 0;
    }

    div + div {
      word-break: break-all;
      margin-left: 4px;
      flex-grow: 1;
      width: 0;
    }
  }
}
</style>