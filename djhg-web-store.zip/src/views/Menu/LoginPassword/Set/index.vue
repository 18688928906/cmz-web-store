<template>
  <ElRow class="page-box">
    <!-- 图标 -->
    <Logo style="font-size: 60px" />

    <!-- 标题 -->
    <div class="label">修改密码</div>

    <!-- 密码A -->
    <ElInput
      v-model="passwordA"
      :maxlength="16"
      oninput="this.value=this.value.replace(/[\u4e00-\u9fa5]/g,'')"
      class="passwordA"
      placeholder="密码"
      @blur="CheckA()"
    />

    <ElRow class="tips">
      <template v-if="type">
        <img :src="$svg['i-0027-D9D9D9']" />
        <div class="A">
          密码由8~16位数字、字母、符号组成，密码至少包含两种以上组合，区分大小写
        </div>
      </template>

      <template v-else>
        <img :src="$svg['i-0027-FF0000']" />
        <div class="B">
          请将密码设置为8~16位并包含数字、字母、符号两种以上字符包含两种以上组合，区分大小写
        </div>
      </template>
    </ElRow>

    <!-- 密码B -->
    <ElInput
      v-model="passwordB"
      :maxlength="16"
      class="passwordB"
      placeholder="确认密码"
    />

    <!-- 下一步按钮 -->
    <ElButton
      type="primary"
      class="next"
      :disabled="passwordA === '' || passwordA !== passwordB"
      @click="next()"
    >
      下一步
    </ElButton>

    <!-- 备案信息 -->
    <Icp />
  </ElRow>
</template>

<script>
import Icp from "../_components/Icp.vue";
import { passwordB } from "@/tool-library/_modules/verify.js";

export default {
  // 自动路由参数
  meta: {
    title: undefined, // 写入浏览器页签
    index: undefined, // 用于排序
    label: "验证码", // 显示用的路由名称
    name: undefined, // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(true), // 控制页面是否需要登录
  },

  // 组件
  components: { Icp },

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    passwordA: "", // 密码
    passwordB: "", // 确认密码
    type: true,
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 检查密码A
    CheckA() {
      this.type = passwordB(this.passwordA);
    },

    // 校验验证码
    next() {
      let data = this.query;
      data.Password = this.passwordA;

      this.Api.UserPasswordAdd.init(data)
        .SetDate()
        .then((_) => {
          ElMessage({
            message: "登录密码修改成功",
            showClose: true,
            grouping: true,
            type: "success",
          });
          this.Api.UserLogin.Quit();
          this.$GO({ path: "/login/account" });
        });
    },
  },
};
</script>

<style lang="scss" scoped>
.page-box {
  // 页面容器
  justify-content: center;
  flex-direction: column;
  align-items: center;
  flex-wrap: nowrap;
  height: 100%;
  width: 100%;

  .label {
    // 标题
    line-height: 26px;
    margin-top: 10px;
    font-size: 18px;
  }

  .passwordA {
    margin-top: 28px;
    height: 36px;
    width: 310px;
  }

  .passwordB {
    margin-top: 20px;
    height: 36px;
    width: 310px;
  }

  .tips {
    // 提示
    flex-wrap: nowrap;
    margin-top: 6px;
    width: 310px;

    img {
      margin-right: 4px;
      height: 16px;
      width: 16px;
    }

    .A {
      color: rgba(187, 187, 187, 1);
      line-height: 16px;
      font-size: 12px;
    }

    .B {
      color: rgba(255, 0, 0, 1);
      line-height: 16px;
      font-size: 12px;
    }
  }

  .next {
    // 下一步
    --el-color-primary-light-5: rgba(187, 187, 187, 1);
    margin-top: 30px;
    height: 36px;
    width: 310px;
  }
}
</style>