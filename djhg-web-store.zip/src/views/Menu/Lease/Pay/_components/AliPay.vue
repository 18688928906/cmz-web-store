<template>
  <div class="ali-box">
    <iframe
      :srcdoc="src"
      frameborder="no"
      border="0"
      marginwidth="0"
      marginheight="0"
      scrolling="no"
      width="300"
      height="300"
      style="overflow: hidden"
    />
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: { query: undefined, detail: undefined },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    src: undefined,
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.Api.OrderPay.init({
      Code: this.query.Code,
      OrderType: 20, // this.detail.Type,
      PayType: 1,
    })
      .SetData()
      .then(($) => {
        this.src = $.data;

        // 订阅心跳，轮询支付状态
        this.QUEUE["_Check_Pay_"] = () => {
          this.Api.OrderCheck.GetData(this.query.Code).then((data) => {
            // 检查是否支付成功
            if (data._code === 200 && !data["2500"]) {
              delete this.QUEUE["_Check_Pay_"]; // 取消订阅
              this.$GO({
                name: "LeaseOrderDetail",
                data: { Id: this.query.Id },
              }); // 支付成功跳转订单详情界面
              window.close(); // 关闭界面
            }
          });
        };
      });
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    delete this.QUEUE["_Check_Pay_"]; // 取消订阅
  },

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.ali-box {
  box-shadow: 0px 4px 16px 0px rgba(0, 0, 0, 0.1);
  box-sizing: border-box;
  border-radius: 4px;
  position: relative;
  margin-top: 20px;
  padding: 10px;
  display: flex;
  flex-grow: 1;
  width: 100%;

  iframe {
    transform: translate(-50%, -50%);
    position: absolute;
    height: 170px;
    width: 170px;
    left: 50%;
    top: 50%;
  }
}
</style>