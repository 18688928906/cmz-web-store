<template>
  <div class="select-box">
    <div class="select" @click="change(null, 1)">
      <ElCheckbox v-model="check[1]" @change="change($event, 1)" />
      <img :src="list[0]" />
    </div>

    <div class="select" @click="change(null, 2)">
      <ElCheckbox v-model="check[2]" @change="change($event, 2)" />
      <img :src="list[1]" />
    </div>

    <div class="select" @click="change(null, 3)">
      <ElCheckbox v-model="check[3]" @change="change($event, 3)" />
      <span>钱包支付(测试)</span>
    </div>
  </div>

  <ElRow class="button-box">
    <ElButton type="danger" size="large" @click="SetType()">立即支付</ElButton>
  </ElRow>
</template>

<script>
import ali from "@/assets/支付/支付宝.png";
import weixin from "@/assets/支付/微信.png";

export default {
  // 组件
  components: {},

  // 接收参数
  props: { type: undefined },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    list: [ali, weixin],
    check: [false, false, false, false],
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 选择
    change(_, $) {
      this.check = this.check.map((item, index) => index === $);
    },

    // 返回类型
    SetType() {
      var type = this.check.findIndex(($) => $);
      type > 0 && this.$emit("update:type", type);
    },
  },
};
</script>

<style lang="scss" scoped>
.select-box {
  box-shadow: 0px 4px 16px 0px rgba(0, 0, 0, 0.1);
  flex-direction: column;
  box-sizing: border-box;
  align-items: stretch;
  border-radius: 4px;
  margin-top: 20px;
  padding: 20px;
  display: flex;
  flex-grow: 1;
  width: 100%;

  div {
    border-bottom: 1px solid rgba(236, 236, 236, 1);
    box-sizing: border-box;
    align-items: center;
    padding-left: 10px;
    cursor: pointer;
    display: flex;
    height: 52px;

    .el-checkbox {
      margin-right: 10px;
    }

    img {
      height: 32px;
    }
  }
}

.button-box {
  justify-content: center;
  margin-top: 20px;

  .el-button {
    --el-color-danger: red;
    width: 200px;
  }
}
</style>