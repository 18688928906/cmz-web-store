<template>
  <ScrollBar v-if="!!detail">
    <TopBar label="收银台" />

    <!-- 页面容器 -->
    <ElRow class="page-box">
      <!-- 时间显示 -->
      <div class="time-box">
        <div class="L">
          <div class="title">{{ title }}</div>
          <div v-if="tips">
            请您在
            <span>{{ tips }}</span>
            内完成支付，超时将自动取消订单
          </div>
        </div>
        <div class="R">
          应付金额
          <span>￥</span>
          <span>{{ detail.Money }}</span>
          元
        </div>
      </div>

      <div class="code-box">
        <div class="info">
          <div>订单号：{{ detail.Code }}</div>
          <div>下单时间：{{ detail.CreateTime }}</div>
        </div>

        <!-- 选择支付方式 -->
        <PaySelect v-if="type === 0" v-model:type="type" />

        <!-- 支付宝支付 -->
        <AliPya v-if="type === 1" :detail="detail" :query="query" />

        <!-- 钱包支付 -->
        <Purse v-if="DEV && type === 3" :detail="detail" :query="query" />
      </div>
    </ElRow>
  </ScrollBar>
</template>

<script>
import PaySelect from "./_components/Select.vue";
import AliPya from "./_components/AliPay.vue";
import Purse from "./_components/Purse.vue";

export default {
  // 自动路由参数，配置看App.vue
  meta: {
    title: undefined, // 写入浏览器页签
    index: undefined, // 用于排序
    label: undefined, // 显示用的路由名称
    name: "PayLease", // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(false), // 控制是否需要登录
  },

  // 组件
  components: { PaySelect, AliPya, Purse },

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    detail: undefined,
    tips: undefined,

    title: "订单已创建成功，请在规定时间内付款！",

    date: 0, // 记录时间
    time: 0,
    type: 0,
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 获取订单详情
    this.Api.LeaseOrderDetail.init(this.query)
      .GetData()
      .then((detail) => {
        this.detail = detail;

        // 非支付订单跳转订单详情
        if (detail.Status.Type !== 1) {
          this.$GO({
            name: "LeaseOrderDetail",
            data: { Id: this.query.Id },
          });
        }

        // 检查倒计时
        else if (((this.time = detail.TimeOut), this.time) > 0) {
          this.date = ~~(new Date().getTime() / 1000) + this.time;
          this.PayTimeOut().QUEUE[this.detail.Code] = (unix) => {
            this.time = this.date - ~~(unix / 1000);
            this.PayTimeOut();
          };
        }
      });
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    this.PayTimeOut(true); // 取消订阅
  },

  // 组件方法
  methods: {
    PayTimeOut(close = false) {
      // 创建时间
      if (this.time > 0 && !close) {
        this.tips = this.TimeConversion(this.time);
      }

      // 支付过期取消订阅
      else {
        this.time = 0;
        delete this.QUEUE[this.detail.Code];
        this.title = "您的支付已过期，请重新下单";
      }

      return this; // 链式
    },
  },
};
</script>

<style lang="scss" scoped>
.page-box {
  // 页面容器
  box-shadow: 0px 4px 8px 0px rgba(0, 0, 0, 0.1);
  background-color: white;
  border-radius: 4px;
  margin-top: 20px;
  padding: 20px;
  width: 1200px;

  .time-box {
    background-color: rgba(255, 247, 232, 1);
    box-sizing: border-box;
    align-items: center;
    padding: 18px 20px;
    display: flex;
    width: 1200px;

    .L {
      flex-grow: 1;

      .title {
        line-height: 24px;
        font-size: 16px;
      }

      .title + div {
        color: rgba(100, 100, 100, 1);
        line-height: 17px;
        margin-top: 8px;
        font-size: 12px;

        span {
          color: red;
        }
      }
    }

    .R {
      align-items: baseline;
      font-size: 12px;
      display: flex;

      span {
        color: red;
      }

      span + span {
        font-size: 1.5em;
      }
    }
  }

  .code-box {
    background-color: rgba(255, 255, 255, 1);
    flex-direction: column;
    box-sizing: border-box;
    position: relative;
    margin-top: 16px;
    display: flex;
    height: 490px;
    width: 1200px;

    .info {
      align-items: center;
      padding-left: 20px;
      flex-shrink: 0;
      display: flex;

      div {
        font-size: 12px;
      }

      div + div {
        margin-left: 48px;
      }
    }
  }
}
</style>