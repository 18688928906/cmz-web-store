<template>
  <ScrollBar v-if="!!Detail">
    <!-- 开发信息 -->
    <div v-if="DEV" class="DEV" style="left: 0">ID：{{ query.Id }}</div>

    <!-- 顶栏 -->
    <TopBar label="结算页" />

    <!-- 内容容器 -->
    <div class="page-box">
      <template v-if="Single">
        <!-- 提交 -->
        <Submit :single="Single" :detail="Detail" :pickup="pickup" />

        <!-- 商品清单 -->
        <Manifest :single="Single" />
      </template>

      <!-- 运输方式 -->
      <Transport
        v-model:pickup="pickup"
        :address="Single?.Address"
        :detail="Detail"
      />

      <!-- 地址选着器 -->
      <Address :detail="Detail" />
    </div>
  </ScrollBar>
</template>

<script>
import Address from "./_components/Address.vue";
import Transport from "./_components/Transport.vue";
import Manifest from "./_components/Manifest.vue";
import Submit from "./_components/Submit.vue";

/**
 * 购买商品结算页
 */
export default {
  // 自动路由参数，配置看App.vue
  meta: {
    title: undefined, // 写入浏览器页签
    index: undefined, // 用于排序
    label: undefined, // 显示用的路由名称
    name: "LeaseBuy", // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(false), // 控制是否需要登录
  },

  // 组件
  components: { Address, Transport, Manifest, Submit },

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {
    // 是否自提
    pickup: {
      get() {
        return this._pickup;
      },
      set(value) {
        this._pickup = value;
        this.BUS["LeaseSettlementSingle"]();
      },
    },
  },

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    Detail: undefined, // 商品信息

    Single: undefined, // 结算信息

    _pickup: false,
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 订阅数据更新
    this.BUS["LeaseSettlementSingle"] = () => {
      var data = { ...this.query }; // 拷贝一份
      data.Address = this.Detail?.Address?.Id; // 抽取默认地址
      data.Pickup = this.Pickup ? 1 : 0;

      // 直接初始化接口并获取参数
      this.Api.LeaseSettlementSingle.init(data)
        .SetData()
        .then(($) => (this.Single = $));
    };

    // 获取商品详情
    this.Api.LeaseDetail.init(this.query.Id)
      .GetData()
      .then(($) => (this.Detail = $));
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    delete this.BUS["LeaseSettlementSingle"];
  },

  // 生命周期函数：离开后调用
  unmounted() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.page-box {
  // 界面容器
  flex-direction: column-reverse;
  align-items: stretch;
  margin-top: 20px;
  display: flex;
  width: 1200px;
}
</style>