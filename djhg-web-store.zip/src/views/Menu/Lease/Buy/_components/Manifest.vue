<template>
  <table class="manifest-box" border="0" cellspacing="0" cellpadding="0">
    <!-- 表头 -->
    <tr style="height: 45px">
      <th style="text-align: left">商品清单</th>
      <th :width="width">日租金（元/天）</th>
      <th :width="width">租赁天数</th>
      <th :width="width">数量</th>
      <th :width="width">优惠</th>
      <th :width="width">小计</th>
    </tr>

    <template v-for="(store, index) in single.Store" :key="index">
      <!-- 店铺信息 -->
      <tr>
        <td colspan="5">
          <div class="store-box">{{ store.Name }}</div>
        </td>
      </tr>

      <!-- 店铺下清单 -->
      <template v-for="item in store.List" :key="item.Id">
        <!-- 商品信息 -->
        <tr>
          <td>
            <!-- 详细信息 -->
            <div class="item-info">
              <ElImage class="logo" :src="item.Img" fit="contain" />
              <div class="info">
                <div class="name-box">
                  <span class="tag">租赁</span>
                  <span class="name">{{ item.Name }}</span>
                </div>

                <div class="sku">{{ item.Sku }}</div>
              </div>
            </div>
          </td>
          <td>{{ item.Currency }}{{ item.Price }}</td>
          <td>{{ item.Term }}</td>
          <td>{{ item.Quantity }}</td>
          <td>{{ item.Currency }}{{ item.Discount }}</td>
          <td style="color: red">{{ item.Currency }}{{ item.Pay }}</td>
        </tr>

        <!-- 备注 -->
        <tr>
          <td colspan="5">
            <div class="remark">
              留言：
              <ElInput
                v-model="item.Remark"
                :maxlength="100"
                placeholder="请先与商家沟通好，以防商家没有看到留言信息"
                style="width: 565px"
                show-word-limit
              />
            </div>
          </td>
        </tr>
      </template>
    </template>
  </table>
</template>

<script>
/**
 * 清单列表
 */
export default {
  // 组件
  components: {},

  // 接收参数
  props: { single: undefined },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    width: 150, // 表头宽度
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.manifest-box {
  // 地址容器
  box-shadow: var(--base-shadow);
  background-color: white;
  margin-top: 20px;

  th {
    border-bottom: 1px solid rgb(238, 238, 238);
    font-weight: normal;
    font-size: 14px;
    padding: 0 20px;
  }

  td {
    text-align: center;
    font-size: 14px;

    .store-box {
      // 店铺容器
      align-items: center;
      padding: 15px 20px;
      font-size: 14px;
      display: flex;
    }

    .item-info {
      // 详细信息
      align-items: flex-start;
      text-align: left;
      display: flex;

      .logo {
        // 图标
        border-radius: 2px;
        flex-shrink: 0;
        margin: 0 20px;
        height: 94px;
        width: 94px;
      }

      .info {
        // 详情
        flex-direction: column;
        align-items: stretch;
        display: flex;
        flex-grow: 1;

        .name-box {
          // 商品名称
          word-break: break-all;
          line-height: 16px;
          text-align: left;

          .tag {
            // 商品类型标签
            background-color: rgba(42, 178, 255, 1);
            transform: translateY(-2px);
            display: inline-block;
            border-radius: 4px;
            margin-right: 10px;
            text-align: center;
            line-height: 16px;
            font-size: 12px;
            flex-shrink: 0;
            color: white;
            height: 16px;
            width: 36px;
          }

          .name {
            // 名称
            font-size: 16px;
          }
        }

        .sku {
          // 规格
          color: rgba(153, 153, 153, 1);
          line-height: 16px;
          margin-top: 10px;
          font-size: 14px;
        }
      }
    }

    .remark {
      align-items: center;
      padding: 12px 20px;
      display: flex;
    }
  }
}
</style>