<template>
  <div class="address-box">
    <!-- 标题栏 -->
    <ElRow class="label-box">
      <div class="label">收货地址</div>
      <div class="more" @click="SetAddress()">
        <span>更多</span>
        <img class="A" :src="$svg['i-0001-999999']" />
        <img class="B" :src="$svg['i-0001-FF0000']" />
      </div>
    </ElRow>

    <!-- 地址栏 -->
    <ElRow class="address-list">
      <!-- 显示收货地址 -->
      <div class="address">
        <template v-if="_Address">
          <ElRow class="A">
            <div v-if="_Address.Default" class="default">默认</div>
            <div class="name">{{ _Address.Name }}</div>
            <div class="phone">{{ HidePhone(_Address.Phone) }}</div>
            <div class="button" @click="RevAddress()">编辑</div>
            <div
              v-if="!_Address.Default && List.length > 1"
              class="button"
              @click="DelAddress()"
            >
              删除
            </div>
          </ElRow>
          <div class="B">
            {{ _Address.Ext }}
            {{ _Address.Address }}
          </div>
        </template>
      </div>

      <!-- 添加新地址 -->
      <ElRow class="add" @click="BUS.OpenAddAddress()">
        <img class="A" :src="$svg['i-0019-D9D9D9']" />
        <img class="B" :src="$svg['i-0019-FF0000']" />
        <span>添加新地址</span>
      </ElRow>
    </ElRow>
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: { detail: undefined },

  // 计算属性
  computed: {
    // 处理地址
    Address: {
      get() {
        return this._Address;
      },
      set(value) {
        this._Address = this.detail.Address = value;
        this.BUS.LeaseSettlementSingle();
      },
    },
  },

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    List: Array(0), // 用户地址

    _Address: undefined, // 被选中的地址
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {
    this.Api.AddressUserList.AddUpdate("LeaseBuy", (list) => {
      this.List = list;
      this.Address = list.find(($) => $.Default) || list[0]; // 获取默认地址
    })
      .GetData(true)
      .then((list) => {
        (list?.length || 0) <= 0 && this.BUS.OpenAddAddress(true); // 没有地址自动弹出新建选框
      });
  },

  // 生命周期函数：离开前调用
  beforeUnmount() {
    this.Api.AddressUserList.DelUpdate("LeaseBuy");
  },

  // 组件方法
  methods: {
    // 编辑地址
    RevAddress() {
      this.BUS.OpenAddAddress(this._Address.Default, this._Address.Id);
    },

    // 删除地址
    DelAddress() {
      this.Api.AddressUserList.DelAddress(this.detail.Id);
    },

    // 打开选择地址框
    SetAddress() {
      this.BUS.OpenAddressList().then(($) => {
        this.Address = $;
        this.BUS.LeaseSettlementSingle();
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.address-box {
  // 地址容器
  box-shadow: var(--base-shadow);
  background-color: white;
  flex-direction: column;
  display: flex;

  .label-box {
    // 标题栏
    border-bottom: 1px solid rgba(238, 238, 238, 1);
    align-items: center;
    padding: 10px 20px;

    .label {
      font-size: 14px;
      flex-grow: 1;
    }

    .more {
      // 更多
      transition: color var(--base-transition);
      color: rgba(153, 153, 153, 1);
      align-items: center;
      font-size: 12px;
      cursor: pointer;
      display: flex;

      img {
        height: 14px;
        width: 14px;
      }

      .A {
        display: block;
      }

      .B {
        display: none;
      }
    }

    .more:hover {
      color: red;

      .A {
        display: none;
      }

      .B {
        display: block;
      }
    }
  }

  .address-list {
    // 地址列表容器
    justify-content: space-between;
    padding: 20px;

    .address,
    .add {
      border-radius: 4px;
      width: calc((100% - 20px) / 2);
      height: 90px;
    }

    .address {
      // 展示地址
      background-color: rgba(249, 249, 249, 1);
      border: 1px solid rgba(249, 249, 249, 1);
      justify-content: space-between;
      flex-direction: column;
      align-items: stretch;
      display: flex;
      padding: 16px;

      .A {
        align-items: center;

        .default {
          // 默认标签
          background-color: red;
          border-radius: 2px;
          margin-right: 12px;
          padding: 4px 6px;
          font-size: 14px;
          color: white;
          flex-shrink: 0;
        }

        .name {
          // 收件人姓名
          text-overflow: ellipsis;
          white-space: nowrap;
          margin-right: 40px;
          overflow: hidden;
          font-size: 14px;
          display: block;
          flex-shrink: 0;
        }

        .phone {
          // 电话号码
          font-size: 14px;
          flex-grow: 1;
        }

        .button {
          // 控制按钮
          transition: color var(--base-transition);
          color: rgba(187, 187, 187, 0);
          font-size: 12px;
          cursor: pointer;
          flex-shrink: 0;

          &:hover {
            color: red !important;
          }
        }

        .button + .button {
          margin-left: 10px;
        }
      }

      .B {
        text-overflow: ellipsis;
        white-space: nowrap;
        overflow: hidden;
        font-size: 14px;
        display: block;
      }

      &:hover {
        .A {
          .button {
            color: rgba(187, 187, 187, 1);
          }
        }
      }
    }

    .add {
      // 添加按钮
      border: 1px solid rgba(187, 187, 187, 1);
      color: rgba(217, 217, 217, 1);
      justify-content: center;
      align-items: center;
      font-size: 18px;
      cursor: pointer;

      img {
        margin-right: 20px;
        height: 36px;
        width: 36px;
      }

      .A {
        display: block;
      }

      .B {
        display: none;
      }

      &:hover {
        border-color: red;
        color: red;

        .A {
          display: none;
        }

        .B {
          display: block;
        }
      }
    }
  }
}
</style>