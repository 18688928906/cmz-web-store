<template>
  <div class="transport-box">
    <!-- 标题栏 -->
    <ElRow class="label-box">
      <div class="label">配送方式</div>
      <div v-if="false" class="more">
        <span>更多</span>
        <img class="A" :src="$svg['i-0001-999999']" />
        <img class="B" :src="$svg['i-0001-FF0000']" />
      </div>
    </ElRow>

    <!-- 选择栏 -->
    <ElRow class="transport-list">
      <div
        class="button"
        :class="{ select: !pickup }"
        @click="$emit('update:pickup', false)"
      >
        快递配送
        <div v-if="!pickup" class="sku-set">
          <img :src="$svg['i-0021-FFFFFF']" />
        </div>
      </div>
      <div
        v-if="detail?.PickUp"
        :class="{ select: pickup }"
        class="button"
        @click="$emit('update:pickup', true)"
      >
        上门自提
        <div v-if="pickup" class="sku-set">
          <img :src="$svg['i-0021-FFFFFF']" />
        </div>
      </div>
    </ElRow>

    <ElRow v-if="pickup" class="address">
      {{ pickup ? "自提地址：" + address : address }}
    </ElRow>
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: { detail: undefined, pickup: undefined, address: undefined },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.transport-box {
  // 地址容器
  box-shadow: var(--base-shadow);
  background-color: white;
  flex-direction: column;
  margin-top: 20px;
  display: flex;

  .label-box {
    // 标题栏
    border-bottom: 1px solid rgba(238, 238, 238, 1);
    align-items: center;
    padding: 10px 20px;

    .label {
      font-size: 14px;
      flex-grow: 1;
    }

    .more {
      // 更多
      transition: color var(--base-transition);
      color: rgba(153, 153, 153, 1);
      align-items: center;
      font-size: 12px;
      cursor: pointer;
      display: flex;

      img {
        height: 14px;
        width: 14px;
      }

      .A {
        display: block;
      }

      .B {
        display: none;
      }
    }

    .more:hover {
      color: red;

      .A {
        display: none;
      }

      .B {
        display: block;
      }
    }
  }

  .transport-list {
    // 地址列表容器
    align-items: center;
    padding: 20px;

    .button {
      border: 1px solid rgba(221, 223, 225, 1);
      justify-content: center;
      align-items: center;
      border-radius: 4px;
      position: relative;
      font-size: 12px;
      cursor: pointer;
      display: flex;
      height: 32px;
      width: 106px;

      .sku-set {
        border-bottom-color: rgba(255, 0, 0, 1);
        border-right-color: rgba(255, 0, 0, 1);
        border-left-color: rgba(255, 0, 0, 0);
        border-top-color: rgba(255, 0, 0, 0);
        border-style: solid;
        position: absolute;
        border-width: 8px;
        height: 16px;
        width: 16px;
        bottom: 0;
        right: 0;

        img {
          position: absolute;
          bottom: -8px;
          right: -8px;
          height: 8px;
          width: 8px;
        }
      }
    }

    .button + .button {
      margin-left: 20px;
    }

    .select,
    .button:hover {
      // 规格鼠标移入和被选中
      border-color: rgba(241, 63, 64, 1);
      color: rgba(241, 63, 64, 1);
    }
  }

  .address {
    color: rgba(102, 102, 102, 1);
    padding: 0 20px 20px;
    font-size: 12px;
  }
}
</style>