<template>
  <!-- 提交容器表格 -->
  <table class="submit-box" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td class="label">商品总价：</td>
      <td :width="width">{{ single.Currency }}{{ single.Price }}</td>
    </tr>

    <tr>
      <td class="label">运费：</td>
      <td :width="width">{{ single.Currency }}{{ single.Freight }}</td>
    </tr>

    <tr>
      <td class="label">优惠：</td>
      <td :width="width">{{ single.Currency }}{{ single.Discount }}</td>
    </tr>

    <tr class="pay">
      <td>实付款：</td>
      <td :width="width">
        <span>{{ single.Currency }}</span>
        <span class="money">{{ single.Pay }}</span>
      </td>
    </tr>

    <tr>
      <td colspan="2" class="label">{{ single.Address }}</td>
    </tr>

    <tr>
      <td colspan="2">
        <div class="btb">
          <ElButton type="danger" @click="AddOrder()">提交订单</ElButton>
        </div>
      </td>
    </tr>
  </table>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: { single: undefined, detail: undefined, pickup: undefined },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    width: 90, // 控制宽度
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 创建订单
    AddOrder() {
      this.Api.LeaseOrderAdd.init({
        Code: this.detail.Code,
        Address: this.detail?.Address?.Id,
        Sku: this.single.Store[0].List[0].SkuId,
        Quantity: this.single.Store[0].List[0].Quantity,
        Remark: this.single.Store[0].List[0].Remark || "",
        PickUp: this.pickup ? 1 : 0,
        Term: this.single.Store[0].List[0].Term,
      })
        .SetData()
        .then((data) => this.$GO({ name: "PayLease", data }));
    },
  },
};
</script>

<style lang="scss" scoped>
.submit-box {
  // 提交容器
  box-shadow: var(--base-shadow);
  background-color: white;
  border-spacing: 10px;
  padding: 6px 10px;
  margin-top: 20px;
  width: 1200px;

  td {
    vertical-align: bottom;
    text-align: right;
    font-size: 12px;
  }

  .label {
    color: rgba(153, 153, 153, 1);
  }

  .pay {
    td {
      color: red;
    }

    .money {
      line-height: 1;
      font-size: 2em;
    }
  }

  .btb {
    // 按钮容器
    flex-direction: row-reverse;
    display: flex;

    .el-button {
      // 覆盖
      --el-color-danger: rgba(255, 0, 0, 1);
      height: 36px;
      width: 112px;
    }
  }
}
</style>