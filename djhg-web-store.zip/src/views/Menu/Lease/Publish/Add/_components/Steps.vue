<template>
  <ElSteps :active="active" finish-status="success" align-center>
    <ElStep v-for="$ in titles" :title="$" :key="$" />
  </ElSteps>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    active: 1, // 激活的项
    titles: ["选择请求类型", "填写相关信息", "发布完成"],
    key: "PublishNeedsSteps",
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.BUS[this.key] = (active) => (this.active = active); // 订阅激活信息
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    delete this.BUS[this.key]; // 关闭订阅
  },

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.el-steps {
  margin-top: 20px;
  width: 1000px;

  :deep(.is-process) {
    border-color: var(--el-text-color-placeholder);
    color: var(--el-text-color-placeholder);
    font-weight: normal;
  }
}
</style>