<template>
  <!-- 地址容器 -->
  <ElRow class="address-box">
    <!-- 详情容器 -->
    <ElRow class="info-box">
      <!-- 地址详情 -->
      <div class="box info">
        <template v-if="_Address">
          <ElRow class="A">
            <div v-if="_Address.Default" class="default">默认</div>
            <div class="name">{{ _Address.Name }}</div>
            <div class="phone">{{ HidePhone(_Address.Phone) }}</div>
            <div class="button" @click="RevAddress()">编辑</div>
            <div
              v-if="!_Address.Default && List.length > 1"
              class="button"
              @click="DelAddress()"
            >
              删除
            </div>
          </ElRow>
          <div class="B">所在地区：{{ _Address.Ext }}</div>
          <div class="B">所在地址：{{ _Address.Address }}</div>
        </template>
      </div>

      <!-- 添加新地址 -->
      <div class="box add" @click="BUS.OpenAddAddress()">
        <img :src="$svg['i-0019-D9D9D9']" alt="" />
        <span>添加新地址</span>
      </div>
    </ElRow>

    <!-- 标题容器 -->
    <ElRow class="title-box">
      <!-- 标题 -->
      <div class="title">退回地址</div>

      <!-- 按钮容器 -->
      <ElRow class="button-box" @click="SetAddress()">
        <span>更多</span>
        <img :src="$svg['i-0006-CCCCCC']" class="img" />
      </ElRow>
    </ElRow>
  </ElRow>
</template>

<script>
export default {
  // 自动路由参数
  meta: {
    title: undefined, // 写入浏览器页签
    index: undefined, // 用于排序
    label: undefined, // 显示用的路由名称
    name: undefined, // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(false), // 控制是否需要登录
  },

  // 组件
  components: {},

  // 接收参数
  props: {
    address: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {
    // 处理地址
    Address: {
      get() {
        return this._Address;
      },
      set(value) {
        this._Address = value;
        this.$emit("update:address", value);
      },
    },
  },

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    List: Array(0), // 用户地址

    _Address: undefined, // 被选中的地址
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.Api.AddressUserList.AddUpdate("LeasePublishAdd", (list) => {
      this.List = list;
      this.Address = list.find(($) => $.Default) || list[0]; // 获取默认地址
    })
      .GetData(true)
      .then((list) => {
        (list?.length || 0) <= 0 && this.BUS.OpenAddAddress(true); // 没有地址自动弹出新建选框
      });
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    this.Api.AddressUserList.DelUpdate("LeasePublishAdd");
  },

  // 组件方法
  methods: {
    // 编辑地址
    RevAddress() {
      this.BUS.OpenAddAddress(this._Address.Default, this._Address.Id);
    },

    // 删除地址
    DelAddress() {
      this.Api.AddressUserList.DelAddress(this.detail.Id);
    },

    // 打开选择地址框
    SetAddress() {
      this.BUS.OpenAddressList().then(($) => {
        this.Address = $;
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.address-box {
  // 地址容器
  flex-direction: column-reverse;
  align-items: stretch;
  width: 100%;

  .info-box {
    // 详情容器
    align-items: stretch;

    .box {
      // 容器
      box-shadow: 0px 4px 8px 0px rgba(0, 0, 0, 0.1);
      width: calc(50% - 20px);
      min-height: 120px;
    }

    .info {
      // 信息
      background-color: rgba(248, 248, 248, 1);
      justify-content: space-between;
      flex-direction: column;
      align-items: stretch;
      padding: 16px;
      display: flex;

      .A {
        align-items: center;

        .default {
          // 默认标签
          background-color: red;
          border-radius: 2px;
          margin-right: 1em;
          padding: 4px 6px;
          font-size: 14px;
          color: white;
          flex-shrink: 0;
        }

        .name {
          // 收件人姓名
          text-overflow: ellipsis;
          white-space: nowrap;
          margin-right: 1em;
          overflow: hidden;
          font-size: 14px;
          display: block;
          flex-shrink: 0;
        }

        .phone {
          // 电话号码
          font-size: 14px;
          flex-grow: 1;
        }

        .button {
          // 控制按钮
          transition: color var(--base-transition);
          color: rgba(187, 187, 187, 0);
          font-size: 12px;
          cursor: pointer;
          flex-shrink: 0;

          &:hover {
            color: red !important;
          }
        }

        .button + .button {
          margin-left: 10px;
        }
      }

      .B {
        text-overflow: ellipsis;
        white-space: nowrap;
        overflow: hidden;
        font-size: 14px;
        display: block;
      }

      &:hover {
        .A {
          .button {
            color: rgba(187, 187, 187, 1);
          }
        }
      }
    }

    .add {
      color: rgba(51, 51, 51, 0.4);
      justify-content: center;
      align-items: center;
      margin-left: 40px;
      font-size: 14px;
      cursor: pointer;
      display: flex;

      img {
        margin-right: 0.5em;
        height: 1.1em;
        width: 1.1em;
      }
    }
  }

  .title-box {
    // 标题容器
    justify-content: space-between;
    margin-bottom: 16px;
    align-items: center;

    .title {
      // 标题
      line-height: 16px;
      font-weight: bold;
      font-size: 14px;
    }

    .button-box {
      // 按钮容器
      align-items: center;
      font-size: 12px;
      cursor: pointer;

      .img {
        transition: all var(--base-transition);
        height: 1em;
        width: 1em;
      }

      &:hover {
        .img {
          transform: rotate(90deg);
        }
      }
    }
  }
}
</style>