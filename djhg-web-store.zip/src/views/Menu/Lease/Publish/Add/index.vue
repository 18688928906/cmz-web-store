<template>
  <ScrollBar>
    <!-- 顶栏 -->
    <TopBarB :label="$options.meta.label" />

    <!-- 表单 -->
    <ElForm
      :inline="true"
      :rules="rules"
      :model="form"
      label-position="top"
      ref="$"
      scroll-to-error
    >
      <!-- 上半容器 -->
      <ElRow class="page-box">
        <div class="title">商品信息</div>

        <!-- 商品分类 -->
        <ElFormItem
          label="商品分类"
          class="item-half"
          style="margin-right: 40px"
          prop="Category"
        >
          <ElCascader
            v-model="form.Category"
            :options="options"
            placeholder="请选择商品分类"
            style="width: 100%"
          />
        </ElFormItem>

        <!-- 商品标题 -->
        <ElFormItem label="商品标题" class="item-half" prop="Title">
          <ElInput
            v-model="form.Title"
            :maxlength="30"
            placeholder="请输入商品标题"
            show-word-limit
          />
        </ElFormItem>

        <!-- 详细简介 -->
        <ElFormItem label="详细简介" prop="Content">
          <ElInput
            v-model="form.Content"
            :maxlength="200"
            :rows="4"
            placeholder="请输入详细简介"
            type="textarea"
            resize="none"
            show-word-limit
          />
        </ElFormItem>

        <!-- 图片上传 -->
        <ElFormItem label="图片上传" prop="File">
          <Upload v-model:file="form.File" />
        </ElFormItem>

        <!-- 上传视频 -->
        <ElFormItem label="视频上传">
          <VideoU v-model:file="form.Video" />
        </ElFormItem>
      </ElRow>

      <!-- 中间容器 -->
      <ElRow class="page-box">
        <div class="title">价格</div>

        <!-- 日租金 -->
        <ElFormItem
          label="日租金(元/天)"
          class="item-half"
          style="margin-right: 40px"
          prop="Rent"
        >
          <ElInputNumber
            v-model="form.Rent"
            :controls="false"
            :precision="2"
            style="width: 100%"
            placeholder="请输入日租金"
          />
        </ElFormItem>

        <!-- 最低租期 -->
        <ElFormItem label="最低租期(天)" class="item-half" prop="Term">
          <ElInputNumber
            v-model="form.Term"
            :controls="false"
            :precision="0"
            style="width: 100%"
            placeholder="请输入最低租期"
          />
        </ElFormItem>

        <!-- 押金 -->
        <ElFormItem
          label="押金(元)"
          class="item-half"
          style="margin-right: 40px"
          prop="Deposit"
        >
          <ElInputNumber
            v-model="form.Deposit"
            :controls="false"
            :precision="2"
            style="width: 100%"
            placeholder="请输入押金"
          />
        </ElFormItem>

        <!-- 库存 -->
        <ElFormItem label="库存" class="item-half" prop="Inventory">
          <ElInputNumber
            v-model="form.Inventory"
            :controls="false"
            :precision="0"
            style="width: 100%"
            placeholder="请输入库存数量"
          />
        </ElFormItem>

        <ElFormItem label="运费">
          <div
            v-for="(item, index) in list"
            :class="{ select: index === form.Exp }"
            :key="index"
            class="sku-item"
            @click="form.Exp = index"
          >
            <span>{{ item }}</span>
            <div v-if="index === form.Exp" class="sku-set">
              <img :src="$svg['i-0021-FFFFFF']" />
            </div>
          </div>
        </ElFormItem>
      </ElRow>

      <!-- 下半容器 -->
      <ElRow class="page-box">
        <AddressBox v-model:address="form.Address" />
        <ElFormItem prop="Address" />

        <!-- 按钮容器 -->
        <ElRow class="button-box">
          <ElButton type="primary" @click="upload()">发布</ElButton>
        </ElRow>
      </ElRow>
    </ElForm>
  </ScrollBar>
</template>

<script>
import Upload from "./_components/Upload.vue";
import VideoU from "./_components/Video.vue";
import AddressBox from "./_components/AddressBox.vue";

export default {
  // 自动路由参数
  meta: {
    title: undefined, // 写入浏览器页签
    index: undefined, // 用于排序
    label: "出租发布", // 显示用的路由名称
    name: undefined, // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(false), // 控制是否需要登录
  },

  // 组件
  components: { Upload, VideoU, AddressBox },

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    options: undefined, // 选项
    list: ["包邮", "到付"],

    // 表单
    form: {
      Category: Array(0), // 商品分类
      Title: "", // 商品标题
      Content: "", // 详细简介
      File: Array(0), // 上传的图片文件
      Video: Array(0), // 上传视频
      Rent: undefined, // 租金
      Term: undefined, // 最低租期
      Deposit: undefined, // 押金
      Inventory: undefined, // 库存
      Exp: 0, // 物流方式
      Address: undefined,
    },

    // 校验
    rules: {
      Category: {
        type: "array",
        required: true,
        message: "商品分类不能为空",
        trigger: "change",
      },
      Title: [{ required: true, message: "商品标题不能为空", trigger: "blur" }],
      Content: [
        { required: true, message: "详细简介不能为空", trigger: "blur" },
      ],
      File: [
        {
          type: "array",
          required: true,
          message: "图片不能为空",
          trigger: "change",
        },
      ],
      Rent: [{ required: true, message: "租金不能为空", trigger: "blur" }],
      Term: [{ required: true, message: "最低租期不能为空", trigger: "blur" }],
      Deposit: [{ required: true, message: "押金不能为空", trigger: "blur" }],
      Inventory: [{ required: true, message: "库存不能为空", trigger: "blur" }],
      Address: [
        {
          validator: (_, value, callback) => {
            if (!!value) {
              callback();
            } else {
              callback(new Error("退回地址不能为空"));
            }
          },
          trigger: "blur",
        },
      ],
    },
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.Api.LeaseCategory.GetData().then(($) => (this.options = $));
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 上传数据
    upload() {
      this.$refs.$.validate().then(($) => {
        if ($) {
          var form = { ...this.form };
          form.Address = form.Address.Id; // 获取退回地址ID
          form.Img = form.File.map((item) => item.response.data.url).join(","); // 拼接图片链接
          form.Video = form.Video.map((item) => item.response.data.url).join(
            ","
          ); // 获取视频

          this.Api.PublishLeaseAdd.init(form)
            .SetData()
            .then(($) => {
              this.$GO({ name: "Home" });
            });
        }
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.el-form {
  // 表单样式覆盖
  flex-direction: column;
  align-items: stretch;
  width: 1200px;
  display: flex;

  .page-box {
    // 页面容器
    box-shadow: var(--base-shadow);
    background-color: white;
    padding: 20px 130px;
    border-radius: 4px;
    margin-top: 20px;

    .title {
      // 标题
      margin-bottom: 16px;
      line-height: 16px;
      font-weight: bold;
      font-size: 14px;
      width: 100%;
    }

    .el-form-item {
      // 覆盖样式
      margin-right: 0;
      width: 100%;

      .el-input-number {
        :deep(.el-input__inner) {
          text-align: left;
        }
      }

      .sku-item {
        // 规格选项
        transition: all var(--base-transition);
        border: 1px solid rgba(165, 164, 164, 1);
        color: rgba(112, 112, 112, 1);
        border-radius: 4px;
        margin-right: 20px;
        text-align: center;
        position: relative;
        line-height: 30px;
        font-size: 14px;
        cursor: pointer;
        height: 30px;
        width: 84px;

        .sku-set {
          border-bottom-color: var(--el-color-primary);
          border-right-color: var(--el-color-primary);
          border-left-color: rgba(255, 0, 0, 0);
          border-top-color: rgba(255, 0, 0, 0);
          border-style: solid;
          position: absolute;
          border-width: 8px;
          height: 16px;
          width: 16px;
          bottom: 0;
          right: 0;

          img {
            position: absolute;
            bottom: -8px;
            right: -8px;
            height: 8px;
            width: 8px;
          }
        }
      }

      .select,
      .sku-item:hover {
        // 规格鼠标移入和被选中
        border: 1px solid var(--el-color-primary);
        color: var(--el-color-primary);
      }
    }

    .item-half {
      width: calc(50% - 20px);
    }

    .button-box {
      // 按钮容器
      justify-content: center;
      margin-top: 40px;
      width: 100%;

      .el-button {
        width: 376px;
      }
    }
  }
}
</style>