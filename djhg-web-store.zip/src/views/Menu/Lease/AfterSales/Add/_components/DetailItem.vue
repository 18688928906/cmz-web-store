<template>
  <ElRow class="detail-item">
    <!-- 商品图 -->
    <img class="logo" :src="detail.Img" />

    <!-- 订单详情 -->
    <ElRow class="detail">
      <!-- 商品名称 -->
      <div class="name">{{ detail.Name }}</div>

      <!-- 规格 -->
      <div class="sku">{{ detail.Sku.join("，") }}</div>

      <!-- 价格 -->
      <ElRow class="price">
        <span>{{ detail.Currency }}</span>
        <span>{{ detail.Price }}</span>
      </ElRow>
    </ElRow>
  </ElRow>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: { detail: undefined },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.detail-item {
  // 订单详情
  align-items: flex-start;
  width: 100%;

  .logo {
    // 订单图
    border-radius: 4px;
    flex-shrink: 0;
    height: 80px;
    width: 80px;
  }

  .detail {
    // 订单详情
    justify-content: space-between;
    flex-direction: column;
    align-items: stretch;
    margin-left: 12px;
    min-height: 80px;
    flex-grow: 1;

    .name {
      // 商品名称
      color: var(--base-color);
      font-size: 14px;
      line-height: 1;
    }

    .sku {
      // 商品规格
      color: rgba(158, 158, 158, 1);
      font-size: 12px;
      line-height: 1;
    }

    .price {
      // 价格
      color: rgba(255, 0, 0, 1);
      align-items: baseline;
      font-size: 14px;
      line-height: 1;

      span + span {
        font-size: 20px;
      }
    }
  }
}
</style>