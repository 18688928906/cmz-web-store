<template>
  <ScrollBar v-if="detail" style="background-color: white">
    <!-- 顶栏 -->
    <TopBar :label="$options.meta.label" />

    <!-- 售后容器 -->
    <ElRow class="after-sales-box">
      <!-- 表单 -->
      <ElForm :model="form" :rules="rules" :label-width="90" ref="$">
        <!-- 订单详情 -->
        <ElFormItem label="退货商品" style="align-items: center">
          <DetailItem :detail="detail" />
        </ElFormItem>

        <!-- 退货退款，仅退款 -->
        <ElFormItem label="服务类型" prop="Type">
          <ElRow class="serve-box">
            <div
              v-for="(item, index) in serve"
              :class="{ select: form.Type === item.value }"
              :key="index"
              class="serve-item"
              @click="SetType(item.value)"
            >
              <span>{{ item.label }}</span>

              <!-- 选中时的标识 -->
              <div v-if="form.Type === item.value" class="serve-set">
                <img :src="$svg['i-0021-FFFFFF']" />
              </div>
            </div>
          </ElRow>
        </ElFormItem>

        <!-- 售后原因选择器 -->
        <ElFormItem label="售后原因" prop="ReasonId">
          <ElSelect
            v-model="form.ReasonId"
            placeholder="请选择售后原因"
            style="width: 260px"
          >
            <ElOption
              v-for="(item, index) in detail.Cause"
              :label="item.label"
              :value="item.value"
              :key="index"
            />
          </ElSelect>
        </ElFormItem>

        <!-- 仅显示 -->
        <ElFormItem label="退款金额">
          <ElRow class="price">
            <span>￥</span>
            <span>{{ detail.Price }}</span>
          </ElRow>
        </ElFormItem>

        <!-- 输入说明 -->
        <ElFormItem label="退款说明">
          <ElInput
            v-model="form.Remark"
            :maxlength="100"
            :rows="3"
            placeholder="请输入退款说明"
            style="width: 700px"
            type="textarea"
            resize="none"
            show-word-limit
          />
        </ElFormItem>

        <ElFormItem label="上传凭证">
          <Upload v-model:file="form.File" />
        </ElFormItem>
      </ElForm>

      <!-- 按钮容器 -->
      <ElRow class="button-box">
        <ElRow class="button" @click="upload()">提交</ElRow>
      </ElRow>
    </ElRow>
  </ScrollBar>
</template>

<script>
import DetailItem from "./_components/DetailItem.vue";
import Upload from "./_components/Upload.vue";

export default {
  // 自动路由参数，配置看App.vue
  meta: {
    title: undefined, // 写入浏览器页签
    index: undefined, // 用于排序
    label: "申请售后", // 显示用的路由名称
    name: "LeaseAfterSalesAdd", // 路由名称

    open: Boolean(true), // 是否在新页面中打开
    token: Boolean(false), // 控制是否需要登录
  },

  // 组件
  components: { DetailItem, Upload },

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    detail: undefined, // 申请详情
    serve: undefined, // 服务类型

    // 表单
    form: {
      Id: undefined, //
      Type: 1, // 服务类型
      Status: 0, // 是否收货
      ReasonId: undefined, // 退款原因
      Remark: "", // 退款说明
      File: Array(0), // 上传文件
    },

    // 校验
    rules: {
      Type: [
        {
          required: true,
          message: "请选择服务类型",
          trigger: "blur",
        },
      ],
      Status: [
        {
          required: true,
          message: "请选择服务类型",
          trigger: "blur",
        },
      ],
      ReasonId: [
        {
          required: true,
          message: "请选择售后原因",
          trigger: "blur",
        },
      ],
    },
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 获取订单详情
    this.Api.LeaseOrderAfterSalesApply.init(this.query)
      .AddUpdate("LeaseAfterSalesAdd", (detail) => {
        this.detail = detail;
        this.form.Id = detail.OrderId;
      })
      .GetData();

    // 设置服务类型
    this.serve = [
      { label: "退货退款", value: 1 },
      { label: "换货", value: 2 },
    ];

    this.form.Type = this.serve[0].value;
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    this.Api.LeaseOrderAfterSalesApply.DelUpdate("LeaseAfterSalesAdd"); // 取消订阅
  },

  // 组件方法
  methods: {
    // 上传数据
    upload() {
      this.$refs.$.validate().then(($) => {
        if ($) {
          var Form = { ...this.form }; // 拷贝数据
          Form.Price = Number(this.detail.Price); // 记录价格
          Form.Type === 1 && delete Form.Status; // 清除收货
          Form.Img = Form.File.map((item) => item.response.data.url).join(","); // 拼接图片链接

          // 获取售后原因
          Form.Reason = this.detail.Cause.find(
            (item) => item.value === Form.ReasonId
          ).label;

          // 申请售后
          this.Api.LeaseOrderAfterSalesAdd.init(Form)
            .SetData()
            .then((Id) =>
              this.$GO({ name: "LeaseAfterSalesDetail", data: { Id } })
            );
        }
      });
    },

    SetType(type) {
      this.form.Type = type;
      this.Api.LeaseOrderAfterSalesApply.SetType(type);
    },
  },
};
</script>

<style lang="scss" scoped>
.after-sales-box {
  // 售后容器
  box-shadow: var(--base-shadow);
  flex-direction: column;
  border-radius: 4px;
  margin-top: 20px;
  padding: 20px;
  width: 1200px;

  .serve-box {
    .serve-item {
      // 规格选项
      border: 1px solid rgba(165, 164, 164, 1);
      transition: all var(--base-transition);
      color: rgba(112, 112, 112, 1);
      justify-content: center;
      align-items: center;
      border-radius: 4px;
      margin-bottom: 8px;
      margin-right: 20px;
      position: relative;
      line-height: 30px;
      font-size: 14px;
      cursor: pointer;
      display: flex;
      height: 30px;
      width: 104px;

      .serve-set {
        border-bottom-color: rgba(255, 0, 0, 1);
        border-right-color: rgba(255, 0, 0, 1);
        border-left-color: rgba(255, 0, 0, 0);
        border-top-color: rgba(255, 0, 0, 0);
        border-style: solid;
        position: absolute;
        border-width: 8px;
        height: 16px;
        width: 16px;
        bottom: 0;
        right: 0;

        img {
          position: absolute;
          bottom: -8px;
          right: -8px;
          height: 8px;
          width: 8px;
        }
      }
    }

    .select,
    .serve-item:hover {
      // 规格鼠标移入和被选中
      border: 1px solid rgba(241, 63, 64, 1);
      color: rgba(241, 63, 64, 1);
    }
  }

  .price {
    // 价格展示
    align-items: baseline;
    font-size: 14px;
    color: red;

    span + span {
      font-size: 1.5em;
    }
  }

  .button-box {
    // 按钮容器
    justify-content: center;
    align-items: center;
    margin-top: 100px;

    .button {
      transition: all var(--base-transition);
      background-color: red;
      justify-content: center;
      align-items: center;
      border-radius: 4px;
      font-size: 16px;
      cursor: pointer;
      color: white;
      height: 44px;
      width: 320px;

      &:hover {
        background-color: var(--el-color-error);
      }
    }
  }
}
</style>