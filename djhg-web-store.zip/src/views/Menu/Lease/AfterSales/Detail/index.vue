<template>
  <ScrollBar v-if="detail">
    <!-- 顶栏 -->
    <TopBar :label="$options.meta.label" />

    <!-- 面包屑 -->
    <Breadcrumb />

    <!-- 订单状态（退货退款） -->
    <StatusA v-if="detail.Type === 2" :detail="detail" />
    <StatusB v-else-if="detail.Type === 1" :detail="detail" />

    <!-- 详情框 -->
    <ElRow class="detail-box">
      <!-- 左侧容器 -->
      <ElRow class="detail-box-left">
        <!-- 售后操作 -->
        <Operate :detail="detail" />

        <!-- 操作记录 -->
        <Logs :list="detail.Logs" />
      </ElRow>

      <!-- 右侧容器 -->
      <ElRow class="detail-box-right">
        <table cellspacing="0" cellpadding="0" border="0">
          <tr style="height: 48px">
            <td width="124">商品名称</td>
            <td>{{ detail.Product.map(($) => $.Name).join(",") }}</td>
          </tr>
          <tr style="height: 48px">
            <td width="124">订单编号</td>
            <td>{{ detail.OrderCode }}</td>
          </tr>
          <tr style="height: 48px">
            <td width="124">成交时间</td>
            <td>{{ detail.Time.Deal }}</td>
          </tr>
          <tr style="height: 48px">
            <td width="124">售后编号</td>
            <td>{{ detail.Code }}</td>
          </tr>
          <tr style="height: 48px">
            <td width="124">退款金额</td>
            <td>￥{{ detail.Money }}</td>
          </tr>
          <tr style="height: 48px">
            <td width="124">申请时间</td>
            <td>{{ detail.Time.Create }}</td>
          </tr>
          <tr style="height: 48px">
            <td width="124">售后类型</td>
            <td>{{ { 1: "仅退款", 2: "退货退款" }[detail.Type] }}</td>
          </tr>
          <tr style="height: 48px">
            <td width="124">申请原因</td>
            <td>{{ detail.Reason }}</td>
          </tr>
          <tr style="height: 48px">
            <td width="124">退款说明</td>
            <td>{{ detail.Remark }}</td>
          </tr>
        </table>
      </ElRow>
    </ElRow>
  </ScrollBar>
</template>

<script>
import Breadcrumb from "./_components/Breadcrumb.vue";
import StatusA from "./_components/StatusA.vue";
import StatusB from "./_components/StatusB.vue";
import Operate from "./_components/Operate.vue";
import Logs from "./_components/Logs.vue";

import Cancel from "./_components/PopUp/Cancel.vue";
import Reapply from "./_components/PopUp/Reapply.vue";
import ExpInfo from "./_components/PopUp/ExpInfo.vue";

export default {
  // 自动路由参数
  meta: {
    title: undefined, // 写入浏览器页签
    index: undefined, // 用于排序
    label: "售后详情", // 显示用的路由名称
    name: "LeaseAfterSalesDetail", // 路由名称

    open: Boolean(true), // 是否在新页面中打开
    token: Boolean(false), // 控制是否需要登录
  },

  // 组件
  components: { Breadcrumb, StatusA, StatusB, Operate, Logs },

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    detail: undefined,
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 获取售后详情
    this.Api.LeaseOrderAfterSalesDetail.init(this.query)
      .AddUpdate("LeaseAfterSalesDetail", (detail) => (this.detail = detail))
      .GetData();

    // 挂载弹出框
    this.BUS.AddPopUp("Cancel", Cancel);
    this.BUS.AddPopUp("Reapply", Reapply);
    this.BUS.AddPopUp("ExpInfo", ExpInfo);
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    this.Api.LeaseOrderAfterSalesDetail.DelUpdate("LeaseAfterSalesDetail"); // 取消订阅

    // 卸载弹出框
    this.BUS.DelPopUp("Cancel");
    this.BUS.DelPopUp("Reapply");
    this.BUS.DelPopUp("ExpInfo");
  },

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.detail-box {
  // 详情容器
  align-items: stretch;
  flex-wrap: nowrap;
  margin-top: 16px;
  width: 1200px;

  .detail-box-left {
    // 左侧
    flex-direction: column;
    align-items: stretch;
    flex-shrink: 0;
    width: 640px;
  }

  .detail-box-right {
    // 右侧
    background-color: white;
    align-items: flex-start;
    margin-left: 16px;
    padding: 16px;
    flex-grow: 1;

    table {
      border-collapse: collapse;
      width: 100%;

      td {
        border: 1px solid rgba(200, 200, 200, 1);
        word-break: break-all;
        padding-left: 4px;
      }
    }
  }
}
</style>