<template>
  <ElRow class="operate-box">
    <!-- 标题容器 -->
    <div class="title-box">
      {{ detail.Status.Title(status) }}
    </div>

    <!-- 提示容器 -->
    <div class="tips-box">
      <!-- 处理关闭和退款完成 -->
      <span v-if="status === 0 || status === 3">
        {{ detail.Status.Tips(status) }}
      </span>

      <!-- 处理失败状态 -->
      <span v-else-if="status === 2">
        {{ detail.Status.Tips(status) }}
      </span>

      <!-- 处理倒计时 -->
      <span v-else-if="!!tips">剩余{{ tips }}</span>
    </div>

    <!-- 按钮容器 -->
    <ElRow class="button-box">
      <!-- 待商家处理 -->
      <template v-if="status === 1">
        <div class="button status1 A" @click="Cancel()">撤销申请</div>
        <div class="button status1 B">修改申请</div>
      </template>

      <!-- 售后失败重新申请 -->
      <div
        v-else-if="status === 0 || status === 2"
        class="button status1 B"
        @click="Reapply()"
      >
        重新申请
      </div>

      <!-- 买家发货 -->
      <template v-if="status === 4">
        <div class="button status2 B" @click="ExpInfo()">填写运单号</div>
        <div class="button status1 A" @click="Cancel()">撤销申请</div>
      </template>
    </ElRow>
  </ElRow>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    detail: undefined,
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    status: undefined, // 售后状态
    tips: undefined,

    date: 0, // 记录时间
    time: 0,
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.status = this.detail.Status.Type; // 获取售后状态

    // 检查需要倒计时
    if ([1, 4, 5].find(($) => $ === this.status)) {
      this.date = ~~(new Date().getTime() / 1000) + this.detail.TimeOut;
      this.PayTimeOut().QUEUE[this.detail.Code] = (unix) => {
        this.time = this.date - ~~(unix / 1000);
        this.PayTimeOut();
      };
    }
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    this.PayTimeOut(true); // 取消订阅
  },

  // 组件方法
  methods: {
    // 设置倒计时
    PayTimeOut(close = false) {
      // 创建时间
      if (this.time > 0 && !close) {
        this.tips = this.TimeConversion(this.time);
      }

      // 支付过期取消订阅
      else {
        this.time = 0;
        delete this.QUEUE[this.detail.Code];
      }

      return this; // 链式
    },

    // 取消
    Cancel() {
      this.BUS.LeaseAfterSalesCancel(this.detail.Id).then((_) => {
        location.reload(); // 刷新当前页面
      });
    },

    // 重新申请
    Reapply() {
      this.BUS.LeaseAfterSalesReapply(this.detail.OrderId);
    },

    // 填写运单号
    ExpInfo() {
      this.BUS.LeaseAfterSalesExpInfo(this.detail.Id).then((_) => {
        location.reload(); // 刷新当前页面
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.operate-box {
  // 操作容器
  background-color: white;
  flex-direction: column;
  padding: 16px;

  .title-box {
    // 标题容器
    font-size: 18px;
    line-height: 1;
  }

  .tips-box {
    // 提示容器
    color: rgba(193, 194, 197, 1);
    margin-top: 16px;
    font-size: 14px;
    line-height: 1;
    height: 14px;
  }

  .button-box {
    // 按钮容器
    align-items: stretch;
    margin-top: 16px;
    height: 26px;

    .button {
      // 通用按钮样式
      border: 1px solid rgba(187, 187, 187, 1);
      transition: var(--base-transition);
      color: rgba(187, 187, 187, 1);
      justify-content: center;
      align-items: center;
      border-radius: 4px;
      font-size: 12px;
      cursor: pointer;
      display: flex;
    }

    .button + .button {
      margin-left: 12px;
    }

    .status1 {
      width: 68px;
    }

    .status2 {
      width: 77px;
    }

    .A:hover,
    .B {
      border-color: red;
      color: red;
    }

    .B:hover {
      background-color: red;
      color: white;
    }
  }
}
</style>