<template>
  <ElRow class="logs-box">
    <div class="title">操作记录</div>

    <!-- 操作记录列表 -->
    <template v-for="(item, index) in list" :key="index">
      <ElRow class="head">
        <!-- 头像 -->
        <ElAvatar :size="40" :src="item.Avatar">{{ item.Name[0] }}</ElAvatar>

        <!-- 用户名称 -->
        <div class="name">{{ item.Name }}</div>

        <!-- 记录时间 -->
        <div class="time">{{ item.Time }}</div>
      </ElRow>

      <!-- 操作说明 -->
      <div v-html="item.Content" class="content" />

      <!-- 图片容器 -->
      <ElRow v-if="!!item.Img && item.Img.length > 0" class="img-box">
        <ElImage
          v-for="($, i) in item.Img"
          :preview-src-list="item.Img"
          :src="$"
          :key="i"
          fit="contain"
        />
      </ElRow>
    </template>
  </ElRow>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: { list: undefined },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.logs-box {
  // 操作记录
  background-color: white;
  flex-direction: column;
  margin-top: 16px;
  padding: 16px;

  .title {
    // 标题
    margin-bottom: 16px;
    font-size: 14px;
  }

  .head {
    // 消息头
    align-items: center;

    .name {
      margin-left: 10px;
      font-size: 14px;
      line-height: 1;
      flex-grow: 1;
    }

    .time {
      color: rgba(153, 153, 153, 1);
      font-size: 14px;
      flex-shrink: 0;
      line-height: 1;
    }
  }

  .content,
  .img-box {
    padding-left: 50px;
  }

  .content {
    word-break: break-all;
  }

  .img-box {
    margin-bottom: 20px;
    margin-top: 12px;

    .el-image {
      height: 60px;
      width: 60px;
    }

    .el-image + .el-image {
      margin-left: 4px;
    }
  }

  .content + .head {
    margin-top: 20px;
  }
}
</style>