<template>
  <!-- 售后撤销 -->
  <transition name="exp">
    <div v-if="show" class="exp-box">
      <!-- 内框 -->
      <div class="exp-box-in">
        <!-- 标题容器 -->
        <div class="title-box">
          <div class="title">填写运单号</div>
          <div class="img-box" @click="close()">
            <img class="A" :src="$svg['i-0015']" />
            <img class="B" :src="$svg['i-0015-FF0000']" alt="" />
          </div>
        </div>

        <!-- 提示 -->
        <ElRow class="tips-box">
          <img :src="$svg['i-0027-FAAD15']" />
          <span>请正确填写相应的运单号，否则可能将影响退款进度</span>
        </ElRow>

        <!-- 选择表单 -->
        <ElForm
          :rules="rules"
          :model="form"
          style="margin-top: 20px"
          label-width="100px"
          ref="$"
        >
          <ElFormItem label="快递运单号" prop="Code">
            <ElInput
              v-model="form.Code"
              placeholder="请在此填写快递运单号"
              @blur="GetCompany()"
            />
          </ElFormItem>

          <ElFormItem label="快递公司" prop="Company">
            <ElSelect
              v-model="form.Company"
              placeholder="请选择快递公司"
              style="width: 100%"
            >
              <ElOption v-if="!!exp" :label="exp.Name" :value="exp.Name" />
            </ElSelect>
          </ElFormItem>

          <ElFormItem label="退货留言">
            <ElInput
              v-model="form.Remark"
              :maxlength="100"
              :rows="5"
              placeholder="可描写退货留言"
              type="textarea"
              resize="none"
              show-word-limit
            />
          </ElFormItem>

          <ElFormItem label="上传图片">
            <Upload v-model:file="form.File" />
          </ElFormItem>
        </ElForm>

        <!-- 按钮容器 -->
        <ElRow class="button-box">
          <ElRow class="A" @click="upload()">确认</ElRow>
          <ElRow class="B" @click="close()">取消</ElRow>
        </ElRow>
      </div>
    </div>
  </transition>
</template>

<script>
import Upload from "../Upload.vue";

export default {
  // 组件
  components: { Upload },

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    BusKey: ["LeaseAfterSalesExpInfo"], // 订阅名称，组件卸载后清理订阅会用到

    upload: undefined, // 上传数据
    exp: undefined, // 物流信息

    show: Boolean(false), // 控制显示

    // 表单
    form: {
      Code: "", // 快递单号
      Company: "", // 物流公司
      Remark: "", // 备注
      File: Array(0),
    },

    // 校验
    rules: {
      Code: [
        {
          required: true,
          message: "快递单号不能为空",
          trigger: "blur",
        },
      ],
      Company: [
        {
          required: true,
          message: "请选择快递公司",
          trigger: "blur",
        },
      ],
    },
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.BUS[this.BusKey[0]] = (Id = undefined) => {
      return new Promise((resolve) => {
        if (!!Id) {
          this.show = true;
        } else {
          this.close();
        }

        // 上传数据
        this.upload = () => {
          var form = { Id, ...this.form };
          form.CompanyCode = this.exp.Code;
          form.Img = form.File.map((item) => item.response.data.url).join(","); // 拼接图片链接
          this.Api.LeaseOrderAfterSalesExpCode.init(form)
            .SetData()
            .then((_) => (this.close(), resolve(true)));
        };
      });
    };
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    delete this.BUS[this.BusKey[0]];
  },

  // 组件方法
  methods: {
    // 关闭操作
    close() {
      this.show = false;
    },

    // 获取物流公司
    GetCompany() {
      if (this.form.Code !== "") {
        this.Api.LeaseExpCompany.init(this.form.Code)
          .GetData()
          .then(($) => {
            this.exp = $;
            this.form.Company = $.Name;
          });
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.exp-box {
  // 外框
  background-color: rgba(0, 0, 0, 0.2);
  position: fixed;
  height: 100vh;
  width: 100vw;
  left: 0;
  top: 0;

  .exp-box-in {
    // 内框
    background-color: rgba(255, 255, 255, 1);
    transform: translate(-50%, -50%);
    border-radius: 4px;
    position: absolute;
    padding: 20px 12px;
    width: 480px;
    left: 50%;
    top: 50%;

    .title-box {
      // 标题容器
      align-items: center;
      margin-bottom: 20px;
      display: flex;

      .title {
        box-sizing: border-box;
        text-align: left;
        font-size: 18px;
        line-height: 1;
        flex-grow: 1;
      }

      .img-box {
        flex-shrink: 0;
        height: 24px;
        width: 24px;

        img {
          cursor: pointer;
          height: 24px;
          width: 24px;
        }

        .A {
          display: block;
        }

        .B {
          display: none;
        }

        &:hover {
          .A {
            display: none;
          }

          .B {
            display: block;
          }
        }
      }
    }

    .tips-box {
      // 提示容器
      background-color: rgba(255, 251, 230, 1);
      border: 1px solid rgba(255, 229, 143, 1);
      color: rgba(95, 90, 89, 1);
      align-items: center;
      font-size: 14px;
      height: 32px;

      img {
        margin: 0 8px 0 14px;
        height: 14px;
        width: 14px;
      }
    }

    .button-box {
      // 按钮容器
      flex-direction: row-reverse;
      align-items: center;
      margin-top: 40px;

      div {
        // 通用样式
        transition: all var(--base-transition);
        border: var(--el-border);
        justify-content: center;
        align-items: center;
        border-radius: 4px;
        cursor: pointer;
        height: 32px;
        width: 72px;
      }

      div + div {
        margin-right: 20px;
      }

      .A {
        background-color: red;
        border-color: red;
        color: white;

        &:hover {
          background-color: rgb(233, 84, 84);
          border-color: rgb(233, 84, 84);
        }
      }

      .B:hover {
        border-color: red;
        color: red;
      }
    }
  }
}

.exp-leave-to,
.exp-enter-from {
  opacity: 0;
}

.exp-leave-active,
.exp-enter-active {
  transition: opacity var(--base-transition);
}

.exp-leave-from,
.exp-enter-to {
  opacity: 1;
}
</style>