<template>
  <!-- 售后撤销 -->
  <transition name="cancel">
    <div v-if="show" class="cancel-box">
      <!-- 内框 -->
      <div class="cancel-box-in">
        <!-- 标题容器 -->
        <div class="title-box">
          <div class="title">重新申请</div>
          <div class="img-box" @click="close()">
            <img class="A" :src="$svg['i-0015']" />
            <img class="B" :src="$svg['i-0015-FF0000']" alt="" />
          </div>
        </div>

        <div class="tips">您确定要重新申请本次售后吗</div>

        <!-- 按钮容器 -->
        <ElRow class="button-box">
          <ElRow class="A" @click="GoReapply()">确认</ElRow>
          <ElRow class="B" @click="close()">取消</ElRow>
        </ElRow>
      </div>
    </div>
  </transition>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    BusKey: ["LeaseAfterSalesReapply"], // 订阅名称，组件卸载后清理订阅会用到

    Id: undefined, // 订单ID

    show: Boolean(false), // 控制显示
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.BUS[this.BusKey[0]] = (Id = undefined) => {
      if (!!Id) {
        this.Id = Id;
        this.show = true;
      } else {
        this.close();
      }
    };
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    delete this.BUS[this.BusKey[0]];
  },

  // 组件方法
  methods: {
    // 关闭操作
    close() {
      this.Id = undefined;
      this.show = false;
    },

    // 重新申请
    GoReapply() {
      this.$GO({ name: "LeaseAfterSalesAdd", data: { Id: this.Id } });
      this.close();
    },
  },
};
</script>

<style lang="scss" scoped>
.cancel-box {
  // 外框
  background-color: rgba(0, 0, 0, 0.2);
  position: fixed;
  height: 100vh;
  width: 100vw;
  left: 0;
  top: 0;

  .cancel-box-in {
    // 内框
    background-color: rgba(255, 255, 255, 1);
    transform: translate(-50%, -50%);
    border-radius: 4px;
    position: absolute;
    padding: 20px 12px;
    width: 480px;
    left: 50%;
    top: 50%;

    .title-box {
      // 标题容器
      align-items: center;
      margin-bottom: 20px;
      display: flex;

      .title {
        box-sizing: border-box;
        text-align: left;
        font-size: 18px;
        line-height: 1;
        flex-grow: 1;
      }

      .img-box {
        flex-shrink: 0;
        height: 24px;
        width: 24px;

        img {
          cursor: pointer;
          height: 24px;
          width: 24px;
        }

        .A {
          display: block;
        }

        .B {
          display: none;
        }

        &:hover {
          .A {
            display: none;
          }

          .B {
            display: block;
          }
        }
      }
    }

    .tips {
      margin: 24px 0 44px;
      font-size: 14px;
    }

    .button-box {
      // 按钮容器
      flex-direction: row-reverse;
      align-items: center;
      margin-top: 20px;

      div {
        // 通用样式
        transition: all var(--base-transition);
        border: var(--el-border);
        justify-content: center;
        align-items: center;
        border-radius: 4px;
        cursor: pointer;
        height: 32px;
        width: 72px;
      }

      div + div {
        margin-right: 20px;
      }

      .A {
        background-color: red;
        border-color: red;
        color: white;

        &:hover {
          background-color: rgb(233, 84, 84);
          border-color: rgb(233, 84, 84);
        }
      }

      .B:hover {
        border-color: red;
        color: red;
      }
    }
  }
}

.cancel-leave-from {
  opacity: 1;
}

.cancel-leave-active {
  transition: opacity var(--base-transition);
}

.cancel-leave-to {
  opacity: 0;
}

.cancel-enter-from {
  opacity: 0;
}

.cancel-enter-active {
  transition: opacity var(--base-transition);
}

.cancel-enter-to {
  opacity: 1;
}
</style>