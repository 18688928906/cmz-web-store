<template>
  <div class="status-box">
    <div :class="{ activation: status >= 0 }" class="main">
      <img v-if="status >= 0" :src="$svg['i-0028-0052D9']" />
      <img v-else :src="$svg['i-0028-999999']" />
      <span>提交申请</span>
    </div>

    <div :class="{ activation: status >= 0 }" class="hr-box">
      <span v-if="status >= 0">等待商家审核</span>
    </div>

    <div :class="{ activation: status >= 1 }" class="main">
      <img v-if="status >= 1" :src="$svg['i-0029-0052D9']" />
      <img v-else :src="$svg['i-0029-999999']" />
      <span>等待审核</span>
    </div>

    <!-- 商家拒绝退款 -->
    <template v-if="status === 2">
      <div class="hr-box" style="border-color: red">
        <span style="color: red">商家拒绝</span>
      </div>
    </template>

    <div v-else :class="{ activation: status === 3 }" class="hr-box">
      <span v-if="status === 3">退款中</span>
    </div>

    <div :class="{ activation: status === 3 }" class="main">
      <img v-if="status === 3" :src="$svg['i-0014-0052D9']" />
      <img v-else :src="$svg['i-0014-999999']" />
      <span>退款完成</span>
    </div>
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    detail: undefined,
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    status: undefined,
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.status = this.detail?.Status?.Type;
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.status-box {
  // 步骤条
  background-color: rgba(255, 255, 255, 1);
  justify-content: space-evenly;
  align-items: center;
  display: flex;
  width: 1200px;
  height: 80px;

  * {
    color: rgba(153, 153, 153, 1);
    flex-shrink: 0;
  }

  .main {
    // 主要提示
    justify-content: center;
    align-items: center;
    font-size: 16px;
    display: flex;
    width: 100px;

    img {
      margin-right: 10px;
      height: 20px;
      width: 20px;
    }
  }

  .activation {
    border-color: rgba(53, 116, 240, 1) !important;

    span {
      color: rgba(53, 116, 240, 1) !important;
    }
  }

  .hr-box {
    // 横线容器
    border-top: 1px solid rgba(153, 153, 153, 1);
    text-align: center;
    line-height: 2em;
    font-size: 12px;
    width: 320px;
    height: 1px;
  }
}
</style>