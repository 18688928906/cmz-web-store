<template>
  <ScrollBar style="background-color: white">
    <!-- 顶栏 -->
    <TopBar />

    <div class="top-list">
      <div v-for="(item, index) in category" :key="index">{{ item.Label }}</div>
    </div>

    <table>
      <template v-for="(item, index) in category" :key="index" class="list">
        <tr>
          <td class="title" colspan="2">{{ item.Label }}</td>
        </tr>

        <tr>
          <td class="hr" colspan="2"></td>
        </tr>

        <template v-for="($, i) in item.Children" :key="i">
          <tr>
            <td width="1">
              <div class="name">
                {{ $.Label }}
              </div>
            </td>
            <td>
              <div class="itemx">
                <template v-if="$?.Children?.length > 0">
                  <div
                    v-for="($$, ii) in $.Children"
                    style="cursor: pointer"
                    :key="ii"
                  >
                    {{ $$.Label }}
                  </div>
                </template>
                <div v-else style="color: rgba(0, 0, 0, 0)">0</div>
              </div>
            </td>
          </tr>
        </template>
      </template>
    </table>
  </ScrollBar>
</template>

<script>
export default {
  // 组件
  components: {},

  // 页面对象
  data: () => ({
    category: [],
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.Api.LeaseClassify.GetData().then(($) => (this.category = $));
  },

  // 组件方法
  methods: {
    goSearch(id, level) {
      this.$router.push({
        path: "/search/shop",
        query: { data: this.$http.base.AES.encrypt({ id, level }) },
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.top-list {
  margin-top: 20px;
  display: flex;
  width: 1200px;

  div {
    background-color: rgba(243, 243, 243, 1);
    color: rgba(0, 0, 0, 1);
    margin-bottom: 20px;
    border-radius: 2px;
    line-height: 32px;
    font-size: 14px;
    padding: 0 8px;
  }

  div + div {
    margin-left: 20px;
  }
}

.top-list + table {
  width: 1200px;

  tr {
    .title {
      border-bottom: 1px solid rgba(187, 187, 187, 1);
      line-height: 44px;
      font-size: 16px;
    }

    .hr {
      height: 20px;
    }

    td {
      vertical-align: top;

      .name {
        text-overflow: ellipsis;
        white-space: nowrap;
        align-items: center;
        overflow: hidden;
        line-height: 1em;
        font-size: 14px;
        display: flex;
        height: 100%;
      }

      .itemx {
        flex-wrap: wrap;
        display: flex;
        width: 100%;

        div {
          color: rgba(153, 153, 153, 100);
          text-overflow: ellipsis;
          box-sizing: border-box;
          margin-bottom: 20px;
          white-space: nowrap;
          margin-right: 20px;
          padding-left: 20px;
          overflow: hidden;
          flex-wrap: wrap;
          font-size: 12px;
          line-height: 14px;
        }

        div:hover {
          color: rgba(255, 0, 0, 1);
        }
      }
    }
  }
}

.list {
  width: 1200px;
}
</style>