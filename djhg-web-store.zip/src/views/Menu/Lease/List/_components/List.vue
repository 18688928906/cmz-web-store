<template>
  <div v-if="list.length > 0" class="list">
    <Item v-for="(item, index) in list" :key="index" :info="item" />
  </div>
</template>

<script>
import Item from "./ListItem.vue";

export default {
  // 组件
  components: { Item },

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    guid: undefined, // 唯一ID

    list: Array(0), // 渲染用参数
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.guid = this.GUID();
    this.Api.ShopList.Update[this.guid] = ($) => this.list.push(...$);
    this.Api.ShopList.GetList(); // 没有数据时更新接口
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    delete this.Api.ShopList.Update[this.guid];
  },

  // 组件方法
  methods: {
    overflow(key) {
      console.log(this.$refs);
      return false;
    },
  },
};
</script>

<style lang="scss" scoped>
.list {
  // 列表容器
  grid-template-columns: repeat(5, 1fr);
  grid-column-gap: 12px;
  grid-row-gap: 12px;
  display: grid;
  width: 1200px;
}

.list > div {
  // 单项容器
  transition: box-shadow var(--base-transition);
  background-color: white;
  flex-direction: column;
  align-items: center;
  border-radius: 8px;
  display: flex;
  height: 300px;
  width: 100%;

  img {
    // 商品图片
    border-radius: 4px;
    margin-top: 20px;
    height: 150px;
    width: 150px;
  }

  .name {
    color: rgba(102, 102, 102, 1);
    line-height: 22.5px;
    position: relative;
    margin-top: 24px;
    overflow: hidden;
    font-size: 14px;
    display: block;
    height: 45px;
    width: 168px;
  }

  .omit::after {
    // 省略号
    background: linear-gradient(to right, transparent, #fff 55%);
    color: rgba(102, 102, 102, 1);
    position: absolute;
    line-height: 22.5px;
    text-align: right;
    content: "…";
    font-size: 14px;
    width: 2.5em;
    bottom: 0;
    right: 0;
  }
}

.list > div:hover {
  // 鼠标移入阴影
  box-shadow: var(--base-shadow);
}
</style>