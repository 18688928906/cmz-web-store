<template>
  <!-- 主容器 -->
  <div v-if="list.length > 0" class="list">
    <Item v-for="(item, index) in list" :key="index" :info="item" />
  </div>

  <ElSkeleton :loading="loading" :animated="true">
    <!-- 骨架屏部分 -->
    <template #template>
      <div class="list">
        <div v-for="item in 5" class="list-skeleton-item" :key="item">
          <ElSkeletonItem
            style="margin-top: 20px; height: 150px; width: 150px"
            variant="image"
          />
          <ElSkeletonItem
            style="margin-top: 28px; height: 14px; width: 168px"
          />
          <ElSkeletonItem style="margin-top: 8px; height: 14px; width: 168px" />
        </div>
      </div>
    </template>

    <!-- 触底提示 -->
    <template #default>
      <div class="list-tips" @click="xxx">客官，已经到底了</div>
    </template>
  </ElSkeleton>
</template>

<script>
import { GUID } from "@/library.js";
import Item from "./ListItem.vue";

export default {
  // 组件
  components: { Item },

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    guid: GUID(), // 唯一ID

    loading: Boolean(true),

    list: Array(0), // 渲染用参数
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 订阅数据更新
    this.Api.LeaseList.AddUpdate(this.guid, ($) => {
      this.loading = !this.Api.LeaseList.Max;
      this.list = [];
      this.list = $;
    }).GetList(true);

    // 获取缓存，如果有的话
    this.list = this.Api.LeaseList.List;

    // 检查是否有触底缓存
    this.loading = !this.Api.LeaseList.Max;
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    this.Api.HomeList.DelUpdate(this.guid); // 取消订阅
  },

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.list {
  // 列表容器
  grid-template-columns: repeat(5, 1fr);
  grid-column-gap: 12px;
  grid-row-gap: 12px;
  display: grid;
  width: 1200px;

  .list-skeleton-item {
    // 单项容器
    background-color: white;
    flex-direction: column;
    align-items: center;
    border-radius: 8px;
    position: relative;
    display: flex;
    height: 300px;
    width: 100%;
  }
}

.el-skeleton {
  // 骨架屏
  width: 1200px;
}

.list + .el-skeleton {
  margin-top: 12px;
}

.list-tips {
  // 触底提示
  color: rgba(178, 178, 178, 1);
  text-align: center;
  margin-top: 20px;
  font-size: 16px;
  line-height: 1;
  width: 1200px;
}
</style>