<template>
  <!-- 顶栏居中容器 -->
  <div class="top-bar">
    <!-- 顶栏内容器 -->
    <div class="top-bar-in">
      <!-- 标题 -->
      <div class="label">{{ label }}</div>
    </div>

    <!-- 下方标题 -->
    <ElRow class="top-bar-ls">
      <!-- 标题容器 -->
      <ElRow
        class="label-box"
        @click="$GO({ path: '/menu/lease/list/classify' })"
      >
        <img :src="$svg['i-0036-FFFFFF']" />
        <div>商品分类</div>
      </ElRow>
    </ElRow>
  </div>
</template>

<script>
/**
 * 通用顶栏
 */
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    // 标题
    label: {
      type: String,
      default: process.env.VUE_APP_TITLE,
    },
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.top-bar {
  // 顶栏
  box-shadow: var(--base-shadow);
  background-color: white;
  flex-direction: column;
  align-items: center;
  display: flex;
  width: 100%;

  .top-bar-in {
    // 顶栏容器
    align-items: center;
    display: flex;
    height: 100px;
    width: 1200px;

    .logo {
      // 图标
      height: 60px;
      width: 60px;
    }

    .label {
      color: rgba(42, 178, 255, 1);
      margin-left: 25px;
      line-height: 1em;
      font-size: 28px;
      flex-grow: 1;
    }
  }

  .top-bar-ls {
    // 下方标题
    width: 1200px;

    .label-box {
      // 标题容器
      background-color: rgba(42, 178, 255, 1);
      align-items: center;
      cursor: pointer;
      height: 40px;
      width: 160px;

      img {
        margin: 0 12px;
        height: 22px;
        width: 22px;
      }

      div {
        font-size: 14px;
        line-height: 1;
        color: white;
      }
    }
  }
}
</style>