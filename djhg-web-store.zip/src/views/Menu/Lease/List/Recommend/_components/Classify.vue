<template>
  <div class="classify">
    <ElScrollbar class="item-scrollbar" height="500px">
      <ElRow v-for="(item, index) in Classify" :key="index" class="item">
        <!-- 一级标题 -->
        <span>{{ item.Label }}</span>

        <!-- 二级弹出框显示 -->
        <ElScrollbar class="scrollbar-in">
          <table
            style="border-collapse: collapse"
            cellspacing="0"
            cellpadding="0"
            border="0"
          >
            <tr v-for="($, i) in item.Children" :key="i">
              <!-- 二级菜单 -->
              <td width="1">
                <ElRow class="label">
                  <span>{{ $.Label }}</span>
                  <img :src="$svg['i-0006-CCCCCC']" />
                </ElRow>
              </td>

              <!-- 三级菜单 -->
              <td>
                <div class="itemx">
                  <template v-if="$?.Children?.length > 0">
                    <div
                      v-for="$$ in $.Children"
                      style="cursor: pointer"
                      :key="$$.Id"
                    >
                      {{ $$.Label }}
                    </div>
                  </template>
                  <div v-else style="color: rgba(0, 0, 0, 0)">0</div>
                </div>
              </td>
            </tr>
          </table>
        </ElScrollbar>
      </ElRow>
    </ElScrollbar>
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    Classify: undefined, // 分类树
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.Api.LeaseClassify.GetData().then(($) => (this.Classify = $));
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.classify {
  // 分类
  background-color: white;
  position: relative;
  width: 160px;

  .item-scrollbar {
    // 调整滚动容器宽度
    width: 100%;
  }

  .item {
    // 单个选项
    border-bottom: 1px solid rgba(244, 244, 244, 1);
    color: var(--base-color);
    align-items: center;
    padding-left: 12px;
    position: static;
    font-size: 12px;
    height: 50px;
    width: 160px;

    .scrollbar-in {
      // 内部滚动
      border: 1px solid rgba(244, 244, 244, 1);
      background-color: white;
      position: absolute;
      display: none;
      height: 500px;
      width: 470px;
      right: 0;
      top: 0;

      :deep(.el-scrollbar__view) {
        padding: 20px;
      }

      table {
        width: 100%;

        tr + tr {
          padding-top: 20px;
        }

        tr > td {
          vertical-align: top;
        }

        .label {
          justify-content: flex-end;
          white-space: nowrap;
          align-items: center;
          flex-wrap: nowrap;
          line-height: 1;
          font-size: 12px;

          img {
            height: 12px;
            width: 12px;
          }
        }

        .itemx {
          flex-wrap: wrap;
          display: flex;
          width: 100%;

          div {
            color: rgba(153, 153, 153, 100);
            text-overflow: ellipsis;
            box-sizing: border-box;
            margin-bottom: 20px;
            white-space: nowrap;
            margin-right: 20px;
            padding-left: 20px;
            overflow: hidden;
            flex-wrap: wrap;
            font-size: 12px;
            line-height: 1;
          }

          div:hover {
            color: rgba(255, 0, 0, 1);
          }
        }
      }
    }

    &:hover {
      background-color: rgba(244, 244, 244, 1);
      color: rgba(0, 0, 0, 1);

      .scrollbar-in {
        //   二级滚动
        display: block;
      }
    }
  }

  &:hover {
    .item-scrollbar {
      // 调整滚动容器宽度
      width: 630px;
    }
  }
}
</style>