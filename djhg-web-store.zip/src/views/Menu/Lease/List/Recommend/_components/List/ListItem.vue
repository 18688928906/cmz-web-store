<template>
  <div class="list-item" @click="OpenDetail()">
    <div v-if="DEV" class="DEV" style="left: 0">ID：{{ info.Id }}</div>

    <!-- 展示图片 -->
    <img :src="info.Img" />

    <!-- 商品名称 -->
    <div class="name" ref="$" :class="{ omit: omit }">
      <span v-if="info.Wholesale" class="wholesale">批发</span>
      <span>{{ info.Name }}</span>
    </div>

    <div class="price">
      {{ info.Currency }}<a>{{ Math.floor(info.Price) }}</a
      >.{{ Decimal(info.Price) }}/天
    </div>
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: ["info"],

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    omit: Boolean(false), // 是否使用省略号
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {
    const $ = this.$refs.$;
    this.omit = $.clientHeight < $.scrollHeight; // 检测文本溢出
  },

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 处理小数
    Decimal($) {
      const d = $.toString().split(".");
      return d[1] || "00";
    },

    // 打开详情
    OpenDetail() {
      this.$GO({ name: "LeaseDetail", data: { Id: this.info.Id } });
    },
  },
};
</script>

<style lang="scss" scoped>
.list-item {
  // 单项容器
  transition: box-shadow var(--base-transition);
  background-color: white;
  flex-direction: column;
  align-items: center;
  border-radius: 8px;
  position: relative;
  display: flex;
  height: 300px;
  width: 100%;

  img {
    // 商品图片
    border-radius: 4px;
    margin-top: 20px;
    height: 150px;
    width: 150px;
  }

  .name {
    // 商品名称
    color: rgba(102, 102, 102, 1);
    word-break: break-all;
    position: relative;
    line-height: 22px;
    margin-top: 24px;
    overflow: hidden;
    font-size: 14px;
    cursor: pointer;
    display: block;
    height: 44px;
    width: 168px;

    .wholesale {
      box-shadow: 0 0 0 1px var(--el-color-primary) inset;
      background-color: var(--el-color-primary-light-8);
      color: var(--el-color-primary);
      border-radius: 2px;
      margin-right: 4px;
      padding: 4px 8px;
      font-size: 12px;
      line-height: 1;
    }
  }

  .price {
    // 商品价格
    color: rgba(255, 0, 0, 100);
    font-weight: bold;
    margin-top: 12px;
    font-size: 14px;
    display: block;
    width: 168px;

    a {
      font-size: 18px;
    }
  }

  .omit::after {
    // 省略号
    background: linear-gradient(to right, transparent, #fff 55%);
    color: rgba(102, 102, 102, 1);
    position: absolute;
    line-height: 22px;
    text-align: right;
    content: "…";
    font-size: 14px;
    width: 2.5em;
    bottom: 0;
    right: 0;
  }
}

.list-item:hover {
  // 鼠标移入阴影
  box-shadow: var(--base-shadow);
}
</style>