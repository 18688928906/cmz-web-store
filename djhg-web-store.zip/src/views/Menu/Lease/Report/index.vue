<template>
  <ScrollBar>
    <TopBar label="商品举报" />
    <div class="report-box">
      <div class="label">商品信息</div>

      <div class="info">
        <img v-if="img" :src="img" />
        <div class="in">
          <div>商品ID：{{ query.Id }}</div>
          <div>商品名称：{{ name }}</div>
        </div>
      </div>

      <div class="label"><a>*</a>举报类型</div>

      <el-select v-model="value" class="select" placeholder="请选择举报类型">
        <el-option
          v-for="item in options"
          :key="item.value"
          :label="item.label"
          :value="item.value"
        />
      </el-select>

      <div class="label"><a>*</a>举报详情</div>

      <el-input
        v-model="textarea"
        :rows="5"
        placeholder="请填写举报详情"
        style="width: 930px; margin-bottom: 30px"
        :maxlength="300"
        resize="none"
        type="textarea"
        show-word-limit
      />

      <div class="label">图片凭证</div>

      <el-upload
        v-model:file-list="fileList"
        class="upload"
        accept=".gif,.jpg,.jpeg,.png,.GIF,.JPG,.PNG"
        style="border: none"
        list-type="picture-card"
        :action="action"
        :limit="5"
      >
        <img style="width: 50px; height: 50px" :src="$svg['i-0031-8B929B']" />
      </el-upload>

      <div class="label" style="color: rgba(102, 102, 102, 1); font-size: 12px">
        最大上传5张图
      </div>

      <div class="btb">
        <el-button
          colorHover="red"
          :disable="disable"
          @click="up()"
          type="danger"
          >提交</el-button
        >
        <el-button colorHover="red" @click="$router.go(-1)">取消</el-button>
      </div>
    </div>
  </ScrollBar>
</template>

<script>
export default {
  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 组件
  components: {},

  // 计算属性
  computed: {
    disable: {
      get() {
        return this.value == undefined || this.textarea == "";
      },
    },
  },

  // 页面对象
  data: () => ({
    id: undefined,
    protype: undefined,
    img: undefined,
    name: undefined,
    value: undefined,
    fileList: [],

    textarea: "",

    action: process.env.VUE_APP_BASE_URL + process.env.VUE_APP_OBS + "/cmz-img/?token=", // 拼接华为OBS服务器地址

    options: [
      { label: "出售违禁商品", value: 1 },
      { label: "产品与实物不服", value: 2 },
      { label: "虚假宣传", value: 3 },
      { label: "虚假交易", value: 4 },
      { label: "其他", value: 5 },
    ],
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.ApiNew.LeaseDetail()
      .init(this.query.Id)
      .GetData()
      .then(($) => {
        this.img = $.Cover?.Imgs[0];
        this.name = $.Name;
      });

    this.action = this.action + this.Api.UserLogin.Token.token; // 写入Token
  },

  // 组件方法
  methods: {
    up() {
      // this.$http.user.report.imgs =
      //   this.fileList.length > 0
      //     ? this.fileList.map(($) => $.response.data.url).join(",")
      //     : undefined;
      // this.$http.user.report.run.then((_) => {
      //   ElMessage({
      //     message: "举报成功",
      //     type: "success",
      //   });
      //   this.$router.back();
      // });
      //   console.log(this.$http.user.report);
      this.ApiNew.LeaseReportAdd()
        .init({
          Id: this.query.Id,
          Type: this.value,
          Img:
            this.fileList.length > 0
              ? this.fileList.map(($) => $.response.data.url).join(",")
              : undefined,
          Content: this.textarea,
        })
        .SetData()
        .then((_) => {
          ElMessage({
            message: "举报成功",
            type: "success",
          });
          this.$router.back();
        });
    },
  },
};
</script>

<style lang="scss" scoped>
.report-box {
  box-shadow: 0px 0px 6px 0px rgba(0, 0, 0, 0.1);
  background-color: white;
  flex-direction: column;
  box-sizing: border-box;
  margin-top: 20px;
  padding: 14px;
  display: flex;
  width: 1200px;

  .label {
    color: rgba(16, 16, 16, 1);
    line-height: 20px;
    margin-bottom: 12px;
    font-size: 14px;

    a {
      color: red;
    }
  }

  .info {
    margin-bottom: 30px;
    display: flex;
    width: 100%;

    img {
      border-radius: 4px;
      flex-shrink: 0;
      height: 60px;
      width: 60px;
    }

    .in {
      margin-left: 10px;
      flex-grow: 1;

      div {
        color: rgba(102, 102, 102, 1);
        font-size: 12px;
      }

      div + div {
        margin-top: 10px;
      }
    }
  }

  .select {
    margin-bottom: 30px;
    width: 260px;
  }

  .btb {
    justify-content: center;
    margin-top: 70px;
    display: flex;

    .ar-button {
      width: 92px;
    }

    .ar-button + .ar-button {
      margin-left: 20px;
    }
  }
}
</style>