<template>
  <ScrollBar v-if="detail" style="background-color: white">
    <!-- 顶栏 -->
    <TopBar label="评价商品" />

    <!-- 评价容器 -->
    <ElRow class="reviews-box">
      <!-- 订单详情 -->
      <Detail
        v-for="(item, index) in detail.List"
        :detail="item"
        :key="index"
      />

      <!-- 表单 -->
      <ElForm
        :model="form"
        :rules="rules"
        label-position="left"
        label-width="auto"
        ref="$"
      >
        <!-- 不校验 -->
        <ElFormItem label="追评">
          <ElInput
            v-model="form.Content"
            :maxlength="150"
            :rows="4"
            placeholder="请在此输入您的评价"
            style="width: 700px"
            type="textarea"
            resize="none"
            show-word-limit
          />
        </ElFormItem>

        <!-- 不校验 -->
        <ElFormItem label="评论图片">
          <Upload v-model:file="form.File" />
        </ElFormItem>
      </ElForm>

      <!-- 按钮容器 -->
      <ElRow class="button-box">
        <ElButton
          class="button"
          type="danger"
          :disabled="!form.Content || form.Content == ''"
          @click="upload()"
        >
          提交
        </ElButton>
      </ElRow>
    </ElRow>
  </ScrollBar>
</template>

<script>
import Detail from "./_components/Detail.vue";
import Upload from "./_components/Upload.vue";

export default {
  // 自动路由参数，配置看App.vue
  meta: {
    title: undefined, // 写入浏览器页签
    index: undefined, // 用于排序
    label: undefined, // 显示用的路由名称
    name: "LeaseReviewsAgain", // 路由名称

    open: Boolean(true), // 是否在新页面中打开
    token: Boolean(false), // 控制是否需要登录
  },

  // 组件
  components: { Detail, Upload },

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    detail: undefined,
    tags: undefined,

    // 表单
    form: {
      Content: "", // 评价详情
      File: Array(0), // 上传文件
    },

    // 校验
    rules: {},
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 获取订单详情
    this.Api.LeaseOrderDetail.init(this.query)
      .AddUpdate("LeaseReviews", (detail) => (this.detail = detail))
      .GetData();
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 上传数据
    upload() {
      this.form.Id = this.query.Comment; // 记录评价ID

      this.form.Img = this.form.File.map((item) => item.response.data.url).join(
        ","
      );

      // 调用接口
      this.Api.LeaseOrderReviewsAgain.init(this.form)
        .SetData()
        .then((_) => {
          // 支付成功跳转订单详情界面
          this.$GO({
            name: "LeaseOrderDetail",
            data: { Id: this.detail.Id },
          });
          window.close(); // 关闭界面
        });
    },
  },
};
</script>

<style lang="scss" scoped>
.reviews-box {
  // 评价容器
  box-shadow: var(--base-shadow);
  flex-direction: column;
  border-radius: 4px;
  margin-top: 20px;
  padding: 20px;
  width: 1200px;

  .el-form {
    // 表单
    margin-top: 20px;

    .el-form-item {
      :deep(.el-form-item__content) {
        line-height: normal;
      }
    }
  }

  .button-box {
    // 按钮容器
    justify-content: center;
    margin-top: 20px;

    .button {
      --el-color-danger-light-3: rgb(233, 84, 84);
      --el-color-danger: rgba(240, 45, 45, 1);
      border-radius: 4px;
      font-size: 16px;
      height: 44px;
      width: 320px;
    }
  }
}
</style>