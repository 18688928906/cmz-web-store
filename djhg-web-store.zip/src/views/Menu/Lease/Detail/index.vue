<template>
  <ScrollBar
    v-if="detail"
    style="background-color: white"
    @load="Api.LeaseCommentsList.GetData($refs.$?.index === 2)"
    @GetTop="GetTop($event)"
  >
    <!-- 开发信息 -->
    <div v-if="DEV && !!detail" class="DEV" style="left: 0">
      ID：{{ detail.Id }}
    </div>

    <!-- 顶栏 -->
    <TopBar ref="T" />

    <!-- 详情操作容器 -->
    <ProductDetailBox style="margin-top: 12px" ref="P">
      <!-- 轮播图容器 -->
      <ProductDetailBanner :login="!detail" :list="detail.Cover?.List">
        <!-- 收藏和举报 -->
        <CollectionAndReport v-if="!!login" :detail="detail" />
      </ProductDetailBanner>

      <!-- 操作容器 -->
      <Operate :detail="detail" />
    </ProductDetailBox>

    <!-- 页签 -->
    <TabBox ref="$" :class="{ 'tb-fixed': fixed }" />

    <div class="virtual-pages">
      <!-- 页面容器 -->
      <PageBox :detail="detail" />

      <!-- 侧边栏 -->
      <SideBox :detail="detail" />
    </div>
  </ScrollBar>
</template>

<script>
import { GUID } from "@/library.js";

import AddToCartSucceed from "./_components/PopUp/AddToCartSucceed.vue";
import CommentsReport from "./_components/PopUp/CommentsReport.vue";

import Operate from "./_components/Operate/Box.vue";
import TabBox from "./_components/TbaBox.vue";
import PageBox from "./_components/Page/Box.vue";
import SideBox from "./_components/SideBox.vue";
import CollectionAndReport from "./_components/CollectionAndReport.vue";

export default {
  meta: {
    title: undefined, // 写入浏览器页签
    index: undefined, // 用于排序
    label: "商品详情", // 显示用的路由名称
    name: "LeaseDetail", // 路由名称

    open: Boolean(true), // 是否在新页面中打开
    token: Boolean(false), // 控制是否需要登录
  },

  // 组件
  components: { Operate, TabBox, PageBox, SideBox, CollectionAndReport },

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    guid: GUID(), // 唯一ID

    detail: undefined, // 商品详情
    login: undefined, // 用户是否登录

    fixed: false, // 控制是否吸顶
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 检查登录数据
    this.login = this.Api.UserLogin.Token;

    // 订阅登录状态改变
    this.Api.UserLogin.AddUpdate(this.guid, ($) => (this.login = $));

    // 初始化并订阅数据
    this.Api.LeaseDetail.init(this.query.Id)
      .AddUpdate(this.guid, (detail) => {
        this.detail = undefined;
        this.detail = detail;
      })
      .GetData();

    // 覆盖写入唯一ID
    const DataA = AddToCartSucceed.data();
    DataA.guid = this.guid;
    AddToCartSucceed.data = () => DataA;

    // 挂载弹出框
    this.BUS.AddPopUp("AddToCartSucceed", AddToCartSucceed);

    // 覆盖写入唯一ID
    const DataB = CommentsReport.data();
    DataB.guid = this.guid;
    CommentsReport.data = () => DataB;

    // 挂载弹出框
    this.BUS.AddPopUp("CommentsReport", CommentsReport);
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    // 删除订阅
    this.Api.LeaseDetail.DelUpdate(this.guid);
    this.Api.UserLogin.DelUpdate(this.guid);

    // 卸载弹出框
    this.BUS.DelPopUp("AddToCartSucceed");
    this.BUS.DelPopUp("CommentsReport");
  },

  // 生命周期函数：离开后调用
  unmounted() {},

  // 组件方法
  methods: {
    // 获取滚动距离
    GetTop($) {
      var height = this.$refs.T.$el.nextElementSibling.offsetHeight;
      height += this.$refs.P.$el.offsetHeight;
      height += 40;
      this.fixed = $ > height;
    },
  },
};
</script>

<style lang="scss" scoped>
.virtual-pages {
  justify-content: space-between;
  align-items: flex-start;
  display: flex;
  width: 1200px;
}

.tb-fixed {
  // 吸顶
  transform: translateX(-50%);
  position: fixed;
  margin-top: 0;
  z-index: 1;
  left: 50%;
  top: 36px;
}
</style>