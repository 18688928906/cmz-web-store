<template>
  <!-- 页签容器 -->
  <div class="tab-box">
    <div :class="{ act: index === 0 }" @click="index = 0">商品详情</div>
    <div :class="{ act: index === 1 }" @click="index = 1">商品参数</div>
    <div :class="{ act: index === 2 }" @click="index = 2">
      商品评价（{{ content }}）
    </div>
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {},

  // 计算属性
  computed: {
    // 配置被选中的项目
    index: {
      get() {
        return this._index;
      },
      set(value) {
        this._index = value;
        this.BUS.SetShopDetailIndex(value); // 发布消息
      },
    },
  },

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    _index: 0, // 配置被选中的项目

    content: 0,
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.BUS.GetShopDetailCommentsContent = ($) => (this.content = $);
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    delete this.BUS.GetShopDetailCommentsContent;
  },

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.tab-box {
  // 说明容器
  background-color: white;
  position: relative;
  margin-top: 40px;
  display: flex;
  width: 1200px;

  div {
    transition: background-color var(--base-transition);
    background-color: white;
    color: var(--base-color);
    text-align: center;
    line-height: 50px;
    font-size: 14px;
    cursor: pointer;
    height: 50px;
    width: 160px;
  }

  .act,
  div:hover {
    background-color: rgba(42, 178, 255, 1);
    color: white;
  }

  &::after {
    background-color: rgba(224, 224, 224, 1);
    position: absolute;
    width: 900px;
    content: "";
    height: 1px;
    bottom: 0;
    left: 0;
  }
}
</style>