<template>
  <!-- 页签容器 -->
  <div class="side-box">
    <!-- 店铺容器 -->
    <div class="store-box">
      <div class="name-box">{{ detail.Store.Name }}</div>
      <img class="logo" :src="detail.Store.Logo" />
      <div class="btb" @click="GoStore()">
        <div class="A">进入店铺</div>
        <div class="B">关注店铺</div>
      </div>

      <div class="authenticated">平台<br />认证</div>
      <img :src="$svg['i-0023-397BFF']" @click="GoChat()" />
    </div>
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: { detail: undefined },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 跳转店铺
    GoStore() {
      this.$GO({
        path: "/menu/store/lease",
        data: { Id: this.detail.Store.Id },
      });
    },

    // 跳转聊天
    GoChat() {
      var data = JSON.parse(JSON.stringify(this.detail.Store));
      data.Product = {
        Id: this.detail.Id, // 商品ID
        Img: this.detail.Cover.Imgs[0], // 商品封面
        Name: this.detail.Name, // 商品名称
        Price: this.detail.Price, // 商品价格
        Sale: this.detail.Sale, // 销量
        Type: 20,
      };
      this.$GO({ name: "Chat", data });
    },
  },
};
</script>

<style lang="scss" scoped>
.side-box {
  // 说明容器
  background-color: white;
  flex-direction: column;
  align-items: stretch;
  position: relative;
  display: flex;
  width: 270px;

  .store-box {
    // 店铺容器
    border: 1px solid rgba(240, 240, 240, 1);
    flex-direction: column;
    align-items: center;
    background: white;
    position: relative;
    border-radius: 4px;
    overflow: hidden;
    display: flex;
    height: 230px;

    .name-box {
      box-shadow: 0px 4px 8px 0px rgba(0, 0, 0, 0.08);
      justify-content: center;
      align-items: center;
      border-radius: 4px;
      font-weight: bold;
      font-size: 14px;
      display: flex;
      height: 36px;
      width: 100%;
    }

    .logo {
      box-shadow: 0px 4px 6px 0px rgba(0, 0, 0, 0.1);
      border-radius: 2px;
      margin-top: 25px;
      height: 96px;
      width: 96px;
    }

    .btb {
      align-items: center;
      margin-top: 26px;
      display: flex;

      div {
        border: 1px solid rgba(29, 33, 41, 0.9);
        justify-content: center;
        align-items: center;
        border-radius: 24px;
        font-size: 12px;
        cursor: pointer;
        display: flex;
        height: 24px;
        width: 76px;

        &:hover {
          background-color: rgba(29, 33, 41, 0.9);
          color: white;
        }
      }

      div + div {
        margin-left: 18px;
      }
    }

    .authenticated {
      // 认证容器
      border: 1px solid rgba(242, 51, 51, 0.33);
      color: rgba(242, 51, 51, 0.33);
      transform: rotate(33deg);
      border-radius: 22px;
      text-align: center;
      position: absolute;
      padding-top: 10px;
      line-height: 12px;
      font-size: 12px;
      height: 44px;
      width: 44px;
      left: -4px;
      top: -4px;
    }

    .authenticated + img {
      // 显示图标
      position: absolute;
      cursor: pointer;
      height: 16px;
      width: 16px;
      right: 40px;
      top: 10px;
    }
  }
}
</style>