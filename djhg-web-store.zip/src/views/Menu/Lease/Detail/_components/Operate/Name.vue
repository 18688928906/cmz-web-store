<template>
  <!-- 商品名称 -->
  <div class="name-box">
    <span class="tag">{{ detail.Wholesale.Type ? "批发" : "租赁" }}</span>
    <span class="name">{{ detail.Name }}</span>
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    detail: undefined, // 商品详情
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.name-box {
  // 商品名称
  word-break: break-all;
  line-height: 24px;

  .tag {
    // 商品类型标签
    background-color: rgba(42, 178, 255, 1);
    transform: translateY(-2px);
    display: inline-block;
    border-radius: 4px;
    margin-right: 10px;
    text-align: center;
    line-height: 20px;
    font-size: 12px;
    flex-shrink: 0;
    color: white;
    height: 20px;
    width: 40px;
  }

  .name {
    // 名称
    font-size: 16px;
  }
}
</style>