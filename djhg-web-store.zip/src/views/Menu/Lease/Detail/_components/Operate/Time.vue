<template>
  <!-- 选择数量 -->
  <div class="quantity-label">
    <span>租赁天数</span>
    <!-- <span v--if="detail.Quantity === detail.Wholesale.Max" class="A">
      （Max）
    </span> -->
  </div>

  <!-- 数量选择器 -->
  <ElInputNumber v-model="detail.Day" :min="detail.MinDay" />
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    detail: undefined, // 商品详情
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.quantity-label {
  // 标题
  color: rgba(153, 153, 153, 1);
  padding-left: 16px;
  line-height: 1em;
  font-size: 14px;
  flex-shrink: 0;
  height: 1em;

  .A {
    color: red;
  }
}

.el-input-number {
  // 覆盖数字输入框属性
  margin-left: 16px;
  width: 122px;

  :deep(span) {
    border-radius: var(--el-border-radius-base);
    background-color: rgba(247, 248, 250, 1);
    --el-color-primary: red;
    border: none;
  }

  :deep(.el-input) {
    --el-input-hover-border: rgba(0, 0, 0, 0);
    --el-input-border-color: rgba(0, 0, 0, 0);
    --el-input-hover-border-color: rgba(0, 0, 0, 0);
    --el-input-focus-border-color: rgba(0, 0, 0, 0);
  }
}
</style>