<template>
  <div class="operate-box">
    <!-- 商品名称 -->
    <Name :detail="detail" />

    <!-- 价格展示 -->
    <Pice :detail="detail" />

    <!-- 运费说明 -->
    <Explain label="运费">
      <div class="fees-explain">{{ detail.Express.FeesExplain }}</div>
    </Explain>

    <!-- 服务说明 -->
    <Explain label="服务" v-if="detail.Serve">
      <div class="serve-box">
        <div v-for="(item, index) in detail.Serve" :key="index">
          <img :src="$svg['i-0014-FF0000']" />
          {{ item.Label }}
        </div>
      </div>
    </Explain>

    <!-- 选择规格 -->
    <Sku v-if="!!detail.Sku" :detail="detail" />

    <ElAlert
      v-else-if="!detail.Sku && !detail.SkuId"
      :closable="false"
      title="错误：该商品没有配置规格，请联系管理员！"
      type="error"
    />

    <!-- 租赁天数 -->
    <Time :detail="detail" />

    <!-- 购买数量 -->
    <Quantity :detail="detail" />

    <!-- 押金 -->
    <Explain label="押金">
      <ElRow class="bond-box">
        <span>{{ detail.Currency }}</span>
        <span> {{ detail.Bond }}</span>
      </ElRow>
    </Explain>

    <!-- 按钮容器 -->
    <ButtonBox :detail="detail" />
  </div>
</template>

<script>
import Name from "./Name.vue";
import Pice from "./Pice.vue";
import Explain from "./Explain.vue";
import Sku from "./Sku.vue";
import Quantity from "./Quantity.vue";
import Time from "./Time.vue";
import ButtonBox from "./ButtonBox.vue";

export default {
  // 组件
  components: { Name, Pice, Explain, Sku, Quantity, Time, ButtonBox },

  // 接收参数
  props: {
    detail: undefined, // 商品详情
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.operate-box {
  // 操作区容器
  grid-template-columns: 100%;
  grid-row-gap: 20px;
  margin-left: 34px;
  display: grid;
  flex-grow: 1;

  .fees-explain {
    // 快递说明
    line-height: 1em;
    font-size: 14px;
  }

  .serve-box {
    // 服务说明
    margin-bottom: -8px;
    margin-right: -20px;
    flex-wrap: wrap;
    display: flex;

    div {
      align-items: center;
      margin-bottom: 8px;
      margin-right: 20px;
      font-size: 14px;
      line-height: 1;
      display: flex;
      height: 1em;

      img {
        margin-right: 4px;
        margin-top: -2px;
        height: 14px;
        width: 14px;
      }
    }
  }

  .bond-box {
    // 押金容器
    align-items: baseline;
    font-size: 12px;

    span + span {
      font-size: 14px;
    }
  }
}
</style>