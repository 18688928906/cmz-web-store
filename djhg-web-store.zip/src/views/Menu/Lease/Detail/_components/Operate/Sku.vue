<template>
  <!-- 选择规格 -->
  <template v-for="(item, index) in list" :key="index">
    <!-- 规格标题 -->
    <div class="sku-label">{{ item.Label }}</div>

    <!-- 规格选项 -->
    <div class="sku-list">
      <template v-for="($, i) in item.Value" :key="i">
        <!-- 不带图的单个选项 -->
        <div
          :class="{ select: item.Select === $.Key }"
          class="sku-item"
          @click="SetSku(index, $.Key)"
        >
          <span>{{ $.Text }}</span>

          <!-- 选中时的标识 -->
          <div v-if="item.Select === $.Key" class="sku-set">
            <img :src="$svg['i-0021-FFFFFF']" />
          </div>
        </div>
      </template>
    </div>
  </template>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    detail: undefined, // 商品详情
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    list: undefined, // 规格列表
    keys: undefined, // 规格对照表
    price: undefined, // 原有价格
    sale: undefined, // 原有销量
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.list = [...this.detail.Sku.List]; // 获取规格
    this.keys = [...this.detail.Sku.IdKeys]; // 获取对照表
    this.price = this.detail.Price; // 保存原有价格
    this.sale = this.detail.Sale; // 保存原有销量
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    /**
     * 选择规格
     * @param {*} Index 所选规格编号
     * @param {*} Key 识别用值
     */
    SetSku(Index, Key) {
      // 获取命中规格
      const keys = this.keys.filter(($) => $.Key[Index] === Key);

      // 循环处理选中规格
      this.list.forEach((item, index) => {
        // 处理操作的项
        if (index === Index) {
          item.Value.forEach(($) => ($.Disabled = false)); // 清除禁用
          item.Select = item.Select === Key ? undefined : Key; // 设置选中项
        }

        // 其他项目检查是否有禁用属性
        else {
          item.Value.forEach(($) => {
            $.Disabled = keys.findIndex((_$) => _$.Key[index] === $.Key) < 0;
            $.Disabled && (item.Select = undefined); // 有禁用的情况清除选项
          });
        }
      });

      // 拼接匹配项
      const KeyList = this.list.map((item) => item.Select).join(",");

      // 获取命中规格
      const Sku = this.keys.find((item) => item.Key.join(",") === KeyList);

      // 检查并处理规格
      if (Sku) {
        this.detail.SkuId = Sku.Id; // 记录选中的规格ID
        this.detail.Price = Sku.Price; // 显示选中规格的价格
        this.detail.Sale = Sku.Sale; // 没有规格恢复销量
        this.detail.Wholesale.Max = Sku.Inventory; // 设定库存上限

        // 限制购买数量
        if (this.detail.Quantity > Sku.Inventory) {
          this.detail.Quantity = Sku.Inventory;
        } else if (this.detail.Quantity === 0) {
          this.detail.Quantity = 1;
        }
      } else {
        this.detail.Price = this.price; // 没有规格恢复价格
        this.detail.Sale = this.sale; // 没有规格恢复销量
        this.detail.Wholesale.Max = undefined; // 清空上限
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.sku-label {
  // 标题
  color: rgba(153, 153, 153, 1);
  padding-left: 16px;
  line-height: 1em;
  font-size: 14px;
  flex-shrink: 0;
  height: 1em;
}

.sku-list {
  // 规格列表
  margin-bottom: -8px;
  margin-right: -20px;
  padding-left: 16px;
  flex-wrap: wrap;
  display: flex;

  .sku-item {
    // 规格选项
    transition: border var(--base-transition), color var(--base-transition);
    border: 1px solid rgba(165, 164, 164, 1);
    color: rgba(112, 112, 112, 1);
    border-radius: 4px;
    margin-bottom: 8px;
    margin-right: 20px;
    position: relative;
    line-height: 30px;
    font-size: 14px;
    padding: 0 20px;
    cursor: pointer;
    height: 30px;

    .sku-set {
      border-bottom-color: rgba(42, 178, 255, 1);
      border-right-color: rgba(42, 178, 255, 1);
      border-left-color: rgba(255, 0, 0, 0);
      border-top-color: rgba(255, 0, 0, 0);
      border-style: solid;
      position: absolute;
      border-width: 8px;
      height: 16px;
      width: 16px;
      bottom: 0;
      right: 0;

      img {
        position: absolute;
        bottom: -8px;
        right: -8px;
        height: 8px;
        width: 8px;
      }
    }
  }

  .select,
  .sku-item:hover {
    // 规格鼠标移入和被选中
    border: 1px solid rgba(42, 178, 255, 1);
    color: rgba(42, 178, 255, 1);
  }
}
</style>