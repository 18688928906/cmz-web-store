<template>
  <!-- 选择数量 -->
  <div class="quantity-label">
    <span>数量</span>
    <span v-if="detail.Wholesale.Max <= 0">（售罄）</span>
    <span v-else-if="lack" class="A">（库存不足）</span>
    <span v-else-if="max" class="A">（Max）</span>
  </div>

  <!-- 数量选择器 -->
  <ElInputNumber
    v-model="detail.Quantity"
    :min="detail.Wholesale.Min"
    :max="detail.Wholesale.Max"
    :disabled="lack"
  />

  <div v-if="max && detail.Wholesale.Type" class="tips">
    批发商品购买数量不能小于商品最低购买数量
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    detail: undefined, // 商品详情
  },

  // 计算属性
  computed: {
    // 最大购买数量
    max: {
      get() {
        return this.detail.Quantity >= this.detail.Wholesale.Max;
      },
    },

    // 判断库存不足
    lack: {
      get() {
        if (this.max) {
          this.detail.Quantity = this.detail.Wholesale.Min;
          return true;
        } else {
          return false;
        }
      },
    },
  },

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.quantity-label {
  // 标题
  color: rgba(153, 153, 153, 1);
  padding-left: 16px;
  line-height: 1em;
  font-size: 14px;
  flex-shrink: 0;
  height: 1em;

  .A {
    color: red;
  }
}

.el-input-number {
  // 覆盖数字输入框属性
  margin-left: 16px;
  width: 122px;
  z-index: 0;

  :deep(span) {
    border-radius: var(--el-border-radius-base);
    background-color: rgba(240, 240, 240, 1);
    --el-color-primary: red;
    border: none;
  }

  :deep(.el-input) {
    --el-input-hover-border: rgba(0, 0, 0, 0);
    --el-input-border-color: rgba(0, 0, 0, 0);
    --el-input-hover-border-color: rgba(0, 0, 0, 0);
    --el-input-focus-border-color: rgba(0, 0, 0, 0);
  }
}

.tips {
  margin-left: 16px;
  font-size: 12px;
  color: red;
}
</style>