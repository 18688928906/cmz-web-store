<template>
  <!-- 按钮容器 -->
  <div class="button-box">
    <ElButton
      :disabled="disabled || detail?.Quantity >= detail?.Wholesale.Max"
      type="primary"
      @click="BuyNow()"
    >
      立即租赁
    </ElButton>
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    detail: undefined, // 商品详情
  },

  // 计算属性
  computed: {
    // 禁用按钮
    disabled: {
      get() {
        return !this.detail?.Sku && !this.detail.SkuId;
      },
    },
  },

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 检查规格
    CheckSku() {
      // 但规格模式直接返回ID
      if (this.detail.SkuId) {
        return this.detail.SkuId;
      }

      // 抽取为选择的规格
      const NullSku = this.detail.Sku?.List?.find((item) => !item.Select);

      // 检查没有选规格的情况
      if (!!NullSku) {
        ElMessage({
          message: "请选择" + NullSku.Label,
          showClose: true,
          grouping: true,
          type: "warning",
        });
      }

      // 处理有规格的选项
      else {
        // 拼接规格
        const Key = this.detail.Sku?.List.map((item) => item.Select).join(",");

        // 获取规格ID
        return this.detail.Sku?.IdKeys.find(
          (item) => item.Key.join(",") === Key
        )?.Id;
      }
    },

    // 立即购买
    BuyNow() {
      // 获取规格
      var Sku = undefined;

      // 检查登录用户
      if (!this.Api.UserLogin.Token) {
        // 未登录去登录
        this.$GO({
          path: "/login/account",
          data: { url: window.location.href },
        });
      } else {
        Sku = this.CheckSku();
      }

      if (!!Sku && this.detail.Wholesale.Max <= 0) {
        ElMessage({
          message: "此商品已售罄",
          showClose: true,
          grouping: true,
          type: "warning",
        });
      } else if (!!Sku && this.detail.Quantity <= 0) {
        ElMessage({
          message: "请选择购买数量",
          showClose: true,
          grouping: true,
          type: "warning",
        });
      } else if (!!Sku && this.detail.Quantity > this.detail.Wholesale.Max) {
        ElMessage({
          message: "购买数量超出库存",
          showClose: true,
          grouping: true,
          type: "warning",
        });
      } else if (!!Sku) {
        // 检查收货地址
        this.BUS.CheckAddress().then((_) => {
          // 跳转支付界面
          this.$GO({
            name: "LeaseBuy",
            data: {
              Id: this.detail.Id, // 商品ID
              Sku, // 商品规格
              Quantity: this.detail.Quantity, // 购买数量
              Term: this.detail.Day,
            },
          });
        });
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.button-box {
  // 按钮容器
  align-items: center;
  padding-left: 16px;
  display: flex;

  .el-button {
    // 覆盖
    --el-color-primary: rgba(42, 178, 255, 1);
    height: 40px;
    width: 160px;
  }

  .el-button + .el-button {
    margin-left: 18px;
  }
}
</style>