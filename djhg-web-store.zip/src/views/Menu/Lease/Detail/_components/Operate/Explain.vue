<template>
  <!-- 说明容器 -->
  <div class="explain-box">
    <div class="label">{{ label }}</div>
    <slot />
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    label: undefined, // 说明标题
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.explain-box {
  // 说明容器
  padding-left: 16px;
  display: flex;

  .label {
    // 标题
    color: rgba(153, 153, 153, 1);
    line-height: 1em;
    font-size: 14px;
    flex-shrink: 0;
    height: 1em;
    width: 48px;
  }
}
</style>