<template>
  <!-- 价格展示 -->
  <div class="collection-and-report">
    <!-- 收藏 -->
    <div class="collection" @click="collection = !collection">
      <template v-if="!collection">
        <img class="A" :src="$svg['i-0016-666666']" />
        <img class="B" :src="$svg['i-0016-FF0000']" />
      </template>
      <template v-else>
        <img class="A" :src="$svg['i-0017-FF0000']" />
        <img class="B" :src="$svg['i-0018-FF0000']" />
      </template>
      <span>收藏</span>
    </div>

    <div style="flex-grow: 1" />

    <div class="report" @click="report()">
      <img class="A" :src="$svg['i-0009']" />
      <img class="B" :src="$svg['i-0009-FF0000']" />
      <span>举报</span>
    </div>
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    detail: undefined, // 商品详情
  },

  // 计算属性
  computed: {
    // 收藏选项
    collection: {
      get() {
        return this.detail.Collection;
      },
      set(value) {
        this.api.SetData(value).then(($) => (this.detail.Collection = $));
      },
    },
  },

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    Api: undefined, // 收藏功能
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.api = this.ApiNew.LeaseCollectionAdd().init(this.detail.Id); // 初始化接口
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 举报按钮
    report() {
      this.$GO({ path: "/menu/lease/report", data: { Id: this.detail.Id } });
    },
  },
};
</script>

<style lang="scss" scoped>
.collection-and-report {
  // 收藏和举报
  align-items: center;
  margin-top: 30px;
  display: flex;
  width: 420px;

  .collection,
  .report {
    color: rgba(102, 102, 102, 1);
    cursor: pointer;
    font-size: 14px;
    flex-shrink: 0;

    &:hover {
      color: rgba(57, 123, 255, 1);
    }
  }

  .collection,
  .report {
    align-items: center;
    display: flex;

    img {
      margin-right: 10px;
      height: 18px;
      width: 18px;
    }

    .A {
      display: block;
    }

    .B {
      display: none;
    }

    &:hover {
      .A {
        display: none;
      }

      .B {
        display: block;
      }
    }
  }
}
</style>