<template>
  <!-- 单行 -->
  <div class="list-item">
    <!-- 用户信息 -->
    <div class="user-info">
      <img class="avatar" :src="item.User.Avatar" />
      <div class="name">{{ item.User.Name }}</div>
      <ElRate v-model="item.Avg" disabled />
    </div>

    <!-- 评语 -->
    <div class="content">{{ item.Content }}</div>

    <!-- 多媒体 -->
    <div class="media" v-if="item.Media.length > 0">
      <template v-for="($, i) in item.Media" :key="i">
        <!-- 显示视频 -->
        <div
          v-if="$.Type === 'video'"
          class="video-box"
          @click="OpenViedo($.Value)"
        >
          <video>
            <source :src="$.Value" type="video/mp4" />
          </video>
          <img :src="$svg['i-0012-FFFFFF']" />
        </div>

        <!-- 显示图片 -->
        <ElImage
          v-else-if="$.Type === 'img'"
          :preview-src-list="item.Media.map((t) => t.Value)"
          :src="$.Value"
          fit="contain"
          class="img"
        />
      </template>
    </div>

    <!-- 视频 -->
    <video v-if="!!Video" width="480" controls>
      <source :src="Video" type="video/mp4" />
    </video>

    <!-- 规格 -->
    <div class="sku">{{ item.Sku }}</div>

    <ElRow class="bottom-box">
      <!-- 发布时间 -->
      <div class="time">{{ item.Time }}</div>

      <!-- 占位 -->
      <div style="flex-grow: 1" />

      <!-- 点赞 -->
      <ElRow class="tsan" @click="Tsan()">
        <img :src="$svg['i-0038']" />
        <span>{{ item.Like || 0 }}</span>
      </ElRow>
    </ElRow>
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    item: undefined,
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    Video: undefined, // 存放视频
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 设置标签
    SetTag(item) {
      item.Select = !item.Select;
    },

    // 打开视频
    OpenViedo(src) {
      this.Video = src;
    },

    // 点赞
    Tsan() {
      this.Api.LeaseCommentsTsan.init(this.item.Id)
        .SetData()
        .then((_) => {
          this.item.Like++;
        });
    },
  },
};
</script>

<style lang="scss" scoped>
.list-item {
  // 单行容器
  border-bottom: 1px solid rgba(224, 224, 224, 1);
  flex-direction: column;
  padding: 20px 18px;
  display: flex;
  width: 900px;

  .user-info {
    // 用户信息
    align-items: center;
    display: flex;

    .avatar {
      // 用户头像
      border-radius: 18px;
      height: 33px;
      width: 34px;
    }

    .name {
      // 用户名称
      margin-right: 20px;
      margin-left: 12px;
      font-size: 14px;
    }
  }

  .content {
    // 评语
    width: calc(100% / 3 * 2);
    word-break: break-all;
    margin-top: 12px;
    font-size: 12px;
  }

  .media {
    // 媒体容器
    grid-template-columns: repeat(auto-fill, 52px);
    width: calc(100% / 3 * 2);
    grid-column-gap: 10px;
    grid-row-gap: 10px;
    margin-top: 12px;
    display: grid;

    .video-box,
    .img {
      height: 52px;
      width: 52px;
    }

    .video-box {
      // 视频容器
      background-color: black;
      position: relative;

      video {
        height: 100%;
        width: 100%;
      }

      img {
        position: absolute;
        height: 50%;
        width: 50%;
        left: 25%;
        top: 25%;
      }
    }
  }

  .media + video {
    margin-top: 12px;
  }

  .sku {
    margin-top: 12px;
  }

  .sku,
  .bottom-box > .time {
    // 规格和时间
    color: rgba(153, 153, 153, 1);
    font-size: 12px;
  }

  .bottom-box {
    // 底部容器
    align-items: center;
    margin-top: 12px;

    .tsan {
      // 点赞
      align-items: center;
      cursor: pointer;

      img {
        margin-right: 2px;
        height: 16px;
        width: 16px;
      }

      span {
        font-size: 14px;
      }
    }
  }
}
</style>