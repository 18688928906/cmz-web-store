<template>
  <!-- 评分容器 -->
  <div class="avg-box">
    <!-- 评分 -->
    <div class="avg">
      <div class="avg-text">商品评分</div>
      <div class="avg-count">{{ avg }}</div>
      <div class="hr" />
    </div>

    <!-- 标签 -->
    <div class="tag-box">
      <div
        v-for="(item, index) in tag"
        :key="index"
        :class="{ act: item.Select }"
        @click="SetTag(item)"
      >
        {{ item.Label }}{{ item.Value }}
      </div>
    </div>
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    avg: undefined, // 商品评分
    tag: undefined, // 评价标签
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 设置标签
    SetTag(item) {
      item.Select = !item.Select;
    },
  },
};
</script>

<style lang="scss" scoped>
.avg-box {
  // 评分容器
  border-bottom: 1px solid rgba(224, 224, 224, 1);
  display: flex;
  width: 900px;

  .avg {
    // 评分
    flex-direction: column;
    align-items: center;
    position: relative;
    flex-shrink: 0;
    display: flex;
    height: 112px;
    width: 160px;

    div {
      line-height: 1em;
    }

    .avg-text {
      color: rgba(165, 164, 164, 1);
      margin-top: 8px;
      font-size: 14px;
    }

    .avg-count {
      margin-top: 16px;
      font-size: 36px;
      color: red;
    }

    .hr {
      background-color: rgba(224, 224, 224, 1);
      top: calc((100% - 50px) / 2);
      position: absolute;
      height: 50px;
      width: 1px;
      right: 0;
    }
  }

  .tag-box {
    // 标签容器
    margin-bottom: -40px;
    margin-right: -40px;
    align-items: center;
    padding: 16px 26px;
    min-height: 112px;
    flex-wrap: wrap;
    display: flex;
    flex-grow: 1;

    div {
      background-color: rgba(245, 245, 245, 1);
      margin-bottom: 40px;
      margin-right: 40px;
      border-radius: 2px;
      line-height: 30px;
      font-size: 14px;
      padding: 0 12px;
      cursor: pointer;
    }

    div:hover,
    .act {
      background-color: rgba(254, 239, 239, 1);
      color: rgba(247, 81, 81, 1);
    }
  }
}
</style>