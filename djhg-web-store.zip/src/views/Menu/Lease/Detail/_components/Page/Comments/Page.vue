<template>
  <!-- 嵌入界面 -->
  <div class="page-box">
    <!-- 评分 -->
    <Avg :avg="Avg" :tag="Tag" />

    <!-- 页签 -->
    <TabBox v-if="Tabs.length > 0" :tabs="Tabs" />

    <ListItem v-for="(item, index) in List" :key="index" :item="item" />
  </div>
</template>

<script>
import Avg from "./Avg.vue";
import TabBox from "./TbaBox.vue";
import ListItem from "./ListItem.vue";

export default {
  // 组件
  components: { Avg, TabBox, ListItem },

  // 接收参数
  props: {
    detail: undefined, // 商品详情
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    Avg: Number(0), // 总评分

    Tag: Array(0), // 评价标签
    Tabs: Array(0), // 分类页签
    List: Array(0), // 评价列表
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 接口初始化，并订阅数据更新
    this.Api.LeaseCommentsList.init({ Id: this.detail.Id })
      .AddUpdate("LeaseComments", (item) => {
        Object.keys(item).forEach(($) => (this[$] = item[$]));
      })
      .GetData();
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    this.Api.LeaseCommentsList.DelUpdate("LeaseComments"); // 取消订阅
  },

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
</style>