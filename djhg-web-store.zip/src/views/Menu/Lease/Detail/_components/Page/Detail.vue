<template>
  <!-- 嵌入界面 -->
  <div class="page-box">
    <!-- 参数显示 -->
    <ElDescriptions
      v-for="(item, index) in Parameters"
      :title="item.Group"
      :key="index"
      :column="4"
    >
      <ElDescriptionsItem
        v-for="($, i) in item.List"
        :span="$.span || 1"
        :label="$.Label"
        :width="225"
        :key="i"
      >
        <span :ref="index + '-' + i">{{ $.Value }}</span>
      </ElDescriptionsItem>
    </ElDescriptions>

    <img
      v-for="(item, index) in detail.Imgs"
      :key="index"
      :src="item"
      style="width: 900px"
    />
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    detail: undefined, // 商品详情
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    Parameters: undefined,
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.Parameters = this.detail.Parameters;
  },

  // 生命周期函数：挂载后调用
  mounted() {
    this.$nextTick(() => {
      this.Parameters = this.Parameters?.map((item, index) => {
        item.List.forEach(($, i) => {
          var span = this.$refs[index + "-" + i][0];
          span = span.parentElement.parentElement; // 获取父级
          span = Math.ceil(span.clientWidth / 225); // 计算所需行数
          $.span = span > 4 ? 4 : span;
        });
        return item;
      });
    });
  },

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.page-box {
  padding-top: 16px;

  :deep(.el-descriptions) {
    .el-descriptions__header {
      .el-descriptions__title {
        color: rgba(153, 153, 153, 1);
        font-weight: normal;
        font-size: 12px;
      }
    }
  }
}
</style>