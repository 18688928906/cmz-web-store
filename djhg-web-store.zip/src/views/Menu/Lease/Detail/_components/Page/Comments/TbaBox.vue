<template>
  <!-- 页签容器 -->
  <div class="tab-box">
    <div
      v-for="item in tabs"
      :class="{ act: index === item.Key }"
      :key="item.Key"
      @click="item.Count > 0 && (index = item.Key)"
    >
      {{ item.Label }}（{{ item.Count || 0 }}）
    </div>

    <!-- 占位框 -->
    <div style="flex-grow: 1" />

    <ElSelect
      v-model="sort"
      size="small"
      @change="Api.ShopCommentsList.SetSort($event)"
    >
      <ElOption label="综合排序" value="synthetically" />
      <ElOption label="最新排序" value="desc" />
    </ElSelect>
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: { tabs: undefined },

  // 计算属性
  computed: {
    // 配置被选中的项目
    index: {
      get() {
        return this._index;
      },
      set(value) {
        this._index = value;
        this.Api.ShopCommentsList.SetType(value);
      },
    },
  },

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    _index: 0, // 配置被选中的项目

    sort: "synthetically",
  }),

  // 生命周期函数：挂载前调用
  created() {
    this._index = this.tabs[0].Key; // 初始化选项
    this.BUS.GetShopDetailCommentsContent(this.tabs[0].Count); // 记录总数
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.tab-box {
  // 说明容器
  border-bottom: 1px solid rgba(224, 224, 224, 1);
  align-items: center;
  padding-left: 16px;
  display: flex;
  width: 900px;
  height: 50px;

  div {
    transition: color var(--base-transition);
    color: rgba(153, 153, 153, 1);
    text-align: center;
    line-height: 1em;
    font-size: 14px;
    cursor: pointer;
    flex-shrink: 0;
  }

  div + div {
    margin-left: 30px;
  }

  .act,
  div:hover {
    color: var(--base-color);
  }

  .el-select {
    // 覆盖样式
    --el-border-color-hover: rgba(0, 0, 0, 0);
    --el-color-primary: rgba(0, 0, 0, 0);
    --el-border-color: rgba(0, 0, 0, 0);
    width: 85px;
  }
}
</style>