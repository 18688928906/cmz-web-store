<template>
  <PageA v-show="index === 0" :detail="detail" />
  <PageB v-show="index === 1" :detail="detail" />
  <PageC v-show="index === 2" :detail="detail" />
</template>

<script>
import PageA from "./Detail.vue";
import PageB from "./Parameters.vue";
import PageC from "./Comments/Page.vue";

export default {
  // 组件
  components: { PageA, PageB, PageC },

  // 接收参数
  props: {
    detail: undefined, // 商品详情
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    index: 0, // 配置被选中的项目
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 订阅页签切换
    this.BUS.SetShopDetailIndex = (index) => (this.index = index);
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    delete this.BUS.SetShopDetailIndex; // 取消订阅
  },

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.page-box {
  // 页面容器
  flex-direction: column;
  align-items: stretch;
  display: flex;
  width: 900px;
}
</style>