<template>
  <!-- 嵌入界面 -->
  <div class="page-box">
    <div v-for="item in detail.Parameters" :key="item.Group" class="group">
      <div class="title">{{ item.Group }}</div>
      <div class="item-box">
        <div v-for="($, i) in item.List" :key="i" class="item">
          <div class="L">{{ $.Label }}</div>
          <div class="R">{{ $.Value }}</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    detail: undefined, // 商品详情
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.group {
  padding: 32px 0;
  display: flex;
  width: 900px;

  .title {
    text-align: right;
    font-size: 12px;
    flex-shrink: 0;
    width: 124px;
  }

  .item-box {
    flex-grow: 1;

    .item {
      display: flex;

      div {
        line-height: 16px;
        font-size: 12px;
      }

      .L {
        text-align: right;
        width: 152px;
      }

      .R {
        margin-left: 20px;
      }
    }

    .item + .item {
      margin-top: 12px;
    }
  }
}

.specific + .specific {
  border-top: 1px solid rgba(220, 223, 230, 1);
}
</style>