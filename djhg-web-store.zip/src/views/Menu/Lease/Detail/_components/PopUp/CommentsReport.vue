<template>
  <!-- 用户举报评价 -->
  <transition name="report">
    <div v-if="show" class="report-box">
      <!-- 内框 -->
      <div class="report-box-in">
        <div class="title">
          <div></div>
          <div></div>
          <div>
            <img src="" alt="" />
            <img src="" alt="" />
          </div>
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    guid: undefined, // 所属界面的唯一ID，由界面写入

    BusKey: ["ShopCommentsReport"], // 订阅名称，组件卸载后清理订阅会用到

    show: Boolean(false), // 控制显示
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.BUS[this.BusKey[0]] = (show = true) => {
      if (!!show) {
        this.show = true;
      } else {
        this.close();
      }
    };
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 关闭操作
    close() {
      this.show = false;
    },
  },
};
</script>

<style lang="scss" scoped>
.report-box {
  // 外框
  background-color: rgba(0, 0, 0, 0.2);
  position: fixed;
  height: 100vh;
  width: 100vw;
  left: 0;
  top: 0;

  .report-box-in {
    // 内框
    background-color: rgba(255, 255, 255, 1);
    transform: translate(-50%, -50%);
    position: absolute;
    width: 628px;
    left: 50%;
    top: 50%;
  }
}

.report-leave-from {
  opacity: 1;
}

.report-leave-active {
  transition: opacity var(--base-transition);
}

.report-leave-to {
  opacity: 0;
}

.report-enter-from {
  opacity: 0;
}

.report-enter-active {
  transition: opacity var(--base-transition);
}

.report-enter-to {
  opacity: 1;
}
</style>