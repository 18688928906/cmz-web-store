<template>
  <!-- 成功加入购物车 -->
  <transition name="addToCart">
    <div v-if="show" class="add-to-cart-succeed">
      <img class="logo" :src="$svg['i-0014-7ABD54']" />
      <div class="text">成功加入购物车！</div>
      <div class="close" @click="close()">
        <img class="A" :src="$svg['i-0015-9D9D9D']" />
        <img class="B" :src="$svg['i-0015-FF0000']" />
      </div>
    </div>
  </transition>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    guid: undefined, // 所属界面的唯一ID，由界面写入
    timeout: undefined, // 定时器

    BusKey: ["ShowAddToCartSucceed"], // 订阅名称，组件卸载后清理订阅会用到

    show: Boolean(false), // 控制显示
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.BUS[this.BusKey[0]] = (show = this.show) => {
      if (!!show) {
        this.show = true;
        const close = this.close;
        clearTimeout(this.timeout);
        this.timeout = setTimeout(close, 1500);
      } else {
        this.close();
      }
    };
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 关闭操作
    close() {
      this.show = false;
    },
  },
};
</script>

<style lang="scss" scoped>
.add-to-cart-succeed {
  // 外框
  box-shadow: var(--base-shadow);
  left: calc(50vw - 380px / 2);
  top: calc(50vh - 70px / 2);
  background-color: white;
  align-items: center;
  border-radius: 4px;
  position: fixed;
  display: flex;
  height: 70px;
  width: 380px;

  .logo {
    // 图标
    margin-left: 16px;
    flex-shrink: 0;
    height: 30px;
    width: 30px;
  }

  .text {
    // 显示文字
    color: rgba(122, 189, 84, 1);
    margin-left: 10px;
    font-size: 18px;
    flex-grow: 1;
  }

  .close {
    // 关闭
    margin-right: 16px;
    cursor: pointer;
    height: 12px;
    width: 12px;

    img {
      height: 100%;
      width: 100%;
    }

    .A {
      display: block;
    }

    .B {
      display: none;
    }
  }

  .close:hover {
    .A {
      display: none;
    }

    .B {
      display: block;
    }
  }
}

.addToCart-leave-from {
  opacity: 1;
}

.addToCart-leave-active {
  transition: opacity var(--base-transition);
}

.addToCart-leave-to {
  opacity: 0;
}

.addToCart-enter-from {
  opacity: 0;
}

.addToCart-enter-active {
  transition: opacity var(--base-transition);
}

.addToCart-enter-to {
  opacity: 1;
}
</style>