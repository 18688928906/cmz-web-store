<template>
  <PageA v-show="index === 0" :detail="detail" />
</template>

<script>
import PageA from "./Detail.vue";

export default {
  // 组件
  components: { PageA },

  // 接收参数
  props: {
    detail: undefined, // 商品详情
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    index: 0, // 配置被选中的项目
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.page-box {
  // 页面容器
  flex-direction: column;
  align-items: stretch;
  display: flex;
  width: 1200px;
}
</style>