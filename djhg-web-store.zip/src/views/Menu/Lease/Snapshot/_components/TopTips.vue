<template>
  <div class="top-tips">
    <!-- 用户提示 -->
    <img :src="$svg['i-0027-FAAD15']" />
    <span>
      提醒：当前页面为订单快照，包含订单创建时的商品信息和下单信息，买卖双方存在争议时，此页面可作为判断依据。
    </span>
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.top-tips {
  // 提醒框
  background-color: rgba(255, 251, 230, 1);
  border: 1px solid rgba(255, 229, 143, 1);
  color: rgba(95, 90, 89, 1);
  align-items: center;
  border-radius: 4px;
  margin-top: 16px;
  font-size: 14px;
  display: flex;
  width: 1200px;
  height: 36px;

  img {
    margin: 0 8px 0 20px;
    height: 16px;
    width: 16px;
  }
}
</style>