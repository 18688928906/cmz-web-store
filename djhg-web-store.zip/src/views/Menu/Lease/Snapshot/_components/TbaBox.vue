<template>
  <!-- 页签容器 -->
  <div class="tab-box">
    <div class="act">商品详情</div>
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.tab-box {
  // 说明容器
  background-color: white;
  position: relative;
  margin-top: 40px;
  display: flex;
  width: 1200px;

  div {
    transition: background-color var(--base-transition);
    background-color: white;
    color: var(--base-color);
    text-align: center;
    line-height: 50px;
    font-size: 14px;
    cursor: pointer;
    height: 50px;
    width: 160px;
  }

  .act {
    background-color: rgba(42, 178, 255, 1);
    color: white;
  }

  &::after {
    background-color: rgba(224, 224, 224, 1);
    position: absolute;
    width: 1200px;
    content: "";
    height: 1px;
    bottom: 0;
    left: 0;
  }
}
</style>