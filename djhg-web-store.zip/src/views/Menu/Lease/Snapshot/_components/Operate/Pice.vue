<template>
  <!-- 价格展示 -->
  <div class="pice-box">
    <div class="currency">{{ detail.Currency }}</div>
    <div class="price">{{ detail.Price }}</div>
    <!-- <div class="sale">销量：{{ detail.Sale }}</div> -->
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    detail: undefined, // 商品详情
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.pice-box {
  // 商品价格
  background-color: rgba(255, 247, 232, 1);
  align-items: baseline;
  border-radius: 4px;
  padding: 12px 16px;
  display: flex;

  div {
    line-height: 1em;
  }

  .currency {
    // 货币种类
    font-size: 16px;
    color: red;
    height: 1em;
  }

  .price {
    // 价格
    font-size: 20px;
    flex-grow: 1;
    color: red;
    height: 1em;
  }

  .sale {
    // 销量
    color: rgba(153, 153, 153, 1);
    margin-left: 10px;
    font-size: 12px;
    height: 1em;
  }
}
</style>