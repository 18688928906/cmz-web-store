<template>
  <!-- 选择规格 -->
  <template v-for="(item, index) in Object.keys(detail.Sku)" :key="index">
    <!-- 规格标题 -->
    <div class="sku-label">{{ item }}</div>

    <!-- 规格选项 -->
    <div class="sku-list">
      <!-- 不带图的单个选项 -->
      <div class="sku-item select">
        <span>{{ detail.Sku[item] }}</span>

        <!-- 选中时的标识 -->
        <div class="sku-set">
          <img :src="$svg['i-0021-FFFFFF']" />
        </div>
      </div>
    </div>
  </template>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    detail: undefined, // 商品详情
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.sku-label {
  // 标题
  color: rgba(153, 153, 153, 1);
  padding-left: 16px;
  line-height: 1em;
  font-size: 14px;
  flex-shrink: 0;
  height: 1em;
}

.sku-list {
  // 规格列表
  margin-bottom: -8px;
  margin-right: -20px;
  padding-left: 16px;
  flex-wrap: wrap;
  display: flex;

  .sku-item {
    // 规格选项
    transition: border var(--base-transition), color var(--base-transition);
    border: 1px solid rgba(165, 164, 164, 1);
    color: rgba(112, 112, 112, 1);
    border-radius: 4px;
    margin-bottom: 8px;
    margin-right: 20px;
    position: relative;
    line-height: 30px;
    font-size: 14px;
    padding: 0 20px;
    cursor: pointer;
    height: 30px;

    .sku-set {
      border-bottom-color: rgba(42, 178, 255, 1);
      border-right-color: rgba(42, 178, 255, 1);
      border-left-color: rgba(255, 0, 0, 0);
      border-top-color: rgba(255, 0, 0, 0);
      border-style: solid;
      position: absolute;
      border-width: 8px;
      height: 16px;
      width: 16px;
      bottom: 0;
      right: 0;

      img {
        position: absolute;
        bottom: -8px;
        right: -8px;
        height: 8px;
        width: 8px;
      }
    }
  }

  .select,
  .sku-item:hover {
    // 规格鼠标移入和被选中
    border: 1px solid rgba(42, 178, 255, 1);
    color: rgba(42, 178, 255, 1);
  }
}
</style>