<template>
  <ScrollBar v-if="detail" style="background-color: white">
    <!-- 开发信息 -->
    <div v-if="DEV && !!detail" class="DEV" style="left: 0">
      ID：{{ detail.Id }}
    </div>

    <!-- 顶栏 -->
    <TopBar ref="T" />

    <!-- 顶部提醒 -->
    <TopTips />

    <!-- 详情操作容器 -->
    <ProductDetailBox style="margin-top: 12px">
      <!-- 轮播图容器 -->
      <ProductDetailBanner
        :login="!detail"
        :list="detail.Cover?.List"
        :loupe="false"
      />

      <!-- 操作容器 -->
      <Operate :detail="detail" />
    </ProductDetailBox>

    <!-- 页签 -->
    <TabBox />

    <div class="virtual-pages">
      <!-- 页面容器 -->
      <PageBox :detail="detail" />
    </div>
  </ScrollBar>
</template>

<script>
import { GUID } from "@/library.js";

import TopTips from "./_components/TopTips.vue";
import Operate from "./_components/Operate/Box.vue";
import TabBox from "./_components/TbaBox.vue";
import PageBox from "./_components/Page/Box.vue";

export default {
  meta: {
    title: undefined, // 写入浏览器页签
    index: undefined, // 用于排序
    label: undefined, // 显示用的路由名称
    name: "LeaseSnapshot", // 路由名称

    open: Boolean(true), // 是否在新页面中打开
    token: Boolean(false), // 控制是否需要登录
  },

  // 组件
  components: { TopTips, Operate, TabBox, PageBox },

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    guid: GUID(), // 唯一ID

    detail: undefined, // 商品详情
    login: undefined, // 用户是否登录

    fixed: false, // 控制是否吸顶
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 检查登录数据
    this.login = this.Api.UserLogin.Token;

    // 订阅登录状态改变
    this.Api.UserLogin.AddUpdate(this.guid, ($) => (this.login = $));

    // 初始化并订阅数据
    this.Api.LeaseSnapshot.init(this.query.Id)
      .AddUpdate(this.guid, (detail) => {
        this.detail = undefined;
        this.detail = detail;
      })
      .GetData();
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    // 删除订阅
    this.Api.LeaseSnapshot.DelUpdate(this.guid);
    this.Api.UserLogin.DelUpdate(this.guid);
  },

  // 生命周期函数：离开后调用
  unmounted() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.virtual-pages {
  justify-content: space-between;
  align-items: flex-start;
  display: flex;
  width: 1200px;
}
</style>