<template>
  <!-- 商品容器 -->
  <ElRow class="product-box">
    <!-- 商品图片 -->
    <img class="logo" :src="detail.Img" />

    <!-- 商品详情 -->
    <ElRow class="info">
      <!-- 商品名称 -->
      <div class="name">{{ detail.Name }}</div>

      <!-- 商品规格 -->
      <div class="sku">{{ detail.Sku.join("，") }}</div>

      <!-- 商品价格 -->
      <ElRow class="price">
        <span>{{ detail.Currency }}</span>
        <span>{{ detail.Price }}</span>
      </ElRow>
    </ElRow>
  </ElRow>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    detail: undefined,
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.product-box {
  // 商品容器
  .logo {
    border-radius: 4px;
    flex-shrink: 0;
    height: 80px;
    width: 80px;
  }

  .info {
    // 商品详情
    justify-content: space-between;
    flex-direction: column;
    margin-left: 12px;
    flex-grow: 1;

    .name {
      // 商品名称
      font-size: 14px;
    }

    .sku {
      // 商品规格
      color: rgba(158, 158, 158, 1);
      font-size: 12px;
    }

    .price {
      // 商品价格
      align-items: baseline;
      font-size: 14px;
      color: red;

      span + span {
        font-size: 20px;
      }
    }
  }
}
</style>