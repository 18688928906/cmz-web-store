<template>
  <!-- 标签容器 -->
  <ElRow class="tag-box">
    <div
      v-for="(item, index) in tags"
      :class="{ select: item.Select }"
      :key="index"
      class="tag-item"
      @click="item.Select = !item.Select"
    >
      <span>{{ item.Label }}</span>

      <!-- 选中时的标识 -->
      <div v-if="item.Select" class="tag-set">
        <img :src="$svg['i-0021-FFFFFF']" />
      </div>
    </div>
  </ElRow>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    tags: undefined,
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.tag-box {
  // 商品容器
  margin-bottom: -8px;
  margin-right: -20px;
  margin-top: 20px;

  .tag-item {
    // 规格选项
    transition: border var(--base-transition), color var(--base-transition);
    border: 1px solid rgba(165, 164, 164, 1);
    color: rgba(112, 112, 112, 1);
    border-radius: 4px;
    margin-bottom: 8px;
    margin-right: 20px;
    position: relative;
    line-height: 30px;
    font-size: 14px;
    padding: 0 20px;
    cursor: pointer;
    height: 30px;

    .tag-set {
      border-bottom-color: var(--brand-1-5);
      border-right-color: var(--brand-1-5);
      border-left-color: rgba(0, 0, 0, 0);
      border-top-color: rgba(0, 0, 0, 0);
      border-style: solid;
      position: absolute;
      border-width: 8px;
      height: 16px;
      width: 16px;
      bottom: 0;
      right: 0;

      img {
        position: absolute;
        bottom: -8px;
        right: -8px;
        height: 8px;
        width: 8px;
      }
    }
  }

  .select,
  .tag-item:hover {
    // 规格鼠标移入和被选中
    border: 1px solid var(--brand-1-5);
    color: var(--brand-1-5);
  }
}
</style>