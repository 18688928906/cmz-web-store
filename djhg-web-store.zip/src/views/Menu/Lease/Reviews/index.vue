<template>
  <ScrollBar v-if="detail" style="background-color: white">
    <!-- 顶栏 -->
    <TopBar label="评价商品" />

    <!-- 评价容器 -->
    <ElRow class="reviews-box">
      <!-- 订单详情 -->
      <Detail
        v-for="(item, index) in detail.List"
        :detail="item"
        :key="index"
      />

      <!-- 选择标签 -->
      <TagBox :tags="tags" />

      <!-- 表单 -->
      <ElForm
        :model="form"
        :rules="rules"
        label-position="left"
        label-width="auto"
        ref="$"
      >
        <!-- 校验大于零 -->
        <ElFormItem prop="Quality" label="商品品质">
          <ElRate
            v-model="form.Quality"
            score-template="{value} 分"
            show-score
          />
        </ElFormItem>

        <!-- 校验大于零 -->
        <ElFormItem prop="Service" label="服务态度">
          <ElRate
            v-model="form.Service"
            score-template="{value} 分"
            show-score
          />
        </ElFormItem>

        <!-- 校验大于零 -->
        <ElFormItem prop="Logistics" label="快递物流">
          <ElRate
            v-model="form.Logistics"
            score-template="{value} 分"
            show-score
          />
        </ElFormItem>

        <!-- 不校验 -->
        <ElFormItem label="评价商品">
          <ElInput
            v-model="form.Content"
            :maxlength="150"
            :rows="4"
            placeholder="请在此输入您的评价"
            style="width: 700px"
            type="textarea"
            resize="none"
            show-word-limit
          />
        </ElFormItem>

        <!-- 不校验 -->
        <ElFormItem label="上传">
          <Upload v-model:file="form.File" />
        </ElFormItem>
      </ElForm>

      <!-- 按钮容器 -->
      <ElRow class="button-box">
        <div class="button" @click="upload()">提交</div>
      </ElRow>
    </ElRow>
  </ScrollBar>
</template>

<script>
import Detail from "./_components/Detail.vue";
import TagBox from "./_components/TagBox.vue";
import Upload from "./_components/Upload.vue";

export default {
  // 自动路由参数，配置看App.vue
  meta: {
    title: undefined, // 写入浏览器页签
    index: undefined, // 用于排序
    label: undefined, // 显示用的路由名称
    name: "LeaseReviews", // 路由名称

    open: Boolean(true), // 是否在新页面中打开
    token: Boolean(false), // 控制是否需要登录
  },

  // 组件
  components: { Detail, TagBox, Upload },

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    detail: undefined,
    tags: undefined,

    // 表单
    form: {
      Content: "", // 评价详情
      Quality: 0, // 商品品质
      Service: 0, // 服务态度
      Logistics: 0, // 快递物流
      File: Array(0), // 上传文件
    },

    // 校验
    rules: {
      Quality: [
        {
          validator: (_, value, callback) =>
            callback(value > 0 ? undefined : new Error("请评价商品品质")),
          trigger: "blur",
        },
      ],
      Service: [
        {
          validator: (_, value, callback) =>
            callback(value > 0 ? undefined : new Error("请评价服务态度")),
          trigger: "blur",
        },
      ],
      Logistics: [
        {
          validator: (_, value, callback) =>
            callback(value > 0 ? undefined : new Error("请评价快递物流")),
          trigger: "blur",
        },
      ],
    },
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 获取订单详情
    this.Api.LeaseOrderDetail.init(this.query)
      .AddUpdate("LeaseReviews", (detail) => (this.detail = detail))
      .GetData()
      .then(($) =>
        // 获取评价标签
        this.Api.LeaseOrderReviewsTag.init({
          Id: $.List[0].ProductId,
        })
          .GetData()
          .then((tags) => (this.tags = tags))
      );
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 上传数据
    upload() {
      this.$refs.$.validate().then(($) => {
        if ($) {
          this.form.Id = this.detail.Id; // 记录订单ID

          // 拼接标签ID
          this.form.Tag = this.tags
            .filter((item) => item.Select)
            .map((item) => item.Value)
            .join(",");

          //  清理没有标签
          this.form.Tag === "" && (this.form.Tag = undefined);

          // 获取视频
          this.form.Video =
            this.form.File.find(
              (item) => item.raw?.type?.split("/")[0] === "video"
            )?.response?.data?.url || undefined;

          // 判断图片
          if (!this.form.Video) {
            this.form.Img = this.form.File.map(
              (item) => item.response.data.url
            ).join(",");
          }

          // 调用接口
          this.Api.LeaseOrderReviewsAdd.init(this.form)
            .SetData()
            .then((_) => {
              // 支付成功跳转订单详情界面
              this.$GO({
                name: "LeaseOrderDetail",
                data: { Id: this.detail.Id },
              });
              window.close(); // 关闭界面
            });
        }
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.reviews-box {
  // 评价容器
  box-shadow: var(--base-shadow);
  flex-direction: column;
  border-radius: 4px;
  margin-top: 20px;
  padding: 20px;
  width: 1200px;

  .el-form {
    // 表单
    margin-top: 20px;

    .el-form-item {
      :deep(.el-form-item__content) {
        line-height: normal;
      }
    }
  }

  .button-box {
    // 按钮容器
    justify-content: center;
    margin-top: 20px;

    .button {
      background-color: rgba(240, 45, 45, 1);
      justify-content: center;
      align-items: center;
      border-radius: 4px;
      font-size: 16px;
      cursor: pointer;
      color: white;
      display: flex;
      height: 44px;
      width: 320px;

      &:hover {
        background-color: rgb(233, 84, 84);
      }
    }
  }
}
</style>