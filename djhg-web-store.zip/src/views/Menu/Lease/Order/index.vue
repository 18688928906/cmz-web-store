<template>
  <ScrollBar v-if="detail">
    <!-- 顶栏 -->
    <TopBar label="订单详情" />

    <!-- 面包屑 -->
    <Breadcrumb />

    <!-- 订单状态 -->
    <Status :detail="detail" />

    <!-- 订单操作 -->
    <Operate :detail="detail" />

    <!-- 用户信息 -->
    <User :detail="detail" />

    <!-- 物流信息 -->
    <Exp v-if="!detail.PickUp" :detail="detail" />

    <!-- 店铺信息 -->
    <div class="store-box">
      <div class="name">{{ detail.Store.Name }}</div>
      <img :src="$svg['i-0023-5C67F5']" />
      <div class="button">联系商家</div>
    </div>

    <Detail :detail="detail" />
  </ScrollBar>
</template>

<script>
import Breadcrumb from "./_components/Breadcrumb.vue";
import Status from "./_components/Status.vue";
import Operate from "./_components/Operate.vue";
import User from "./_components/User.vue";
import Exp from "./_components/Exp.vue";
import Detail from "./_components/Detail.vue";
import ConfirmReceipt from "./_components/PopUp/ConfirmReceipt.vue";
import Cancel from "./_components/PopUp/Cancel.vue";

export default {
  // 自动路由参数，配置看App.vue
  meta: {
    title: undefined, // 写入浏览器页签
    index: undefined, // 用于排序
    label: undefined, // 显示用的路由名称
    name: "LeaseOrderDetail", // 路由名称

    open: Boolean(true), // 是否在新页面中打开
    token: Boolean(false), // 控制是否需要登录
  },

  // 组件
  components: { Breadcrumb, Status, Operate, User, Exp, Detail },

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    detail: undefined,
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 获取订单详情
    this.Api.LeaseOrderDetail.init(this.query)
      .AddUpdate("LeaseOrderDetail", (detail) => (this.detail = detail))
      .GetData();

    // 挂载弹出框
    this.BUS.AddPopUp("ConfirmReceipt", ConfirmReceipt);
    this.BUS.AddPopUp("Cancel", Cancel);
    this.BUS.AddPopUp("Invoice", Invoice);
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    this.BUS.DelPopUp("ConfirmReceipt"); // 卸载弹出框
    this.BUS.DelPopUp("Cancel");
    this.BUS.DelPopUp("Invoice");
  },

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.store-box {
  // 店铺信息
  align-items: center;
  margin-top: 16px;
  display: flex;
  width: 1200px;

  .name,
  .button {
    // 店铺名称和按钮
    transition: all var(--base-transition);
    color: rgba(16, 16, 16, 0.6);
    font-size: 12px;
  }

  .button {
    cursor: pointer;

    &:hover {
      color: red;
    }
  }

  img {
    margin-right: 4px;
    margin-left: 24px;
    height: 16px;
    width: 16px;
  }
}
</style>