<template>
  <!-- 用户举报评价 -->
  <transition name="confirm">
    <div v-if="show" class="confirm-box">
      <!-- 内框 -->
      <div class="confirm-box-in">
        <!-- 时间图标 -->
        <img class="time-logo" :src="TimeImg" />

        <!-- 标题 -->
        <div class="title">确认收货</div>

        <!-- 提示 -->
        <div class="tips">
          为保障您的售后权益，收到商品请检查无误后再确认收货
        </div>

        <!-- 按钮容器 -->
        <div class="button-box">
          <div class="A" @click="close()">取消</div>
          <div class="B" @click="confirm()">确认收货</div>
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
import TimeImg from "@/assets/time.png";
export default {
  // 组件
  components: {},

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    TimeImg, // 显示图片

    guid: undefined, // 所属界面的唯一ID，由界面写入
    confirm: undefined,

    BusKey: ["LeaseConfirmReceipt"], // 订阅名称，组件卸载后清理订阅会用到

    show: Boolean(false), // 控制显示
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.BUS[this.BusKey[0]] = (orderId = undefined) =>
      new Promise((resolve) => {
        if (!!orderId) {
          this.show = true;
        } else {
          this.close();
        }

        // 定义回调
        this.confirm = () => {
          if (!!orderId) {
            this.Api.LeaseOrderReceipt.SetData(orderId).then(($) => {
              this.close();
              resolve($);
            });
          }
        };
      });
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 关闭操作
    close() {
      this.show = false;
    },
  },
};
</script>

<style lang="scss" scoped>
.confirm-box {
  // 外框
  background-color: rgba(0, 0, 0, 0.2);
  position: fixed;
  height: 100vh;
  width: 100vw;
  left: 0;
  top: 0;

  .confirm-box-in {
    // 内框
    background-color: rgba(255, 255, 255, 1);
    transform: translate(-50%, -50%);
    flex-direction: column;
    align-items: center;
    border-radius: 4px;
    position: absolute;
    display: flex;
    width: 412px;
    left: 50%;
    top: 50%;

    .time-logo {
      // 时间图标
      margin-top: 24px;
      height: 120px;
      width: 120px;
    }

    .title {
      // 标题
      font-size: 18px;
      margin: 20px;
    }

    .tips {
      // 提示
      color: rgba(187, 187, 187, 1);
      margin-bottom: 52px;
      font-size: 14px;
    }

    .button-box {
      // 按钮容器
      margin-bottom: 20px;
      align-items: center;
      display: flex;

      div {
        transition: all var(--base-transition);
        justify-content: center;
        border-style: solid;
        align-items: center;
        border-radius: 4px;
        border-width: 1px;
        font-size: 12px;
        cursor: pointer;
        display: flex;
        height: 28px;
        width: 68px;
      }

      div + div {
        margin-left: 40px;
      }

      .A {
        border-color: rgba(193, 194, 197, 1);
        color: rgba(59, 59, 59, 1);

        &:hover {
          border-color: rgba(53, 116, 240, 1);
          color: rgba(53, 116, 240, 1);
        }
      }

      .B {
        border-color: rgba(53, 116, 240, 1);
        color: rgba(53, 116, 240, 1);
        background-color: white;

        &:hover {
          background-color: rgba(53, 116, 240, 1);
          color: white;
        }
      }
    }
  }
}

.confirm-leave-from {
  opacity: 1;
}

.confirm-leave-active {
  transition: opacity var(--base-transition);
}

.confirm-leave-to {
  opacity: 0;
}

.confirm-enter-from {
  opacity: 0;
}

.confirm-enter-active {
  transition: opacity var(--base-transition);
}

.confirm-enter-to {
  opacity: 1;
}
</style>