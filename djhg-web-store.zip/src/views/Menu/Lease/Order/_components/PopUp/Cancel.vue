<template>
  <!-- 用户举报评价 -->
  <transition name="cancel">
    <div v-if="show" class="cancel-box">
      <!-- 内框 -->
      <div class="cancel-box-in">
        <!-- 标题容器 -->
        <div class="title-box">
          <div class="title">取消订单</div>
          <div class="img-box" @click="close()">
            <img class="A" :src="$svg['i-0015']" />
            <img class="B" :src="$svg['i-0015-FF0000']" alt="" />
          </div>
        </div>

        <!-- 提示 -->
        <ElRow class="tips-box">
          <img :src="$svg['i-0027-FAAD15']" />
          <span>取消成功后的订单将无法恢复</span>
        </ElRow>

        <!-- 选择表单 -->
        <ElForm :model="form" :rules="rules" style="margin-top: 20px" ref="$">
          <!-- 选择原因 -->
          <ElFormItem label="取消原因：" prop="Type">
            <ElSelect v-model="form.Type" placeholder="请选择取消原因">
              <ElOption
                v-for="(item, index) in list"
                :label="item.Label"
                :value="item.Value"
                :key="index"
              />
            </ElSelect>
          </ElFormItem>

          <!-- 输入说明 -->
          <!-- <ElFormItem label="取消说明：" prop="Content">
            <ElInput
              v-model="form.Content"
              :maxlength="150"
              :rows="5"
              placeholder="请输入取消说明"
              type="textarea"
              resize="none"
              show-word-limit
            />
          </ElFormItem> -->
        </ElForm>

        <!-- 按钮容器 -->
        <ElRow class="button-box">
          <ElRow class="A" @click="upload()">确认</ElRow>
          <ElRow class="B" @click="close()">取消</ElRow>
        </ElRow>
      </div>
    </div>
  </transition>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    guid: undefined, // 所属界面的唯一ID，由界面写入
    list: undefined,
    orderId: undefined, // 订单ID
    upload: undefined, // 上传方法

    BusKey: ["LeaseOrderCancel"], // 订阅名称，组件卸载后清理订阅会用到

    show: Boolean(false), // 控制显示

    // 表单
    form: {
      Type: undefined, // 取消类型
      Content: "", // 取消原因
    },

    // 校验
    rules: {
      Type: [
        {
          required: true,
          message: "取消原因不能为空",
          trigger: "change",
        },
      ],
      Content: [
        {
          required: true,
          message: "取消说明不能为空",
          trigger: "blur",
        },
      ],
    },
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.BUS[this.BusKey[0]] = (orderId = undefined) => {
      return new Promise((resolve) => {
        if (!!orderId) {
          this.orderId = orderId;
          this.Api.LeaseCancelReason.GetData().then((data) => {
            this.list = data;
            this.show = true;
          });
        } else {
          this.close();
        }

        // 上传数据
        this.upload = () =>
          this.$refs.$.validate().then(($) => {
            if ($) {
              var from = { ...this.form };
              from.Id = this.orderId;
              this.Api.LeaseCancelAdd.init(from)
                .SetData()
                .then((_) => {
                  this.close();
                  resolve(true);
                });
            }
          });
      });
    };
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    delete this.BUS[this.BusKey[0]];
  },

  // 组件方法
  methods: {
    // 关闭操作
    close() {
      this.$refs.$.resetFields(); // 清除表单
      this.show = false;
    },
  },
};
</script>

<style lang="scss" scoped>
.cancel-box {
  // 外框
  background-color: rgba(0, 0, 0, 0.2);
  position: fixed;
  height: 100vh;
  width: 100vw;
  left: 0;
  top: 0;

  .cancel-box-in {
    // 内框
    background-color: rgba(255, 255, 255, 1);
    transform: translate(-50%, -50%);
    border-radius: 4px;
    position: absolute;
    padding: 20px 12px;
    width: 620px;
    left: 50%;
    top: 50%;

    .title-box {
      // 标题容器
      align-items: center;
      margin-bottom: 20px;
      display: flex;

      .title {
        box-sizing: border-box;
        text-align: left;
        font-size: 18px;
        line-height: 1;
        flex-grow: 1;
      }

      .img-box {
        flex-shrink: 0;
        height: 24px;
        width: 24px;

        img {
          cursor: pointer;
          height: 24px;
          width: 24px;
        }

        .A {
          display: block;
        }

        .B {
          display: none;
        }

        &:hover {
          .A {
            display: none;
          }

          .B {
            display: block;
          }
        }
      }
    }

    .tips-box {
      // 提示容器
      background-color: rgba(255, 251, 230, 1);
      border: 1px solid rgba(255, 229, 143, 1);
      color: rgba(95, 90, 89, 1);
      align-items: center;
      font-size: 14px;
      height: 32px;

      img {
        margin: 0 8px 0 14px;
        height: 14px;
        width: 14px;
      }
    }

    .button-box {
      // 按钮容器
      flex-direction: row-reverse;
      align-items: center;
      margin-top: 20px;

      div {
        // 通用样式
        transition: all var(--base-transition);
        border: var(--el-border);
        justify-content: center;
        align-items: center;
        border-radius: 4px;
        cursor: pointer;
        height: 32px;
        width: 72px;
      }

      div + div {
        margin-right: 20px;
      }

      .A {
        background-color: red;
        border-color: red;
        color: white;

        &:hover {
          background-color: rgb(233, 84, 84);
          border-color: rgb(233, 84, 84);
        }
      }

      .B:hover {
        border-color: red;
        color: red;
      }
    }
  }
}

.cancel-leave-from {
  opacity: 1;
}

.cancel-leave-active {
  transition: opacity var(--base-transition);
}

.cancel-leave-to {
  opacity: 0;
}

.cancel-enter-from {
  opacity: 0;
}

.cancel-enter-active {
  transition: opacity var(--base-transition);
}

.cancel-enter-to {
  opacity: 1;
}
</style>