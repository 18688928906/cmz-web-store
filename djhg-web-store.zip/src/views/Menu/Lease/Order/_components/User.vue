<template>
  <div class="user-box">
    <!-- 标题 -->
    <div class="label">收货信息</div>

    <!-- 用户信息 -->
    <div v-if="!!detail.Exp.Name || !!detail.Exp.Phone" class="user">
      <div v-if="!!detail.Exp.Name">
        <span>收货人姓名：</span>
        <span>{{ detail.Exp.Name }}</span>
      </div>
      <div v-if="!!detail.Exp.Phone">
        <span>手机号码：</span>
        <span>{{ detail.Exp.Phone }}</span>
      </div>
    </div>

    <!-- 地址 -->
    <div class="address">
      <span>{{ detail.PickUp ? "自提" : "收货" }}地址：</span>
      <span>{{ detail.Exp.AddressDetail }}</span>
    </div>
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: { detail: undefined },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.user-box {
  // 用户信息容器
  background-color: white;
  flex-direction: column;
  padding: 14px 20px;
  margin-top: 16px;
  display: flex;
  width: 1200px;

  .label {
    // 标题
    font-size: 14px;
  }

  .user {
    // 用户信息
    align-items: center;
    margin-top: 16px;
    display: flex;

    div {
      color: rgba(16, 16, 16, 0.6);
      line-height: 1em;
      font-size: 12px;

      span + span {
        color: var(--base-color);
      }
    }

    div + div {
      margin-left: 120px;
    }
  }

  .address {
    // 地址
    color: rgba(16, 16, 16, 0.6);
    margin-top: 16px;
    font-size: 12px;

    span + span {
      color: var(--base-color);
    }
  }
}
</style>