<template>
  <tr class="list-item">
    <!-- 商品信息 -->
    <td>
      <div class="info-box">
        <!-- 商品图片 -->
        <img class="logo" :src="detail.Img" />

        <!-- 信息 -->
        <div class="info">
          <div class="id">商品ID：{{ detail.Id }}</div>
          <div class="name">{{ detail.Name }}</div>
        </div>
      </div>
    </td>

    <!-- 规格信息 -->
    <td>
      <div class="sku">
        <div class="sku-in">
          <div v-for="(item, index) in detail.Sku" :key="index">{{ item }}</div>
        </div>
      </div>
    </td>

    <!-- 购买数量 -->
    <td class="quantity">{{ detail.Quantity }}</td>

    <!-- 单价 -->
    <td class="quantity">￥{{ detail.Price }}</td>

    <!-- 申请售后 -->
    <td class="quantity">
      <span class="button">申请售后</span>
    </td>
  </tr>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: { detail: undefined },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.list-item {
  // 行
  border: 1px solid rgba(238, 238, 238, 1);
  border-top: none;

  .info-box {
    // 商品信息容器
    padding: 12px;
    display: flex;

    .logo {
      border-radius: 2px;
      flex-shrink: 0;
      height: 80px;
      width: 80px;
    }

    .info {
      // 商品信息
      margin-left: 12px;
      font-size: 12px;

      .id {
        color: rgba(174, 174, 174, 1);
      }

      .name {
        margin-top: 12px;
      }
    }
  }

  .sku {
    // 规格信息
    flex-direction: column;
    align-items: center;
    display: flex;

    .sku-in {
      flex-direction: column;
      align-items: stretch;
      display: flex;

      div {
        font-size: 12px;
      }

      div + div {
        margin-top: 12px;
      }
    }
  }

  .quantity {
    // 购买数量
    text-align: center;
    font-size: 12px;

    .button {
      // 售后按钮
      cursor: pointer;

      &:hover {
        color: red;
      }
    }
  }
}
</style>