<template>
  <div class="breadcrumb">
    <!-- 面包屑容器 -->
    <ElBreadcrumb separator=">">
      <ElBreadcrumbItem>首页</ElBreadcrumbItem>
      <ElBreadcrumbItem>我的订单</ElBreadcrumbItem>
      <ElBreadcrumbItem>订单详情</ElBreadcrumbItem>
    </ElBreadcrumb>
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.breadcrumb {
  // 面包屑容器
  margin: 16px 0;
  width: 1200px;
}
</style>