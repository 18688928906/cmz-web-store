<template>
  <div class="exp-box">
    <!-- 标题 -->
    <div class="label">物流信息</div>

    <!-- 物流详情容器 -->
    <div class="info-box">
      <div class="info">
        <div>
          <span>物流公司：</span>
          <span>{{ exp?.Company || "-" }}</span>
        </div>
        <div>
          <span>快递单号：</span>
          <span>{{ exp?.Code || "-" }}</span>
        </div>
      </div>

      <!-- 时间线 -->
      <ElScrollbar style="flex-grow: 1" height="184px">
        <ElTimeline style="padding-right: 8px">
          <ElTimelineItem
            v-for="(item, index) in list"
            :timestamp="item.Time"
            :color="index === 0 ? '#F56602' : undefined"
            :key="index"
          >
            <span :style="index === 0 ? 'color:#F56602' : undefined">{{
              item.Text
            }}</span>
          </ElTimelineItem>
        </ElTimeline>
      </ElScrollbar>
    </div>
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: { detail: undefined },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    list: Array(0),
    exp: undefined,
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 物流信息
    if (this.detail.Status.Type > 2) {
      this.Api.OrderExp.init(this.detail.Exp)
        .GetData()
        .then(($) => {
          this.exp = $;
          this.list = $.List;
        });
    }
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.exp-box {
  // 物流信息
  background-color: white;
  flex-direction: column;
  padding: 14px 20px;
  margin-top: 16px;
  display: flex;
  width: 1200px;

  .label {
    // 标题
    font-size: 14px;
  }

  .info-box {
    // 信息容器
    margin-top: 14px;
    display: flex;
    height: 184px;

    .info {
      // 物流信息
      border-right: 1px solid rgba(187, 187, 187, 1);
      flex-shrink: 0;
      width: 220px;

      div {
        color: rgba(16, 16, 16, 0.6);
        line-height: 1em;
        font-size: 12px;
      }

      div + div {
        margin-top: 14px;
      }
    }
  }
}
</style>