<template>
  <div class="detail-box">
    <!-- 标题 -->
    <div class="label">物流信息</div>

    <!-- 订单时间 -->
    <div class="time">
      <div>
        <span>订单编号：</span>
        <span>{{ detail.Code }}</span>
      </div>
      <div v-if="!!detail.Exp.Name">
        <span>下单时间：</span>
        <span>{{ detail.CreateTime }}</span>
      </div>
    </div>

    <!-- 订单商品表 -->
    <table
      style="--th-color: rgba(247, 247, 247, 1); border-collapse: collapse"
      cellspacing="0"
      cellpadding="0"
      border="0"
    >
      <!-- 定义表头 -->
      <tr class="table-title">
        <th class="left" style="padding-left: 12px">商品信息</th>
        <th width="180">规格信息</th>
        <th width="160">数量</th>
        <th width="160">单价（元）</th>
        <th width="160">操作</th>
      </tr>

      <ListItem
        v-for="(item, index) in detail.List"
        :detail="item"
        :key="index"
      />
    </table>

    <!-- 显示价格 -->
    <div class="price-calculation">
      <div>商品总价：</div>
      <div>￥{{ detail.Price }}</div>
    </div>

    <div class="price-calculation">
      <div>运费：</div>
      <div>￥{{ detail.Exp.Price }}</div>
    </div>

    <div class="price-calculation">
      <div>优惠：</div>
      <div>￥{{ detail.Coupon }}</div>
    </div>

    <div class="price-calculation">
      <div style="color: red">实付款：</div>
      <div style="color: red">
        <span>￥</span>
        <span style="font-size: 20px">{{ detail.Money }}</span>
      </div>
    </div>
  </div>
</template>

<script>
import ListItem from "./ListItem/Item.vue";
export default {
  // 组件
  components: { ListItem },

  // 接收参数
  props: { detail: undefined },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.detail-box {
  // 订单详情
  background-color: white;
  flex-direction: column;
  padding: 14px 20px;
  margin-top: 16px;
  display: flex;
  width: 1200px;

  .label {
    // 标题
    font-size: 14px;
  }

  .time {
    // 用户信息
    align-items: center;
    margin: 16px 0;
    display: flex;

    div {
      color: rgba(16, 16, 16, 0.6);
      line-height: 1em;
      font-size: 12px;

      span + span {
        color: var(--base-color);
      }
    }

    div + div {
      margin-left: 120px;
    }
  }

  .table-title {
    // 表头
    border: 1px solid rgba(238, 238, 238, 1);
    background-color: var(--th-color);
    border-bottom: none;

    th {
      font-weight: normal;
      position: relative;
      line-height: 14px;
      font-size: 12px;
      cursor: default;
      height: 38px;
    }

    .left {
      text-align: left;
    }
  }

  // 价格展示容器
  .price-calculation {
    justify-content: flex-end;
    align-items: baseline;
    margin-top: 12px;
    display: flex;

    div {
      color: rgba(153, 153, 153, 1);
      text-align: right;
    }

    div + div {
      color: var(--base-color);
      min-width: 90px;
    }
  }
}
</style>