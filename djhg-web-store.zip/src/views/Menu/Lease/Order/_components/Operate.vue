<template>
  <div class="operate-box">
    <!-- 标题容器 -->
    <div class="title-box">
      <!-- 标题 -->
      <div class="title">{{ detail.Status.Info(detail.Status.Type) }}</div>

      <!-- 待收货倒计时 -->
      <template
        v-if="(detail.Status.Type == 1 || detail.Status.Type == 5) && !!tips"
      >
        <img class="time-icon" :src="$svg['i-0024-3C3C3C']" />
        <div class="time-out">
          <span>剩余时间</span>
          <span>{{ tips }}</span>
        </div>
      </template>
    </div>

    <!-- 提示语 -->
    <div v-if="detail.Status.Type == 1" class="tips">
      未在规定时间内进行付款，订单将自动取消
    </div>

    <!-- 交易关闭 -->
    <div v-else-if="detail.Status.Type == 0" class="tips">
      <div>关闭类型：{{ detail.Cancellation }}</div>
      <div>关闭时间：{{ detail.Payend }}</div>
    </div>

    <!-- 没有提示语的占位 -->
    <div v-else class="tips" />

    <!-- 操作按钮容器 -->
    <div class="button-box">
      <!-- 处理付款 -->
      <template v-if="detail.Status.Type == 1">
        <div class="button go-pay" @click="GoPay()">立即付款</div>
        <div class="button no-pay" @click="Cancel()">取消订单</div>
      </template>

      <!-- 卖家没有发货 -->
      <template v-else-if="detail.Status.Type == 2">
        <div class="button go-pay" @click="ExpeditingShipments()">催发货</div>
      </template>

      <!-- 买家没有收货 -->
      <template v-else-if="detail.Status.Type == 3">
        <div class="button go-pay" @click="ConfirmReceipt()">确认收货</div>
      </template>

      <!-- 完成后评价 -->
      <template v-else-if="detail.Status.Type == 4">
        <div
          v-if="detail.Comment === 0"
          class="button go-com"
          @click="GoReviews()"
        >
          去评价
        </div>
        <div
          v-else-if="detail.Comment === 1"
          class="button go-com"
          @click="GoReviewsAgain()"
        >
          去追评
        </div>
        <div v-if="detail.Invoice" class="button no-pay">开票</div>
      </template>

      <!-- 自提订单 -->
      <template v-else-if="detail.Status.Type == 5">
        <div class="button go-pay" @click="ConfirmReceipt()">确认收货</div>
      </template>
    </div>
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: { detail: undefined },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    tips: "", // 倒计时提醒
    date: 0, // 记录时间
    time: 0, // 支付倒计时
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 检查倒计时
    if (((this.time = this.detail.TimeOut), this.time) > 0) {
      this.date = ~~(new Date().getTime() / 1000) + this.time;
      this.SetTimeOut().QUEUE[this.detail.Code] = (unix) => {
        this.time = this.date - ~~(unix / 1000);
        this.SetTimeOut();
      };
    }
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    this.SetTimeOut(true); // 停用定时器
  },

  // 组件方法
  methods: {
    // 过期倒计时
    SetTimeOut(close = false) {
      // 创建时间
      if (this.time > 0 && !close) {
        this.tips = this.TimeConversion(this.time);
      }

      // 支付过期取消订阅
      else {
        this.detail.Status.Type = this.time = 0;
        delete this.QUEUE["-" + this.detail.Code];
      }

      return this; // 链式
    },

    // 催促发货
    ExpeditingShipments() {
      this.Api.LeaseOrderExpediting.SetData(this.detail.Id);
    },

    // 确认收货
    ConfirmReceipt() {
      this.BUS.LeaseConfirmReceipt(this.detail.Id).then(($) => {
        this.detail.Status.Type = 4;
      });
    },

    // 去支付
    GoPay() {
      this.$GO({
        name: "PayLease",
        data: { Id: this.detail.Id, Code: this.detail.Code },
      });
    },

    // 去评价
    GoReviews() {
      this.$GO({
        name: "LeaseReviews",
        data: { Id: this.detail.Id },
      });
    },

    // 去追评
    GoReviewsAgain() {
      this.$GO({
        name: "ShopReviewsAgain",
        data: { Id: this.detail.Id, Comment: this.detail.CommentId },
      });
    },

    // 取消订单
    Cancel() {
      this.BUS.LeaseOrderCancel(this.detail.Id).then((_) => {
        this.detail.Status.Type = 0;
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.operate-box {
  // 操作功能容器
  background-color: white;
  flex-direction: column;
  padding: 14px 20px;
  margin-top: 16px;
  display: flex;
  width: 1200px;

  .title-box {
    // 标题功能容器
    align-items: center;
    display: flex;

    .title {
      font-weight: bold;
      font-size: 18px;
    }

    .time-icon {
      // 支付倒计时图标
      margin-left: 20px;
      height: 14px;
      width: 14px;
    }

    .time-out {
      // 倒计时
      margin-left: 4px;
      font-size: 12px;

      span + span {
        color: red;
      }
    }
  }

  .tips {
    // 提示语句
    color: rgba(193, 194, 197, 1);
    align-items: center;
    line-height: 1em;
    margin-top: 14px;
    font-size: 12px;
    display: flex;
    height: 1em;

    div + div {
      margin-left: 40px;
    }
  }

  .button-box {
    // 按钮容器
    align-items: stretch;
    margin-top: 14px;
    display: flex;
    height: 26px;

    .button {
      // 通用按钮样式
      transition: all var(--base-transition);
      justify-content: center;
      border-style: solid;
      align-items: center;
      border-radius: 3px;
      border-width: 1px;
      cursor: pointer;
      display: flex;
      width: 90px;
    }

    .button + .button {
      margin-left: 14px;
    }

    .go-pay {
      // 去支付
      background-color: red;
      border-color: red;
      color: white;

      &:hover {
        background-color: rgba(255, 90, 90, 1);
        border-color: rgba(255, 90, 90, 1);
      }
    }

    .no-pay {
      // 取消支付
      background-color: white;
      border-color: rgba(193, 194, 197, 1);
      color: rgba(102, 102, 102, 1);

      &:hover {
        background-color: red;
        border-color: red;
        color: white;
      }
    }

    .go-com {
      // 去评价
      background-color: white;
      border-color: red;
      color: red;

      &:hover {
        background-color: red;
        color: white;
      }
    }
  }
}
</style>