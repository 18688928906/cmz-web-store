<template>
  <div class="status-box">
    <!-- 处理关闭的订单 -->
    <template v-if="status === 0">
      <div class="main">
        <img :src="$svg['i-0028-0052D9']" />
        <span style="color: rgba(53, 116, 240, 1)">申请取消</span>
      </div>
      <div class="hr-box" style="border-color: rgba(53, 116, 240, 1)" />
      <div class="main">
        <img :src="$svg['i-0029-0052D9']" />
        <span style="color: rgba(53, 116, 240, 1)">系统审核</span>
      </div>
      <div class="hr-box" style="border-color: rgba(53, 116, 240, 1)" />
      <div class="main">
        <img :src="$svg['i-0014-0052D9']" />
        <span style="color: rgba(53, 116, 240, 1)">取消成功</span>
      </div>
      <div style="width: 180px" />
      <div style="width: 100px" />
    </template>

    <!-- 处理正常订单 -->
    <template v-else>
      <div :class="{ activation: status >= 1 }" class="main">
        <img v-if="status >= 1" :src="$svg['i-0028-7BBC52']" />
        <img v-else :src="$svg['i-0028-999999']" />
        <span>提交订单</span>
      </div>

      <div :class="{ activation: status >= 1 }" class="hr-box">
        <span v-if="status >= 1">等待支付</span>
      </div>

      <div :class="{ activation: status >= 2 }" class="main">
        <img v-if="status >= 2" :src="$svg['i-0029-7BBC52']" />
        <img v-else :src="$svg['i-0029-999999']" />
        <span>支付成功</span>
      </div>

      <div :class="{ activation: status >= 2 }" class="hr-box">
        <span v-if="status >= 2">等待发货</span>
      </div>

      <!-- 处理自提 -->
      <template v-if="detail.PickUp">
        <div :class="{ activation: status >= 3 }" class="main">
          <img :src="$svg['i-0030-7BBC52']" />
          <span>买家自提</span>
        </div>

        <div :class="{ activation: status >= 3 }" class="hr-box">
          <span v-if="status >= 3">等待自提</span>
        </div>
      </template>

      <!-- 处理物流 -->
      <template v-else>
        <div :class="{ activation: status >= 3 }" class="main">
          <img v-if="status >= 3" :src="$svg['i-0026-7BBC52']" />
          <img v-else :src="$svg['i-0026-999999']" />
          <span>商家发货</span>
        </div>

        <div :class="{ activation: status >= 3 }" class="hr-box">
          <span v-if="status >= 3">等待收货</span>
        </div>
      </template>

      <!-- 用户收货 -->
      <div :class="{ activation: status == 4 }" class="main">
        <img v-if="status == 4" :src="$svg['i-0014-7BBC52']" />
        <img v-else :src="$svg['i-0014-999999']" />
        <span>确认收货</span>
      </div>
    </template>
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    detail: undefined,
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    status: undefined,
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.status = this.detail?.Status?.Type;
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.status-box {
  // 步骤条
  background-color: rgba(255, 255, 255, 1);
  justify-content: space-evenly;
  align-items: center;
  display: flex;
  width: 1200px;
  height: 80px;

  * {
    color: rgba(153, 153, 153, 1);
    flex-shrink: 0;
  }

  .main {
    // 主要提示
    justify-content: center;
    align-items: center;
    font-size: 16px;
    display: flex;
    width: 100px;

    img {
      margin-right: 10px;
      height: 20px;
      width: 20px;
    }
  }

  .activation {
    border-color: rgba(123, 188, 82, 1) !important;

    span {
      color: rgba(123, 188, 82, 1) !important;
    }
  }

  .hr-box {
    // 横线容器
    border-top: 1px solid rgba(153, 153, 153, 1);
    text-align: center;
    line-height: 2em;
    font-size: 12px;
    width: 180px;
    height: 1px;
  }
}
</style>