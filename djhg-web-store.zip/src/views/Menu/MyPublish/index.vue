<template>
  <RouterViewqQuery />
</template>

<script>
export default {
  // 自动路由参数
  meta: {
    title: undefined, // 写入浏览器页签
    // index: Number(1), // 用于排序
    index: undefined, // 用于排序
    // label: "我的发布", // 显示用的路由名称
    label: undefined, // 显示用的路由名称
    name: undefined, // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(false), // 控制是否需要登录
  },

  // 组件
  components: {},

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
</style>