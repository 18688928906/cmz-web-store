<template>
  <div class="this-list-box">
    <template v-for="(item, index) in modelValue" :key="index">
      <div class="this-list-date">
        {{ item.times }}
        <div class="ibl">{{ item.browseList?.length || 0 }}个商品</div>
        <div class="hrs" />
      </div>
      <div class="this-list-item">
        <item
          v-for="($item, $index) in item.browseList"
          :key="$index"
          :item="$item"
          :manage="manage"
        />
      </div>
    </template>
  </div>
</template>

<script>
import Item from "./item.vue";
export default {
  // 接收参数
  props: {
    // 自定义v-model
    modelValue: undefined,
    manage: undefined,
  },

  // 组件
  components: { Item },

  // 生命周期函数：挂载前调用
  //   created() {
  //     console.log(this.modelValue);
  //   },
};
</script>

<style lang="scss" scoped>
.this-list-box {
  // 主容器
  flex-direction: column;
  align-items: center;
  display: flex;
  width: 100%;

  .this-list-date {
    // 时间
    color: rgba(16, 16, 16, 1);
    align-items: baseline;
    margin-bottom: 20px;
    margin-top: 30px;
    font-size: 28px;
    width: 1200px;
    display: flex;

    .ibl {
      margin-left: 10px;
      font-size: 14px;
    }

    .hrs {
      background-color: rgba(204, 204, 204, 100);
      margin-left: 10px;
      flex-grow: 1;
      height: 1px;
    }
  }

  .this-list-item {
    // 内容容器
    grid-template-columns: repeat(5, 230px);
    grid-column-gap: 12px;
    grid-row-gap: 12px;
    display: grid;
    // width: 1200px;
  }
}
</style>