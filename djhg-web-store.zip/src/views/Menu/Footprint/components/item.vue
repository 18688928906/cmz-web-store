<template>
  <div class="home-list-tiem">
    <img :src="proUrl" @click="goProduct()" />

    <div class="title" @click="goProduct()">{{ proName }}</div>

    <div class="price">¥{{ (proPrice || 0).toFixed(2) }}</div>

    <!-- <div class="business" @click="goStore()">{{ storeName }}</div> -->
    <template v-if="manage">
      <div class="cover" @click="item.manage = !item.manage" />
      <ElCheckbox v-model="item.manage" />
    </template>

    <div v-else-if="!del" class="delete">
      <img :src="$svg['i-0015-FFFFFF']" @click="del = true" />
    </div>

    <div v-if="del && !manage" class="del-box">
      <div class="text">确定删除？</div>
      <div class="btA" @click="delt">确定</div>
      <div class="btB" @click="del = false">取消</div>
    </div>
  </div>
</template>

<script>
export default {
  // 页面对象
  data: () => ({
    mid: undefined,
    id: undefined,
    pid: undefined,
    proId: undefined,
    proUrl: undefined,
    proName: undefined,
    proPrice: undefined,
    price: undefined,
    // storeName: undefined,
    del: false,
  }),

  // 接收参数
  props: { item: undefined, manage: undefined },

  setup(props) {
    return props.item;
  },

  // 组件方法
  methods: {
    // 跳转商品
    goProduct() {
      this.$GO({
        name: { 10: "ShopDetail", 20: "LeaseDetail", 40: "SurplusDetail" }[40],
        data: { Id: this.pid || this.id },
      });
    },

    // 跳转店铺
    goStore() {
      this.$router.push({
        path: `/store`,
        query: {
          data: window.btoa(JSON.stringify({ id: this.mid })),
          aax: 12345,
        },
      });
    },

    delt() {
      this.Api.FootprintDel.init({ Ids: this.id })
        .SetData()
        .then((_) => {
          this.Api.FootprintList.init({ Type: 40 }).GetList();
        });
    },
  },
};
</script>

<style lang="scss" scoped>
.home-list-tiem {
  background-color: rgba(255, 255, 255, 1);
  flex-direction: column;
  align-items: center;
  border-radius: 4px;
  position: relative;
  overflow: hidden;
  cursor: pointer;
  display: flex;
  width: 230px;

  .cover,
  .del-box {
    position: absolute;
    height: 100%;
    width: 100%;
    left: 0;
    top: 0;
  }

  .del-box {
    background-color: rgba(187, 187, 187, 0.65);

    .text {
      transform: translate(-50%, -50%);
      position: absolute;
      line-height: 1em;
      font-size: 14px;
      color: white;
      left: 50%;
      top: 50%;
    }

    .btA,
    .btB {
      position: absolute;
      text-align: center;
      line-height: 30px;
      font-size: 14px;
      cursor: pointer;
      bottom: 70px;
      height: 30px;
      width: 80px;
    }

    .btA {
      background-color: red;
      border-radius: 4px;
      color: white;
      left: calc((100% - 80px * 2 - 4px) / 2);
    }
    .btB {
      background-color: white;
      border-radius: 4px;
      color: rgba(16, 16, 16, 1);
      right: calc((100% - 80px * 2 - 4px) / 2);
    }
  }

  .delete {
    background-color: rgba(0, 0, 0, 0.1);
    border-radius: 4px;
    position: absolute;
    cursor: pointer;
    display: none;
    padding: 5px;
    height: 30px;
    width: 30px;
    right: 0;
    top: 0;

    img {
      height: 20px;
      width: 20px;
      margin: 0;
    }
  }

  .el-checkbox {
    position: absolute;
    left: 12px;
    top: 0;
  }

  img {
    margin-top: 20px;
    display: block;
    height: 150px;
    width: 150px;
  }

  .title {
    line-height: 18px;
    margin-top: 25px;
    overflow: hidden;
    font-size: 14px;
    display: block;
    height: 36px;
    width: 168px;
  }

  .price {
    color: rgba(255, 0, 0, 100);
    margin-top: 12px;
    font-size: 18px;
    display: block;
    width: 168px;
    margin-bottom: 22px;
  }

  .business {
    color: rgba(16, 16, 16, 1);
    position: absolute;
    line-height: 18px;
    font-size: 14px;
    display: block;
    bottom: 14px;
    right: 21px;
  }

  &:hover {
    .delete {
      display: block;
    }
  }
}
</style>