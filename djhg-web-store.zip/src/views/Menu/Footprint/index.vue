<template>
  <ScrollBar>
    <TopBar :src="src" label="我的足迹" />

    <div class="hr" />

    <div class="tbs">
      <TabsBarSmall
        v-model="index"
        :list="['全新', '租赁', '二手']"
        :manage="manage"
        :flist="list"
        color="#000"
        left
        @manage="manage = !manage"
        @changes="change($event)"
      />
    </div>

    <list v-if="list?.length > 0" v-model="list" :manage="manage" />

    <div v-else class="no-list">
      <img :src="NoList" />
    </div>
  </ScrollBar>
</template>

<script>
import TabsBarSmall from "./components/tabs_bar_small.vue";
import List from "./components/list.vue";

import src from "@/assets/Logo我的足迹.png";
import NoList from "@/assets/暂无足迹.png";

export default {
  token: true, // 该页面需要TOKEN
  open: true, // 新窗口打开

  // 组件
  components: { TabsBarSmall, List },

  // 计算属性
  computed: {
    index: {
      get() {
        return this._index;
      },
      set(value) {
        this.list = undefined;
        this._index = value;
        this.$nextTick((_) => {
          this.list = this.tabList[40 /*this.tabIndex[this._index]*/];
        });
      },
    },
  },

  // 页面对象
  data: () => ({
    tabs: ["tab0", "tab1", "tab2"],
    tab: 0, // 控制调用的页签
    tabList: {
      10: [],
      20: [],
      40: [],
    }, // 页签数据
    tabIndex: [],
    list: undefined,
    _index: 0,
    manage: false,
    src,
    NoList,
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.tabIndex = Object.keys(this.tabList);
    // this.tabIndex.forEach((Type) => {
    var Type = 40;
    this.Api.FootprintList.init({ Type })
      .AddUpdate("CollectionList", (item) => {
        this.tabList[Type] = undefined;
        this.list = undefined;
        this.$nextTick(() => {
          this.tabList[Type] = item?.list;
          this.list = item?.list;
        });
      })
      .GetList();
    // });
  },

  // 组件方法
  methods: {
    change(event) {
      this.list.map((item) => {
        item.browseList = item.browseList.map(($) => {
          $.manage = event;
          return $;
        });
        return item;
      });

      this.tabList[40] = this.list;
    },
  },
};
</script>

<style lang="scss" scoped>
.hr {
  background-color: rgba(244, 244, 244, 1);
  flex-shrink: 0;
  height: 1px;
  width: 100%;
}

.tbs {
  background-color: rgba(255, 255, 255, 1);
  width: 100%;
  display: flex;
}

.tabs-bar-tool {
  align-items: center;
  display: flex;
  height: 100%;

  img {
    height: 20px;
    width: 20px;
  }

  span {
    color: rgba(16, 16, 16, 1);
    line-height: 20px;
    margin-left: 5px;
    font-size: 14px;
  }
}

.no-list {
  // 没有列表
  justify-content: center;
  flex-direction: row;
  align-items: center;
  padding: 100px 0px;
  flex-wrap: nowrap;
  display: flex;

  img {
    width: 120px;
  }
}
</style>