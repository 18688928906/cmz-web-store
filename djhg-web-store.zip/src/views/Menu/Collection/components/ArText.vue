<template>
  <svg class="ar-text" height="1em" :width="w">
    <!-- 文本内容 -->
    <text dominant-baseline="middle" :y="y" ref="$" x="0">
      <slot />
    </text>
  </svg>
</template>

<script>
export default {
  // 组件名称
  name: "ArText",

  // 组件
  components: {},

  // 接收参数
  props: {},

  // 抛出事件名称
  emits: [],

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    config: { attributes: true, childList: true }, // 配置监听
    mo: undefined, // 对象监听器
    w: 0, // 宽度
    h: 0, // 遮盖层高度
    y: 0, // 偏移
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.mo = new MutationObserver(this.setSize); // 创建监听
  },

  // 生命周期函数：挂载后调用
  mounted() {
    this.setSize().mo.observe(this.$refs.$, this.config); // 启用监听
  },

  // 生命周期函数：离开前调用
  beforeUnmount() {
    this.mo.disconnect(); // 关闭监听
  },

  // 组件方法
  methods: {
    // 设置尺寸
    setSize() {
      const size = this.$refs.$.getBoundingClientRect(); // 尺寸
      this.w = size.width; // 配置宽度
      this.h = size.height;
      this.y = this.h / 2; // 配置垂直偏移
      return this; // 链式调用
    },
  },
};
</script>

<style lang="scss">
.ar-text {
  // 主要容器样式
  font-family: Helvetica;
  box-sizing: border-box;
  overflow: visible;
  font-size: 1rem;

  > text {
    // 文字显示部分
    font-family: inherit;
    font-size: 1em;
  }
}
</style>