<template>
  <div v-if="false" class="type-box">
    <div>商品分类：</div>
    <div class="but" :class="{ btr: index == 10 }" @click="index = 10">
      全新商品
    </div>
    <div class="but" :class="{ btr: index == 20 }" @click="index = 20">
      租赁商品
    </div>
    <div class="but" :class="{ btr: index == 40 }" @click="index = 40">
      二手商品
    </div>
  </div>

  <div style="height: 12px"></div>

  <div class="this-list-box" v-if="list?.length > 0">
    <div class="this-list-item">
      <Item
        v-for="(item, $index) in list"
        :manage="manage"
        :type="index"
        :key="$index"
        :item="item"
      />
    </div>
  </div>

  <div v-else class="no-list">
    <img :src="NoList" />
  </div>
</template>

<script>
import Item from "./item.vue";
import NoList from "@/assets/暂无收藏.png";
export default {
  // 接收参数
  props: {
    // 自定义v-model
    modelValue: undefined,

    manage: undefined,
  },

  // 组件
  components: { Item },

  // 计算属性
  computed: {
    index: {
      get() {
        return this._index;
      },
      set(value) {
        this.list = undefined;
        this._index = value;
        this.$nextTick((_) => {
          this.list = this.tabList[this._index];
        });
      },
    },
  },

  // 页面对象
  data: () => ({
    tabs: ["tab0", "tab1", "tab2"],
    tab: 0,
    tabList: {
      10: [],
      20: [],
      40: [],
    }, // 页签数据
    tabIndex: [],
    list: undefined,
    _index: 0,
    NoList,
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.BUS.CollectionSearch = (value) =>
      this.Api.CollectionList.init({ Type: 40, Keyword: value })
        .AddUpdate("CollectionList", (item) => {
          this.tabList[40] = undefined;
          this.tabList[40] = item?.list;
          this.index = 40;
        })
        .GetList();

    this.tabIndex = Object.keys(this.tabList);
    // this.tabIndex.forEach((Type) => {
    this.Api.CollectionList.init({ Type: 40 })
      .AddUpdate("CollectionList", (item) => {
        this.tabList[40] = undefined;
        this.tabList[40] = item?.list;
        this.index = 40;
      })
      .GetList();
    // });
  },
};
</script>

<style lang="scss" scoped>
.type-box {
  background-color: white;
  align-items: center;
  margin-bottom: 12px;
  margin-top: 20px;
  display: flex;
  width: 1200px;
  height: 54px;

  div {
    color: rgba(152, 152, 152, 1);
    line-height: 1;
    margin-left: 22px;
    font-size: 14px;
  }

  div + div {
    margin-left: 30px;
  }

  .but {
    border-radius: 2px;
    padding: 4px 8px;
    cursor: pointer;
  }

  .btr,
  .but:hover {
    color: white;
    background-color: red;
  }
}

.this-list-box {
  // 主容器
  flex-direction: column;
  align-items: center;
  display: flex;
  width: 100%;

  .this-list-date {
    // 时间
    color: rgba(16, 16, 16, 1);
    margin-bottom: 20px;
    line-height: 40px;
    margin-top: 30px;
    font-size: 28px;
    width: 1200px;
  }

  .this-list-item {
    // 内容容器
    grid-template-columns: repeat(5, 230px);
    grid-column-gap: 12px;
    grid-row-gap: 12px;
    display: grid;
    // width: 1200px;
  }
}

.no-list {
  // 没有列表
  justify-content: center;
  flex-direction: row;
  align-items: center;
  padding: 100px 0px;
  flex-wrap: nowrap;
  display: flex;

  img {
    width: 120px;
  }
}
</style>