<template>
  <div class="tabs-bar-small">
    <!-- 页头 -->
    <div
      class="tabs-bar-small-top"
      :style="`justify-content:${
        left !== false ? 'flex-start' : 'center'
      };width:${width};`"
    >
      <div class="tabs-bar-in" ref="button-box">
        <template v-for="(item, index) in list" :key="index">
          <div
            class="button"
            :style="tab == index ? 'color:' + color : ''"
            :ref="`button${index}`"
            @click="click(index)"
          >
            {{ item }}
          </div>
        </template>

        <div class="hrx" v-if="style" :style="style" />
      </div>

      <div style="flex-grow: 1" />

      <!-- <ArText>测试文字</ArText> -->

      <template v-if="manage">
        <ElRow style="align-items: center">
          <ElCheckbox
            v-model="emanage"
            label="全选"
            @change="$emit('changes', $event)"
          />
        </ElRow>

        <ElRow class="cancel" @click="cancel()">
          <img :src="$svg['i-0048-999999']" alt="" />
          <span>取消收藏</span>
        </ElRow>
      </template>

      <ElRow class="manage" @click="$emit('manage')">
        <img :src="$svg['i-0020']" alt="" />
        <span>批量管理</span>
      </ElRow>

      <!-- 搜索框 -->
      <div class="search-box">
        <input v-model="input" placeholder="订单编号/商品名称" type="text" />
        <div class="button" @click="BUS.CollectionSearch(input)">
          <img :src="$svg['i-0025-828282']" />
        </div>
      </div>

      <div class="slot-box"><slot name="top" /></div>
    </div>

    <!-- 页签内容 -->
    <div class="tabs-bar-box" v-if="router === false">
      <template v-for="(item, index) in list" :key="index">
        <slot v-if="tab == index" :name="`tab${index}`" />
      </template>
      <slot name="tab" />
    </div>

    <!-- 路由模式 -->
    <div class="tabs-bar-box" v-else>
      <router-view />
    </div>
  </div>
</template>

<script>
import ArText from "../../Collection/components/ArText.vue";

export default {
  // 组件
  components: { ArText },
  // 接收参数
  props: {
    list: {
      type: Array,
      default: [],
    },

    left: {
      type: Boolean,
      default: false,
    },

    width: {
      type: String,
      default: "1200px",
    },

    modelValue: {
      type: Number,
      default: 0,
    },

    // 使用路由模式
    router: {
      type: Boolean,
      default: false,
    },

    manage: {
      type: Boolean,
      default: false,
    },

    color: {
      type: String,
      default: "rgba(255,0,0,1)",
    },

    refl: undefined,
    refr: undefined,
  },

  // 页面对象
  data: () => ({
    style: undefined,
    w: undefined,
    x: undefined,
    emanage: false,
    input: "",
  }),

  // 计算属性
  computed: {
    // 映射
    tab: {
      get() {
        return this.modelValue;
      },
      set(value) {
        this.$emit("update:modelValue", value); // 回写
        this.$emit("getIndex", value); // 回写
      },
    },
  },

  watch: {
    modelValue(value) {
      this.click(value);
    },
  },

  // 生命周期函数：挂载后调用
  mounted() {
    this.click(this.modelValue);
  },

  // 组件方法
  methods: {
    // 点击事件
    click(index) {
      const // 创建对象
        box = this.$refs["button-box"].getBoundingClientRect(),
        dom = this.$refs[`button${index}`],
        but = (dom && dom[0] && dom[0].getBoundingClientRect()) || undefined;

      if (but) {
        const x = (but.x - box.x) / this.$scale + "px";
        const w = but.width / this.$scale + "px";
        this.style = `left:${x};width:${w};background-color:${this.color};`;
      }

      this.tab = index;
    },

    // 取消收藏
    cancel() {
      if (this.tab === 0) {
        this.Api.CollectionDelete.init({
          Ids: this.refl
            .filter(($) => !!$.manage)
            .map(($) => $.id)
            .join(","),
        })
          .SetData()
          .then(() => {
            this.emanage = false;
            this.Api.CollectionList.init({ Type: 40 }).GetList();
          });
      } else if (this.tab === 1) {
        this.Api.CollectionStoreDelete.init({
          Ids: this.refr
            .filter(($) => !!$.manage)
            .map(($) => $.StoreId)
            .join(","),
        })
          .SetData()
          .then(() => {
            this.emanage = false;
            this.BUS.CollectionSearch();
          });
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.tabs-bar-small {
  // 主体布局
  justify-content: flex-start;
  box-sizing: border-box;
  flex-direction: column;
  align-items: center;
  flex-shrink: 0;
  display: flex;
  width: 100%;

  .tabs-bar-small-top {
    // 主体布局
    align-items: center;
    flex-direction: row;
    position: relative;
    display: flex;
    height: 50px;

    .tabs-bar-in {
      // 内部布局
      justify-content: flex-start;
      align-items: stretch;
      flex-direction: row;
      position: relative;
      display: flex;

      .button {
        // 内部按钮
        transition: color 0.2s ease 0s;
        color: rgba(152, 152, 152, 1);
        text-align: center;
        line-height: 50px;
        font-size: 14px;
        cursor: pointer;
      }

      .button + .button {
        margin-left: 58px;
      }

      .hrx {
        transition: width 0.2s ease 0s, left 0.2s ease 0s;
        background-color: rgba(255, 0, 0, 1);
        position: absolute;
        flex-shrink: 0;
        height: 2px;
        bottom: 0;
      }
    }

    .cancel {
      color: rgba(153, 153, 153, 1);
      margin: 0 20px;
    }

    .cancel,
    .manage {
      // 管理功能
      align-items: center;
      cursor: pointer;

      img {
        margin-right: 5px;
        height: 20px;
        width: 20px;
      }

      span {
        font-size: 14px;
      }
    }

    .search-box {
      // 搜索框
      border: 1px solid rgba(187, 187, 187, 1);
      align-items: center;
      display: flex;
      height: 32px;
      width: 228px;
      margin-left: 32px;

      input {
        // 输入框
        line-height: 1em;
        font-size: 12px;
        padding: 0 4px;
        outline: none;
        flex-grow: 1;
        height: 30px;
        border: none;
      }

      .button {
        // 按钮
        background-color: rgba(247, 247, 247, 1);
        align-items: center;
        cursor: pointer;
        display: flex;
        height: 30px;
        width: 40px;

        img {
          margin-left: 12px;
          height: 20px;
          width: 20px;
        }
      }
    }

    .slot-box {
      // 顶部插槽容器
      transform: translateY(-50%);
      position: absolute;
      right: 0;
      top: 50%;
    }
  }

  .tabs-bar-box {
    // 内容容器
    position: relative;
    flex-shrink: 0;
    display: block;
    width: 100%;
  }
}
</style>