<template>
  <div class="this-list-box">
    <div class="this-list-item">
      <Item
        v-for="(item, index) in modelValue"
        :item="item"
        :type="type"
        :key="index"
      />
    </div>
  </div>
</template>

<script>
import Item from "./item.vue";
export default {
  // 接收参数
  props: {
    // 自定义v-model
    modelValue: undefined,
    type: undefined,
  },

  // 组件
  components: { Item },
};
</script>

<style lang="scss" scoped>
.this-list-box {
  // 主容器
  flex-direction: column;
  align-items: center;
  display: flex;
  width: 100%;

  .this-list-date {
    // 时间
    color: rgba(16, 16, 16, 1);
    margin-bottom: 20px;
    line-height: 40px;
    margin-top: 30px;
    font-size: 28px;
    width: 1200px;
  }

  .this-list-item {
    // 内容容器
    grid-template-columns: repeat(auto-fill, 250px);
    grid-column-gap: calc(200px / 3);
    grid-row-gap: calc(200px / 3);
    display: grid;
    width: 1200px;
  }
}
</style>