<template>
  <div class="collection-store">
    <template v-if="list?.length > 0">
      <div
        v-for="(item, index) in list"
        :key="index"
        class="collection-store-box"
      >
        <div class="collection-store-left">
          <img class="store-logo" :src="item.Logo" />
          <span class="store-name">{{ item.Name }}</span>
          <div class="store-operate">
            <img :src="$svg['i-0050-A9A9A9']" />
            <span @click="GoStore(item.StoreId)">进店逛逛</span>
            <img :src="$svg['i-0007-A9A9A9']" />
            <span @click="GoChat(item.StoreId)">联系客服</span>
          </div>
        </div>

        <div class="collection-store-products">
          <template v-for="($item, $index) in item.Products" :key="$index">
            <div class="collection-store-item">
              <img :src="$item.Logo" @click="GoProduct($item.Id)" />
              <div>¥{{ $item.Price }}</div>
            </div>
          </template>
        </div>

        <ElCheckbox v-if="manage" v-model="item.manage" />
      </div>
    </template>

    <div v-else class="no-list">
      <img :src="NoList" />
    </div>
  </div>
</template>

<script>
import NoList from "@/assets/暂无收藏店铺.png";
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    manage: undefined,
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    list: undefined,
    NoList,
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.BUS.CollectionSearch = (value) =>
      this.Api.CollectionStoreList.init({ Keyword: value })
        .GetData()
        .then(($) => {
          this.list = $;

          // 强制取消选中状态
          this.list.forEach((element) => {
            element.manage = false;
          });
        });

    this.Api.CollectionStoreList.GetData().then(($) => (this.list = $));
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 跳转店铺
    GoStore(Id) {
      this.$GO({
        path: "/menu/store/surplus",
        data: { Id },
      });
    },

    // 跳转聊天，携带商品
    GoChat(Id) {
      this.$GO({ name: "Chat", data: { Id } });
    },

    // 跳转产品
    GoProduct(Id) {
      this.$GO({
        path: "/menu/surplus/detail",
        data: { Id },
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.collection-store {
  // 主容器
  margin-top: 20px;
  justify-content: flex-start;
  flex-direction: column;
  align-items: center;
  position: relative;
  display: flex;
  width: 100%;

  .collection-store-box {
    // 单条容器
    border-bottom: 1px solid rgba(229, 229, 229, 100);
    background-color: white;
    justify-content: flex-start;
    align-items: stretch;
    flex-direction: row;
    position: relative;
    display: flex;
    height: 200px;
    width: 1200px;

    .collection-store-left {
      // 左侧商店信息
      justify-content: center;
      flex-direction: column;
      align-items: center;
      position: relative;
      flex-shrink: 0;
      display: flex;
      width: 240px;

      .store-logo {
        // 店铺图标
        height: 60px;
        width: 60px;
      }

      .store-name {
        // 店铺名称
        text-align: center;
        line-height: 20px;
        margin-top: 10px;
        font-size: 14px;
      }

      .store-operate {
        // 操作功能
        justify-content: center;
        flex-direction: row;
        align-items: center;
        position: relative;
        margin-top: 39px;
        display: flex;

        img {
          margin-right: 4px;
          height: 14px;
          width: 14px;
        }

        span {
          color: rgba(153, 153, 153, 1);
          line-height: 17px;
          font-size: 12px;
          cursor: pointer;
        }

        span + img {
          margin-left: 30px;
        }
      }
    }

    .collection-store-products {
      // 商品列表
      padding: 20px 40px 10px 60px;
      align-items: stretch;
      flex-direction: row;
      display: flex;
      flex-grow: 1;

      .collection-store-item {
        // 单个商品展示
        img {
          margin-bottom: 10px;
          height: 140px;
          width: 140px;
        }

        div {
          color: rgba(255, 0, 0, 1);
          text-align: center;
          line-height: 20px;
          font-size: 14px;
          width: 100%;
        }
      }

      .collection-store-item + .collection-store-item {
        margin-left: 40px;
      }
    }

    .el-checkbox {
      position: absolute;
      left: 12px;
      top: 4px;
    }
  }

  .no-list {
    // 没有列表
    justify-content: center;
    flex-direction: row;
    align-items: center;
    padding: 100px 0px;
    flex-wrap: nowrap;
    display: flex;

    img {
      width: 120px;
    }
  }
}
</style>