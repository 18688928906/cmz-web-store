<template>
  <ScrollBar>
    <TopBar :src="src" label="我的收藏" />

    <div class="hr" />

    <div class="tbs">
      <TabsBarSmall
        v-model="index"
        :list="['收藏的商品', '收藏的店铺']"
        :refl="$refs?.$?.list"
        :refr="$refs?.$$?.list"
        :manage="manage"
        color="#000"
        left
        @manage="manage = !manage"
        @changes="change($event)"
      />
    </div>

    <!-- 商品 -->
    <Shop v-if="index === 0" :manage="manage" ref="$"> </Shop>

    <!-- 店铺 -->
    <template v-else-if="index === 1">
      <collection-store :manage="manage" ref="$$" />
    </template>
  </ScrollBar>
</template>

<script>
import TabsBarSmall from "./components/tabs_bar_small.vue";
import CollectionStore from "./components/store.vue";
import List from "./components/list.vue";
import Shop from "./components/shop.vue";

import src from "@/assets/Logo我的收藏.png";

export default {
  token: true, // 该页面需要TOKEN
  open: true,

  // 组件
  components: {
    TabsBarSmall,
    CollectionStore,
    List,
    Shop,
  },

  // 计算属性
  computed: {
    index: {
      get() {
        return this._index;
      },
      set(value) {
        this.manage = false;
        this._index = value;
      },
    },
  },

  // 页面对象
  data: () => ({
    tabs: ["tab0", "tab1", "tab2"],
    tab: 0,
    tabList: {
      10: [],
      20: [],
      40: [],
    }, // 页签数据
    tabIndex: [],
    _index: 0,
    manage: false,
    src,
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 组件方法
  methods: {
    change($) {
      this.index === 0 &&
        this.$refs.$?.list.forEach((item) => {
          item.manage = $;
        });

      this.index === 1 &&
        this.$refs.$$?.list.forEach((item) => {
          item.manage = $;
        });
    },
  },
};
</script>

<style lang="scss" scoped>
.hr {
  background-color: rgba(244, 244, 244, 1);
  flex-shrink: 0;
  height: 1px;
  width: 100%;
}

.tbs {
  background-color: rgba(255, 255, 255, 1);
  width: 100%;
  display: flex;
}

.tabs-bar-tool {
  align-items: center;
  display: flex;
  height: 100%;

  img {
    height: 20px;
    width: 20px;
  }

  span {
    color: rgba(16, 16, 16, 1);
    line-height: 20px;
    margin-left: 5px;
    font-size: 14px;
  }
}

.tabs-flex {
  justify-content: center;
  display: flex;
}
</style>