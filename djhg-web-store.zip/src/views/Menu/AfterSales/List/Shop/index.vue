<template>
  <OrderPageBox>
    <!-- 选择订单类型 -->
    <TbaBox :maps="Maps" />

    <table
      style="--th-color: rgba(247, 247, 247, 1); border-collapse: collapse"
      cellspacing="0"
      cellpadding="0"
      border="0"
    >
      <!-- 定义表头 -->
      <tr class="table-title">
        <th class="left" style="padding-left: 8px">商品信息</th>
        <th class="left" width="114">退款金额</th>
        <th width="163">申请时间</th>
        <ThSelectTypeA :width="158" />
        <ThSelectTypeB :width="133" />
        <th width="143">订单操作</th>
      </tr>

      <!-- 渲染列 -->
      <template v-if="List">
        <ListItem v-for="(item, index) in List" :key="index" :detail="item" />
      </template>
    </table>
  </OrderPageBox>
</template>

<script>
import OrderPageBox from "../_components/OrderPageBox.vue";
import TbaBox from "./_components/TbaBox.vue";
import ThSelectTypeA from "./_components/ThSelectTypeA.vue";
import ThSelectTypeB from "./_components/ThSelectTypeB.vue";
import ListItem from "./_components/List-Item/Item.vue";

export default {
  // 自动路由参数
  meta: {
    title: undefined, // 写入浏览器页签
    index: Number(1), // 用于排序
    label: "全新售后", // 显示用的路由名称
    name: "AfterSalesListShop", // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(true), // 控制是否需要登录
  },

  // 组件
  components: { OrderPageBox, TbaBox, ThSelectTypeA, ThSelectTypeB, ListItem },

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    List: undefined,
    Maps: undefined,
    width: 150,
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 初始化并订阅接口
    this.Api.ShopOrderAfterSalesList.init()
      .AddUpdate(this.$options.meta.name, (Data) => {
        this.List = undefined; // 清空
        this.$nextTick(() => {
          this.List = Data.List; // 刷新数据
          this.Maps = Data.Maps; // 数量记录
        });
      })
      .GetList();

    // 订阅页面加载
    this.BUS.AfterSalesLisrMore = () => {
      this.Api.ShopOrderAfterSalesList.GetList();
    };
  },

  // 生命周期函数：挂载后调用
  mounted() {
    // 发布菜单选中
    this.BUS.SetMenuLabel(this.$options.meta.label);
    this.BUS.AfterSalesLitType(this.$options.meta.index);
  },

  // 生命周期函数：离开前调用
  beforeUnmount() {
    this.List?.forEach((item) => delete this.BUS[item.Code]); // 清空列表订阅
    this.Api.ShopOrderAfterSalesList.DelUpdate(this.$options.meta.name); // 取消订阅
  },

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.table-title {
  // 表头
  background-color: var(--th-color);

  th {
    font-weight: normal;
    position: relative;
    line-height: 14px;
    font-size: 12px;
    cursor: default;
    height: 38px;
  }

  .left {
    text-align: left;
  }
}
</style>