<template>
  <!-- 表头状态选择 -->
  <th :width="width" @mouseenter="Show = true" @mouseleave="Show = false">
    <span>售后类型</span>
    <img class="down" :src="$svg['i-0022']" />

    <!-- 弹出窗口 -->
    <transition name="floating-transition">
      <div v-show="Show" class="list-box">
        <div
          v-for="(item, index) in list"
          :key="index"
          @click="SetType(item.page)"
        >
          {{ item.label }}
        </div>
      </div>
    </transition>
  </th>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    width: {
      type: Number,
      default: 150,
    },
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    Show: Boolean(false), // 控制弹出框显示

    list: [
      { label: "全部订单", page: null },
      { label: "仅退款", page: 1 },
      { label: "退款退货", page: 2 },
    ],
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 设置类型
    SetType(type) {
      this.Show = false;
      this.Api.ShopOrderAfterSalesList.SetType(type);
    },
  },
};
</script>

<style lang="scss" scoped>
.down {
  // 下拉图标
  vertical-align: text-top;
  margin-left: 8px;
  font-size: 0;
  height: 14px;
  width: 14px;
}

.list-box {
  // 选项列表
  box-shadow: var(--base-shadow);
  background-color: white;
  position: absolute;
  overflow: hidden;
  font-size: 12px;
  width: 100%;
  z-index: 1;
  top: 100%;
  left: 0;

  div {
    // 单个选项
    font-size: inherit;
    line-height: 3em;
    cursor: pointer;
    width: 100%;

    &:hover {
      color: red;
    }
  }

  div + div {
    border-top: 1px solid rgba(238, 238, 238, 1);
  }
}

/* ---------- 帧动画 ---------- */
.floating-transition-leave-from {
  height: calc(3em * 3);
}

.floating-transition-leave-active {
  transition: height var(--base-transition);
}

.floating-transition-leave-to {
  height: 0;
}

.floating-transition-enter-from {
  height: 0;
}

.floating-transition-enter-active {
  transition: height var(--base-transition);
}

.floating-transition-enter-to {
  height: calc(3em * 3);
}
</style>