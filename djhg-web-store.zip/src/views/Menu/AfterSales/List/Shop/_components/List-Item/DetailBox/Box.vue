<template>
  <tr class="detail-box">
    <!-- 订单信息 -->
    <Detail :detail="detail" />

    <!-- 退款 -->
    <td style="color: red">{{ detail.Currency }}{{ detail.Price }}</td>

    <!-- 申请时间 -->
    <td style="text-align: center">{{ detail.CreateTime }}</td>

    <!-- 类型 -->
    <td style="text-align: center">
      {{ detail.Type.Label(detail.Type.Value) }}
    </td>

    <!-- 状态 -->
    <td style="text-align: center">
      {{ detail.Status.Label(detail.Status.Type) }}
    </td>

    <td style="text-align: center">
      <span class="button" @click="GoDetail()">售后详情</span>
    </td>
  </tr>
</template>

<script>
import Detail from "./Detail.vue";

export default {
  // 组件
  components: { Detail },

  // 接收参数
  props: { detail: undefined },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 打开售后详情
    GoDetail() {
      this.$GO({ name: "ShopAfterSalesDetail", data: { Id: this.detail.Id } });
    },
  },
};
</script>

<style lang="scss" scoped>
.detail-box {
  // 详情容器
  border: 1px solid rgba(238, 238, 238, 1);
  border-top: none;

  td {
    position: relative;
    font-size: 12px;
  }

  .button {
    // 按钮
    cursor: pointer;

    &:hover {
      color: red;
    }
  }
}
</style>