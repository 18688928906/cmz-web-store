<template>
  <ScrollBar @load="BUS.AfterSalesLisrMore()">
    <TopBar :label="$options.meta.label" :src="src" />

    <!-- 页签容器 -->
    <TbaBox v-if="false" />

    <RouterViewqQuery />
  </ScrollBar>
</template>

<script>
import TbaBox from "./_components/TbaBox.vue";
import src from "@/assets/Logo售后服务.png";

export default {
  // 自动路由参数
  meta: {
    title: undefined, // 写入浏览器页签
    index: undefined, // 用于排序
    label: "售后服务", // 显示用的路由名称
    name: undefined, // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(false), // 控制是否需要登录
  },

  // 组件
  components: { TbaBox },

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({ src }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    delete this.BUS.AfterSalesLisrMore; // 删除订阅
  },

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
</style>