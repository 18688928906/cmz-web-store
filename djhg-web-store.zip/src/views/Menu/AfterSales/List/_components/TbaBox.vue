<template>
  <!-- 页签容器 -->
  <div class="tab-box" ref="tab-box">
    <!-- 页签选项 -->
    <div
      v-for="(item, index) in list"
      :class="{ act: page === item.page }"
      :key="index"
      class="tab"
      ref="tab"
      @click="click(index)"
    >
      {{ item.label }}
    </div>

    <!-- 站位框 -->
    <div style="flex-grow: 1" />

    <!-- 移动下划线 -->
    <div v-if="!!style" :style="style" class="hrx" />
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {},

  // 计算属性
  computed: {
    // 配置被选中的项目
    page: {
      get() {
        return this._page;
      },
      set(value) {
        this._page = value;
      },
    },
  },

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    _page: undefined, // 配置被选中的项目
    style: undefined, // 下划线样式

    list: [
      { label: "全新售后", page: "AfterSalesListShop" },
      { label: "租赁售后", page: "AfterSalesListLease" },
      { label: "二手售后", page: "AfterSalesListSurplus" },
    ],
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.BUS.AfterSalesLitType = ($) => this.click(--$); // 订阅页面切换
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    delete this.BUS.AfterSalesLitType; // 取消订阅
  },

  // 组件方法
  methods: {
    // 点击事件
    click(index) {
      this.page = this.list[index].page; // 记录选中的页签
      const box = this.$refs["tab-box"].getBoundingClientRect();
      const tab = this.$refs["tab"][index].getBoundingClientRect();

      // 拼接样式
      this.style = {
        left: tab.x - box.x - 4 + "px",
        width: tab.width + 8 + "px",
      };

      this.$GO({ name: this.page });
    },
  },
};
</script>

<style lang="scss" scoped>
.tab-box {
  // 说明容器
  background-color: white;
  align-items: center;
  position: relative;
  margin-top: 16px;
  display: flex;
  width: 1200px;
  height: 50px;

  .tab {
    // 页签
    color: rgba(169, 169, 169, 1);
    text-align: center;
    margin-left: 8px;
    line-height: 1em;
    font-size: 16px;
    cursor: pointer;
  }

  .tab + .tab {
    margin-left: 68px;
  }

  .act,
  .tab:hover {
    color: var(--base-color);
    font-weight: bold;
  }

  .recycle-bin {
    // 回收站
    align-items: center;
    cursor: pointer;
    display: flex;

    img {
      height: 20px;
      width: 20px;
    }

    div {
      color: rgba(169, 169, 169, 1);
      margin-right: 14px;
      margin-left: 8px;
      font-size: 14px;
    }

    .A {
      display: block;
    }

    .B {
      display: none;
    }

    &:hover {
      div {
        color: red;
      }

      .A {
        display: none;
      }

      .B {
        display: block;
      }
    }
  }

  .hrx {
    // 移动下划线
    transition: width var(--base-transition), left var(--base-transition);
    background-color: var(--base-color);
    position: absolute;
    height: 2px;
    bottom: 5px;
  }
}
</style>