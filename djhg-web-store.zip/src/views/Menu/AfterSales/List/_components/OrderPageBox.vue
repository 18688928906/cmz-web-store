<template>
  <!-- 订单子页面 -->
  <div class="order-page-box"><slot /></div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.order-page-box {
  // 页面容器
  background-color: white;
  flex-direction: column;
  align-items: stretch;
  margin-top: 16px;
  padding: 12px;
  display: flex;
  width: 1200px;
}
</style>