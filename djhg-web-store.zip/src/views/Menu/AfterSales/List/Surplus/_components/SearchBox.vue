<template>
  <!-- 搜索容器 -->
  <div class="search-box" ref="search-box">
    <ElSelect v-model="value">
      <ElOption
        v-for="(item, index) in options"
        :label="item.label"
        :value="item.value"
        :key="index"
      />
    </ElSelect>
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {},

  // 计算属性
  computed: {
    // 配置被选中的项目
    value: {
      get() {
        return this._value;
      },
      set(value) {
        this._value = value;
        this.$emit("type", value >= 0 ? value : null); // 回参
        this.Api.SurplusOrderList.SetType(value >= 0 ? value : null);
      },
    },
  },

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    _value: undefined, // 配置被选中的项目

    options: [
      { label: "全部订单", value: -1 },
      { label: "待付款", value: 1 },
      { label: "待发货", value: 2 },
      { label: "待收货", value: 3 },
      { label: "待评价", value: 4 },
    ],
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.value = this.options[0].value;
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.search-box {
  // 说明容器
  background-color: white;
  margin-bottom: 28px;
  align-items: center;
  position: relative;
  display: flex;
  width: 100%;

  :deep(.el-select) {
    --el-input-border-radius: 4px;
    width: 240px;
  }
}
</style>