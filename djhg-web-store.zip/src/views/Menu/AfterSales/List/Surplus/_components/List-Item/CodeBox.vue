<template>
  <tr class="order-store">
    <!-- 订单信息 -->
    <td>
      <div class="flex-box">
        <div class="text">订单编号：</div>
        <ElPopover
          :content="content"
          placement="right"
          trigger="hover"
          width="150"
          @hide="content = '点击复制'"
        >
          <template #reference>
            <div
              class="code"
              ref="$A"
              @click="CopyCode(detail.Code.Order, '$A')"
            >
              {{ detail.Code.Order }}
            </div>
          </template>
        </ElPopover>
        <div class="text">售后编号：</div>
        <ElPopover
          :content="content"
          placement="right"
          trigger="hover"
          width="150"
          @hide="content = '点击复制'"
        >
          <template #reference>
            <div
              class="code"
              title="点击复制"
              ref="$B"
              @click="CopyCode(detail.Code.Refund, '$B')"
            >
              {{ detail.Code.Refund }}
            </div>
          </template>
        </ElPopover>
      </div>
    </td>

    <!-- 店铺名称 -->
    <td class="name" @click="GoStore()">{{ detail.Store.Name }}</td>

    <!-- 客服 -->
    <td colspan="3">
      <div class="flex-box" @click="GoChat()">
        <img class="logo" :src="$svg['i-0023-5C67F5']" />
        <div class="code">联系商家</div>
      </div>
    </td>

    <td>
      <ElRow v-if="type === 2 || type === 3" class="delete-box">
        <div @click="Del()">
          <img class="A" :src="$svg['i-0020']" />
          <img class="B" :src="$svg['i-0020-FF0000']" />
        </div>
      </ElRow>
    </td>
  </tr>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: { detail: undefined },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    type: undefined,
    content: "点击复制",
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.type = this.detail.Status.Type;
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 复制单号
    CopyCode(code, $) {
      // 主要选择方案，需要https支持
      if (navigator.clipboard?.writeText) {
        navigator.clipboard.writeText(code);
        this.content = "复制成功";
      }

      // 备用选择方案，有可能被废弃
      else {
        window.getSelection().selectAllChildren(this.$refs[$]);
        document.execCommand("Copy");
        this.content = "复制成功";
      }
    },

    // 删除功能
    Del() {
      this.Api.SurplusOrderAfterSalesDelete.init({ Id: this.detail.Id })
        .SetData()
        .then(() => {
          this.BUS.AfterSalesDel(this.detail.Id);
        });
    },

    // 跳转店铺
    GoStore() {
      this.$GO({
        path: "/menu/store/surplus",
        data: { Id: this.detail.Store.Id },
      });
    },

    // 跳转聊天
    GoChat() {
      this.$GO({
        name: "Chat",
        data: this.detail.Store,
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.order-store {
  // 订单与店铺信息
  border: 1px solid rgba(238, 238, 238, 1);
  background-color: var(--th-color);
  border-bottom: none;
  height: 36px;

  .flex-box {
    // 布局容器
    align-items: center;
    display: flex;
    height: 100%;
    width: 100%;

    div {
      font-size: 12px;
      line-height: 1;
      display: flex;
    }

    .text {
      color: rgba(153, 153, 153, 1);
      margin-left: 12px;
      flex-shrink: 0;
    }

    .code {
      // 订单号
      color: rgba(60, 60, 60, 1);
      cursor: pointer;
      flex-shrink: 0;

      &:hover {
        color: red;
      }
    }

    .logo {
      display: inline-block;
      margin-right: 4px;
      font-size: 0;
      height: 16px;
      width: 16px;
    }
  }

  .name {
    // 店铺名称
    color: rgba(60, 60, 60, 1);
    white-space: nowrap;
    padding-right: 8px;
    text-align: right;
    cursor: pointer;
    font-size: 12px;
    line-height: 1;
    flex-shrink: 0;

    &:hover {
      color: red;
    }
  }

  &:hover {
    .delete-order {
      filter: opacity(100%);
    }
  }

  .delete-box {
    justify-content: flex-end;
    padding-right: 12px;
    display: none;

    div,
    img {
      height: 16px;
      width: 16px;
    }

    .A {
      cursor: pointer;
      display: block;
    }

    .B {
      cursor: pointer;
      display: none;
    }

    div:hover {
      .A {
        display: none;
      }

      .B {
        display: block;
      }
    }
  }

  &:hover {
    .delete-box {
      display: flex;
    }
  }
}
</style>