<template>
  <!-- 页签容器 -->
  <ElRow class="tab-box" ref="tab-box">
    <!-- 开发信息 -->
    <div
      v-if="DEV && maps"
      style="top: -12px; right: calc(100% + 12px)"
      class="DEV"
    >
      订单总数：{{ maps }}
    </div>

    <!-- 搜索框 -->
    <ElRow class="search-box">
      <ElInput
        v-model="input"
        placeholder="售后编号/订单编号/商品名称"
        type="text"
        clearable
      />
    </ElRow>

    <!-- 时间选框 -->
    <ElRow class="search-box">
      <div class="tips">申请时间</div>
      <ElDatePicker
        v-model="date"
        style="flex-grow: 1; box-shadow: none"
        start-placeholder="开始时间"
        end-placeholder="结束时间"
        range-separator="至"
        type="daterange"
        size="small"
      />
    </ElRow>

    <!-- 搜索按钮 -->
    <div class="search-button" @click="search()">查询</div>

    <!-- 占位框 -->
    <div style="flex-grow: 1" />
  </ElRow>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: { maps: undefined },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    input: "",
    date: undefined,
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 搜索
    search() {
      // 计算时间
      this.Api.SurplusOrderAfterSalesList.SetTime(
        this.getDate(this.date?.[0] || undefined),
        this.getDate(this.date?.[1] || undefined, "23:59:59")
      );

      if (this.input !== "") {
        this.Api.SurplusOrderAfterSalesList.SetKeyword(this.input); // 不带时间直接调用
      } else {
        this.Api.SurplusOrderAfterSalesList.SetKeyword(""); // 不带时间直接调用
      }
    },

    // 获取时间
    getDate(date, time = "00:00:00") {
      return date
        ? [date.getFullYear(), date.getMonth() + 1, date.getDate()].join("-") +
            " " +
            time
        : date;
    },
  },
};
</script>

<style lang="scss" scoped>
.tab-box {
  // 说明容器
  background-color: white;
  margin-bottom: 12px;
  align-items: center;
  position: relative;
  height: 30px;
  width: 100%;

  .search-box {
    // 搜索框
    border: 1px solid rgba(187, 187, 187, 1);
    align-items: center;
    flex-wrap: nowrap;
    overflow: hidden;
    height: 30px;
    width: 220px;

    .el-input {
      --el-input-border: none;

      :deep(*) {
        box-shadow: none;
      }
    }

    input {
      // 输入框
      line-height: 1em;
      font-size: 12px;
      padding: 0 4px;
      outline: none;
      flex-grow: 1;
      height: 100%;
      border: none;
    }

    .tips {
      // 提示
      color: rgba(187, 187, 187, 1);
      font-size: 12px;
      flex-shrink: 0;
      line-height: 1;
      margin: 0 8px;
    }
  }

  .search-box + .search-box {
    margin-left: 16px;
    width: 280px;
  }

  .search-button {
    // 搜索按钮
    background-color: rgba(221, 221, 221, 1);
    color: var(--base-color);
    justify-content: center;
    align-items: center;
    border-radius: 4px;
    margin-left: 16px;
    font-size: 12px;
    cursor: pointer;
    display: flex;
    height: 30px;
    width: 60px;
  }
}
</style>