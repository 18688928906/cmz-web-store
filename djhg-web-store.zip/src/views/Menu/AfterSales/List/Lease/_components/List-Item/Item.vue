<template>
  <!-- 列表间距 -->
  <tr style="height: 12px" />

  <!-- 订单与店铺信息 -->
  <CodeBox :detail="detail" />

  <!-- 详情容器 -->
  <DetailBox :detail="detail" />
</template>

<script>
import CodeBox from "./CodeBox.vue";
import DetailBox from "./DetailBox/Box.vue";
export default {
  // 组件
  components: { CodeBox, DetailBox },

  // 接收参数
  props: { detail: undefined },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
</style>