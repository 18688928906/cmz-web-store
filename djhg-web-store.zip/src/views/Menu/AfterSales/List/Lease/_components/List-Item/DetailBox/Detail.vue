<template>
  <td>
    <!-- 开发信息 -->
    <div v-if="DEV" class="DEV" style="right: 100%">
      订单ID：{{ detail.Id }}
    </div>

    <!-- 商品详情 -->
    <div class="detail">
      <img class="logo" :src="detail.Img" />
      <!-- 商品信息 -->
      <div class="info-box" ref="$" :class="{ omit: omit }">
        <div class="name">
          <span>{{ detail.Name }}</span>
        </div>
        <div class="sku">{{ detail.Sku }}</div>
      </div>
    </div>
  </td>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: { detail: undefined },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    omit: Boolean(false), // 是否使用省略号
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {
    const $ = this.$refs.$;
    this.omit = $.clientHeight < $.scrollHeight; // 检测文本溢出
  },

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.detail {
  // 详情
  align-items: flex-start;
  padding: 32px 8px 12px;
  display: flex;
  width: 100%;

  .logo {
    // 商品图标
    border-radius: 4px;
    flex-shrink: 0;
    height: 80px;
    width: 80px;
  }

  .info-box {
    // 信息容器
    justify-content: space-between;
    flex-direction: column;
    align-items: stretch;
    margin-left: 12px;
    min-height: 80px;
    display: flex;
    flex-grow: 1;

    .name {
      // 商品名称
      position: relative;
      line-height: 20px;
      margin-top: -4px;
      overflow: hidden;
      font-size: 12px;
      display: block;
      width: 272px;

      .button {
        // 快照按钮
        cursor: pointer;

        &:hover {
          color: red;
        }
      }
    }

    .omit::after {
      // 省略号
      background: linear-gradient(to right, transparent, #fff 55%);
      color: rgba(102, 102, 102, 1);
      position: absolute;
      line-height: 16px;
      text-align: right;
      content: "…";
      font-size: 12px;
      width: 2.5em;
      bottom: 0;
      right: 0;
    }

    .sku {
      color: rgba(153, 153, 153, 1);
      font-size: 12px;
    }
  }
}
</style>