<template>
  <tr class="order-store">
    <!-- 订单信息 -->
    <td>
      <div class="flex-box">
        <div class="text">订单编号：</div>
        <div
          class="code"
          title="点击复制订单编号"
          @click="CopyCode(detail.Code.Order)"
        >
          {{ detail.Code.Order }}
        </div>
        <div class="text">售后编号：</div>
        <div
          class="code"
          title="点击复制售后编号"
          @click="CopyCode(detail.Code.Refund)"
        >
          {{ detail.Code.Refund }}
        </div>
      </div>
    </td>

    <!-- 店铺名称 -->
    <td class="name">{{ detail.Store.Name }}</td>

    <!-- 客服 -->
    <td colspan="4">
      <div class="flex-box">
        <img class="logo" :src="$svg['i-0023-5C67F5']" />
        <div class="code">联系商家</div>
      </div>
    </td>
  </tr>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: { detail: undefined },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 复制单号
    CopyCode(code) {
      navigator.clipboard.writeText(code); // 粘贴到剪贴板
    },
  },
};
</script>

<style lang="scss" scoped>
.order-store {
  // 订单与店铺信息
  border: 1px solid rgba(238, 238, 238, 1);
  background-color: var(--th-color);
  border-bottom: none;
  height: 36px;

  .flex-box {
    // 布局容器
    align-items: center;
    display: flex;
    height: 100%;
    width: 100%;

    div {
      font-size: 12px;
      line-height: 1;
      display: flex;
    }

    .text {
      color: rgba(153, 153, 153, 1);
      margin-left: 12px;
      flex-shrink: 0;
    }

    .code {
      // 订单号
      color: rgba(60, 60, 60, 1);
      cursor: pointer;
      flex-shrink: 0;

      &:hover {
        color: red;
      }
    }

    .logo {
      display: inline-block;
      margin-right: 4px;
      font-size: 0;
      height: 16px;
      width: 16px;
    }
  }

  .name {
    // 店铺名称
    color: rgba(60, 60, 60, 1);
    white-space: nowrap;
    padding-right: 8px;
    text-align: right;
    cursor: pointer;
    font-size: 12px;
    line-height: 1;
    flex-shrink: 0;

    &:hover {
      color: red;
    }
  }

  &:hover {
    .delete-order {
      filter: opacity(100%);
    }
  }
}
</style>