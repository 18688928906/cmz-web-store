<template>
  <ScrollBar
    v-if="false"
    :distance="300"
    @load="Api.HomeList.GetData(true)"
    @GetTop="scroll = $event"
    @guid="guid = $event"
  >
    <!-- 首页轮播图 -->
    <BannerHome />

    <!-- 首页板块 -->
    <PlateBox />

    <div class="Title">活动专区</div>

    <!-- 活动板块 -->
    <HomeEvent />

    <div class="Title">推荐商品</div>

    <!-- 商城列表 -->
    <HomeList />
  </ScrollBar>

  <!-- 临时嵌入二手界面 -->
  <Surplus @guid="guid = $event" />

  <!-- 浮动框 -->
  <Floating :scroll="scroll" :guid="guid" />
</template>

<script>
import PlateBox from "./_components/Plate/PlateBox.vue";
import Floating from "./_components/Floating.vue";

import Surplus from "@/views/Menu/Surplus/List/Recommend/index.vue";

import verify from "@/tool-library/_modules/verify.js";

export default {
  // 自动路由参数
  meta: {
    title: undefined, // 写入浏览器页签
    index: Number(0), // 用于排序
    label: "首页", // 显示用的路由名称
    name: "Home", // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(false), // 控制是否需要登录
  },

  // 组件
  components: { PlateBox, Floating, Surplus },

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    guid: String(""), // 储存页面滚动监听ID
    scroll: Number(0), // 储存页面滚动
  }),

  // 生命周期函数：挂载前调用
  created() {
    // console.log(verify.URL("http://www.google.com"));
  },

  // 生命周期函数：挂载后调用
  mounted() {
    this.BUS.SetMenuLabel(this.$options.meta.label); // 发布菜单选中
  },

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.Title {
  font-size: 28px;
  line-height: 1;
  margin: 18px 0;
  width: 1200px;
}
</style>