<template>
  <div class="EventBox">
    <ElSkeleton :loading="List.length === 0" :animated="true">
      <!-- 骨架屏部分 -->
      <template #template>
        <ElSkeletonItem class="title" style="width: 240px" />
        <div class="swiper" style="display: flex">
          <div
            v-for="item in 6"
            class="item"
            :style="item > 1 ? 'margin-left:15px' : ''"
            :key="item"
          >
            <ElSkeletonItem
              style="height: 174px; width: 174px"
              variant="image"
            />
            <ElSkeletonItem style="height: 14px" />
          </div>
        </div>
      </template>

      <template #default>
        <!-- 标题 -->
        <div class="title">两年半价换新品活动区</div>

        <!-- 滚动组件 -->
        <Swiper
          ref="$"
          :slidesPerView="6"
          :spaceBetween="15"
          :grabCursor="true"
          :navigation="true"
          :modules="modules"
          :autoplay="{
            disableOnInteraction: true,
            delay: 3000,
          }"
          :loop="true"
        >
          <SwiperSlide v-for="(item, index) in List" :key="index">
            <div class="item">
              <img :src="item.Img" />
              <div @click="OpenDetail(item.Id)">{{ item.Name }}</div>
              <div v-if="DEV" class="DEV">ID：{{ item.Id }}</div>
            </div>
          </SwiperSlide>
        </Swiper>

        <!-- 上一个 -->
        <div class="Prev" @click="PrevEl()">
          <img :src="$svg['i-0005-FFFFFF']" />
        </div>

        <!-- 下一个 -->
        <div class="Next" @click="NextEl()">
          <img :src="$svg['i-0006-FFFFFF']" />
        </div>
      </template>
    </ElSkeleton>
  </div>
</template>

<script>
// 导入滚动组件
import { Navigation, Autoplay } from "swiper";
import { Swiper, SwiperSlide } from "swiper/vue";

/**
 * 首页活动
 */
export default {
  // 组件名称
  name: "HomeEvent",

  // 组件
  components: { Swiper, SwiperSlide },

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    modules: [Autoplay, Navigation], // 滚动组件配置
    List: Array(0),
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 初始化接口并更新数据
    // this.ApiNew.ShopList()
    this.ApiNew.SurplusList() // 临时切换接口
      .init({ Limit: 18 })
      .GetList(true)
      .then((list) => (this.List = list));
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 上一个
    PrevEl() {
      this.$refs.$.$el.swiper.navigation.prevEl.click(); // 模拟点击
    },

    // 下一个
    NextEl() {
      this.$refs.$.$el.swiper.navigation.nextEl.click(); // 模拟点击
    },

    // 打开详情
    OpenDetail(Id) {
      // this.$GO({ name: "ShopDetail", data: { Id } });
      this.$GO({ name: "SurplusDetail", data: { Id } });
    },
  },
};
</script>

<style lang="scss" scoped>
.EventBox {
  // 首页活动
  transition: box-shadow var(--base-transition);
  background-color: white;
  padding: 26px 40px 12px;
  flex-direction: column;
  border-radius: 8px;
  position: relative;
  overflow: hidden;
  display: flex;
  width: 1200px;

  .title {
    // 标题
    font-size: 24px;
    line-height: 1;
    height: 24px;
  }

  .swiper {
    // 滚动组件
    margin-top: 25px;
    height: 200px;
    width: 1120px;
    z-index: auto;

    :deep(.swiper-wrapper) {
      z-index: inherit;
    }

    :deep(.swiper-button-prev),
    :deep(.swiper-button-next) {
      display: none;
    }

    .item {
      // 单项
      justify-content: space-between;
      flex-direction: column;
      align-items: stretch;
      position: relative;
      display: flex;
      height: 200px;
      width: 174px;

      img {
        height: 174px;
        width: 174px;
      }

      div {
        text-overflow: ellipsis;
        white-space: nowrap;
        overflow: hidden;
        font-size: 14px;
        cursor: pointer;
        display: block;
      }

      div:hover {
        color: red;
      }
    }
  }

  .Prev,
  .Next {
    transition: transform var(--base-transition);
    background-color: rgba(0, 0, 0, 0.35);
    justify-content: center;
    border-radius: 17px;
    align-items: center;
    position: absolute;
    overflow: hidden;
    cursor: pointer;
    display: flex;
    height: 34px;
    width: 34px;
    top: 150px;

    img {
      height: 17px;
      width: 17px;
    }
  }

  .Prev {
    // 上一个
    transform: translateX(-50%);
    padding-left: 17px;
    left: -17px;
  }

  .Next {
    // 下一个
    transform: translateX(50%);
    padding-right: 17px;
    right: -17px;
  }
}

.EventBox:hover {
  // 鼠标移入
  box-shadow: var(--base-shadow);

  .Prev,
  .Next {
    transform: translateX(0);
  }
}
</style>