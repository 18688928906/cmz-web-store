<template>
  <!-- 右侧悬浮 -->
  <div class="floating">
    <div class="item" @click="$GO({ path: '/menu/chat' }, true)">
      <img class="A" :src="$svg['i-0056-757575']" />
      <img class="B" :src="$svg['i-0056-FFFFFF']" />
      消息
    </div>

    <div class="hr" />

    <div class="item" @click="$GO({ path: '/menu/help/feedback' })">
      <img class="A" :src="$svg['i-0055-757575']" />
      <img class="B" :src="$svg['i-0055-FFFFFF']" />
      反馈
    </div>

    <div class="hr" />

    <div class="item" @click="open12377()">
      <img class="A" :src="$svg['i-0009-757575']" />
      <img class="B" :src="$svg['i-0009-FFFFFF']" />
      举报
    </div>

    <div v-if="top" class="hr" />

    <transition name="floating-transition">
      <div v-if="top" class="item" @click="BUS[guid]()">
        <img class="A" :src="$svg['i-0010-757575']" />
        <img class="B" :src="$svg['i-0010-FFFFFF']" />
        顶部
      </div>
    </transition>
  </div>

  <!-- 左侧悬浮（临时关闭） -->
  <ElTooltip v-if="false" placement="bottom" effect="light">
    <!-- 需求图标 -->
    <img :src="src" class="needs-logo" />

    <!-- 触发按钮 -->
    <template #content>
      <ul class="needs-list">
        <li @click="$GO({ path: '/menu/publish/needs/select' })">需求发布</li>
        <li @click="$GO({ path: '/menu/lease/publish/add' })">出租发布</li>
        <li @click="$GO({ path: '/menu/surplus/publish/add' })">二手发布</li>
      </ul>
    </template>
  </ElTooltip>
</template>

<script>
import src from "@/assets/发布图标.png";

export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    // 滚动参数
    scroll: {
      type: Number,
      default: 0,
    },

    // 滚动容器的唯一ID
    guid: {
      type: String,
      default: undefined,
    },
  },

  // 计算属性
  computed: {
    top: {
      get() {
        return this.scroll > document.body.clientHeight; // 大于浏览器可视高度显示顶部按钮
      },
    },
  },

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({ src }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    open12377() {
      window.open("https://12377.cn/");
    },
  },
};
</script>

<style lang="scss" scoped>
.floating {
  // 悬浮框
  transform: translate(625px, -120px);
  box-shadow: var(--base-shadow);
  background-color: white;
  flex-direction: column;
  align-items: center;
  border-radius: 4px;
  overflow: hidden;
  position: fixed;
  display: flex;
  width: 60px;
  left: 50%;
  top: 50%;

  .item {
    // 内容容器
    transition: background-color var(--base-transition);
    background-color: rgba(51, 51, 51, 0);
    color: rgba(117, 117, 117, 1);
    flex-direction: column;
    align-items: center;
    position: relative;
    overflow: hidden;
    font-size: 14px;
    cursor: pointer;
    line-height: 1;
    display: flex;
    height: 60px;
    width: 100%;

    img {
      margin-bottom: 4px;
      margin-top: 10px;
      font-size: 0;
      height: 24px;
      width: 24px;
    }

    .A {
      display: block;
    }

    .B {
      display: none;
    }
  }

  .item:hover {
    // 鼠标移入
    // background-color: rgba(51, 51, 51, 1);
    background-color: rgba(249, 104, 40, 1);
    color: white;

    .A {
      display: none;
    }

    .B {
      display: block;
    }
  }

  .hr {
    // 分割线
    background-color: rgba(239, 239, 239, 1);
    height: 1px;
    width: 40px;
  }

  /* ---------- 帧动画 ---------- */
  .floating-transition-leave-from {
    height: 60px;
  }

  .floating-transition-leave-active {
    transition: height var(--base-transition);
  }

  .floating-transition-leave-to {
    height: 0px;
  }

  .floating-transition-enter-from {
    height: 0px;
  }

  .floating-transition-enter-active {
    transition: height var(--base-transition);
  }

  .floating-transition-enter-to {
    height: 60px;
  }
}

.needs-logo {
  // 需求触发图标
  transform: translate(-625px, -120px);
  position: fixed;
  height: 79px;
  width: 72px;
  right: 50%;
  top: 50%;
}

.needs-list {
  // 需求触发按钮
  padding: 8px 0;
  margin: 0;

  li {
    color: var(--base-color);
    list-style: none;
    font-size: 14px;
    cursor: pointer;
    padding: 0 4px;

    & + li {
      margin-top: 8px;
    }

    &:hover {
      color: #228aff;
    }
  }
}
</style>