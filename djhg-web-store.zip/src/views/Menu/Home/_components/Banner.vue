<template>
  <ElSkeleton :loading="list.length <= 0" :animated="true">
    <!-- 骨架屏部分 -->
    <template #template>
      <ElSkeletonItem variant="image" style="width: 1200px; height: 460px" />
    </template>

    <!-- 轮播图部分 -->
    <template #default>
      <ElCarousel
        height="460px"
        :interval="interval * 1000"
        @change="index = $event"
      >
        <!-- 使用背景优化图片 -->
        <ElCarouselItem
          v-for="(item, index) in list"
          :style="`background-image:url('${item}');`"
          :key="index"
        >
          <div v-if="DEV" class="DEV">{{ item }}</div>
        </ElCarouselItem>
      </ElCarousel>
    </template>
  </ElSkeleton>
</template>

<script>
/**
 * 首页轮播图
 */
export default {
  // 组件名称
  name: "BannerHome",

  // 组件
  components: {},

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    list: Array(0), // 轮播图队列

    interval: Number(3), // 跑马灯间隔
    index: Number(0), // 当前轮播图索引
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.Api.HomeBanner.GetData().then(($) => (this.list = $));
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.el-skeleton,
.el-carousel {
  // 骨架屏和轮播图容器
  border-radius: 8px;
  margin-top: 12px;
  flex-shrink: 0;
  width: 1200px;
}

.el-carousel {
  .el-carousel__item {
    background-repeat: no-repeat;
    background-size: 100% 100%;
  }
}

.el-skeleton {
  // 骨架屏防止溢出
  overflow: hidden;
  height: 460px;
}
</style>