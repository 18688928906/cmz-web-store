<template>
  <div class="plate-img" :style="`background-image:url('${src}');`">
    <slot />
  </div>
</template>

<script>
/**
 * 首页板块图片
 */
export default {
  // 组件
  components: {},

  // 接收参数
  props: ["src"],

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.plate-img {
  // 使用背景优化图片
  transition: box-shadow var(--base-transition);
  background-repeat: no-repeat;
  background-size: 100% 100%;
  border-radius: 4px;
  position: relative;
  cursor: pointer;
  height: 140px;
  width: 140px;
}

.plate-img:hover {
  // 鼠标移入模块出现阴影
  box-shadow: var(--base-shadow);
}
</style>