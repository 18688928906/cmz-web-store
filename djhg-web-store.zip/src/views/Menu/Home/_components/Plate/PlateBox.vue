<template>
  <div class="plate-box">
    <PlateShop />
    <PlateLease />
    <PlateSurplus />
    <PlateRecycle />
    <PlateDemand />
  </div>
</template>

<script>
import PlateShop from "./PlateShop.vue";
import PlateLease from "./PlateLease.vue";
import PlateSurplus from "./PlateSurplus.vue";
import PlateRecycle from "./PlateRecycle.vue";
import PlateDemand from "./PlateDemand.vue";

/**
 * 首页板块
 */
export default {
  // 组件
  components: {
    PlateShop,
    PlateLease,
    PlateSurplus,
    PlateRecycle,
    PlateDemand,
  },

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.plate-box {
  // 首页板块容器
  grid-template-columns: repeat(3, 392px);
  grid-template-rows: repeat(2, 392px);
  grid-column-gap: 12px;
  grid-row-gap: 12px;
  margin-top: 12px;
  display: grid;
  width: 1200px;

  .plate {
    // 板块添加过度
    transition: box-shadow var(--base-transition);
  }

  .plate:hover {
    // 板块鼠标移入阴影
    box-shadow: var(--base-shadow);
  }
}
</style>