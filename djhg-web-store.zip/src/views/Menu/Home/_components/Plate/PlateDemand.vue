<template>
  <div class="plate">
    <ElSkeleton :loading="List.length === 0" :animated="true">
      <!-- 骨架屏部分 -->
      <template #template>
        <div class="label-box">
          <ElSkeletonItem class="label" style="width: 56px" />
          <ElSkeletonItem class="tips" style="width: 108px" />
        </div>
        <div class="list">
          <div v-for="item in 3" class="list-item" :key="item">
            <ElSkeletonItem variant="image" class="avatar" />
            <div class="info-box">
              <ElSkeletonItem class="user" style="width: 100px" />
              <div class="info">
                <ElSkeletonItem class="label" />
                <ElSkeletonItem style="width: 100px" />
              </div>
            </div>
          </div>
        </div>
      </template>

      <template #default>
        <!-- 标签容器 -->
        <div class="label-box" @click="GoList()">
          <div class="label">需求</div>
          <div class="tips">用户需求公示</div>
        </div>

        <!-- 列表 -->
        <div class="list">
          <template v-for="(item, index) in List" :key="index">
            <!-- 超过3条不再渲染 -->
            <div v-if="index < 3" class="list-item">
              <!-- 用户头像 -->
              <img class="avatar" :src="item.User.Avatar" />

              <!-- 需求内容 -->
              <div class="info-box">
                <div class="user">{{ item.User.Name }}</div>
                <div class="info">
                  <div class="label">{{ item.Label }}</div>
                  <div>{{ item.CreateTime }}</div>
                </div>
              </div>

              <div v-if="DEV" class="DEV" style="right: 0; top: -4px">
                ID：{{ item.Id }}
              </div>
            </div>
          </template>
        </div>
      </template>
    </ElSkeleton>
  </div>
</template>

<script>
/**
 * 首页需求板块
 */
export default {
  // 组件
  components: {},

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    List: Array(0),
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 初始化接口并更新数据
    this.ApiNew.DemandList()
      .init({ Limit: 3 })
      .GetList(true)
      .then((list) => (this.List = list));
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 跳转列表
    GoList() {
      this.$GO({ path: "/menu/needs/list/lease" });
    },
  },
};
</script>

<style lang="scss" scoped>
.plate {
  // 首页板块容器
  background-color: white;
  flex-direction: column;
  grid-column-start: 2;
  align-items: stretch;
  grid-column-end: 4;
  border-radius: 8px;
  display: flex;
  height: 100%;
  width: 100%;

  .label-box {
    // 标签容器
    flex-direction: column;
    align-items: center;
    cursor: pointer;
    display: flex;

    .label {
      // 标签
      text-align: center;
      font-weight: bold;
      margin-top: 16px;
      font-size: 28px;
      line-height: 1;
      height: 28px;
    }

    .tips {
      // 标签
      color: rgba(153, 153, 153, 1);
      text-align: center;
      margin-top: 11px;
      font-size: 18px;
      line-height: 1;
      height: 18px;
    }
  }

  .list {
    // 内容列
    flex-direction: column;
    align-items: stretch;
    margin-top: 20px;
    padding: 0 40px;
    display: flex;
    width: 100%;

    .list-item {
      // 单条
      border-bottom: 1px solid rgba(239, 239, 239, 1);
      position: relative;
      padding-bottom: 11px;
      align-items: center;
      position: relative;
      display: flex;

      .avatar {
        // 头像
        border-radius: 26px;
        flex-shrink: 0;
        height: 52px;
        width: 52px;
      }

      .info-box {
        // 需求信息
        align-items: flex-start;
        flex-direction: column;
        align-items: stretch;
        margin-left: 35px;
        display: flex;
        flex-grow: 1;

        .user {
          // 用户
          font-size: 14px;
          width: 100%;
        }

        .info {
          // 信息
          margin-top: 8px;
          font-size: 12px;
          display: flex;

          .label {
            flex-grow: 1;
          }

          .label + div {
            color: rgba(153, 153, 153, 1);
            margin-left: 2em;
            flex-shrink: 0;
          }
        }
      }
    }

    .list-item + .list-item {
      margin-top: 18px;
    }
  }
}
</style>