<template>
  <!-- 轮播图 -->
  <ElCarousel indicator-position="none" height="100%" arrow="never">
    <template v-for="(item, index) in list" :key="index">
      <!-- 使用背景优化图片 -->
      <ElCarouselItem
        v-if="index < list.length - 3"
        :style="`background-image:url('${item.Img}');`"
        @click="$emit('setId', item.Id)"
      >
        <div v-if="DEV" class="DEV">ID：{{ item.Id }}</div>
      </ElCarouselItem>
    </template>
  </ElCarousel>
</template>

<script>
/**
 * 首页板块轮播图
 */
export default {
  // 组件
  components: {},

  // 接收参数
  props: ["list"],

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.el-carousel {
  // 覆盖组件样式
  transition: box-shadow var(--base-transition);
  border-radius: 4px;
  cursor: pointer;
  height: 100%;
  width: 100%;

  .el-carousel__item {
    background-repeat: no-repeat;
    background-size: 100% 100%;
  }
}

.el-carousel:hover {
  // 鼠标移入模块出现阴影
  box-shadow: var(--base-shadow);
}
</style>