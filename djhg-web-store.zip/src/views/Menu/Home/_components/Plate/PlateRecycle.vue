<template>
  <div class="plate">
    <ElSkeleton :loading="List.length === 0" :animated="true">
      <!-- 骨架屏部分 -->
      <template #template>
        <div class="label-box">
          <ElSkeletonItem class="label" style="width: 112px" />
          <ElSkeletonItem class="tips" style="width: 126px" />
        </div>
        <div class="list">
          <ElSkeletonItem
            v-for="item in 4"
            style="width: 100%; height: 100%; border-radius: 4px"
            variant="image"
            :key="item"
          />
        </div>
      </template>

      <template #default>
        <!-- 标签容器 -->
        <div class="label-box">
          <div class="label">回收中心</div>
          <div class="tips">旧品回收估价区</div>
        </div>

        <!-- 列表 -->
        <div class="list">
          <!-- 超过4条内容 -->
          <template v-if="List.length > 4">
            <!-- 跑马灯 -->
            <PlateBanner :list="List" />

            <!-- 正常显示图片 -->
            <template v-for="(item, index) in List" :key="index">
              <PlateImg v-if="index >= List.length - 3" :src="item.Img">
                <div v-if="DEV" class="DEV">ID：{{ item.Id }}</div>
              </PlateImg>
            </template>
          </template>

          <!-- 小于4条内容 -->
          <template v-else>
            <PlateImg
              v-for="(item, index) in List"
              :src="item.Img"
              :key="index"
            >
              <div v-if="DEV" class="DEV">ID：{{ item.Id }}</div>
            </PlateImg>
          </template>
        </div>
      </template>
    </ElSkeleton>
  </div>
</template>

<script>
import PlateBanner from "./PlateBanner.vue";
import PlateImg from "./PlateImg.vue";

/**
 * 首页回收板块
 */
export default {
  // 组件
  components: { PlateBanner, PlateImg },

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    List: Array(0),
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 初始化接口并更新数据
    this.ApiNew.RecycleHomeList()
      .GetList(true)
      .then((list) => (this.List = list));
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.plate {
  // 首页板块容器
  background-color: white;
  flex-direction: column;
  align-items: stretch;
  border-radius: 8px;
  display: flex;
  height: 100%;
  width: 100%;

  .label-box {
    // 标签容器
    flex-direction: column;
    align-items: center;
    cursor: pointer;
    display: flex;

    .label {
      // 标签
      text-align: center;
      font-weight: bold;
      margin-top: 16px;
      font-size: 28px;
      line-height: 1;
      height: 28px;
    }

    .tips {
      // 标签
      color: rgba(153, 153, 153, 1);
      text-align: center;
      margin-top: 11px;
      font-size: 18px;
      line-height: 1;
      height: 18px;
    }
  }

  .list {
    // 内容列
    grid-template-columns: 140px 140px;
    grid-template-rows: 140px 140px;
    justify-content: center;
    box-sizing: border-box;
    grid-column-gap: 20px;
    position: relative;
    grid-row-gap: 8px;
    margin-top: 16px;
    display: grid;
  }
}
</style>