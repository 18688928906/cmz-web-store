<template>
  <div class="page">
    <!-- 背景图片 -->
    <img :src="bg" class="bg" />

    <ElRow
      v-loading="loading"
      element-loading-background="rgba(0,0,0,0.2)"
      class="page-box"
    >
      <!-- 聊天历史记录 -->
      <History v-model:chat="chat" :store="store" :from="from" :query="query" />

      <!-- 通信界面 -->
      <Communication :store="store" :from="from" :chat="chat" :query="query" />

      <!-- 商品 -->
      <Product :chat="chat" :query="query" :from="from" :store="store" />
    </ElRow>
  </div>
</template>

<script>
import bg from "@/assets/聊天背景.jpg";

import { GUID } from "@/library.js";
import History from "./_components/History/Box.vue";
import Communication from "./_components/Communication/Box.vue";
import Product from "./_components/Product/Box.vue";

export default {
  // 自动路由参数
  meta: {
    title: undefined, // 写入浏览器页签
    index: undefined, // 用于排序
    label: "聊天界面", // 显示用的路由名称
    name: "Chat", // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(true), // 控制是否需要登录
  },

  // 组件
  components: { History, Communication, Product },

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    bg, // 背景图片

    guid: GUID(), // 唯一ID

    loading: true,

    chat: undefined, // 会话

    // 用户信息
    from: {
      userType: 1, // 固定类型
      userId: String(window?.$USER$?.UserId), // 当前用户ID
      nickName: window?.$USER$?.Nick, // 当前用户昵称
      headurl: window?.$USER$?.Avatar, // 当前用户头像
    },

    store: {}, // 保存店铺信息
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.Api.UserCustomerOrderList.SetStoreId(this.query.Id); // 获取店铺订单

    if (!!this.query.Id) {
      // 获取在线客服
      this.Api.UserCustomerId.init({ Id: this.query.Id })
        .AddUpdate("UserCustomerId", (Id) => {
          this.store = { Id: String(Id), StoreId: String(this.query.Id) }; // 获取客服ID
        })
        .GetData()
        .then(() => {
          // 建立长连接
          this.Api.UserCustomerWebSocket.UseLink().then((ws) => {
            ws.Send({ type: 3 }); // 获取会话
          });
        });
    } else {
      this.store = { Id: undefined, StoreId: undefined }; // 获取客服ID

      // 建立长连接
      this.Api.UserCustomerWebSocket.UseLink().then((ws) => {
        ws.Send({ type: 3 }); // 获取会话
        this.loading = false;
      });
    }

    // 订阅消息
    this.Api.UserCustomerWebSocket.AddUpdate(this.guid, (data) => {
      this.loading = data?.Loading === true; // 处理加载
    });
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    this.Api.UserCustomerWebSocket.Close().DelUpdate(this.guid); // 关闭会话并取消数据订阅
  },

  // 组件方法
  methods: {
    // 设置聊天列表
    SetChatList($) {
      this.ChatList = $;
    },
  },
};
</script>

<style lang="scss" scoped>
.page {
  // 页面
  position: relative;
  overflow: hidden;
  height: 100%;
  width: 100%;

  .bg {
    // 背景图
    height: calc(100% + 12px);
    width: calc(100% + 12px);
    position: absolute;
    filter: blur(5px);
    left: -6px;
    top: -6px;
  }

  .page-box {
    // 布局容器
    border: 1px solid rgba(223, 225, 229, 1);
    left: calc((100% - 1200px) / 2);
    background-color: white;
    align-items: stretch;
    border-radius: 20px;
    position: absolute;
    flex-wrap: nowrap;
    overflow: hidden;
    width: 1200px;
    height: 80%;
    top: 10%;
  }
}
</style>