<template>
  <ElRow class="order-box">
    <template v-if="!!query.Product && store.StoreId === String(query.Id)">
      <ElRow class="label">
        <div />
        <span>正在咨询</span>
        <div />
      </ElRow>

      <Product :store="store" :detail="query.Product" :from="from" />
    </template>

    <template v-if="!!list">
      <!-- 标题 -->
      <ElRow class="label">
        <div />
        <span>店铺订单</span>
        <div />
      </ElRow>

      <!-- 滚动容器 -->
      <ElScrollbar v-if="list">
        <Item
          v-for="(item, index) in list"
          :store="store"
          :detail="item"
          :from="from"
          :key="index"
        />
      </ElScrollbar>
    </template>

    <ElRow v-else-if="!store.Id" class="no">请选择联系人</ElRow>
  </ElRow>
</template>

<script>
import { GUID } from "@/library.js";
import Item from "./Item.vue";
import Product from "./Product.vue";

export default {
  // 组件
  components: { Item, Product },

  // 接收参数
  props: {
    // 唯一ID
    guid: {
      type: String,
      default: GUID(),
    },

    // 店铺信息
    from: {
      type: Object,
      default: () => Object(),
    },

    // 店铺信息
    store: {
      type: Object,
      default: () => Object(),
    },

    query: undefined, // 获取解密后的传参
    chat: undefined, // 会话
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    list: undefined,
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 订阅订单数据
    this.Api.UserCustomerOrderList.AddUpdate(this.guid, (data) => {
      this.list = undefined;
      this.$nextTick((_) => {
        this.list = data;
      });
    });
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.order-box {
  // 订单容器
  justify-content: flex-start;
  flex-direction: column;
  border-left: inherit;
  align-items: center;
  flex-wrap: nowrap;
  padding: 0 12px;
  flex-shrink: 0;
  height: 100%;
  width: 260px;

  .label {
    // 标题容器
    justify-content: space-between;
    color: rgba(96, 98, 102, 1);
    margin-bottom: 12px;
    align-items: center;
    font-weight: bold;
    margin-top: 20px;
    width: 160px;

    span {
      color: rgba(96, 98, 102, 1);
      font-size: 12px;
    }

    div {
      background-color: rgba(96, 98, 102, 1);
      height: 1px;
      width: 50px;
    }
  }

  .el-scrollbar {
    // 滚动容器
    flex-grow: 1;
    width: 100%;
  }

  .product {
    // 商品
    background-color: rgba(215, 235, 255, 1);
    border-radius: 10px;
    padding: 10px;
    width: 100%;

    .logo {
      border-radius: 4px;
      height: 80px;
      width: 80px;
    }
  }

  .no {
    justify-content: center;
    align-items: center;
    font-size: 14px;
    flex-grow: 1;
  }
}
</style>