<template>
  <ElRow class="product">
    <img class="logo" :src="detail.Img" />
    <ElRow class="info-box">
      <!-- 商品名称 -->
      <div class="name" ref="$" :class="{ omitA: omit }" @click="opexn()">
        <div v-if="detail.Type === 10" class="A">
          <SvgText>全新</SvgText>
        </div>
        <div v-if="detail.Type === 40" class="B">
          <SvgText>二手</SvgText>
        </div>
        <div v-if="detail.Type === 20" class="C">
          <SvgText>租赁</SvgText>
        </div>
        <span>{{ detail.Name }}</span>
      </div>

      <!-- 订单价格 -->
      <ElRow class="price-box">
        <div class="price">￥{{ detail.Price }}</div>
      </ElRow>

      <div class="button" @click="UpOrder()">发送链接</div>
    </ElRow>
  </ElRow>
</template>

<script>
import SvgText from "./SvgText.vue";

export default {
  // 组件
  components: { SvgText },

  // 接收参数
  props: {
    // 详情
    detail: {
      type: Object,
      default: () => Object(),
    },

    // 店铺信息
    from: {
      type: Object,
      default: () => Object(),
    },

    // 店铺信息
    store: {
      type: Object,
      default: () => Object(),
    },
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    omit: Boolean(false), // 是否使用省略号
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {
    const $ = this.$refs.$;
    this.omit = $.clientHeight < $.scrollHeight; // 检测文本溢出
  },

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 上传订单
    UpOrder() {
      var $ = new Date();
      $ = [
        [$.getFullYear(), $.getMonth() + 1, $.getDate()]
          .map((t) => (t > 9 ? "" : "0") + t)
          .join("-"), // 年月日
        [$.getHours(), $.getMinutes(), $.getSeconds()]
          .map((t) => (t > 9 ? "" : "0") + t)
          .join(":"), // 时分秒
      ];
      var pro = {
        id: this.detail.Id,
        coverImgurl: this.detail.Img,
        proName: this.detail.Name,
        minPrice: this.detail.Price,
        saleCount: this.detail.Sale,
        proType: this.detail.Type,
        qty: this.detail.Max,
      };
      var data = {
        date: $.join(" "),
        from: this.from,
        text: "[商品]",
        pro,
        to: String(this.store.Id),
        type: 13,
      };
      this.Api.UserCustomerWebSocket.Send(data);
      data.merchantid = String(this.store.Id);
      this.Api.UserCustomerWebSocket._WsOnMessage(
        { data: JSON.stringify(data) },
        this.Api.UserCustomerWebSocket._ws
      );
    },

    // 打开
    opexn() {
      this.$GO(
        { path: "/menu/surplus/detail", data: { Id: this.detail.Id } },
        true
      );
    },
  },
};
</script>

<style lang="scss" scoped>
.product {
  // 商品
  background-color: rgba(215, 235, 255, 1);
  border-radius: 10px;
  flex-wrap: nowrap;
  padding: 10px;
  width: 100%;

  .logo {
    // 商品图
    border-radius: 4px;
    flex-shrink: 0;
    height: 80px;
    width: 80px;
  }

  .info-box {
    // 信息容器
    justify-content: space-between;
    flex-direction: column;
    align-items: stretch;
    flex-wrap: nowrap;
    margin-left: 4px;
    flex-grow: 1;
    height: 80px;

    .name {
      // 商品名称
      word-break: break-all;
      position: relative;
      line-height: 18px;
      overflow: hidden;
      font-size: 14px;
      cursor: pointer;
      display: block;
      height: 36px;
      width: 100%;

      .A,
      .B,
      .C {
        transform: translateY(2px);
        display: inline-block;
        border-radius: 14px;
        margin-right: 12px;
        height: 14px;
        width: 30px;
      }

      .A {
        box-shadow: inset 1px 1px 1px 0px rgba(205, 37, 0, 0.63),
          inset -1px -1px 2px 0px #cd2500, 0px 0px 4px 0px rgba(255, 46, 0, 0.5);

        background-color: rgba(253, 63, 21, 1);
      }

      .B {
        box-shadow: inset 1px 1px 1px 0px rgba(0, 119, 186, 0.63),
          inset -1px -1px 2px 0px #008ad8,
          0px 0px 4px 0px rgba(0, 163, 255, 0.5);

        background-color: rgba(42, 178, 255, 1);
      }

      .C {
        box-shadow: inset 1px 1px 1px 0px rgba(0, 165, 55, 0.63),
          inset -1px -1px 2px 0px #00a537,
          0px 0px 4px 0px rgba(0, 255, 139, 0.5);

        background-color: rgba(66, 185, 131, 1);
      }
    }

    .omit::after {
      // 省略号
      background: linear-gradient(
        to right,
        transparent,
        rgba(215, 235, 255, 1) 55%
      );
      position: absolute;
      line-height: 18px;
      text-align: right;
      content: "…";
      font-size: 14px;
      width: 2.5em;
      bottom: 0;
      right: 0;
    }
  }

  .button {
    // 按钮
    border: 1px solid rgba(57, 123, 255, 1);
    color: rgba(57, 123, 255, 1);
    border-radius: 1em;
    text-align: center;
    line-height: 16px;
    font-size: 12px;
    cursor: pointer;
    width: 68px;
  }

  .price-box {
    align-items: center;

    .price {
      font-weight: bold;
      font-size: 12px;
      color: red;
    }
  }
}
</style>