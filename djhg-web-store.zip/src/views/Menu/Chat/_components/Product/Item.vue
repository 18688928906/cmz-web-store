<template>
  <ElRow class="item-box">
    <!-- 订单状态 -->
    <ElRow class="item-label-box">
      <span>{{ detail.Status.Label(detail.Status.Type) }}</span>
      <div v-if="detail.Type === 10" class="A">
        <SvgText>全新</SvgText>
      </div>
      <div v-if="detail.Type === 40" class="B">
        <SvgText>二手</SvgText>
      </div>
      <div v-if="detail.Type === 20" class="C">
        <SvgText>租赁</SvgText>
      </div>
    </ElRow>

    <!-- 订单信息 -->
    <div class="item-info">
      <div class="code"><span>订单编号：</span>{{ detail.Code }}</div>
      <div class="code"><span>下单时间：</span>{{ detail.Time }}</div>
      <ElRow class="info-box">
        <img :src="detail.Img" class="logo" />
        <ElRow class="info">
          <!-- 商品名称 -->
          <div class="name" ref="$" :class="{ omit: omit }">
            {{ detail.Name }}
          </div>

          <!-- 发送按钮 -->
          <div class="button" @click="UpOrder()">发送链接</div>
        </ElRow>
      </ElRow>
      <ElRow v-if="detail.Status.Type !== 1 && !!detail.Price" class="price">
        实付款：<span>￥{{ detail.Price }}</span>
      </ElRow>
    </div>
  </ElRow>
</template>

<script>
import SvgText from "./SvgText.vue";

export default {
  // 组件
  components: { SvgText },

  // 接收参数
  props: {
    // 详情
    detail: {
      type: Object,
      default: () => Object(),
    },

    // 店铺信息
    from: {
      type: Object,
      default: () => Object(),
    },

    // 店铺信息
    store: {
      type: Object,
      default: () => Object(),
    },
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    omit: Boolean(false), // 是否使用省略号
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {
    const $ = this.$refs.$;
    this.omit = $.clientHeight < $.scrollHeight; // 检测文本溢出
  },

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 获取时间
    GetTime() {
      var now = new Date(); // 获取当前时间
      var time = new Date(this.detail.Time); // Unix转时间对象
      if (
        time.getFullYear() !== now.getFullYear() ||
        time.getMonth() !== now.getMonth() ||
        time.getDate() !== now.getDate()
      ) {
        return [time.getFullYear(), time.getMonth() + 1, time.getDate()].join(
          "/"
        );
      } else {
        return [time.getHours(), time.getMinutes()].join(":");
      }
    },

    // 上传订单
    UpOrder() {
      var $ = new Date();
      $ = [
        [$.getFullYear(), $.getMonth() + 1, $.getDate()]
          .map((t) => (t > 9 ? "" : "0") + t)
          .join("-"), // 年月日
        [$.getHours(), $.getMinutes(), $.getSeconds()]
          .map((t) => (t > 9 ? "" : "0") + t)
          .join(":"), // 时分秒
      ];
      var data = {
        date: $.join(" "),
        from: this.from,
        text: "[订单]",
        order: this.detail.$,
        to: String(this.store.Id),
        type: 2003,
      };
      this.Api.UserCustomerWebSocket.Send(data);
      data.merchantid = String(this.store.Id);
      this.Api.UserCustomerWebSocket._WsOnMessage(
        { data: JSON.stringify(data) },
        this.Api.UserCustomerWebSocket._ws
      );
    },
  },
};
</script>

<style lang="scss" scoped>
.item-box {
  // 单项容器
  background-color: rgba(245, 245, 245, 1);
  flex-direction: column;
  align-items: stretch;
  border-radius: 10px;
  position: relative;
  flex-wrap: nowrap;
  width: 100%;

  .item-label-box {
    // 标题容器
    justify-content: space-between;
    align-items: center;
    padding-right: 16px;
    padding-left: 10px;
    margin-bottom: 4px;
    margin-top: 10px;

    span {
      color: rgba(253, 63, 21, 1);
      font-size: 12px;
    }

    div {
      border-radius: 14px;
      // overflow: hidden;
      color: white;
      // height: 14px;
    }

    .A {
      box-shadow: inset 1px 1px 1px 0px rgba(205, 37, 0, 0.63),
        inset -1px -1px 2px 0px #cd2500, 0px 0px 4px 0px rgba(255, 46, 0, 0.5);

      background-color: rgba(253, 63, 21, 1);
    }

    .B {
      box-shadow: inset 1px 1px 1px 0px rgba(0, 119, 186, 0.63),
        inset -1px -1px 2px 0px #008ad8, 0px 0px 4px 0px rgba(0, 163, 255, 0.5);

      background-color: rgba(42, 178, 255, 1);
    }

    .C {
      box-shadow: inset 1px 1px 1px 0px rgba(0, 165, 55, 0.63),
        inset -1px -1px 2px 0px #00a537, 0px 0px 4px 0px rgba(0, 255, 139, 0.5);

      background-color: rgba(66, 185, 131, 1);
    }
  }

  .item-info {
    // 订单信息
    border-top: 1px solid rgba(223, 225, 229, 1);
    padding: 10px 8px;

    .code {
      // 订单编号
      margin-bottom: 12px;
      line-height: 1em;
      font-size: 12px;

      span {
        color: rgba(96, 98, 102, 1);
      }
    }

    .info-box {
      // 订单信息容器
      align-items: center;
      flex-wrap: nowrap;

      .logo {
        // 商品图
        border-radius: 4px;
        flex-shrink: 0;
        height: 80px;
        width: 80px;
      }

      .info {
        // 商品信息
        justify-content: space-between;
        flex-direction: column;
        align-items: stretch;
        flex-wrap: nowrap;
        margin-left: 6px;
        flex-grow: 1;
        height: 75px;

        .name {
          // 商品名称
          word-break: break-all;
          position: relative;
          line-height: 14px;
          overflow: hidden;
          font-size: 12px;
          height: 28px;
        }

        .omit::after {
          // 省略号
          background: linear-gradient(
            to right,
            transparent,
            rgba(245, 245, 245, 1) 55%
          );
          color: rgba(102, 102, 102, 1);
          position: absolute;
          line-height: 14px;
          text-align: right;
          content: "…";
          font-size: 12px;
          width: 2.5em;
          bottom: 0;
          right: 0;
        }

        .button {
          // 按钮
          border: 1px solid rgba(57, 123, 255, 1);
          color: rgba(57, 123, 255, 1);
          border-radius: 1em;
          text-align: center;
          line-height: 16px;
          font-size: 12px;
          cursor: pointer;
          width: 68px;
        }
      }
    }

    .price {
      justify-content: space-between;
      color: rgba(96, 98, 102, 1);
      font-weight: bold;
      line-height: 1em;
      margin-top: 12px;
      font-size: 12px;

      span {
        color: red;
      }
    }
  }
}

.item-box + .item-box {
  margin-top: 12px;
}
</style>