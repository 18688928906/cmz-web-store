<template>
  <ElRow
    :class="{ 'item-active': String(detail.StoreId) === String(store.StoreId) }"
    class="item-box"
    @click="SetId()"
  >
    <ElBadge :value="detail.Unread" :hidden="detail.Unread < 1" is-dot>
      <ElAvatar :size="32" :src="detail.Avatar">
        {{ detail.Name?.[0] }}
      </ElAvatar>
    </ElBadge>

    <div class="info-box">
      <!-- 聊天对象信息 -->
      <ElRow class="info">
        <div class="name">{{ detail.Name }}</div>
        <div class="time">{{ GetTime() }}</div>
      </ElRow>

      <!-- 最新消息 -->
      <div v-if="detail.Type === 10" class="last">{{ detail.Last || "-" }}</div>
      <div v-else-if="detail.Type === 11" class="last">[图片]</div>
      <div v-else-if="detail.Type === 12" class="last">[订单]</div>
      <div v-else-if="detail.Type === 13" class="last">[商品]</div>
      <div v-else-if="detail.Type === 2001" class="last">[支付提醒]</div>
      <div v-else-if="detail.Type === 2002" class="last">[确认订单]</div>
      <div v-else-if="detail.Type === 2003" class="last">[订单]</div>
      <div v-else-if="detail.Type === 2004" class="last">[物流]</div>
      <div v-else class="last">{{ detail.Last || "-" }}</div>
    </div>
  </ElRow>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    // 详情
    detail: {
      type: Object,
      default: () => Object(),
    },

    // 店铺信息
    store: {
      type: Object,
      default: () => Object(),
    },
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 获取时间
    GetTime() {
      var now = new Date(); // 获取当前时间
      var time = new Date(this.detail.Time); // Unix转时间对象
      if (
        time.getFullYear() !== now.getFullYear() ||
        time.getMonth() !== now.getMonth() ||
        time.getDate() !== now.getDate()
      ) {
        return [time.getFullYear(), time.getMonth() + 1, time.getDate()].join(
          "/"
        );
      } else {
        return [time.getHours(), time.getMinutes()].join(":");
      }
    },

    // 切换聊天对象
    SetId() {
      this.detail.Unread = 0; // 清除未读
      this.store.Id = this.detail.Id;
      this.store.StoreId = this.detail.StoreId;
      this.Api.UserCustomerWebSocket.Send({ type: 3 }); // 获取会话
      this.Api.UserCustomerOrderList.SetStoreId(this.detail.StoreId); // 获取店铺订单
    },
  },
};
</script>

<style lang="scss" scoped>
.item-box {
  // 单项容器
  align-items: center;
  flex-wrap: nowrap;
  padding: 0 10px;
  cursor: pointer;
  height: 50px;
  width: 100%;

  .el-avatar {
    flex-shrink: 0;
  }

  .info-box {
    // 信息容器
    margin-left: 14px;
    width: 190px;

    .info {
      align-items: center;
      flex-wrap: nowrap;
      overflow: hidden;

      div {
        line-height: 16px;
        font-size: 12px;
        line-height: 1;
      }

      .name {
        text-overflow: ellipsis;
        white-space: nowrap;
        font-weight: bold;
        overflow: hidden;
        flex-grow: 1;
      }

      .time {
        color: rgba(192, 196, 204, 1);
        margin-left: 16px;
        flex-shrink: 0;
      }
    }

    .last {
      // 最新消息
      color: rgba(96, 98, 102, 1);
      text-overflow: ellipsis;
      white-space: nowrap;
      line-height: 16px;
      overflow: hidden;
      margin-top: 8px;
      font-size: 12px;
      display: block;
    }
  }
}

.item-active {
  background-color: rgba(198, 226, 255, 0.7);
  border-left: 4px solid var(--el-color-primary);
  padding-left: 6px;
}
</style>