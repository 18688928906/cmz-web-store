<template>
  <ElRow class="history-box">
    <!-- 搜索功能 -->
    <ElRow class="search-box">
      <img :src="$svg['i-0025-828282']" />
      <ElInput v-model="input" clearable />
    </ElRow>

    <!-- 滚动容器 -->
    <ElScrollbar>
      <Item
        v-for="(item, index) in _list"
        :detail="item"
        :store="store"
        :key="index"
      />
    </ElScrollbar>
  </ElRow>
</template>

<script>
import { GUID } from "@/library.js";
import Item from "./Item.vue";
export default {
  // 组件
  components: { Item },

  // 接收参数
  props: {
    // 唯一ID
    guid: {
      type: String,
      default: GUID(),
    },

    // 店铺信息
    store: {
      type: Object,
      default: () => Object(),
    },

    // 店铺信息
    from: {
      type: Object,
      default: () => Object(),
    },

    chat: undefined, // 会话
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {
    _list: {
      get() {
        if (!this.input || this.input == "") {
          return this.list;
        } else {
          return this.list.filter(($) => $.Name.includes(this.input));
        }
      },
    },
  },

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    input: "",
    bug: false, // 检查发生BUG进行中断
    list: undefined,
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 订阅消息
    this.Api.UserCustomerWebSocket.AddUpdate(this.guid, (data) => {
      if (data.Type === 3) {
        this.list = undefined; // 强制刷新
        this.list = data.List; // 处理聊天列表
        var item = this.list.find(($) => $.StoreId === this.store.StoreId);

        // 有会话处理聊天记录
        if (!!item) {
          this.store.Name = item.Name; // 会话名称
          this.store.StoreId = item.StoreId;
          this.store.Merchant = item.Merchant; // 会话ID
          this.$emit("update:chat", item.ChatId); // 会话ID
        }

        // 没有记录尝试新建连接
        else if (!this.bug || !item) {
          this.bug = true; // 打开报错拦截
          !!this.query.Id &&
            this.Api.UserCustomerId.GetData().then(() => this.NewChat());
        }

        // 全部失败
        else {
          ElMessage.error("聊天创建失败，请刷新当前界面");
        }
      }
    });

    this.BUS.GetStoreAvatar = (Id) => {
      return this.list.find(($) => $.Id === Id)?.Avatar;
    };
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    this.Api.UserCustomerWebSocket.DelUpdate(this.guid); // 取消数据订阅
    delete this.BUS.GetStoreAvatar;
  },

  // 组件方法
  methods: {
    // 新建会话
    NewChat() {
      var $ = new Date();
      $ = [
        [$.getFullYear(), $.getMonth() + 1, $.getDate()]
          .map((t) => (t > 9 ? "" : "0") + t)
          .join("-"), // 年月日
        [$.getHours(), $.getMinutes(), $.getSeconds()]
          .map((t) => (t > 9 ? "" : "0") + t)
          .join(":"), // 时分秒
      ];
      this.Api.UserCustomerWebSocket.Send({
        date: $.join(" "),
        from: this.from,
        text: "",
        to: String(this.store.Id),
        type: 2000,
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.history-box {
  // 历史容器
  justify-content: flex-start;
  flex-direction: column;
  border-right: inherit;
  align-items: stretch;
  flex-wrap: nowrap;
  flex-shrink: 0;
  height: 100%;
  width: 260px;

  .search-box {
    // 搜索容器
    border: 1px solid rgba(223, 225, 229, 1);
    background-color: white;
    margin: 20px 15px 12px;
    border-radius: 20px;
    align-items: center;
    flex-wrap: nowrap;
    overflow: hidden;
    height: 32px;

    img {
      margin-left: 8px;
      height: 14px;
      width: 14px;
    }

    .el-input {
      flex-grow: 1;

      :deep(.el-input__wrapper) {
        box-shadow: none;
      }
    }
  }
}
</style>