<template>
  <ElRow class="item-box">
    <!-- 前头像 -->
    <div class="avatar">
      <ElAvatar v-if="!detail.User" :size="32" :src="Avatar">
        {{ detail.Name[0] }}
      </ElAvatar>
    </div>

    <!-- 信息容器 -->
    <div
      class="info"
      :style="`flex-direction:${detail.User ? 'row-reverse' : 'row'}`"
    >
      <!-- 处理文本类型 -->
      <div v-if="detail.Type === 10" class="textA">
        {{ detail.Data }}

        <!-- 时间 -->
        <div :style="detail.User ? 'right:0px' : 'left:0px'" class="time">
          {{ GetTime() }}
        </div>

        <Read :detail="detail" />
      </div>

      <!-- 处理图片类 -->
      <ImgBox v-else-if="detail.Type === 11" :detail="detail" />

      <!-- 处理订单类型 -->
      <div v-else-if="detail.Type === 12" class="textB">
        <Order :detail="detail" />

        <!-- 时间 -->
        <div :style="detail.User ? 'right:0px' : 'left:0px'" class="time">
          {{ GetTime() }}
        </div>

        <Read :detail="detail" />
      </div>

      <!-- 处理支付提醒 -->
      <div v-else-if="detail.Type === 2001" class="textB">
        <ReminderPayment :detail="detail" />

        <!-- 时间 -->
        <div :style="detail.User ? 'right:0px' : 'left:0px'" class="time">
          {{ GetTime() }}
        </div>

        <Read :detail="detail" />
      </div>

      <!-- 处理核对订单 -->
      <div v-else-if="detail.Type === 2002" class="textB">
        <CheckOrder :detail="detail" :from="from" :store="store" />

        <!-- 时间 -->
        <div :style="detail.User ? 'right:0px' : 'left:0px'" class="time">
          {{ GetTime() }}
        </div>

        <Read :detail="detail" />
      </div>

      <!-- 处理订单类型 -->
      <div v-else-if="detail.Type === 2003" class="textB">
        <Order :detail="detail" />

        <!-- 时间 -->
        <div :style="detail.User ? 'right:0px' : 'left:0px'" class="time">
          {{ GetTime() }}
        </div>

        <Read :detail="detail" />
      </div>

      <!-- 处理物流类型 -->
      <div v-else-if="detail.Type === 2004" class="textB">
        <Exp :detail="detail" />

        <!-- 时间 -->
        <div :style="detail.User ? 'right:0px' : 'left:0px'" class="time">
          {{ GetTime() }}
        </div>

        <Read :detail="detail" />
      </div>

      <!-- 处理商品类型 -->
      <div v-else-if="detail.Type === 13" class="textB">
        <Product :detail="detail" />

        <!-- 时间 -->
        <div :style="detail.User ? 'right:0px' : 'left:0px'" class="time">
          {{ GetTime() }}
        </div>

        <Read :detail="detail" />
      </div>
    </div>

    <!-- 后头像 -->
    <div class="avatar">
      <ElAvatar v-if="detail.User" :size="32" :src="User?.Avatar">
        {{ User.Nick[0] }}
      </ElAvatar>
    </div>
  </ElRow>
</template>

<script>
import ImgBox from "./ImgBox.vue";
import Order from "./Order.vue";
import Product from "./Product.vue";
import Read from "./Read.vue";
import Exp from "./Exp.vue";
import ReminderPayment from "./ReminderPayment.vue";
import CheckOrder from "./CheckOrder.vue";
export default {
  // 组件
  components: {
    ImgBox,
    Order,
    Product,
    Read,
    Exp,
    ReminderPayment,
    CheckOrder,
  },

  // 接收参数
  props: {
    // 详情
    detail: {
      type: Object,
      default: () => Object(),
    },

    // 店铺信息
    store: {
      type: Object,
      default: () => Object(),
    },

    // 店铺信息
    from: {
      type: Object,
      default: () => Object(),
    },
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    User: window.$USER$,
    Avatar: undefined,
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.Avatar = this.BUS.GetStoreAvatar(this.store.Id) || this.detail?.Avatar;
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 获取时间
    GetTime() {
      var now = new Date(); // 获取当前时间
      var time = new Date(this.detail.Time); // Unix转时间对象
      if (
        time.getFullYear() !== now.getFullYear() ||
        time.getMonth() !== now.getMonth() ||
        time.getDate() !== now.getDate()
      ) {
        return [time.getFullYear(), time.getMonth() + 1, time.getDate()]
          .map(($) => ($ > 9 ? $ : "0" + $))
          .join("/");
      } else {
        return [time.getHours(), time.getMinutes()]
          .map(($) => ($ > 9 ? $ : "0" + $))
          .join(":");
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.item-box {
  // 单项容器
  align-items: flex-start;
  position: relative;
  flex-wrap: nowrap;
  margin-top: 20px;
  padding: 0 20px;
  width: 100%;

  .avatar {
    // 头像容器
    flex-shrink: 0;
    height: 32px;
    width: 32px;
  }

  .info {
    // 信息容器
    margin: 0 10px;
    display: flex;
    flex-grow: 1;

    .textA,
    .textB {
      background-color: rgba(255, 255, 255, 1);
      word-break: break-all;
      border-radius: 10px;
      position: relative;
      line-height: 16px;
      font-size: 12px;

      .time {
        color: rgba(192, 196, 204, 1);
        top: calc(100% + 8px);
        white-space: nowrap;
        position: absolute;
        font-size: 12px;
      }
    }

    .textA {
      // 用户文本
      padding: 10px 20px;
      max-width: 424px;
    }

    .textB {
      // 商家文本
      padding: 10px;
    }
  }
}

.item-box + .item-box {
  margin-top: 36px;
}
</style>