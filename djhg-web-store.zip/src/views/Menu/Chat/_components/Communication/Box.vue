<template>
  <ElRow class="communication-box">
    <!-- 店铺名称 -->
    <div class="store">{{ store.Name }}</div>

    <!-- 对话列表 -->
    <ElScrollbar v-if="!!store.Id" class="list-box" ref="$" @scroll="scroll">
      <div style="width: 100%; padding: 20px 0" ref="$in">
        <Item
          v-for="(item, index) in list"
          :detail="item"
          :key="index"
          :from="from"
          :store="store"
          ref="$item"
        />
        <div style="height: 36px"></div>
      </div>
    </ElScrollbar>
    <ElRow v-else class="no">请选择联系人</ElRow>

    <!-- 按钮容器 -->
    <ElRow class="button-box">
      <!-- 表情组件 -->
      <Emoji :btimg="btimg" @input="input = input + $event" />

      <!-- 上传功能 -->
      <ElUpload
        v-model:file-list="file"
        :show-file-list="false"
        :on-success="success"
        :maxlength="500"
        :action="action"
        :accept="accept"
        :limit="1"
        class="upload"
      >
        <div class="imgx">
          <img :src="btimg[2]" />
          <img :src="btimg[3]" />
        </div>
      </ElUpload>
    </ElRow>

    <!-- 用户输入值 -->
    <ElInput
      v-model="input"
      :maxlength="500"
      :rows="4"
      placeholder="请输入消息，按Enter/点击”发送“按钮进行消息发送"
      class="textarea"
      type="textarea"
      resize="none"
      @keyup.enter="UpText()"
    />

    <ElRow style="flex-direction: row-reverse; padding: 0 20px">
      <ElButton type="primary" @click="UpText()" :disabled="!store.Id">
        发送/Enter
      </ElButton>
    </ElRow>
  </ElRow>
</template>

<script>
import { GUID } from "@/library.js";
import Emoji from "./Emoji.vue";
import Item from "./Item.vue";
import Button1A from "@/assets/表情按钮A.png";
import Button1B from "@/assets/表情按钮B.png";
import Button2A from "@/assets/图片按钮A.png";
import Button2B from "@/assets/图片按钮B.png";

export default {
  // 组件
  components: { Emoji, Item },

  // 接收参数
  props: {
    // 唯一ID
    guid: {
      type: String,
      default: GUID() + "-xxxxxx",
    },

    // 店铺信息
    store: {
      type: Object,
      default: () => Object(),
    },

    // 店铺信息
    from: {
      type: Object,
      default: () => Object(),
    },

    query: undefined, // 获取解密后的传参
    chat: undefined, // 会话
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {
    // 检查会话变动
    chat(value) {
      this.max = true;
      this.record.page = 1;
      this.record.conversationId = value; // 写入会话ID
      this.list = undefined; // 清空记录
      this.list = Array(0); // 初始化记录

      // 没有会话ID的话不要获取历史记录
      if (!!value) {
        this.Api.UserCustomerWebSocket.Send({
          type: 4,
          from: this.from,
          record: this.record,
          to: String(this.store.Id),
        }); // 查询会话历史
      }
    },
  },

  // 页面对象
  data: () => ({
    id: undefined, // 记录当前聊天的ID

    action:
      process.env.VUE_APP_BASE_URL +
      process.env.VUE_APP_OBS +
      "/cmz-img/?token=", // 拼接华为OBS服务器地址
    accept: [".jpg", ".jpeg", ".png", ".gif"].join(","), // 支持的上传格式
    file: Array(0), // 上传的文件

    record: {
      page: 1, // 获取页码
      limit: 15, // 获取数量
      conversationId: undefined,
    },

    list: Array(0),

    input: "", // 输入的内容

    max: false,

    btimg: [Button1A, Button1B, Button2A, Button2B], // 按钮图标
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.action = this.action + this.Api.UserLogin.Token.token; // 写入Token
    this.accept = [this.accept, this.accept.toUpperCase()].join(","); // 大写转换

    var check = ($) => {
      return $.StoreId === this.store?.StoreId || $.Id === this.store?.Id;
    };

    // 订阅消息
    this.Api.UserCustomerWebSocket.AddUpdate(this.guid, (data) => {
      // 消除已读状态
      if (data.Type === 2005) {
        this.list.forEach(($) => ($.Read = true));
      }

      // 获取历史记录
      if (data.Type === 4) {
        this.input = "";
        this.max = data.List.length < this.record.limit;
        var list = data.List.filter(($) => check($));
        this.list.unshift(...list); // 存放历史记录
        if (this.record.page > 1) {
          this.$nextTick(() => {
            var top = this.$refs.$item[list.length].$el.offsetTop; // 获取数据加载后的位置
            this.$refs.$.setScrollTop(top - 36); // 滚动到指定位置
          });
          return; // 跳出阻止跳转底部
        }
      }

      // 获取文本信息
      if (data.Type === 10 && check(data)) {
        this.list.push(data); // 存放历史记录
      }

      // 获取图片信息
      if (data.Type === 11 && check(data)) {
        this.list.push(data); // 存放历史记录
      }

      // 获取订单信息
      if ((data.Type === 12 || data.Type === 2003) && check(data)) {
        this.list.push(data); // 存放历史记录
      }

      // 订单支付提醒
      if (data.Type === 2001 && check(data)) {
        this.list.push(data); // 存放历史记录
      }

      // 核对订单地址
      if (data.Type === 2002 && check(data)) {
        this.list.push(data); // 存放历史记录
      }

      // 接收物流消息
      if (data.Type === 2004 && check(data)) {
        this.list.push(data); // 存放历史记录
      }

      // 获取商品消息
      if (data.Type === 13 && check(data)) {
        this.list.push(data); // 存放历史记录
      }
      this.GoBottom(); // 跳转底部
    });

    this.BUS.ChatGoBottom = () => this.GoBottom();
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    this.Api.UserCustomerWebSocket.DelUpdate(this.guid);
    delete this.BUS.ChatGoBottom;
  },

  // 组件方法
  methods: {
    // 跳转底部
    GoBottom() {
      // 渲染完成后自动进入底部
      this.$nextTick(() => {
        this.$refs.$?.setScrollTop?.(this.$refs.$in.clientHeight);
      });
    },

    // 上传文本
    UpText() {
      if (!!this.input && !/^\s*$/g.test(this.input)) {
        var $ = new Date();
        $ = [
          [$.getFullYear(), $.getMonth() + 1, $.getDate()]
            .map((t) => (t > 9 ? "" : "0") + t)
            .join("-"), // 年月日
          [$.getHours(), $.getMinutes(), $.getSeconds()]
            .map((t) => (t > 9 ? "" : "0") + t)
            .join(":"), // 时分秒
        ];
        var data = {
          date: $.join(" "),
          from: this.from,
          text: this.input,
          to: String(this.store.Id),
          type: 10,
        };
        this.Api.UserCustomerWebSocket.Send(data);
        data.merchantid = String(this.store.Id);
        this.Api.UserCustomerWebSocket._WsOnMessage(
          { data: JSON.stringify(data) },
          this.Api.UserCustomerWebSocket._ws
        );
      }
      this.input = ""; // 清掉输入消息
    },

    // 图片上传成功
    success(file) {
      var $ = new Date();
      $ = [
        [$.getFullYear(), $.getMonth() + 1, $.getDate()]
          .map((t) => (t > 9 ? "" : "0") + t)
          .join("-"), // 年月日
        [$.getHours(), $.getMinutes(), $.getSeconds()]
          .map((t) => (t > 9 ? "" : "0") + t)
          .join(":"), // 时分秒
      ];
      var data = {
        date: $.join(" "),
        from: this.from,
        text: file.data.url,
        to: String(this.store.Id),
        type: 11,
      };
      this.Api.UserCustomerWebSocket.Send(data);
      data.merchantid = String(this.store.Id);
      this.Api.UserCustomerWebSocket._WsOnMessage(
        { data: JSON.stringify(data) },
        this.Api.UserCustomerWebSocket._ws
      );
      this.file = Array(0);
    },

    // 滚动
    scroll({ scrollTop: top }) {
      if (top <= 0 && !this.max) {
        this.max = true;
        this.record.page++;
        this.Api.UserCustomerWebSocket.Send({
          type: 4,
          from: this.from,
          record: this.record,
          to: String(this.store.Id),
        }); // 查询会话历史
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.communication-box {
  // 通信界面
  flex-direction: column;
  align-items: stretch;
  flex-wrap: nowrap;
  padding: 20px 0;
  flex-grow: 1;

  .store {
    // 店铺
    font-weight: bold;
    line-height: 32px;
    font-size: 14px;
    padding: 0 20px;
    flex-shrink: 0;
    height: 32px;
  }

  .button-box {
    // 按钮容器
    align-items: center;
    margin-top: 12px;
    padding: 0 20px;

    .imgx {
      img {
        display: none;
      }

      img + img {
        display: block;
      }

      &:hover {
        img {
          display: block;
        }

        img + img {
          display: none;
        }
      }
    }

    img,
    .upload {
      height: 16px;
      width: 16px;
    }
  }

  .list-box {
    // 列表容器
    background-color: rgba(246, 246, 246, 1);
    flex-grow: 1;
  }

  .no {
    background-color: rgba(246, 246, 246, 1);
    justify-content: center;
    align-items: center;
    font-size: 14px;
    flex-grow: 1;
  }

  .textarea {
    width: calc(100% - 40px);
    margin-left: 20px;

    :deep(.el-textarea__inner) {
      box-shadow: none;
      padding-right: 0;
      padding-left: 0;
    }
  }
}
</style>