<template>
  <Order :detail="detail" :exp="exp">
    <ElRow class="exp-box">
      <svg class="top" width="14" height="14">
        <text
          dominant-baseline="central"
          font-family="Helvetica"
          text-anchor="middle"
          font-size="8"
          fill="white"
          y="50%"
          x="50%"
        >
          {{ detail.Exp.Status[detail.Exp.Status.length - 1] }}
        </text>
      </svg>

      <ElRow class="exp-info">
        <ElRow class="status-box">
          <div class="status">{{ detail.Exp.Status }}</div>
          <div>{{ detail.Exp.Time }}</div>
        </ElRow>
        <div class="context nowrap">{{ detail.Exp.Context }}</div>
      </ElRow>
    </ElRow>

    <div class="button-box">
      <span @click="OpenExp()">查看详情</span>
    </div>
  </Order>
</template>

<script>
import Order from "./Order.vue";

export default {
  // 组件
  components: { Order },

  // 接收参数
  props: {
    // 详情
    detail: {
      type: Object,
      default: () => Object(),
    },
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    exp: undefined,
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.exp = this.detail.Exp.Company + ":" + this.detail.Exp.Code;
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 打开物流
    OpenExp() {
      this.$GO(
        { path: "/menu/surplus/order", data: { Id: this.detail.Data.Id } },
        true
      );
      // var data = { Code: this.detail.Exp.Code };
      // this.PopUp.ExpState(data);
    },
  },
};
</script>

<style lang="scss" scoped>
.exp-box {
  // 物流容器
  align-items: flex-start;
  flex-wrap: nowrap;
  margin-top: 10px;
  max-width: 384px;

  .top {
    // 顶层标识
    background-color: rgba(255, 0, 0, 1);
    border-radius: 14px;
    margin-right: 10px;
    flex-shrink: 0;
  }

  .exp-info {
    // 物流信息
    flex-direction: column;
    flex-grow: 1;
    width: 100%;

    .status-box {
      // 状态容器
      align-items: center;
      flex-wrap: nowrap;

      div {
        line-height: 14px;
      }

      .status {
        // 状态
        color: rgba(252, 23, 23, 1);
        margin-right: 8px;
      }

      .status + div {
        color: rgba(96, 98, 102, 1);
        font-size: 12px;
      }
    }

    .context {
      word-break: break-all;
      line-height: 14px;
      margin-top: 4px;
      font-size: 12px;
      width: 100%;
    }
  }
}

.button-box {
  text-align: right;
  line-height: 1em;
  margin-top: 8px;
  font-size: 12px;

  span {
    color: rgba(57, 123, 255, 1);
    cursor: pointer;
  }
}
</style>