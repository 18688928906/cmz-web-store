<template>
  <ElRow class="order">
    <div class="reminder">订单确认</div>

    <ElRow
      style="
        background-color: rgba(246, 246, 246, 1);
        border-radius: 4px;
        flex-wrap: nowrap;
      "
    >
      <img class="logo" :src="detail.Data.Img" />
      <ElRow class="info-box">
        <!-- 商品名称 -->
        <ElRow class="name-box">
          <div :title="detail.Data.Name" class="name nowrap">
            {{ detail.Data.Name }}
          </div>
          <div class="price">￥{{ detail.Data.Price }}</div>
        </ElRow>

        <!-- 规格容器 -->
        <ElRow class="sku-box">
          <div class="sku">{{ detail.Data.Sku }}</div>
          <div>×{{ detail.Data.Qty }}</div>
        </ElRow>

        <!-- 订单价格 -->
        <ElRow class="price-box">
          实付款：<span class="price">￥{{ detail.Data.Pay }}</span>
        </ElRow>
      </ElRow>
    </ElRow>

    <div class="address">
      姓名：{{ detail.Receipt.Name[1] }}
      <template v-for="item in detail.Receipt.Name.length - 1" :key="item">
        *
      </template>
    </div>
    <div class="address">电话：{{ HidePhone(detail.Receipt.Phone) }}</div>
    <div class="address">地址：{{ detail.Receipt.Address }}</div>

    <div class="button-box">
      <div v-if="!detail.Receipt.Sure" @click="check()">确认</div>
      <div v-else style="background-color: rgba(192, 196, 204, 1)">已确认</div>
    </div>
  </ElRow>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    // 详情
    detail: {
      type: Object,
      default: () => Object(),
    },

    // 店铺信息
    store: {
      type: Object,
      default: () => Object(),
    },

    // 店铺信息
    from: {
      type: Object,
      default: () => Object(),
    },
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    omit: Boolean(false), // 是否使用省略号
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    SetDate(date) {
      var t = new Date(date);
      var A = [t.getFullYear(), t.getMonth() + 1, t.getDate()]
        .map(($) => ($ > 9 ? String($) : "0" + $))
        .join("-");
      var B = [t.getHours(), t.getMinutes(), t.getSeconds()]
        .map(($) => ($ > 9 ? String($) : "0" + $))
        .join(":");
      return A + " " + B;
    },

    check() {
      var $ = new Date();
      $ = [
        [$.getFullYear(), $.getMonth() + 1, $.getDate()]
          .map((t) => (t > 9 ? "" : "0") + t)
          .join("-"), // 年月日
        [$.getHours(), $.getMinutes(), $.getSeconds()]
          .map((t) => (t > 9 ? "" : "0") + t)
          .join(":"), // 时分秒
      ];
      var data = JSON.stringify(this.detail.$);
      data = JSON.parse(data);
      data.address.sureId = data.id;
      data.address.isSure = 1;
      data.date = $.join(" ");
      data.from = this.from;
      data.text = "[订单]";
      data.to = String(this.store.Id);
      data.type = 3000;
      // var data = {
      //   date: $.join(" "),
      //   from: this.from,
      //   text: "[订单]",
      //   order: this.detail.$,
      //   to: String(this.store.Id),
      //   type: 3000,
      // };
      delete data.id;
      this.Api.UserCustomerWebSocket.Send(data);
      this.detail.Receipt.Sure = true;
    },
  },
};
</script>

<style lang="scss" scoped>
.order {
  flex-direction: column;
  align-items: stretch;
  flex-wrap: nowrap;
  width: 404px;

  .reminder {
    margin-bottom: 8px;
    line-height: 14px;
    font-weight: bold;
    height: 14px;
  }

  .logo {
    // 商品图
    border-radius: 4px;
    flex-shrink: 0;
    height: 80px;
    width: 80px;
  }

  .info-box {
    // 信息容器
    justify-content: space-between;
    width: calc(100% - 80px);
    flex-direction: column;
    align-items: stretch;
    flex-wrap: nowrap;
    margin-left: 4px;
    flex-grow: 1;
    height: 80px;

    .name-box {
      flex-wrap: nowrap;

      .name,
      .price {
        color: rgba(96, 98, 102, 1);
        margin-right: 10px;
        line-height: 18px;
      }

      .name {
        // 商品名称
        font-size: 12px;
        flex-grow: 1;
      }

      .price {
        // 商品价格
        font-size: 14px;
        flex-shrink: 0;
      }
    }

    .sku-box {
      flex-wrap: nowrap;

      div {
        color: rgba(192, 196, 204, 1);
        margin-right: 10px;
        line-height: 18px;
        font-size: 12px;
      }

      .sku {
        flex-grow: 1;
      }

      .sku + div {
        flex-shrink: 0;
      }
    }

    .price-box {
      color: rgba(16, 16, 16, 1);
      align-items: baseline;
      font-size: 12px;

      .price {
        font-weight: bold;
        font-size: 16px;
        color: red;
      }
    }
  }
}

.address {
  // 显示地址
  line-height: 14px;
  max-width: 384px;
  font-size: 12px;
  margin-top: 8px;
}

.button-box {
  padding-left: calc(100% - 72px);
  margin-top: 8px;

  div {
    background-color: rgba(57, 123, 255, 1);
    border-radius: 32px;
    text-align: center;
    line-height: 32px;
    font-size: 12px;
    cursor: pointer;
    color: white;
    display: block;
    height: 32px;
    width: 72px;
  }
}
</style>