<template>
  <ElRow class="product">
    <img class="logo" :src="detail.Data.Img" />
    <ElRow class="info-box">
      <!-- 商品名称 -->
      <ElRow class="name-box">
        <div class="name">{{ detail.Data.Name }}</div>
        <div class="price">￥{{ detail.Data.Price }}</div>
      </ElRow>
    </ElRow>
  </ElRow>
</template>

<script>
import SvgText from "./SvgText.vue";

export default {
  // 组件
  components: { SvgText },

  // 接收参数
  props: {
    // 详情
    detail: {
      type: Object,
      default: () => Object(),
    },
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.product {
  // 商品
  background-color: rgba(246, 246, 246, 1);
  border-radius: 6px;
  width: 360px;

  .logo {
    // 商品图
    border-radius: 6px;
    flex-shrink: 0;
    height: 80px;
    width: 80px;
  }

  .info-box {
    // 信息容器
    justify-content: space-between;
    flex-direction: column;
    align-items: stretch;
    padding-right: 10px;
    flex-wrap: nowrap;
    margin-left: 4px;
    flex-grow: 1;
    height: 80px;

    .name-box {
      // 商品名称
      align-items: center;
      flex-wrap: nowrap;
      width: 100%;

      .name {
        // 名称
        color: rgba(96, 98, 102, 1);
        line-height: 18px;
        font-size: 12px;
        flex-grow: 1;
      }

      .price {
        // 价格
        color: rgba(96, 98, 102, 1);
        line-height: 18px;
        margin-left: 4px;
        font-size: 12px;
        flex-shrink: 0;
      }
    }
  }
}
</style>