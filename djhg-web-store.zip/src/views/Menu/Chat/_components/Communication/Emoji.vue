<template>
  <div
    style="margin-right: 20px"
    class="emoji-box"
    @mouseleave="Show = false"
    @mouseenter="Show = true"
  >
    <!-- 触发图标 -->
    <img :src="btimg[0]" />
    <img :src="btimg[1]" />

    <!-- 表情符号 -->
    <transition name="simple">
      <div v-if="Show" class="emoji">
        <div class="emoji-in">
          <div
            v-for="(item, index) in $Emoji"
            :key="index"
            @click="$emit('input', item.text)"
          >
            {{ item.text }}
          </div>
        </div>
      </div>
    </transition>
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    btimg: {
      type: Array,
      default: () => Array(0),
    },
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    Show: false,
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.emoji-box {
  position: relative;
  height: 16px;
  width: 16px;

  img {
    height: inherit;
    width: inherit;
    display: none;
  }

  img + img {
    display: block;
  }

  .emoji {
    // 表情容器
    position: absolute;
    height: 36px;
    width: 36px;
    bottom: 0;
    left: 0;

    .emoji-in {
      grid-template-columns: repeat(18, 1.3em);
      border: 1px solid rgb(223, 225, 229);
      background-color: white;
      position: absolute;
      font-size: 18px;
      padding: 0.2em;
      display: grid;
      bottom: 100%;
      left: -0.5em;

      div {
        line-height: 1.3em;
        text-align: center;
        font-size: inherit;
        cursor: pointer;
        height: 1.3em;
        width: 1.3em;
      }
    }
  }

  &:hover {
    img {
      display: block;
    }

    img + img {
      display: none;
    }
  }
}
</style>