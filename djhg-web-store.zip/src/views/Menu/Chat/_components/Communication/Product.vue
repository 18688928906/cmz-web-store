<template>
  <ElRow
    style="
      background-color: rgba(246, 246, 246, 1);
      border-radius: 4px;
      width: 404px;
    "
  >
    <img class="logo" :src="detail.Data.Img" />
    <ElRow class="info-box">
      <!-- 商品名称 -->
      <div class="name nowrap" ref="$" :class="{ omit: omit }" @click="opexn()">
        {{ detail.Data.Name }}
      </div>

      <div class="sale">
        月售{{ detail.Data.Sale }} | 库存{{ detail.Data.Max }}件
      </div>

      <!-- 订单价格 -->
      <ElRow class="price-box">
        <div class="price">￥{{ detail.Data.Price }}</div>
      </ElRow>
    </ElRow>
  </ElRow>
</template>

<script>
import SvgText from "./SvgText.vue";

export default {
  // 组件
  components: { SvgText },

  // 接收参数
  props: {
    // 详情
    detail: {
      type: Object,
      default: () => Object(),
    },
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    omit: Boolean(false), // 是否使用省略号
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {
    const $ = this.$refs.$;
    this.omit = $.clientHeight < $.scrollHeight; // 检测文本溢出
  },

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 打开
    opexn() {
      this.$GO(
        { path: "/menu/surplus/detail", data: { Id: this.detail.Data.Id } },
        true
      );
    },
  },
};
</script>

<style lang="scss" scoped>
.logo {
  // 商品图
  border-radius: 4px;
  height: 80px;
  width: 80px;
}

.info-box {
  // 信息容器
  justify-content: space-between;
  flex-direction: column;
  align-items: stretch;
  flex-wrap: nowrap;
  margin-left: 4px;
  padding: 4px 0;
  height: 80px;
  width: 136px;

  .name {
    // 商品名称
    word-break: break-all;
    position: relative;
    line-height: 18px;
    overflow: hidden;
    font-size: 14px;
    cursor: pointer;
    display: block;
    height: 36px;
    width: 100%;

    .A,
    .B,
    .C {
      transform: translateY(2px);
      display: inline-block;
      border-radius: 14px;
      margin-right: 12px;
      height: 14px;
      width: 30px;
    }
  }

  .omit::after {
    // 省略号
    background: linear-gradient(to right, transparent, white 55%);
    position: absolute;
    line-height: 18px;
    text-align: right;
    content: "…";
    font-size: 14px;
    width: 2.5em;
    bottom: 0;
    right: 0;
  }
}

.sale {
  color: rgba(192, 196, 204, 1);
}

.price-box {
  align-items: center;

  .price {
    font-weight: bold;
    font-size: 16px;
    color: red;
  }
}
</style>