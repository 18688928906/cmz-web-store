<template>
  <ElRow class="order">
    <ElRow v-if="!exp" class="status-box">
      {{ detail.Data.Status.Label(detail.Data.Status.Type) }}
    </ElRow>

    <ElRow class="code-box">
      <div v-if="exp">物流信息</div>
      <div v-else>订单编号:{{ detail.Data.Code }}</div>
      <div v-if="!!detail.Data.Time && !exp">
        下单时间:{{ SetDate(detail.Data.Time) }}
      </div>
      <div v-else>{{ exp }}</div>
    </ElRow>

    <ElRow
      style="
        background-color: rgba(246, 246, 246, 1);
        border-radius: 4px;
        flex-wrap: nowrap;
      "
    >
      <img class="logo" :src="detail.Data.Img" />
      <ElRow class="info-box">
        <!-- 商品名称 -->
        <ElRow class="name-box">
          <div :title="detail.Data.Name" class="name nowrap">
            {{ detail.Data.Name }}
          </div>
          <div class="price">￥{{ detail.Data.Price }}</div>
        </ElRow>

        <!-- 规格容器 -->
        <ElRow class="sku-box">
          <div class="sku">{{ detail.Data.Sku }}</div>
          <div>×{{ detail.Data.Qty }}</div>
        </ElRow>

        <!-- 订单价格 -->
        <ElRow class="price-box">
          实付款：<span class="price">￥{{ detail.Data.Pay }}</span>
        </ElRow>
      </ElRow>
    </ElRow>

    <slot />
  </ElRow>
</template>

<script>
import SvgText from "./SvgText.vue";

export default {
  // 组件
  components: { SvgText },

  // 接收参数
  props: {
    // 详情
    detail: {
      type: Object,
      default: () => Object(),
    },

    // 快递单号
    exp: undefined,
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    omit: Boolean(false), // 是否使用省略号
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    SetDate(date) {
      var t = new Date(date);
      var A = [t.getFullYear(), t.getMonth() + 1, t.getDate()]
        .map(($) => ($ > 9 ? String($) : "0" + $))
        .join("-");
      var B = [t.getHours(), t.getMinutes(), t.getSeconds()]
        .map(($) => ($ > 9 ? String($) : "0" + $))
        .join(":");
      return A + " " + B;
    },
  },
};
</script>

<style lang="scss" scoped>
.order {
  flex-direction: column;
  align-items: stretch;
  flex-wrap: nowrap;
  width: 404px;

  .status-box {
    // 状态容器
    border-bottom: 1px solid rgba(220, 223, 230, 1);
    color: rgba(253, 63, 21, 1);
    padding-bottom: 10px;
    margin-bottom: 10px;
    line-height: 1em;
    font-size: 14px;
  }

  .code-box {
    // 编号容器
    justify-content: space-between;
    margin-bottom: 10px;
    flex-wrap: nowrap;

    div {
      color: rgba(16, 16, 16, 1);
      line-height: 1em;
      font-size: 12px;
    }

    div + div {
      margin-left: 28px;
    }
  }

  .logo {
    // 商品图
    border-radius: 4px;
    flex-shrink: 0;
    height: 80px;
    width: 80px;
  }

  .info-box {
    // 信息容器
    justify-content: space-between;
    width: calc(100% - 80px);
    flex-direction: column;
    align-items: stretch;
    flex-wrap: nowrap;
    margin-left: 4px;
    padding: 4px 0;
    flex-grow: 1;
    height: 80px;

    .name-box {
      flex-wrap: nowrap;

      .name,
      .price {
        color: rgba(96, 98, 102, 1);
        margin-right: 10px;
        line-height: 18px;
      }

      .name {
        // 商品名称
        font-size: 12px;
        flex-grow: 1;
      }

      .price {
        // 商品价格
        font-size: 14px;
        flex-shrink: 0;
      }
    }

    .sku-box {
      flex-wrap: nowrap;

      div {
        color: rgba(192, 196, 204, 1);
        margin-right: 10px;
        line-height: 18px;
        font-size: 12px;
      }

      .sku {
        flex-grow: 1;
      }

      .sku + div {
        flex-shrink: 0;
      }
    }

    .price-box {
      color: rgba(16, 16, 16, 1);
      align-items: baseline;
      font-size: 12px;

      .price {
        font-weight: bold;
        font-size: 16px;
        color: red;
      }
    }
  }
}
</style>