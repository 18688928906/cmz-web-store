<template>
  <div class="item-img-box" :style="`width:${width}%`">
    <ElImage
      :preview-src-list="[detail.Data]"
      :src="detail.Data"
      ref="$"
      @load="SetWidth()"
    />

    <!-- 时间 -->
    <div :style="detail.User ? 'right:0px' : 'left:0px'" class="time">
      {{ GetTime() }}
    </div>

    <Read :detail="detail" />
  </div>
</template>

<script>
import Read from "./Read.vue";
export default {
  // 组件
  components: { Read },

  // 接收参数
  props: {
    // 详情
    detail: {
      type: Object,
      default: () => Object(),
    },
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    width: 50,
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 获取时间
    GetTime() {
      var now = new Date(); // 获取当前时间
      var time = new Date(this.detail.Time); // Unix转时间对象
      if (
        time.getFullYear() !== now.getFullYear() ||
        time.getMonth() !== now.getMonth() ||
        time.getDate() !== now.getDate()
      ) {
        return [time.getFullYear(), time.getMonth() + 1, time.getDate()].join(
          "/"
        );
      } else {
        return [time.getHours(), time.getMinutes()].join(":");
      }
    },

    // 设置宽度
    SetWidth() {
      if (this.$refs.$.$el.clientHeight > this.$refs.$.$el.clientWidth) {
        this.width =
          (this.$refs.$.$el.clientWidth / this.$refs.$.$el.clientHeight) * 50;
      } else {
        this.width = 50;
      }

      this.BUS.ChatGoBottom();
    },
  },
};
</script>

<style lang="scss" scoped>
.item-img-box {
  position: relative;
  display: flex;

  .time {
    color: rgba(192, 196, 204, 1);
    top: calc(100% + 8px);
    position: absolute;
    font-size: 12px;
    right: 0px;
  }
}
</style>