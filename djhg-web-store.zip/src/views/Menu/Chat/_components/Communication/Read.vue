<template>
  <template v-if="detail.User">
    <div class="read" :class="detail.Read ? 'A' : 'B'">
      {{ detail.Read ? "已读" : "未读" }}
    </div>
  </template>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    // 详情
    detail: {
      type: Object,
      default: () => Object(),
    },
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.read {
  position: absolute;
  line-height: 1em;
  font-size: 12px;
  left: -30px;
  bottom: 0;
}

.A {
  color: rgba(192, 196, 204, 1);
}

.B {
  color: var(--el-color-primary);
}
</style>