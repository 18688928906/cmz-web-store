<template>
  <ScrollBar>
    <div class="page">
      <div class="title">关于防诈骗声明</div>

      <div class="text">
        <template v-for="$ in 7" :key="$">&nbsp;</template>
        近期，本公司接到一些关于“星贝佳”“聚美旗舰”APP通过高额回报骗取受害者钱财的举报，不法分子以本公司名义，制作虚假合同章、营业执照及我司证件照等资料，在网上以刷单完成任务为噱头，诱导大家下载“星贝佳”“聚美旗舰”APP进行网络诈骗。在此我们对受害者深表同情，同时请大家提高警惕。此行为不仅严重侵害大家的合法权益，而且还严重影响本公司形象及名誉。特此本公司声明如下：
      </div>
      <div class="text">
        <template v-for="$ in 7" :key="$">&nbsp;</template>
        一、我司为正常经营企业，经营内容与“星贝佳”、“聚美旗舰”&nbsp;APP&nbsp;没有任何关联。
      </div>
      <div class="text">
        <template v-for="$ in 7" :key="$">&nbsp;</template>
        二、“星贝佳”、“聚美旗舰”APP此举严重影响我司名誉，导致我司名誉形象受损，我们严厉谴责这种行为，此行为为诈骗行为，是违法行为，是国家严厉打击的非法行为。我们对此将严查到底，保留上诉权利。
      </div>
      <div class="text">
        <template v-for="$ in 7" :key="$">&nbsp;</template>
        三、本公司从未委托或授权其他单位或个人对外收取任何费用。
      </div>
      <div class="text">
        <template v-for="$ in 7" :key="$">&nbsp;</template>
        四、其他任何机构或个人以本公司名义收取任何费用的，都是不法分子，请大家注意分辨。我司对此不承担相应的法律责任，对其侵害本公司合法权益的行为，我司将严厉查处并追究相关人员的法律责任。
      </div>
      <div class="text">
        <template v-for="$ in 7" :key="$">&nbsp;</template>
        在此，提醒广大群众，在网上各种以刷单，兼职，高回报为借口的都是诈骗。如遇上当受骗，请及时向当地公安机关报案。如需我司提供协助的受害者，请致电：0769-81880999&nbsp;转&nbsp;8002
      </div>
      <div class="text">
        <template v-for="$ in 7" :key="$">&nbsp;</template>
        特此声明！
      </div>

      <div class="text" style="text-align: right; margin-top: 45px">
        广东宇壕网络科技发展有限公司
      </div>
      <div class="text" style="text-align: right">2022年8月18日</div>
    </div>
  </ScrollBar>
</template>

<script>
export default {
  // 自动路由参数
  meta: {
    title: undefined, // 写入浏览器页签
    index: undefined, // 用于排序
    label: undefined, // 显示用的路由名称
    name: undefined, // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(false), // 控制页面是否需要登录
  },

  // 组件
  components: {},

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.page {
  width: 1200px;

  .title {
    color: rgba(16, 16, 16, 1);
    text-align: center;
    font-size: 20px;
    width: 100%;
    margin: 45px 0;
  }

  .text {
    color: rgba(16, 16, 16, 1);
    font-size: 14px;
    line-height: 2em;
  }
}
</style>