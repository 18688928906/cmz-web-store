<template>
  <!-- <TitleRow label="店铺信息" /> -->
  <TitleRow label="基本信息" />

  <!-- 输入表单 -->
  <ElForm
    :rules="rules"
    :model="query"
    label-position="top"
    ref="$"
    scroll-to-error
  >
    <ElFormItem label="店铺logo" prop="ShopLogo">
      <ElPopover
        placement="top-start"
        trigger="hover"
        content="1、logo中不得含有侵权和第三方版权素材。2、logo中含有品牌需有品牌方相关授权。3、图片尺寸为800*800以上，支持PNG、JPG、JPEG格式，大小不超过5M"
      >
        <template #reference>
          <img :src="$svg['i-0049']" class="help" />
        </template>
      </ElPopover>
      <Upload v-model:file="query.ShopLogo" />
    </ElFormItem>

    <ElFormItem label="店铺名称" prop="ShopName">
      <ElInput
        v-model="query.ShopName"
        placeholder="请输入店铺名称"
        maxlength="30"
        show-word-limit
        @input="change($event)"
      />
    </ElFormItem>

    <ElFormItem label="店铺类型" prop="ShopType">
      <ElSelect
        v-model="query.ShopType"
        placeholder="请选择店铺类型"
        style="width: 100%"
      >
        <ElOption
          v-for="(item, index) in ShopOptions"
          :value="index"
          :label="item"
          :key="index"
        />
      </ElSelect>
    </ElFormItem>

    <ElFormItem label="主营类目" prop="Operation">
      <ElSelect
        v-model="query.Operation"
        placeholder="请输入主营类目"
        style="width: 100%"
      >
        <ElOption
          v-for="(item, index) in Operation"
          :value="index"
          :label="item"
          :key="index"
        />
      </ElSelect>
    </ElFormItem>

    <ElFormItem label="店铺规模:" prop="ShopScale">
      <ElSelect
        v-model="query.ShopScale"
        placeholder="请选择店铺规模"
        style="width: 100%"
      >
        <ElOption
          v-for="(item, index) in ShopScale"
          :value="index"
          :label="item"
          :key="index"
        />
      </ElSelect>
    </ElFormItem>

    <ElFormItem label="店铺简介">
      <ElInput
        v-model="query.Introduce"
        :maxlength="100"
        :rows="5"
        placeholder="请输入店铺简介"
        style="width: 900px"
        type="textarea"
        resize="none"
        show-word-limit
      />
    </ElFormItem>
  </ElForm>

  <ElButton type="primary" class="next" @click="next()">下一步</ElButton>
</template>

<script>
import TitleRow from "../_components/TitleRow.vue";
import Upload from "./_components/Upload.vue";
import verify from "@/tool-library/_modules/verify.js";

export default {
  // 自动路由参数
  meta: {
    title: undefined, // 写入浏览器页签
    index: undefined, // 用于排序
    label: undefined, // 显示用的路由名称
    name: undefined, // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(true), // 控制是否需要登录
  },

  // 组件
  components: { TitleRow, Upload },

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    ShopOptions: [
      "个体工商户/个体店",
      "普通企业店/自营店",
      "厂家直营店/旗飯店",
      "授权专营店/专卖店",
      "多方代理店/综合店",
    ],
    // ShopOptions: ["个体工商户", "普通企业店", "旗舰店", "专营店", "专卖店"],
    Operation: ["普通商品", "特种商品", "医疗商品"],
    ShopScale: [
      "个体工商户",
      "一般纳税人",
      "政/企事业单位",
      "行业100强企业",
      "中国500强企业",
      "世界500强企业",
    ],

    // 校验
    rules: {
      ShopLogo: [
        { required: true, message: "请上传店铺图标", trigger: "change" },
      ],
      ShopName: [
        { required: true, message: "店铺名称不能为空", trigger: "blur" },
      ],
      ShopType: [
        { required: true, message: "店铺类型不能为空", trigger: "change" },
      ],
      ShopScale: [
        { required: true, message: "店铺规模不能为空", trigger: "change" },
      ],
      Operation: [
        { required: true, message: "主营类目不能为空", trigger: "change" },
      ],
    },
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.BUS.BusinessOccupancySteps(1);
    this.rules.ShopName.push({
      validator: (_, value, callback) =>
        this.Api.BusinessRegistrationCheckName.init({
          Name: value.replace(/​/g, ""),
        })
          .GetData()
          .then((_) => callback())
          .catch((msg) => callback(new Error(msg))),
      trigger: "blur",
    });
    !!this.query?.ShopName && this.change(this.query.ShopName); // 初始化内容
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 下一步
    next() {
      this.$refs.$.validate().then(($) => {
        if ($) {
          this.query.ShopName = this.query.ShopName.replace(/​/g, ""); // 清除零宽字符
          this.BUS.SaveBusinessOccupancyForm(); // 储存数据
          this.$GO({ path: "/menu/business/occupancy/merchantInfo" });
        }
      });
    },

    // 检查用户名
    CheckName(value, callback) {
      this.Api.BusinessRegistrationCheckName.init({
        Name: value,
      })
        .GetData()
        .then((_) => callback())
        .catch((msg) => callback(new Error(msg)));
    },

    // 字符输入转换
    change($) {
      var zero = "​"; // 零宽字符（这里有个字符，正常是看不见的）
      const RE = new RegExp(zero, "g");
      $ = $.replace(RE, ""); // 清除零宽字符
      $ = $.split(""); // 拆成单个字符
      $.filter((t) => verify.hanzi(t)).forEach(() => $.unshift(zero)); // 检查汉字的数量然和插零宽字符
      this.query.ShopName = $.join("");
    },
  },
};
</script>

<style lang="scss" scoped>
.el-form {
  // 表单样式覆盖
  margin-top: 24px;
  width: 600px;

  .help {
    position: absolute;
    height: 14px;
    width: 14px;
    left: 80px;
    top: -25px;
  }
}

.next {
  // 下一步
  margin-bottom: 60px;
  margin-top: 30px;
  width: 120px;
}
</style>