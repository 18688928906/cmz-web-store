<template>
  <div class="label">注册商家账号</div>

  <!-- 表单 -->
  <ElForm
    :hide-required-asterisk="true"
    :rules="rules"
    :model="query"
    label-width="auto"
    ref="$"
  >
    <ElFormItem label="手机号码" prop="Phone">
      <ElInput
        v-model="query.Phone"
        :maxlength="11"
        oninput="this.value=this.value.replace(/[^0-9]/g,'')"
        placeholder="请输入手机号"
        show-word-limit
      />
    </ElFormItem>

    <ElFormItem label="验证码" prop="Code">
      <ElRow class="valid-box">
        <ElInput
          v-model="query.Code"
          :maxlength="6"
          oninput="this.value=this.value.replace(/[^0-9]/g,'')"
          placeholder="请输入验证码"
        />
        <ElButton
          :disabled="
            time > 0 || !/^1[3456789]\d{9}$/.test(query.Phone) || cphone
          "
          type="primary"
          @click="valid()"
        >
          {{ time > 0 ? `（${time}s）` : "获取验证码" }}
        </ElButton>
        <!-- <ElButton
          :disabled="!/^1[3456789]\d{9}$/.test(query.Phone) || cphone"
          type="primary"
          @click="valid()"
        >
          获取验证码
        </ElButton> -->
      </ElRow>
    </ElFormItem>

    <ElFormItem label="用户名" prop="Name">
      <ElInput v-model="query.Name" placeholder="请输入用户名" />
    </ElFormItem>

    <ElFormItem label="密码" prop="Password">
      <ElInput
        v-model="query.Password"
        :maxlength="16"
        placeholder="请输入密码"
        type="password"
        show-password
      />
    </ElFormItem>

    <ElFormItem label="确认密码" prop="PasswordV">
      <ElInput
        v-model="query.PasswordV"
        :maxlength="16"
        placeholder="请确认密码"
        type="password"
        show-password
      />
    </ElFormItem>
  </ElForm>

  <SetProtocol v-model="chick" />

  <ElButton
    :disabled="!chick"
    :loading="loading"
    style="width: 260px; margin-bottom: 60px"
    type="primary"
    @click="next()"
  >
    注册并入驻
  </ElButton>
</template>

<script>
import SetProtocol from "./_components/SetProtocol.vue";
import { passwordB, userNameA, phone } from "@/tool-library/_modules/verify.js";

export default {
  // 自动路由参数
  meta: {
    title: undefined, // 写入浏览器页签
    index: undefined, // 用于排序
    label: "入口", // 显示用的路由名称
    name: undefined, // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(true), // 控制是否需要登录
  },

  // 组件
  components: { SetProtocol },

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    timeout: Number(0), // 倒计时目标时间
    time: Number(0), // 倒计时

    loading: false, // 按钮加载状态
    cphone: false, // 检查手机

    // 校验
    rules: {
      Phone: [
        { required: true, message: "请输入11位手机号码", trigger: "blur" },
        {
          validator: (_, value, callback) => {
            callback(
              phone(value) ? undefined : new Error("请输入11位手机号码")
            );
          },
          trigger: "change",
        },
      ],
      Code: [{ required: true, message: "请输入6位验证码", trigger: "blur" }],
      Name: [
        {
          required: true,
          message: "8-16个字符，可由中英文、数字、“-”、“_”组成",
          trigger: "blur",
        },
        {
          validator: (_, value, callback) => {
            callback(
              userNameA(value, 8, 16)
                ? undefined
                : new Error("8-16个字符，可由中英文、数字、“-”、“_”组成")
            );
          },
        },
      ],
      Password: [
        {
          required: true,
          message: "密码8到16位，需包含字母、数字",
          trigger: "blur",
        },
        {
          validator: (_, value, callback) => {
            callback(
              passwordB(value, 8, 16)
                ? undefined
                : new Error("密码8到16位，需包含字母、数字")
            );
          },
        },
      ],
      PasswordV: [
        {
          required: true,
          message: "两次填写的密码不一致",
          trigger: "blur",
        },
      ],
    },

    chick: false,
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.BUS.BusinessOccupancySteps(0);

    this.rules.PasswordV.push({
      validator: (_, value, callback) => {
        if (value === this.query.Password) {
          callback();
        } else {
          callback(new Error("两次填写的密码不一致"));
        }
      },
      trigger: "blur",
    });

    // 云端手机号查重
    this.rules.Phone.push({
      validator: (_, value, callback) =>
        this.Api.BusinessRegistrationCheckPhone.init({
          Phone: value,
        })
          .GetData()
          .then((_) => {
            this.cphone = false;
            callback();
          })
          .catch((msg) => {
            this.cphone = true;
            callback(new Error(msg));
          }),
      trigger: "blur",
    });

    // 云端用户名查重
    this.rules.Name.push({
      validator: (_, value, callback) =>
        this.Api.BusinessRegistrationCheckAccount.init({
          Account: value,
        })
          .GetData()
          .then((_) => callback())
          .catch((msg) => callback(new Error(msg))),
      trigger: "blur",
    });
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 下一步
    next() {
      this.$refs.$.validate().then(($) => {
        if ($) {
          this.loading = true;
          this.Api.BusinessRegistrationAdd.init(this.query)
            .SetData()
            .then(($) => {
              this.BUS.SaveBusinessOccupancyForm(); // 储存数据
              this.$GO({ path: "/menu/business/occupancy/shopinfo/" });
            })
            .finally((_) => (this.loading = false));
        }
      });
    },

    // 验证码
    valid() {
      this.timeout = new Date().getTime() + 120 * 1000;
      this.usetimeout();
      this.Api.BusinessRegistrationVerify.init(this.query.Phone)
        .SetData()
        .catch(($) => {});
    },

    // 使用倒计时
    usetimeout() {
      // 订阅心跳
      this.QUEUE.Validss = (unix) => {
        this.time = Math.floor((this.timeout - unix) / 1000);

          console.log(this.timeout);
        if (this.time <= 0) {
          this.timeout = this.time = 0;
          delete this.QUEUE.Validss; // 销毁订阅
        }
      };
    },
  },
};
</script>

<style lang="scss" scoped>
.label {
  border-bottom: 1px solid rgba(238, 238, 238, 100);
  justify-content: center;
  align-items: center;
  font-size: 16px;
  display: flex;
  height: 64px;
  width: 100%;
}

.el-form {
  // 覆盖表单样式
  margin-top: 30px;
  width: 370px;

  .el-form-item {
    margin-bottom: 30px;
  }

  .phone {
    // 手机号
    width: 100%;
  }

  .valid-box {
    // 验证码
    flex-wrap: nowrap;
    width: 100%;

    .el-input {
      flex-grow: 1;
    }

    .el-button {
      margin-left: 10px;
      width: 100px;
    }
  }
}
</style>