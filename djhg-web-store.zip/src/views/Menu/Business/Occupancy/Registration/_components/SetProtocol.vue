<template>
  <div class="protocol-box">
    <div class="checkbox">
      <input id="protocol" type="checkbox" v-model="model" />
      <label for="protocol"></label>
    </div>
    <div class="protocol">
      请阅读并同意
      <span @click="go(8)">《商家入驻协议》</span>
      、
      <span @click="go(19)">《商品回收协议》</span>
      、
      <span @click="go(6)">《商品租赁协议》</span>
      、
      <span @click="go(20)">《商家技术服务费管理规范》</span>
      、
      <span @click="go(12)">《参谋者平台合作协议》</span>
    </div>
  </div>
</template>

<script>
export default {
  // 接收参数
  props: {
    // 自定义v-model
    modelValue: undefined,
  },

  // 计算属性
  computed: {
    // 自定义v-model
    model: {
      get() {
        return this.modelValue;
      },
      set(value) {
        this.$emit("update:modelValue", value); // 回写自定义v-model
      },
    },
  },

  // 组件方法
  methods: {
    // 打开用户协议
    go(Id) {
      this.$router.push({ path: "/protocol", query: { Id } });
    },
  },
};
</script>

<style lang="scss" scoped>
.protocol-box {
  // 用户协议
  margin: 30px 0 20px 0;
  align-items: center;
  display: flex;
  width: 324px;

  .checkbox {
    // 选择器
    position: relative;
    height: 16px;
    width: 16px;

    input {
      display: none;
    }

    label {
      border: 1px solid rgba(187, 187, 187, 1);
      transition: border 0.2s ease 0s;
      box-sizing: border-box;
      position: absolute;
      border-radius: 8px;
      cursor: pointer;
      height: 16px;
      width: 16px;
      left: 0;
      top: 0;
    }

    label:before {
      transition: background-color 0.2s ease 0s;
      background-color: rgba(34, 138, 255, 0);
      border-radius: 6px;
      position: absolute;
      height: 10px;
      width: 10px;
      content: "";
      left: 2px;
      top: 2px;
    }

    input[type="checkbox"]:checked + label {
      border-color: rgba(34, 138, 255, 1);
    }

    input[type="checkbox"]:checked + label:before {
      background-color: rgba(34, 138, 255, 1);
    }
  }

  .protocol {
    color: rgba(51, 51, 51, 1);
    margin-left: 10px;
    line-height: 17px;
    font-size: 12px;

    span {
      color: rgba(34, 138, 255, 1);
      cursor: pointer;
    }
  }
}
</style>