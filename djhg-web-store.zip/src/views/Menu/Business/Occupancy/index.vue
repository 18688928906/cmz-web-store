<template>
  <ScrollBar>
    <TopBar :src="logosrc" label="商家入驻" />

    <ElRow class="page-box">
      <Steps :shoptype="form.ShopType" />
      <RouterViewqQuery :query="form" />
    </ElRow>
  </ScrollBar>
</template>

<script>
import Steps from "./_components/Steps.vue";
import logosrc from "@/assets/Logo商家入驻.png";

export default {
  // 自动路由参数
  meta: {
    title: undefined, // 写入浏览器页签
    index: undefined, // 用于排序
    label: "入驻表单入口", // 显示用的路由名称
    name: undefined, // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(true), // 控制是否需要登录
  },

  // 组件
  components: { Steps },

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    logosrc,
    form: {
      Phone: "", // 手机号
      Code: "", // 验证码
      Name: "", // 用户名
      Password: "", // 密码
      PasswordV: "", // 校验密码

      ShopLogo: Array(0), // 店铺图标
      ShopName: "", // 店铺名称
      ShopType: undefined, // 店铺类型
      Operation: undefined, // 主营类目
      Introduce: "", // 店铺简介

      Licence: Array(0), // 营业执照
      CompanyName: "", // 公司名称
      ShopScale: undefined, // 店铺规模
      USCC: "", // 统一社会信用代码
      USCCS: "", // 统一社会信用代码有效期，开始
      USCCD: "", // 统一社会信用代码有效期，结束
      USCCX: false, // 统一社会信用代码有效期，长期模式
      LicenAddressId: Array(0), // 营业执照所在地
      Address: "", // 住所
      Credentials: Array(0), // 资历
      CardType: 0, // 证件类型

      RealName: "", // 身份证姓名 or 护照姓名
      ID: "", // 身份证号
      Passport: "", // 护照号
      DurationEu: 0, // 身份证有效期控制
      Duration: undefined, // 身份证有效期
      DurationEnd: undefined, // 身份证有效期结束
      ID_Img: Array(0), // 存放身份证照片
      Passport_Img: Array(0), // 护照图片

      ContactName: "", // 联系人姓名
      Email: "", // 联系人邮箱
      ContacPhone: "", // 联系人电话
      ContacValid: "", // 验证码
    }, // 表单

    key: "SaveBusinessOccupancyForm", // 识别键
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.BUS.SaveBusinessOccupancyForm = () => {
      var form = JSON.stringify(this.form); // 转换成字符串
      form = this.AES.encrypt(form); // 加密参数
      localStorage.setItem(this.key, form); // 储存表单
    };

    var form = localStorage.getItem(this.key);

    if (!!form) {
      form = this.AES.decrypt(form);
      form = JSON.parse(form);
      Object.keys(form).forEach((key) => (this.form[key] = form[key]));
    } else {
      this.init();
      this.$GO({
        path: !!window.$TOKEN$
          ? "/menu/business/occupancy/registration"
          : "/menu/home",
      });
    }
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    localStorage.removeItem(this.key);
  },

  // 组件方法
  methods: {
    init() {
      this.form = {
        Phone: "", // 手机号
        Code: "", // 验证码
        Name: "", // 用户名
        Password: "", // 密码
        PasswordV: "", // 校验密码

        ShopLogo: Array(0), // 店铺图标
        ShopName: "", // 店铺名称
        ShopType: undefined, // 店铺类型
        Operation: undefined, // 主营类目
        Introduce: "", // 店铺简介

        Licence: Array(0), // 营业执照
        CompanyName: "", // 公司名称
        ShopScale: undefined, // 店铺规模
        USCC: "", // 统一社会信用代码
        USCCS: "", // 统一社会信用代码有效期，开始
        USCCD: "", // 统一社会信用代码有效期，结束
        USCCX: false, // 统一社会信用代码有效期，长期模式
        LicenAddressId: Array(0), // 营业执照所在地
        Address: "", // 住所
        Credentials: Array(0), // 资历
        CardType: 0, // 证件类型

        RealName: "", // 身份证姓名 or 护照姓名
        ID: "", // 身份证号
        Passport: "", // 护照号
        DurationEu: 0, // 身份证有效期控制
        Duration: undefined, // 身份证有效期
        DurationEnd: undefined, // 身份证有效期结束
        ID_Img: Array(0), // 存放身份证照片
        Passport_Img: Array(0), // 护照图片

        ContactName: "", // 联系人姓名
        Email: "", // 联系人邮箱
        ContacPhone: "", // 联系人电话
        ContacValid: "", // 验证码
      };
      this.BUS.SaveBusinessOccupancyForm();
    },
  },
};
</script>

<style lang="scss" scoped>
.page-box {
  // 页面容器
  box-shadow: var(--base-shadow);
  background-color: white;
  flex-direction: column;
  align-items: center;
  border-radius: 4px;
  margin-top: 20px;
  width: 1200px;
}
</style>