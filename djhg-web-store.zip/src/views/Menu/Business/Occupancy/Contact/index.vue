<template>
  <TitleRow label="联系人信息" />

  <!-- 输入表单 -->
  <ElForm
    :rules="rules"
    :model="query"
    label-position="top"
    ref="$"
    scroll-to-error
  >
    <!-- 联系人姓名 -->
    <ElFormItem label="联系人姓名:" prop="ContactName">
      <ElInput
        v-model="query.ContactName"
        :maxlength="20"
        placeholder="请输入联系人姓名"
        show-word-limit
      />
    </ElFormItem>

    <!-- 联系人邮箱 -->
    <ElFormItem label="联系人邮箱:" prop="Email">
      <ElInput v-model="query.Email" placeholder="请输入联系人邮箱" />
    </ElFormItem>

    <!-- 联系人电话 -->
    <ElFormItem label="联系人电话:" prop="ContacPhone">
      <ElInput
        v-model="query.ContacPhone"
        :maxlength="11"
        oninput="this.value=this.value.replace(/[^0-9]/g,'')"
        placeholder="请输入联系人电话"
        show-word-limit
      />
    </ElFormItem>

    <!-- 验证码 -->
    <!-- <ElFormItem label="验证码:" prop="ContacValid">
      <ElRow class="ContacValid">
        <ElInput v-model="query.ContacValid" placeholder="请输入验证码" />
        <ElButton
          :disabled="time > 0 || !rephone(query.ContacPhone)"
          style="width: 140px"
          type="primary"
          @click="valid()"
        >
          {{ time > 0 ? `（${time}s）` : "验证码" }}
        </ElButton>
      </ElRow>
    </ElFormItem> -->
  </ElForm>

  <ElRow style="margin-bottom: 60px; margin-top: 30px">
    <ElButton class="next" @click="GoBack()">上一步</ElButton>
    <ElButton type="primary" class="next" :loading="loading" @click="next()"
      >提交</ElButton
    >
  </ElRow>
</template>

<script>
import TitleRow from "../_components/TitleRow.vue";

import verify from "@/tool-library/_modules/verify.js";

export default {
  // 自动路由参数
  meta: {
    title: undefined, // 写入浏览器页签
    index: undefined, // 用于排序
    label: undefined, // 显示用的路由名称
    name: undefined, // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(true), // 控制是否需要登录
  },

  // 组件
  components: { TitleRow },

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    timeout: Number(0), // 倒计时目标时间
    time: Number(0), // 倒计时

    loading: false, // 按钮加载状态

    // 校验
    rules: {
      ContactName: [
        { required: true, message: "联系人姓名不能为空", trigger: "blur" },
      ],
      ContacPhone: [
        { required: true, message: "联系人电话不能为空", trigger: "blur" },
        {
          validator: (_, value, callback) => {
            callback(verify.phone(value) ? undefined : "请输入11位手机号码");
          },
        },
      ],
      // ContacValid: [
      //   { required: true, message: "验证码不能为空", trigger: "blur" },
      // ],
      Email: [
        {
          validator: (_, value, callback) => {
            callback(
              verify.email(value) || value === "" ? undefined : "请输入正确邮箱"
            );
          },
        },
      ],
    },

    rephone: undefined,
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.Api.AddressOptions.GetData().then(($) => (this.AddressOptions = $)); // 获取地址选择器参数
    this.BUS.BusinessOccupancySteps(3);
    this.rephone = verify.phone;
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 下一步
    next() {
      this.$refs.$.validate().then(($) => {
        if ($) {
          var form = JSON.stringify(this.query); // 拷贝表单
          form = JSON.parse(form);
          form.ShopLogo = form.ShopLogo[0].response.data.url; // 处理店铺图标
          form.Licence = form.Licence[0].response.data.url; // 营业执照
          form.LicenAddressId = this.Api.AddressOptions.GetExt(
            form.LicenAddressId
          ); //form.LicenAddressId.join(","); // 拼接地址ID
          form.Credentials = form.Credentials?.map(
            (item) => item.response?.data?.url
          )
            .filter((item) => !!item)
            .join(","); // 资历
          form.ID_Img = form.ID_Img?.map(($) => $?.[0]?.response?.data?.url); // 身份证图片
          form.Passport_Img = form.Passport_Img?.map(
            ($) => $?.response?.data?.url
          ).join(","); // 护照图片

          let vx = (n) => (Number(n) > 9 ? n : "0" + n);

          if (!!form.Duration) {
            var t = new Date(form.Duration);
            var y = t.getFullYear();
            var m = t.getMonth() + 1;
            var d = t.getDate();
            form.Duration = vx(y) + "-" + vx(m) + "-" + vx(d) + " 00:00:00";
          }

          if (form.DurationEu > 0) {
            form.DurationEnd = "2099-12-31 00:00:00";
          } else if (!!form.DurationEnd) {
            var t = new Date(form.DurationEnd);
            var y = t.getFullYear();
            var m = t.getMonth() + 1;
            var d = t.getDate();
            form.DurationEnd = vx(y) + "-" + vx(m) + "-" + vx(d) + " 00:00:00";
          }

          if (!!form.USCCS) {
            var t = new Date(form.USCCS);
            var y = t.getFullYear();
            var m = t.getMonth() + 1;
            var d = t.getDate();
            form.USCCS = vx(y) + "-" + vx(m) + "-" + vx(d) + " 00:00:00";
          }

          if (form.USCCX) {
            form.USCCD = "2099-12-31 00:00:00";
          } else if (!!form.USCCD) {
            var t = new Date(form.USCCD);
            var y = t.getFullYear();
            var m = t.getMonth() + 1;
            var d = t.getDate();
            form.USCCD = vx(y) + "-" + vx(m) + "-" + vx(d) + " 00:00:00";
          }

          this.loading = true;
          this.Api.BusinessRegistrationRegister.init(form)
            .SetData()
            .then((_) => {
              this.$GO({ path: "/menu/business/audit" });
            })
            .finally(() => {
              this.loading = false;
            });
        }
      });
    },

    // 返回上级
    GoBack() {
      this.BUS.SaveBusinessOccupancyForm(); // 储存数据
      this.$router.go(-1);
    },

    // 验证码
    valid() {
      this.timeout = new Date().getTime() + 120 * 1000;
      this.usetimeout();
      this.Api.BusinessRegistrationVerify.init(this.query.ContacPhone)
        .SetData()
        .catch(($) => {});
    },

    // 使用倒计时
    usetimeout() {
      // 订阅心跳
      this.QUEUE.Valid = (unix) => {
        this.time = Math.floor((this.timeout - unix) / 1000);
        if (this.time <= 0) {
          this.timeout = this.time = 0;
          delete this.QUEUE.Valid; // 销毁订阅
        }
      };
    },
  },
};
</script>

<style lang="scss" scoped>
.el-form {
  // 表单样式覆盖
  margin-top: 24px;
  width: 600px;

  :deep(.el-date-editor) {
    width: 100%;

    .el-input__wrapper {
      width: inherit;
    }
  }

  .ContacValid {
    flex-direction: row;
    align-items: center;
    flex-wrap: nowrap;
    width: 100%;

    .el-button {
      margin-left: 16px;
    }
  }
}

.next {
  // 下一步
  width: 158px;
}
</style>