<template>
  <!-- 商品容器 -->
  <div class="upload-box">
    <UpA v-model:file="file[0]" :form="form" />

    <UpB v-model:file="file[1]" :form="form" />

    <SampleBox v-for="(item, index) in Sample" :src="item" :key="index" />
  </div>
</template>

<script>
import SampleB from "@/assets/身份证正.png";
import SampleC from "@/assets/身份证反.png";

import SampleBox from "./SampleBox.vue";
import UpA from "./UploadID-A.vue";
import UpB from "./UploadID-B.vue";

export default {
  // 组件
  components: { SampleBox, UpA, UpB },

  // 接收参数
  props: {
    // 文件对象
    file: {
      type: Array,
      default: () => Array(0),
    },

    form: undefined,
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    Sample: [SampleB, SampleC], // 示例图
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.upload-box {
  // 商品容器
  grid-template-columns: repeat(auto-fill, 100px);
  grid-gap: 12px 12px;
  position: relative;
  min-height: 100px;
  display: grid;
  width: 100%;
}
</style>