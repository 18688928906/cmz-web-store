<template>
  <!-- 商品容器 -->
  <div class="upload-box">
    <template v-for="(item, index) in _file" :key="index">
      <!-- 显示图片 -->
      <div v-if="!!item?.response?.data?.url" class="img-box">
        <!-- 图片展示 -->
        <ElImage
          :src="item.response.data.url"
          style="width: 98px; height: 98px"
          fit="contain"
        />

        <!-- 关闭容器 -->
        <div class="close" @click="remove(index)">
          <img class="A" :src="$svg['i-0032']" />
          <img class="B" :src="$svg['i-0032-FF0000']" />
        </div>
      </div>
    </template>

    <!-- 进度条 -->
    <div v-if="percent" class="percent">{{ percent || 0 }}%</div>

    <!-- 上传功能 -->
    <ElUpload
      v-show="_file.length < 1"
      v-model:file-list="_file"
      :before-upload="before"
      :show-file-list="false"
      :on-progress="progress"
      :on-success="success"
      :action="action"
      :accept="accept"
      :limit="1"
      class="upload"
    >
      <img :src="$svg['i-0031-8B929B']" />
    </ElUpload>

    <SampleBox :src="Sample[0]" />
  </div>
</template>

<script>
import { compressAccurately } from "image-conversion";
import SampleC from "@/assets/护照案例.png";
import SampleBox from "./SampleBox.vue";

export default {
  // 组件
  components: { SampleBox },

  // 接收参数
  props: {
    // 文件对象
    file: {
      type: Array,
      default: () => Array(0),
    },
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    action:
      process.env.VUE_APP_BASE_URL +
      process.env.VUE_APP_OBS +
      "/cmz-img/?token=", // 拼接华为OBS服务器地址
    accept: [".jpg", ".jpeg", ".png"].join(","), // 支持的上传格式

    percent: undefined, // 上传进度

    _file: Array(0), // 映射

    video: false, // 视频模式
    full: false, // 满文件

    Sample: [SampleC], // 示例图
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.action = this.action + this.Api.UserLogin.Token.token; // 写入Token
    this.accept = [this.accept, this.accept.toUpperCase()].join(","); // 大写转换
    this._file = this.file; // 写入已上传文件
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 上传前检查
    before($) {
      return compressAccurately($, 1024 * 1);
    },

    // 上传时
    progress($) {
      this.percent = ~~$.percent; // 记录上传进度
    },

    // 上传成功
    success($) {
      this.percent = undefined; // 上传成功清除进度
      this.$emit("update:file", this._file);
    },

    // 删除文件
    remove(index) {
      this._file.splice(index, 1);
      this.$emit("update:file", this._file);
    },
  },
};
</script>

<style lang="scss" scoped>
.upload-box {
  // 商品容器
  grid-template-columns: repeat(auto-fill, 100px);
  grid-gap: 12px 12px;
  position: relative;
  min-height: 100px;
  display: grid;
  width: 100%;

  .percent {
    // 进度
    border: var(--el-border);
    justify-content: center;
    align-items: center;
    border-radius: 4px;
    display: flex;
    height: 100px;
    width: 100px;
  }

  .img-box {
    // 图片容器
    border: var(--el-border);
    border-radius: 4px;
    position: relative;
    height: 100px;
    width: 100px;

    .close {
      // 关闭
      position: absolute;
      cursor: pointer;
      display: none;
      height: 16px;
      width: 16px;
      right: -8px;
      top: -8px;

      img {
        height: inherit;
        width: inherit;
      }

      .A {
        display: block;
      }

      .B {
        display: none;
      }

      &:hover {
        .A {
          display: none;
        }

        .B {
          display: block;
        }
      }
    }

    &:hover {
      .close {
        display: block;
      }
    }
  }

  .upload {
    // 上传功能
    transition: var(--base-transition);
    border: var(--el-border);
    border-radius: 4px;
    height: 100px;
    width: 100px;

    :deep(.el-upload) {
      // 内部样式覆盖
      height: 100%;
      width: 100%;
    }

    &:hover {
      border-color: var(--el-color-primary);
    }
  }

  .count {
    // 计数
    color: rgba(153, 153, 153, 1);
    align-items: flex-end;
    line-height: 1;
    display: flex;
  }
}
</style>