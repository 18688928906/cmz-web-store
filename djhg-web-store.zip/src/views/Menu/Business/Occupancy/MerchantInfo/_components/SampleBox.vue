<template>
  <ElRow class="sample-box">
    <div class="label">示例</div>
    <ElImage :src="src" fit="contain" />
  </ElRow>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    src: undefined,
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.sample-box {
  // 示例容器
  background-color: rgba(244, 244, 245, 1);
  border: var(--el-border);
  flex-direction: column;
  align-items: center;
  border-radius: 4px;
  position: relative;
  height: var(--size);
  width: var(--size);
  flex-wrap: nowrap;
  --size: 100px;

  .label {
    color: rgba(96, 98, 102, 1);
    font-size: 12px;
  }

  .el-image {
    height: 70%;
    width: 100%;
  }
}
</style>