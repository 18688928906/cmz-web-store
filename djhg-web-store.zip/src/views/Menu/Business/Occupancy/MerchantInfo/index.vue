<template>
  <!-- <TitleRow :label="query.ShopLogo > 0 ? '企业信息' : '个体工商户信息'" /> -->
  <TitleRow label="主体信息" />

  <!-- 输入表单 -->
  <ElForm
    :rules="rules"
    :model="query"
    label-position="top"
    ref="$"
    scroll-to-error
  >
    <!-- 上传一张营业执照 -->
    <ElFormItem label="营业执照上传:" prop="Licence">
      <UploadLicence v-model:file="query.Licence" :form="query" />
    </ElFormItem>

    <!-- 公司名称 -->
    <ElFormItem label="公司名称:" prop="CompanyName">
      <ElInput
        v-model="query.CompanyName"
        placeholder="请输入公司名称"
        maxlength="60"
        show-word-limit
      />
    </ElFormItem>

    <!-- 统一社会信用代码 -->
    <ElFormItem label="统一社会信用代码:" prop="USCC">
      <ElInput
        v-model="query.USCC"
        placeholder="请输入统一社会信用代码"
        maxlength="18"
        show-word-limit
      />
    </ElFormItem>

    <!-- 统一社会信用代码有效期 -->
    <ElFormItem label="营业期限:">
      <ElFormItem prop="USCCS">
        <ElDatePicker
          v-model="query.USCCS"
          placeholder="成立日期"
          type="date"
        />
      </ElFormItem>
      <span style="font-size: 14px; margin: 0 20px">至</span>
      <ElFormItem prop="USCCD">
        <ElDatePicker
          v-if="query.USCCX"
          :disabled="true"
          placeholder="截止日期"
          type="date"
        />
        <ElDatePicker
          v-else
          v-model="query.USCCD"
          placeholder="截止日期"
          type="date"
        />
      </ElFormItem>
      <ElCheckbox
        v-model="query.USCCX"
        style="margin-left: 20px"
        label="长期"
        @change="check('USCCD')"
      />
    </ElFormItem>

    <!-- 营业执照所在地 -->
    <ElFormItem label="营业执照所在地:" prop="LicenAddressId">
      <ElCascader
        v-model="query.LicenAddressId"
        :options="AddressOptions"
        style="width: 100%"
      />
    </ElFormItem>

    <!-- 住所 -->
    <ElFormItem label="住所:" prop="Address">
      <ElInput
        v-model="query.Address"
        placeholder="请输入营业执照上的住所"
        maxlength="100"
        show-word-limit
      />
    </ElFormItem>

    <!-- 资质信息 -->
    <ElFormItem
      label="资质信息（品牌授权证明、商标注册证、类目特殊资质等):"
      prop="Credentials"
    >
      <UploadCredentials v-model:file="query.Credentials" />
    </ElFormItem>

    <!-- 店铺规格限制非个体户 -->
    <!-- <ElFormItem label="证件类型:" prop="CardType">
      <ElSelect
        v-model="query.CardType"
        placeholder="请选择证件类型"
        style="width: 100%"
      >
        <ElOption
          v-for="(item, index) in ['身份证', '护照']"
          :value="index"
          :label="item"
          :key="index"
        />
      </ElSelect>
    </ElFormItem> -->

    <!-- 上传身份证 -->
    <ElFormItem label="身份证照片" prop="ID_Img">
      <ElPopover
        placement="top-start"
        trigger="hover"
        content="身份证照片请上传横图"
      >
        <template #reference>
          <!-- <img :src="$svg['i-0053']" class="help" /> -->
          <img :src="$svg['i-0049']" class="help" />
        </template>
      </ElPopover>
      <UploadID v-model:file="query.ID_Img" :form="query" />
    </ElFormItem>

    <!-- 姓名 -->
    <ElFormItem
      :label="query.CardType > 0 ? '护照姓名:' : '法人姓名:'"
      prop="RealName"
    >
      <ElInput
        v-model="query.RealName"
        :placeholder="
          query.CardType > 0 ? '请输入护照证姓名' : '请输入身份证姓名'
        "
        maxlength="40"
        show-word-limit
      />
    </ElFormItem>

    <template v-if="query.CardType > 0">
      <!-- 护照号 -->
      <ElFormItem label="护照号" prop="Passport">
        <ElInput v-model="query.Passport" placeholder="请输入护照号" />
      </ElFormItem>

      <!-- 上传护照 -->
      <ElFormItem label="护照上传" prop="ID_Img">
        <UploadPassport v-model:file="query.Passport_Img" />
      </ElFormItem>
    </template>

    <template v-else>
      <!-- 身份证号 -->
      <ElFormItem label="法人身份证号" prop="ID">
        <ElInput
          v-model="query.ID"
          placeholder="请输入身份证号"
          maxlength="18"
          show-word-limit
        />
      </ElFormItem>

      <!-- 身份证有效期 -->
      <!-- <ElFormItem label="法人身份证有效期" prop="DurationEu">
        <ElRadioGroup v-model="query.DurationEu">
          <ElRadio :label="0" border>固定</ElRadio>
          <ElRadio :label="1" border>长期</ElRadio>
        </ElRadioGroup>
      </ElFormItem> -->

      <!-- 身份证有效期 -->
      <!-- <ElFormItem label="法人身份证有效期有效期"> -->
      <ElFormItem label="法人身份证有效期">
        <ElFormItem prop="Duration">
          <ElDatePicker
            v-model="query.Duration"
            placeholder="开始日期"
            type="date"
          />
        </ElFormItem>
        <span style="font-size: 14px; margin: 0 20px">至</span>
        <ElFormItem prop="DurationEnd">
          <ElDatePicker
            v-if="query.DurationEu"
            :disabled="true"
            placeholder="截止日期"
            type="date"
          />
          <ElDatePicker
            v-else
            v-model="query.DurationEnd"
            placeholder="截止日期"
            type="date"
          />
        </ElFormItem>
        <ElCheckbox
          v-model="query.DurationEu"
          :trueLabel="1"
          :falseLabel="0"
          style="margin-left: 20px"
          label="长期"
          @change="check('DurationEnd')"
        />
      </ElFormItem>

      <!-- 上传身份证 -->
      <!-- <ElFormItem label="身份证上传" prop="ID_Img">
        <UploadID v-model:file="query.ID_Img" />
      </ElFormItem> -->
    </template>
  </ElForm>

  <ElButton type="primary" class="next" @click="next()">下一步</ElButton>
</template>

<script>
import TitleRow from "../_components/TitleRow.vue";
import UploadLicence from "./_components/UploadLicence.vue";
import UploadCredentials from "./_components/UploadCredentials.vue";
import UploadID from "./_components/UploadID.vue";
import UploadPassport from "./_components/UploadPassport.vue";

import verify from "@/tool-library/_modules/verify.js";

export default {
  // 自动路由参数
  meta: {
    title: undefined, // 写入浏览器页签
    index: undefined, // 用于排序
    label: undefined, // 显示用的路由名称
    name: undefined, // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(true), // 控制是否需要登录
  },

  // 组件
  components: {
    TitleRow,
    UploadLicence,
    UploadCredentials,
    UploadID,
    UploadPassport,
  },

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    AddressOptions: undefined,

    now: new Date(),

    // 校验
    rules: {
      // 营业执照图片
      Licence: [
        {
          type: "array",
          required: true,
          message: "请上传营业执照",
        },
      ],

      // 公司名称
      CompanyName: [{ required: true, message: "公司名称不能为空" }],

      // 店铺规模
      ShopScale: [{ required: true, message: "店铺规模不能为空" }],

      // 统一社会信用代码
      USCC: [
        {
          required: true,
          message: "统一社会信用代码不能为空",
        },
        {
          validator: (_, value, callback) => {
            callback(
              verify.USCC(value)
                ? undefined
                : new Error("请正确填写统一社会信用代码")
            );
          },
        },
      ],

      // 有效日期
      USCCS: [
        {
          required: true,
          message: "营业期限不能为空",
        },
      ],

      // 有效日期
      USCCD: [],

      // 营业执照所在地ID
      LicenAddressId: [
        {
          type: "array",
          required: true,
          message: "营业执照所在地不能为空",
        },
      ],

      // 详细地址
      Address: [{ required: true, message: "住所不能为空" }],

      // 真实姓名
      RealName: [{ required: true, message: "姓名不能为空" }],

      // 身份证号
      ID: [
        { required: true, message: "身份证号不能为空" },
        {
          validator: (_, value, callback) => {
            callback(
              verify.idCard(value) ? undefined : new Error("请正确填写身份证号")
            );
          },
        },
      ],

      // 护照号码
      Passport: [{ required: true, message: "护照号不能为空" }],

      // 选择身份证有效期，显示个必填符号
      DurationEu: [{ required: true, message: "" }],

      // 有效日期
      Duration: [{ required: true, message: "有效日期不能为空" }],

      // 有效日期结束
      DurationEnd: [],

      // 上传身份证图片
      ID_Img: [
        { required: true, message: "身份证不能为空" },
        {
          validator: (_, value, callback) => {
            if (!value[0]?.[0]) {
              callback(new Error("身份证正面不能为空"));
            } else if (!value[1]?.[0]) {
              callback(new Error("身份证背面不能为空"));
            } else {
              callback();
            }
          },
        },
      ],

      // 上传护照图片
      Passport_Img: [
        {
          type: "array",
          required: true,
          message: "护照不能为空",
        },
      ],
    },
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.Api.AddressOptions.GetData().then(($) => (this.AddressOptions = $)); // 获取地址选择器参数
    this.BUS.BusinessOccupancySteps(2);
    if (this.query.ShopType !== 0) {
      this.rules.Credentials = [
        {
          type: "array",
          required: true,
          message: "资质信息不能为空",
        },
      ];
    }

    this.rules.USCCD.push({
      validator: (_, value, callback) => {
        callback(
          (value !== undefined && value !== "") || this.query.USCCX
            ? undefined
            : new Error("营业期限不能为空")
        );
      },
    });

    this.rules.DurationEnd.push({
      validator: (_, value, callback) => {
        callback(
          (value !== undefined && value !== "") || this.query.DurationEu === 1
            ? undefined
            : new Error("身份证截止日期不能为空")
        );
      },
    });
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 下一步
    next() {
      this.$refs.$.validate().then(($) => {
        if ($) {
          this.BUS.SaveBusinessOccupancyForm(); // 储存数据
          this.$GO({ path: "/menu/business/occupancy/contact" });
        }
      });
    },

    check($) {
      this.$refs.$.validateField($);
    },

    // 用户选择店铺类型
    change(value) {
      this.BUS.BusinessOccupancyStepsType(
        value > 0 ? "填写企业信息" : "填写个体工商户信息"
      );
    },
  },
};
</script>

<style lang="scss" scoped>
.el-form {
  // 表单样式覆盖
  margin-top: 24px;
  width: 600px;

  :deep(.el-date-editor) {
    width: 100%;

    .el-input__wrapper {
      width: 100%;
    }
  }

  .help {
    position: absolute;
    height: 14px;
    width: 14px;
    left: 90px;
    top: -25px;
  }
}

.next {
  // 下一步
  margin-bottom: 60px;
  margin-top: 30px;
  width: 158px;
}
</style>