<template>
  <ElRow>{{ label }}</ElRow>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    label: {
      type: String,
      default: "默认标题",
    },
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.el-row {
  background-color: var(--el-color-primary-light-9);
  align-items: center;
  border-radius: 4px;
  padding: 0 calc((100% - 600px) / 2);
  margin-top: 48px;
  font-size: 16px;
  height: 60px;
  width: 100%;
}
</style>