<template>
  <ElSteps v-if="active > 0" :active="active" align-center>
    <template v-if="shoptype === undefined">
      <ElStep v-for="$ in titlesA" :title="$" :key="$" />
    </template>
    <template v-else-if="shoptype > 0">
      <ElStep v-for="$ in titlesB" :title="$" :key="$" />
    </template>
    <template v-else>
      <ElStep v-for="$ in titlesC" :title="$" :key="$" />
    </template>
  </ElSteps>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: { shoptype: undefined },

  // 计算属性
  computed: {
    title: {
      get() {
        if (this.shoptype === undefined) {
          return this.titles;
        } else {
          return this.titles.map((item, index) =>
            index === 1
              ? this.shoptype > 0
                ? "填写主体信息"
                : "填写主体信息" // "填写个体工商户信息"
              : item
          );
        }
      },
    },
  },

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    active: 0, // 激活的项
    titlesA: [
      "填写基本信息",
      "填写主体信息" /* "填写相关信息" */,
      "填写联系人信息",
      "提交完成",
    ],
    titlesB: ["填写基本信息", "填写主体信息", "填写联系人信息", "提交完成"],
    titlesC: [
      "填写基本信息",
      "填写主体信息" /* "填写个体工商户信息" */,
      "填写联系人信息",
      "提交完成",
    ],
    key: "BusinessOccupancySteps",
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.BUS[this.key] = (active) => (this.active = active); // 订阅激活信息
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    delete this.BUS[this.key]; // 关闭订阅
  },

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.el-steps {
  margin-top: 24px;
  width: 1000px;

  :deep(.is-finish) {
    .el-step__icon {
      box-shadow: 1px 2px 2px 0px rgba(0, 0, 0, 0.1), -2px -2px 4px 0px #ffffff;
      background: linear-gradient(133deg, #3b7cff 0%, #98bcff 100%);
      color: white;
      border: none;
    }
  }

  :deep(.is-process) {
    border-color: var(--el-text-color-placeholder);
    color: var(--el-text-color-placeholder);
    font-weight: normal;

    .el-step__icon {
      background: linear-gradient(133deg, #d2d2d2 0%, #fbfbfb 100%);
      box-shadow: 1px 2px 2px 0px rgba(0, 0, 0, 0.1), -2px -2px 4px 0px #ffffff;
      color: #3b7cff;
      border: none;
    }
  }

  :deep(.is-wait) {
    .el-step__icon {
      background: linear-gradient(133deg, #d2d2d2 0%, #fbfbfb 100%);
      box-shadow: 1px 2px 2px 0px rgba(0, 0, 0, 0.1), -2px -2px 4px 0px #ffffff;
      color: #3b7cff;
      border: none;
    }
  }
}
</style>