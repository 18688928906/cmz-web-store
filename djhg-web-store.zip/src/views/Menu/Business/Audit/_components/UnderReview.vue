<template>
  <ElRow class="row-box">
    <!-- 标题 -->
    <ElRow class="label">
      <img :src="$svg['i-0014-7BBC52']" />
      <span>审核中</span>
    </ElRow>

    <!-- 审核 -->
    <div class="tips">请耐心等待平台审核，审核周期一般为1-3个工作日</div>
  </ElRow>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.row-box {
  background-color: rgba(236, 245, 255, 1);
  border: 1px solid var(--el-color-primary);
  justify-content: center;
  flex-direction: column;
  border-radius: 10px;
  align-items: center;
  flex-wrap: nowrap;
  margin-top: 40px;
  height: 92px;
  width: 600px;

  .label {
    // 标题
    align-items: center;
    font-size: 18px;

    img {
      margin-right: 0.25em;
      height: 1em;
      width: 1em;
    }

    span {
      color: var(--el-color-primary);
      font-weight: bold;
      font-size: 1em;
    }
  }

  .tips {
    // 提示语
    line-height: 1.2em;
    font-weight: bold;
    margin-top: 8px;
    font-size: 14px;
  }
}
</style>