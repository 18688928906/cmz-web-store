<template>
  <ScrollBar>
    <TopBar :src="logosrc" label="商家入驻" />

    <ElRow class="page-box">
      <!-- 审核提示 -->
      <UnderReview v-if="state.Type === 2" />

      <!-- 审核成功 -->
      <Succeed v-else-if="state.Type === 3" />

      <!-- 审核失败 -->
      <Overrule v-else-if="state.Type === 4" :msg="state.Msg" />

      <!-- 审核提示 -->
      <UnderReview v-else />
    </ElRow>
  </ScrollBar>
</template>

<script>
import UnderReview from "./_components/UnderReview.vue";
import Succeed from "./_components/Succeed.vue";
import Overrule from "./_components/Overrule.vue";
import logosrc from "@/assets/Logo商家入驻.png";

export default {
  // 自动路由参数
  meta: {
    title: undefined, // 写入浏览器页签
    index: undefined, // 用于排序
    label: undefined, // 显示用的路由名称
    name: undefined, // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(true), // 控制是否需要登录
  },

  // 组件
  components: { UnderReview, Succeed, Overrule },

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    logosrc,
    state: 0, // 审核状态
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.Api.BusinessInquireProgress.GetData().then(($) => {
      this.state = $;
    });
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.page-box {
  // 页面容器
  box-shadow: var(--base-shadow);
  background-color: white;
  flex-direction: column;
  align-items: center;
  border-radius: 4px;
  min-height: 640px;
  margin-top: 20px;
  width: 1200px;
}
</style>