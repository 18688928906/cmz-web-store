<template>
  <ScrollBar v-if="state === 1">
    <TopBar :src="logosrc" label="商家入驻" />

    <div class="big-img">
      <img :src="src" style="height: 100%; width: 100%" />
      <!-- 这里预留一张大图 -->
    </div>

    <div class="title">入驻流程</div>

    <div class="steps-box">
      <div class="number">01</div>

      <div class="steps-item">
        <div class="label">阅读协议</div>
        <div class="tips">阅读并同意协议</div>
      </div>

      <div class="number">02</div>

      <div class="steps-item">
        <div class="label">提交资料</div>
        <div class="tips">填写信息及资料</div>
      </div>

      <div class="number">03</div>

      <div class="steps-item">
        <div class="label">平台审核</div>
        <div class="tips">48h内审核完成</div>
      </div>

      <div class="number">04</div>

      <div class="steps-item">
        <div class="label">入驻成功</div>
        <div class="tips">发布商品</div>
      </div>
    </div>

    <ElButton
      style="width: 280px"
      type="danger"
      @click="$GO({ path: '/menu/business/occupancy/registration' })"
      round
    >
      立即入驻
    </ElButton>
  </ScrollBar>
</template>

<script>
import logosrc from "@/assets/Logo商家入驻.png";
import src from "@/assets/入驻.png";
export default {
  // 自动路由参数
  meta: {
    title: undefined, // 写入浏览器页签
    index: Number(0), // 用于排序
    label: "免费入驻", // 显示用的路由名称
    name: undefined, // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(true), // 控制是否需要登录
  },

  // 组件
  components: {},

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    state: undefined,
    src,
    logosrc,
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.Api.BusinessInquireProgress.GetData().then(($) => {
      this.state = $.Type;
      // 处理非未入驻
      if (this.state !== 1) {
        this.$GO({ path: "/menu/business/audit" });
      }
    });
  },

  // 生命周期函数：挂载后调用
  mounted() {
    // 发布菜单选中
    this.BUS.SetMenuLabel(this.$options.meta.label);
  },

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.big-img {
  background-color: darkgray;
  text-align: center;
  line-height: 500px;
  font-size: 50px;
  height: 500px;
  width: 100%;
}

.title {
  font-size: 24px;
  margin: 20px;
}

.steps-box {
  margin-bottom: 60px;
  align-items: center;
  display: flex;

  .number {
    color: rgba(255, 168, 168, 1);
    font-size: 68px;
    line-height: 1;
  }

  .steps-item {
    flex-direction: column;
    margin-left: 4px;
    display: flex;

    div {
      line-height: 1;
    }

    .label {
      font-size: 20px;
    }

    .tips {
      color: rgba(153, 153, 153, 1);
      margin-top: 18px;
      font-size: 12px;
    }
  }

  .steps-item + .number {
    margin-left: 72px;
  }
}
</style>