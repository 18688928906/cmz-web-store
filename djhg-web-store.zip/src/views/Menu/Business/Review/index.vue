<template>
  <ScrollBar>
    <TopBar :src="logosrc" label="商家入驻" />

    <ElRow class="page-box">
      <Overrule />

      <!-- 回显表单 -->
      <ElForm
        v-if="!!form"
        :rules="rules"
        :model="form"
        label-position="top"
        ref="$"
        scroll-to-error
      >
        <div class="label-box">
          基本信息
          <!-- 店铺信息 -->
        </div>

        <ElFormItem label="店铺logo" prop="ShopLogo">
          <UploadStoreLogo v-model:list="form.ShopLogo" />
        </ElFormItem>

        <ElFormItem label="店铺名称" prop="ShopName">
          <ElInput
            v-model="form.ShopName"
            placeholder="请输入店铺名称"
            maxlength="30"
            show-word-limit
          />
        </ElFormItem>

        <ElFormItem label="店铺类型" prop="ShopType">
          <ElSelect
            v-model="form.ShopType"
            placeholder="请选择店铺类型"
            style="width: 100%"
          >
            <ElOption
              v-for="(item, index) in Shop0ptions"
              :value="index"
              :label="item"
              :key="index"
            />
          </ElSelect>
        </ElFormItem>

        <ElFormItem label="主营类目" prop="Operation">
          <ElSelect
            v-model="form.Operation"
            placeholder="请输入主营类目"
            style="width: 100%"
          >
            <ElOption
              v-for="(item, index) in Operation"
              :value="index"
              :label="item"
              :key="index"
            />
          </ElSelect>
        </ElFormItem>

        <ElFormItem label="店铺规模:" prop="ShopScale">
          <ElSelect
            v-model="form.ShopScale"
            placeholder="请选择店铺规模"
            style="width: 100%"
          >
            <ElOption
              v-for="(item, index) in ShopScale"
              :value="index"
              :label="item"
              :key="index"
            />
          </ElSelect>
        </ElFormItem>

        <ElFormItem label="店铺简介">
          <ElInput
            v-model="form.Introduce"
            :maxlength="100"
            :rows="5"
            placeholder="请输入店铺简介"
            type="textarea"
            resize="none"
            show-word-limit
          />
        </ElFormItem>

        <div class="label-box">
          主体信息
          <!-- 个体工商信息 -->
        </div>

        <!-- 上传一张营业执照 -->
        <ElFormItem label="营业执照上传:" prop="Licence">
          <UploadLicence v-model:list="form.Licence" :form="form" />
        </ElFormItem>

        <ElFormItem label="公司名称:" prop="CompanyName">
          <ElInput
            v-model="form.CompanyName"
            placeholder="请输入公司名称"
            maxlength="60"
            show-word-limit
          />
        </ElFormItem>

        <ElFormItem label="统一社会信用代码:" prop="USCC">
          <ElInput
            v-model="form.USCC"
            placeholder="请输入统一社会信用代码"
            maxlength="18"
            show-word-limit
          />
        </ElFormItem>

        <!-- 统一社会信用代码有效期 -->
        <ElFormItem label="营业期限:">
          <ElFormItem prop="USCCS" style="margin: 0; width: auto">
            <ElDatePicker
              v-model="form.USCCS"
              value-format="YYYY-MM-DD"
              placeholder="成立日期"
              style="width: 100%"
              type="date"
            />
          </ElFormItem>
          <span style="font-size: 14px; margin: 0 20px">至</span>
          <ElFormItem prop="USCCD" style="margin: 0; width: auto">
            <ElDatePicker
              v-if="form.USCCX"
              :disabled="true"
              placeholder="截止日期"
              style="width: 100%"
              type="date"
            />
            <ElDatePicker
              v-else
              v-model="form.USCCD"
              value-format="YYYY-MM-DD"
              placeholder="截止日期"
              style="width: 100%"
              type="date"
            />
          </ElFormItem>
          <ElCheckbox
            v-model="form.USCCX"
            style="margin-left: 20px"
            label="长期"
          />
        </ElFormItem>

        <ElFormItem label="营业执照所在地:" prop="LicenAddress">
          <ElCascader
            v-if="!!AddressOptions"
            v-model="form.LicenAddress"
            :options="AddressOptions"
            style="width: 100%"
          />
        </ElFormItem>

        <ElFormItem label="住所:" prop="Address">
          <ElInput
            v-model="form.Address"
            placeholder="请输入营业执照上的住所"
            maxlength="100"
            show-word-limit
          />
        </ElFormItem>

        <!-- 资质信息 -->
        <ElFormItem
          label="资质信息（品牌授权证明、商标注册证、类目特殊资质等):"
          prop="Credentials"
        >
          <UploadCredentials v-model:list="form.Credentials" />
        </ElFormItem>

        <ElFormItem label="身份证上传" prop="ID_Img">
          <UploadID v-model:file="form.ID_Img" :form="form" />
        </ElFormItem>

        <!-- <ElFormItem label="证件类型:" prop="CardType">
          <ElSelect
            v-model="form.CardType"
            placeholder="请选择证件类型"
            style="width: 100%"
          >
            <ElOption
              v-for="(item, index) in ['身份证', '护照']"
              :value="index"
              :label="item"
              :key="index"
            />
          </ElSelect>
        </ElFormItem> -->

        <ElFormItem
          :label="form.CardType > 0 ? '护照姓名:' : '法人姓名:'"
          prop="RealName"
        >
          <ElInput
            v-model="form.RealName"
            :placeholder="
              form.CardType > 0 ? '请输入护照证姓名' : '请输入身份证姓名'
            "
            maxlength="40"
            show-word-limit
          />
        </ElFormItem>

        <template v-if="form.CardType > 0">
          <!-- 护照号 -->
          <ElFormItem label="护照号" prop="Passport">
            <ElInput v-model="form.Passport" placeholder="请输入护照号" />
          </ElFormItem>

          <!-- 上传护照 -->
          <ElFormItem label="护照上传" prop="ID_Img">
            <UploadPassport v-model:list="form.Passport_Img" />
          </ElFormItem>
        </template>

        <template v-else>
          <!-- 身份证号 -->
          <ElFormItem label="法人身份证号" prop="ID">
            <ElInput
              v-model="form.ID"
              placeholder="请输入身份证号"
              maxlength="18"
              show-word-limit
            />
          </ElFormItem>

          <!-- 身份证有效期 -->
          <!-- <ElFormItem label="身份证有效期" prop="DurationEu">
            <ElRadioGroup v-model="form.DurationEu">
              <ElRadio :label="0" border>固定</ElRadio>
              <ElRadio :label="1" border>长期</ElRadio>
            </ElRadioGroup>
          </ElFormItem> -->

          <!-- 身份证有效期 -->
          <!-- <ElFormItem v-if="form.DurationEu === 0" label="有效期"> -->
          <ElFormItem label="法人身份证有效期">
            <ElFormItem prop="Duration" style="margin: 0; width: auto">
              <ElDatePicker
                v-model="form.Duration"
                value-format="YYYY-MM-DD"
                placeholder="开始日期"
                style="width: 100%"
                type="date"
              />
            </ElFormItem>
            <span style="font-size: 14px; margin: 0 20px">至</span>
            <ElFormItem prop="DurationEnd" style="margin: 0; width: auto">
              <ElDatePicker
                v-if="form.DurationEu === 1"
                :disabled="true"
                placeholder="截止日期"
                style="width: 100%"
                type="date"
              />
              <ElDatePicker
                v-else
                v-model="form.DurationEnd"
                value-format="YYYY-MM-DD"
                placeholder="截止日期"
                style="width: 100%"
                type="date"
              />
            </ElFormItem>
            <ElCheckbox
              v-model="form.DurationEu"
              :trueLabel="1"
              :falseLabel="0"
              style="margin-left: 20px"
              label="长期"
              @change="check('DurationEnd')"
            />
          </ElFormItem>

          <!-- <ElFormItem label="身份证上传" prop="ID_Img">
            <UploadID v-model:file="form.ID_Img" :form="form"/>
          </ElFormItem> -->
        </template>

        <div class="label-box">联系人信息</div>

        <!-- 联系人姓名 -->
        <ElFormItem label="联系人姓名" prop="ContactName">
          <ElInput
            v-model="form.ContactName"
            :maxlength="20"
            placeholder="请输入联系人姓名"
            show-word-limit
          />
        </ElFormItem>

        <!-- 联系人邮箱 -->
        <ElFormItem label="联系人邮箱" prop="Email">
          <ElInput v-model="form.Email" placeholder="请输入联系人邮箱" />
        </ElFormItem>

        <!-- 联系人电话 -->
        <ElFormItem label="联系人电话" prop="ContacPhone">
          <ElInput
            v-model="form.ContacPhone"
            :maxlength="11"
            oninput="this.value=this.value.replace(/[^0-9]/g,'')"
            placeholder="请输入联系人电话"
            show-word-limit
          />
        </ElFormItem>

        <!-- 验证码 -->
        <!-- <ElFormItem label="验证码:" prop="ContacValid">
          <ElRow class="ContacValid">
            <ElInput v-model="form.ContacValid" placeholder="请输入验证码" />
            <ElButton
              :disabled="
                time > 0 || !/^1[3456789]\d{9}$/.test(form.ContacPhone)
              "
              style="width: 140px"
              type="primary"
              @click="valid()"
            >
              {{ time > 0 ? `（${time}s）` : "验证码" }}
            </ElButton>
          </ElRow>
        </ElFormItem> -->
      </ElForm>

      <ElRow v-if="!!form" class="button-box">
        <ElButton type="primary" plain @click="$router.go(-1)">取消</ElButton>
        <ElButton type="primary" @click="Review()">提交</ElButton>
      </ElRow>
    </ElRow>
  </ScrollBar>
</template>

<script>
import Overrule from "./_components/Overrule.vue";

import UploadStoreLogo from "./_components/UploadStoreLogo.vue";
import UploadLicence from "./_components/UploadLicence.vue";
import UploadCredentials from "./_components/UploadCredentials.vue";
import UploadPassport from "./_components/UploadPassport.vue";
import UploadID from "./_components/UploadID.vue";

import verify from "@/tool-library/_modules/verify.js";

import logosrc from "@/assets/Logo商家入驻.png";

export default {
  // 自动路由参数
  meta: {
    title: undefined, // 写入浏览器页签
    index: undefined, // 用于排序
    label: undefined, // 显示用的路由名称
    name: undefined, // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(true), // 控制是否需要登录
  },

  // 组件
  components: {
    Overrule,
    UploadStoreLogo,
    UploadLicence,
    UploadCredentials,
    UploadPassport,
    UploadID,
  },

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    logosrc,
    Shop0ptions: [
      "个体工商户/个体店",
      "普通企业店/自营店",
      "厂家直营店/旗飯店",
      "授权专营店/专卖店",
      "多方代理店/综合店",
    ],
    // Shop0ptions: ["个体工商户", "普通企业店", "旗舰店", "专营店", "专卖店"],
    Operation: ["普通商品", "特种商品", "医疗商品"],
    ShopScale: [
      "个体工商户",
      "一般纳税人",
      "政/企事业单位",
      "行业100强企业",
      "中国500强企业",
      "世界500强企业",
    ],

    timeout: Number(0), // 倒计时目标时间
    time: Number(0), // 倒计时

    AddressOptions: undefined,
    form: undefined,

    // 校验
    rules: {
      ShopLogo: [
        { required: true, message: "请上传店铺图标", trigger: "change" },
      ],

      ShopName: [
        { required: true, message: "店铺名称不能为空", trigger: "blur" },
      ],

      ShopType: [
        { required: true, message: "店铺类型不能为空", trigger: "change" },
      ],

      ShopScale: [
        { required: true, message: "店铺规模不能为空", trigger: "change" },
      ],

      Operation: [
        { required: true, message: "主营类目不能为空", trigger: "change" },
      ],

      // 营业执照图片
      Licence: [
        {
          type: "array",
          required: true,
          message: "请上传营业执照",
          trigger: "change",
        },
      ],

      // 公司名称
      CompanyName: [
        { required: true, message: "公司名称不能为空", trigger: "blur" },
      ],

      // 店铺规模
      ShopScale: [
        { required: true, message: "店铺规模不能为空", trigger: "change" },
      ],

      // 统一社会信用代码
      USCC: [
        {
          required: true,
          message: "统一社会信用代码不能为空",
        },
        {
          validator: (_, value, callback) => {
            callback(
              verify.USCC(value)
                ? undefined
                : new Error("请正确填写统一社会信用代码")
            );
          },
        },
      ],

      // 有效日期
      USCCD: [{ required: true, message: "营业期限不能为空", trigger: "blur" }],

      // 有效日期
      USCCD: [],

      // 营业执照所在地ID
      LicenAddress: [
        {
          type: "array",
          required: true,
          message: "营业执照所在地不能为空",
          trigger: "blur",
        },
      ],

      // 详细地址
      Address: [{ required: true, message: "住所不能为空", trigger: "blur" }],

      // 真实姓名
      RealName: [{ required: true, message: "姓名不能为空", trigger: "blur" }],

      // 身份证号
      ID: [
        { required: true, message: "身份证号不能为空", trigger: "blur" },
        {
          validator: (_, value, callback) => {
            if (!/(^\d{15}$)|(^\d{17}([0-9]|X)$)/.test(value)) {
              callback(new Error("请正确填写身份证号"));
            } else {
              callback();
            }
          },
          trigger: "blur",
        },
      ],

      // 护照号码
      Passport: [
        { required: true, message: "护照号不能为空", trigger: "blur" },
      ],

      // 选择身份证有效期，显示个必填符号
      DurationEu: [{ required: true, message: "", trigger: "blur" }],

      // 有效日期
      Duration: [
        { required: true, message: "有效日期不能为空", trigger: "blur" },
      ],

      // 有效日期结束
      DurationEnd: [],

      // 上传身份证图片
      ID_Img: [
        { required: true, message: "身份证不能为空", trigger: "blur" },
        {
          validator: (_, value, callback) => {
            if (!value[0]?.[0]) {
              callback(new Error("身份证正面不能为空"));
            } else if (!value[1]?.[0]) {
              callback(new Error("身份证背面不能为空"));
            } else {
              callback();
            }
          },
          trigger: "blur",
        },
      ],

      // 上传护照图片
      Passport_Img: [
        {
          type: "array",
          required: true,
          message: "护照不能为空",
          trigger: "blur",
        },
      ],

      ContactName: [
        { required: true, message: "联系人姓名不能为空", trigger: "blur" },
      ],

      ContacPhone: [
        { required: true, message: "联系人电话不能为空", trigger: "blur" },
        {
          validator: (_, value, callback) => {
            if (/^1[3456789]\d{9}$/.test(value)) {
              callback();
            } else {
              callback(new Error("请输入11位手机号码"));
            }
          },
          trigger: "blur",
        },
      ],

      ContacValid: [
        { required: true, message: "验证码不能为空", trigger: "blur" },
      ],
    },
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.Api.AddressOptions.GetData().then(($) => (this.AddressOptions = $)); // 获取地址选择器参数
    this.Api.BusinessRegistrationEcho.GetData().then(($) => {
      $.LicenAddress = this.Api.AddressOptions.GetIds($.LicenAddress);
      this.form = $;
    }); // 获取回显表单

    this.rules.ShopName.push({
      validator: (_, value, callback) =>
        this.Api.BusinessRegistrationCheckName.init({
          Name: value,
          Id: this.form.StoreID,
        })
          .GetData()
          .then((_) => callback())
          .catch((msg) => callback(msg)),
      trigger: "blur",
    });

    this.rules.USCCD.push({
      validator: (_, value, callback) => {
        callback(
          (value !== undefined && value !== "") || this.query.USCCX
            ? undefined
            : new Error("营业期限不能为空")
        );
      },
    });

    this.rules.DurationEnd.push({
      validator: (_, value, callback) => {
        callback(
          (value !== undefined && value !== "") || this.query.DurationEu === 1
            ? undefined
            : new Error("身份证截止日期不能为空")
        );
      },
    });
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 验证码
    valid() {
      this.timeout = new Date().getTime() + 120 * 1000;
      this.usetimeout();
      this.Api.BusinessRegistrationVerify.init(this.form.ContacPhone)
        .SetData()
        .catch(($) => {});
    },

    check($) {
      this.$refs.$.validateField($);
    },

    // 使用倒计时
    usetimeout() {
      // 订阅心跳
      this.QUEUE.Valid = (unix) => {
        this.time = Math.floor((this.timeout - unix) / 1000);
        if (this.time <= 0) {
          this.timeout = this.time = 0;
          delete this.QUEUE.Valid; // 销毁订阅
        }
      };
    },

    // 重新申请
    Review() {
      this.$refs.$.validate().then(($) => {
        if ($) {
          var form = JSON.parse(JSON.stringify(this.form)); // 拷贝表单
          form.ID_Img = form.ID_Img.map((item) => item[0]);
          form.LicenAddress = this.Api.AddressOptions.GetExt(form.LicenAddress);
          form.ShopLogo = form.ShopLogo[0];
          form.Licence = form.Licence[0];
          form.Credentials = form.Credentials.join(",");
          form.Passport_Img = form.Passport_Img[0];

          this.Api.BusinessRegistrationReview.init(form)
            .SetData()
            .then((_) => {
              this.$GO({ path: "/menu/business/audit" });
            });
        }
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.page-box {
  // 页面容器
  box-shadow: var(--base-shadow);
  background-color: white;
  flex-direction: column;
  align-items: center;
  border-radius: 4px;
  margin-top: 20px;
  width: 1200px;

  .el-form {
    // 回显表单
    width: 100%;

    .label-box {
      // 标题容器
      background-color: rgba(236, 245, 255, 1);
      margin-bottom: 18px;
      padding-left: 40px;
      line-height: 42px;
      font-weight: bold;
      font-size: 16px;
      width: 100%;
    }

    .el-form-item {
      margin-left: 25%;
      width: 50%;

      .ContacValid {
        flex-direction: row;
        align-items: center;
        flex-wrap: nowrap;
        width: 100%;

        .el-button {
          margin-left: 16px;
        }
      }
    }
  }

  .button-box {
    margin: 12px 0 30px;

    .el-button {
      width: 158px;
    }

    .is-plain {
      --el-button-border-color: var(--el-color-primary);
      --el-button-bg-color: rgb(255, 255, 255);
    }
  }
}
</style>