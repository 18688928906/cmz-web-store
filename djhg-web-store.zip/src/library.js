// import CryptoJS from "crypto-js" // 使用CDN加速

import lib from "@/tool-library/main.js"

// 发布订阅功能
export var _bus = lib.busFunction

// 心跳功能
export var Queue = lib.queue

// 记录当前模式
export var DEV = !!process.env.VUE_APP_DEV

// 发布订阅功能
export var BUS = lib.bus

// 加密库，开发模式下不加密
export var AES = {
    encrypt: ($) => lib.aes.encrypt($, process.env.VUE_APP_GUID), // CryptoJS.AES.encrypt($, process.env.VUE_APP_GUID).toString(), // 加密
    decrypt: ($) => lib.aes.decrypt($, process.env.VUE_APP_GUID), // CryptoJS.AES.decrypt($, process.env.VUE_APP_GUID).toString(CryptoJS.enc.Utf8) // 解密
}

// 注册浏览器数据库
export var DB = undefined // window.indexedDB.open(process.env.VUE_APP_GUID)

// 注册时间列队
export var QUEUE = lib.queue()

// 生成唯一ID
export var GUID = lib.guid

// 获取对象类型
export var TYPE = ($) => Object.prototype.toString.call($)

// 创建图片转文字用画布
var canvas = document.createElement("canvas")

// 文字转换图片
export var TB64 = ($ = {
    text: "测试",
    color: "#000000",
    size: 12,
    align: "left",
    width: 1200
}) => {
    var dpr = window.devicePixelRatio * 2 // 双倍高清
    $.width = Math.round(($.width || 1200) * dpr)
    $.size = Math.round($.size * dpr)

    let context = canvas.getContext("2d") // 获取绘图环境
    context.font = `normal ${$.size}px 宋体` // 粗，字号，字体

    let [t, x, y] = [Array(), 0, 0]  // 生成参数
    $.text.split("").forEach(key => {
        x += context.measureText(key).width // 获取当前字符横向坐标
        if (x > $.width) { x = 0, y++ } // 处理换行
        t[y] = (t[y] || "") + key // 储存字符
    })

    canvas.width = $.width || 1200 // 设置画布宽度
    canvas.height = $.size * t.length // 设置画布高度

    context = canvas.getContext("2d") // 新建画布
    context.fillStyle = "#ffffff" // 设置白色画笔
    context.fillRect(0, 0, canvas.width, canvas.height) // 绘制白色背景，rect为方形

    context.fillStyle = $.color // 设置黑色画笔
    context.textBaseline = "middle";
    context.font = `normal ${$.size}px 宋体` // 粗，字号，字体

    // 处理多行文本
    if (t.length > 1) {
        t.forEach((key, index) => {
            context.fillText(key, 0, canvas.height / t.length * (index + 0.5)) // 添加文字
        })
    }

    // 处理单行文本
    else {
        context.textAlign = $.align // 设置居中
        let width = { left: 0, center: $.width / 2, right: $.width }[$.align]
        context.fillText($.text, width, canvas.height / 2) // 添加文字
    }

    let b64 = canvas.toDataURL("image/jpeg") // 返回Base64
    canvas.height = canvas.width = 0 // 清空画布
    return b64
}

// 隐藏号码
export var HidePhone = lib.hidePhone

// 过期倒计时秒转描述
export var TimeConversion = (Second) => {
    // 创建时间
    var time = [
        ~~(Second / 60 / 60 / 24), // 天
        ~~((Second / 60 / 60) % 24), // 时
        ~~((Second / 60) % 60), // 分
        ~~(Second % 60), // 秒
    ].map(($) => ($ < 10 ? `0${$}` : String($)));

    // 时间格式转换
    time[0] = Second < 86400 ? "" : `${time[0]}天`;
    time[1] = Second < 3600 ? "" : `${time[1]}时`;
    time[2] = Second < 60 ? "" : `${time[2]}分`;
    time[3] = Second < 0 ? "" : `${time[3]}秒`;

    return time.join(""); // 拼接时间
}

// Webpack批量导入组件功能
export var Components = File => {
    var Mod = Object({})
    File?.keys?.()?.forEach($ => Mod[$.replace(".vue", "").split("/").pop()] = File($).default || File($))
    return Mod
}

// 导出成对象
export default Object({ BUS, AES, DB, QUEUE, GUID, DEV, TYPE, TB64, HidePhone, TimeConversion })