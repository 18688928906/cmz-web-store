# 接口参数说明

## 参数翻译表

| 键 | 名称 | 类型 | 默认值 | 所属 | 备注 |
| - | - | - | - | - | - |
| `Limit` | 分页长度 | Number | `10` | List | ~ |
| `OrderCode` | 订单编号 | String | ~ | Any | ~ |
| `OrderId` | 订单ID | Number | ~ | Any | ~ |
| `Page` | 分页页码 | Number | `1` | List | ~ |
| `StoreId` | 店铺ID | Number | ~ | Any | ~ |