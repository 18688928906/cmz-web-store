import cookie from "js-cookie"
import axios from "axios" // 使用CDN加速
import { defineStore } from "pinia"
import library from "@/library.js"
import { GO } from "@/router/index.js";

/**
 * 日志输出方法
 * @param {*} label 显示标题
 * @param {*} fun 日志方法
 */
var log = (label, data) => {
    if (process.env.VUE_APP_DEV) {
        console.group(label)
        console.log(data)
        console.groupEnd()
    }
}

// 导出匿名基础类
export default class {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     * @param {*} timeout 过期时间
     */
    constructor(baseURL, timeout = 30000) {
        this._baseURL = baseURL // 储存默认路径
        this._cookie = cookie // 导入Cookie工具
        this._api = axios.create({ baseURL, timeout }) // 创建Axios实例
        this._store = defineStore // 导入响应式
        this._log = log // 传递日志方法
        this._ID = process.env.VUE_APP_GUID // 获取项目ID
        this._RouterGo = GO // 路由跳转功能
        this._Update = Object({}) // 更新订阅
        this._HaveData = ($) => ($ !== undefined && $ !== null)

        // 批量导入基础库
        Object.keys(library).forEach(key => this[key] = library[key])

        // 请求拦截器
        this._api.interceptors.request.use((config) => {
            config.headers['uuid'] = localStorage.getItem("UUID")
            config.UpTime = new Date().getTime() // 储存发起时间
            var Token = localStorage.getItem(`${this._ID}-TOKEN`) // 从缓存中获取Token
            Token = !!Token ? JSON.parse(this.AES.decrypt(Token)) : window.$TOKEN$ // 解密Token，没有则从缓存中获取

            // 处理掉过期的Token
            if (Token?.expire <= new Date().getTime()) {
                Token = undefined
                localStorage.removeItem(`${this._ID}-TOKEN`)
            }

            // 检查并把Token写进请求头
            if (!!Token && config.UseToken !== false) {
                config.headers["token"] = Token.token
            }

            // 没有TOKEN且需要登录的接口中断请求
            else if (config.haveToken === true) {
                config.cancelToken = new axios.CancelToken($ => $(false))
            }

            return config // 回参
        })

        // 响应拦截器
        this._api.interceptors.response.use((response) => {
            // 检查响应数据
            if (response.data) {
                var { code, msg } = response?.data // 获取错误代码和错误信息
                var label = response?.config?.label || "没有配置API名称" // 获取API名称
                var data = response?.data?.data || response?.data || {}  // 获取响应数据
                data._time = new Date().getTime() - response.config.UpTime  // 记录响应耗时
                data._msg = msg, data._code = code || 200 // 记录错误信息

                // 检查是否有错误代码
                if (process.env.VUE_APP_DEV && data._code !== undefined) {
                    console.group(`%c${label}(${data._code})`, `color:${data._code == 200 ? "green" : "red"}`) // 输出接口名称

                    log("链接:", response.config.url)
                    var params = response.config.data || response.config.params
                    if (params) { log("负载:", params) }
                    if (msg) { log("信息:", msg) }
                    log("数据:", data)

                    console.groupEnd()

                    ElNotification({
                        title: label + "：" + response?.config?.method,
                        message: "耗时：" + data._time,
                        type: { 200: "success", 500: "error" }[data._code] || "warning",
                    })
                }

                response = data // 替换参数
            }

            return response // 回参
        })
    }

    // 更新数据
    _UseUpdate(value, useJson = false) {
        if (useJson) {
            if (this.TYPE(value) === this.TYPE(Object())) {
                value = JSON.parse(JSON.stringify(value))
            } else if (this.TYPE(value) === this.TYPE(Array())) {
                value = JSON.parse(JSON.stringify(value))
            }
        }
        Object.keys(this._Update).forEach(key => this.TYPE(this._Update[key]) === this.TYPE(Function()) && this._Update[key](value))
        return value
    }

    // 增加订阅
    AddUpdate(key, fun) {
        this._Update[key] = fun
        return this
    }

    // 删除订阅
    DelUpdate(key) {
        delete this._Update[key]
        return this
    }
}