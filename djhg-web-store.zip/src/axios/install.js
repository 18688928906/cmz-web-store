import guid from "@/tool-library/_modules/guid.js"
let UUID = localStorage.getItem("UUID") || guid()

// 初始化GUID，防止储存无限堆栈
if (localStorage.getItem("GUID") !== process.env.VUE_APP_GUID) {
    localStorage.clear() // 清空
    localStorage.setItem("GUID", process.env.VUE_APP_GUID) // 记录新的GUID
}

localStorage.setItem("UUID", UUID)

localStorage.setItem("BDT", process.env.VUE_APP_BDT) // 编译的时间

var File = require.context("@/axios/Module", true, /\.js/) // 获取全部模块文件
var Capitalized = $ => $.charAt(0).toUpperCase() + $.slice(1) // 大写方法

// 导出默认
export default Object({
    // 导出安装方法
    install: (vue, baseURL) => {
        vue.config.globalProperties.Api = Object() // 创建储存

        // 处理全部导入的模块
        vue.config.globalProperties.ApiNew = File.keys().map($ => {
            // 直接覆盖参数
            $ = {
                key: $.replace(".", "").replace(".js", "").split("/").map(Capitalized).join(""), // 拼接键名
                component: File($).default || File($) // 实例化组件
            }
            vue.config.globalProperties.Api[$.key] = new $.component(baseURL) // 创建直接调用的模块
            return $ // 回参
        }).reduce((obj, $) => {
            obj[$.key] = (url = baseURL) => new $.component(url) // 转换成对象
            return obj // 回参
        }, Object())
    }

})