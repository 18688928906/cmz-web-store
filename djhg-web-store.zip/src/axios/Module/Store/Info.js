// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
    }

    // 外部初始化
    init($) {
        this._Params.Id = $
        return this

    }

    // 内部初始化
    _init() {
        // 定义参数
        this._Params = [
            "Id", // 店铺ID
        ].reduce((total, key) => (total[key] = undefined, total), Object({}))
        this._Data = undefined // 内部缓存
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams() {
        var Params = {} // 创建覆盖用的变量
        Params.storeId = String(this._Params.Id)
        return Params // 回参
    }

    /**
     * 获取选择
     * @param {*} params // 接口参数
     */
    GetData(params = this._GetParams()) {
        return this._api({
            label: "店铺信息", // 接口标题
            method: "get", // 接口方法
            url: "/store/score/info", // 访问地址
            params, // 地址携参
            data: undefined,// 传递参数
        }).then(data => {
            if (data._code === 200 && !!data.info) {
                var Data = data.info // 创建储存
                try {
                    // 转换数据格式
                    Data = {
                        Id: this._Params.Id, // 店铺ID
                        Logo: Data.logo, // 店铺图标
                        Name: Data.name, // 店铺名称
                    }

                    // 处理评分
                    Data.Score = {
                        Lease: Number(data?.scoreMap?.leaseScore || 0).toFixed(1), // 租赁评分
                        Shop: Number(data?.scoreMap?.shopScore || 0).toFixed(1), // 全新评分
                        Surplus: Number(data?.scoreMap?.surplusScore || 0).toFixed(1), // 二手评分
                    }

                    this._Data = Data // 储存
                    return this._UseUpdate(this._Data) // 回参
                } catch (error) {
                    throw this.DEV ? error : "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) { throw data._msg }
        })
    }
}