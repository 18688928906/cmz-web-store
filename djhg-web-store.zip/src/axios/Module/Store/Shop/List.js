// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
    }

    // 外部初始化
    init($) {
        Object.keys(this._Params).forEach(key => $?.[key] && (this._Params[key] = $?.[key])) // 写入参数
        this._Data = {} // 初始化储存
        return this // 链式调用
    }

    // 内部初始化
    _init() {
        // 定义参数
        this._Params = [
            "Classify", // 分类
            "Id", // 店铺ID
            "Limit", // 每页长度
            "Keyword", // 搜索关键字
            "Page", // 页数
            "Sort", // 排序
        ].reduce((total, key) => (total[key] = undefined, total), Object({}))
        this._Data = undefined // 内部缓存
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams($ = this._Params) {
        var Params = {} // 创建覆盖用的变量
        Params.storeId = Number($.Id)
        Params.page = Number($.Page || 1)
        Params.limit = Number($.Limit || 16)
        Params.keyword = String($.Keyword || "")
        !!$.Classify && (Params.classifyId = $.Classify)
        !!$.Sort && (Params[$.Sort.Key] = $.Sort.Value)
        !Params.sort && (Params.sort = "asc")
        return Params // 回参
    }

    /**
     * 获取数据
     * @param {*} params // 接口参数
     */
    GetData(params = this._GetParams()) {
        return this._api({
            label: "全新列表", // 接口标题
            method: "get", // 接口方法
            url: "/shop/pro/list/new", // 访问地址
            params, // 地址携参
            data: undefined // 传递参数
        }).then(data => {
            if (data._code === 200 && data.page?.list?.length > 0) {
                var Data = data.page // 创建储存
                try {
                    this._Data.List = Data.list.map($ => ({
                        Id: $.id, // 商品ID
                        Price: ($.minPrice || 0).toFixed(2), // 商品价格
                        Name: $.proName || "该商品没有设置名称", // 商品名称
                        Img: $.coverImgurl, // 商品图片
                        Sales: $.saleCount || 0, // 销量
                        Currency: "￥", // 货币种类
                        Wholesale: $.wholesale > 0, // 批发

                        // 店铺信息
                        Store: {
                            name: $.storeName || "该店铺没有名称" // 店铺名称
                        }
                    }))
                    this._Data.Count = Data.totalCount // 总条目数
                    return this._UseUpdate(this._Data) // 回参
                } catch (error) {
                    throw this.DEV ? error : "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) { throw data._msg }
        })
    }

    // 配置筛选
    SetSort(Key, Value) {
        this._Params.Sort = { Value: Value ? "asc" : "desc" } // 初始化筛选
        this._Params.Sort.Key = {
            Sort: "sort", // 默认
            Price: "priceSort", // 价格
            Sales: "salesSort", // 销量
            New: "newSort", // 新品
        }[Key]
        this._Params.Page = 1 // 初始化页码
        return this.GetData()
    }

    // 设置分类
    SetClassify(Id) {
        this._Params.Classify = Id
        this._Params.Page = 1 // 初始化页码
        return this.GetData()
    }

    // 设置页码
    SetPage(Page) {
        this._Params.Page = Page
        return this.GetData()
    }

    // 关键字搜索
    SetKeyword(Input) {
        this._Params.Keyword = Input
        this._Params.Classify = undefined
        this._Params.Page = 1 // 初始化页码
        return this.GetData()
    }
}