import base from "@/axios/base.js";

// 单笔结算
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init($) {
        this.Ids = $?.Ids  // 商品ID
        this.Address = $?.Address // 收件地址
        this.Data = undefined // 缓存数据
        return this // 链式调用
    }

    /**
    * 拼接参数
    */
    _GetParams() {
        var Params = {
            cartIds: this.Ids,
            receivedId: this.Address,
        }
        return Params
    }

    /**
     * 设置选择
     * @param {*} params // 接口参数
     */
    SetData(params = this._GetParams()) {
        return this._api({
            label: "购物车结算", // 接口标题
            method: "get", // 接口方法
            url: "/shop/cart/settlement", // 访问地址
            params, // 地址携参
            data: undefined // 传递参数
        }).then(data => {
            if (data._code === 200 && !!data.settlementVo) {
                var Data = data.settlementVo
                try {
                    this.Data = {
                        Address: Data.addr, // 收货地址
                        Discount: (Data.discountMoney || 0).toFixed(2), // 优惠
                        Freight: (Data.expMoney || 0).toFixed(2), // 运费
                        Price: (Data.totalPrice || 0).toFixed(2), // 总价
                        Pay: (Data.payAmount || 0).toFixed(2), // 实际付款
                        Currency: "￥", // 货币种类
                        Store: Array(0), // 店铺
                    }

                    // 商品抽取转换店铺信息
                    Data.commodityList?.forEach(item => {
                        // 检测不到店铺就创建
                        if (this.Data.Store.findIndex($ => $.Id === item.shopId) < 0) {
                            this.Data.Store.push({
                                Id: item.shopId, // 店铺ID
                                Name: item.shopName || "该店铺没有名称", // 店铺名称
                                List: Array(0) // 清单列表
                            })
                        }

                        // 写入店铺信息
                        this.Data.Store.find($ => $.Id === item.shopId).List.push({
                            Id: item.proId, // 商品ID
                            Img: item.proImg, // 商品图片
                            Name: item.proName, // 商品名称
                            Quantity: item.proNum, // 购买数量
                            Sku: item.skuName, // 规格
                            SkuId: item.skuId, // 规格ID
                            Price: (item.proPrice || 0).toFixed(2), // 单价
                            Discount: (item.discountMoney || 0).toFixed(2), // 优惠
                            Pay: (item.totalPrice || 0).toFixed(2), // 小计
                            Currency: "￥", // 货币种类
                            Remark: "" // 备注
                        })
                    })

                    return this._UseUpdate(this.Data) // 回参
                } catch (error) {
                    throw "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) {
                throw data._msg
            }
        })
    }
}