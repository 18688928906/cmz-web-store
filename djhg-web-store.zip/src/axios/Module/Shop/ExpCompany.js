import base from "@/axios/base.js";

// 商品详情
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init(Code) {
        this.Code = Code || "" // 物流号
        return this
    }

    /**
     * 拼接参数
     */
    _GetParams() {
        var Params = { shipNumber: this.Code }
        return Params
    }

    /**
     * 获取物流公司
     */
    GetData(params = this._GetParams()) {
        return this._api({
            label: "识别物流单号是什么快递公司", // 接口标题
            method: "get", // 接口方法
            url: "/shop/ship/company", // 访问地址
            params, // 地址携参
            data: undefined // 传递参数
        }).then(data => {
            if (data._code === 200) {
                try {
                    return { Name: data.expName, Code: data.com || 0 } // 回参
                } catch (error) {
                    throw this.DEV ? error : "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) {
                throw data._msg
            }
        })

    }
}