import base from "@/axios/base.js";

// 加入购物车
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init($) {
        this.Id = $?.Id || Number(0) // 商品ID
        this.Code = $?.Code || String() // 商品编码
        this.Sku = $?.Sku || Number(0) // 商品规格
        this.Quantity = $?.Count || Number(0) // 购买数量
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams() {
        var Params = {
            proId: this.Id,
            proCode: this.Code,
            skuId: this.Sku,
            qty: this.Quantity,
            type: 10
        }
        return Params
    }

    /**
     * 设置选择
     * @param {*} data // 接口参数
     */
    SetData(data = this._GetParams()) {
        return this._api({
            label: "加入购物车", // 接口标题
            method: "post", // 接口方法
            url: "/add/shopping/cart", // 访问地址
            params: undefined, // 地址携参
            data // 传递参数
        }).then(data => {
            if (data._code === 200) {
                try {
                    return true
                } catch (error) {
                    throw "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) {
                throw data._msg
            }
        })
    }
}