import base from "@/axios/base.js";

// 订单详情
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init(Data) {
        this.Id = Data?.Id || Number(0) // 订单ID
        this.Data = undefined // 清空缓存
        return this
    }

    /**
     * 拼接参数
     */
    _GetParams() {
        var Params = { id: this.Id }
        return Params
    }

    /**
     * 获取列表
     * @param {*} Update // 更新获取
     */
    GetData(Update = false, params = this._GetParams()) {
        // 没有缓存从服务器获取
        if (Update || !this.Data) {
            return this._api({
                label: "获取商城订单详情", // 接口标题
                method: "get", // 接口方法
                url: "/shop/order/info", // 访问地址
                params, // 地址携参
                data: undefined // 传递参数
            }).then(data => {
                if (data._code === 200 && !!data.info) {
                    var Data = data.info // 创建储存
                    try {
                        // 转换数据格式
                        this.Data = {
                            Cancellation: Data.cancellationTypeName, // 取消原因
                            Code: Data.orderCode, // 订单号
                            Comment: Data.commentStatus || 0, // 评论状态
                            CommentId: Data.commentId, // 评论ID
                            Coupon: Number(Data.storeCoupon || 0 || 0).toFixed(2), // 优惠
                            CreateTime: Data.createTime, // 创建时间
                            Id: Data.id, // 订单ID
                            Invoice: Data.invoiceStatus === null || Data.invoiceStatus === undefined, // 是否可以开具发票
                            Money: Number(Data.payMoney || 0).toFixed(2), // 支付金额
                            Payend: Data.payendTime, // 关闭时间
                            TimeOut: 0, // 计时功能
                            PickUp: Data.selfmention === 1, // 是否支持自提 
                            Price: Number(Data.goodsMoney || 0).toFixed(2), // 单价
                            Type: Data.orderType, // 订单类型

                            // 订单状态
                            Status: {
                                Type: Data.orderStatus, // 状态
                                Info: (status) => [
                                    "交易关闭",
                                    "等待支付",
                                    "等待商家发货",
                                    "等待确认收货",
                                    "交易完成",
                                    "等待买家上门取货"
                                ][status], // 状态说明
                            }
                        }

                        // 订单列表
                        this.Data.List = Data.detailList.map(item => ({
                            Currency: "￥", // 货币种类
                            Id: item.id, // 订单ID
                            Img: item.proUrl, // 商品图片
                            Name: item.proName, // 商品名称
                            Price: Number(item.price || 0).toFixed(2), // 单价
                            ProductId: item.proId, // 产品ID
                            Quantity: item.qty || 0, // 商品数量
                            Sku: item.proSkuName?.split(",").map(($, i) => $ + "：" + (item.skuValue?.split(",")?.[i] || "-")) // 拼接规格名称
                        }))

                        // 处理地址参数
                        this.Data.Exp = {
                            Address: Data.orderExpDetail?.addressDetail || Data.detailList?.[0]?.detailAddress || "", // 收件地址
                            Code: Data.orderExpDetail?.expNo || Data.expNo || "-", // 快递单号
                            Company: Data.orderExpDetail?.expName || Data.expName || "-", // 快递公司
                            Id: Data.orderExpDetail?.id || Data.expId, // 物流ID
                            Name: Data.orderExpDetail?.receiver || Data.expName, // 用户姓名
                            Phone: Data.orderExpDetail?.phone || Data.expPhone, // 用户手机
                            Prefix: Data.orderExpDetail?.addrPrefix || Data.detailList?.[0]?.selfAddressName || "", // 地区
                            Price: Number(Data.expMoney || 0).toFixed(2), // 运费
                        }

                        // 拼接详细地址
                        this.Data.Exp.AddressDetail = Data.expAddrDetail || [
                            ...this.Data.Exp.Prefix.split(" "),
                            ...this.Data.Exp.Address.split(" ")
                        ].join(" ")

                        // 处理需要倒计时的状态
                        if (this.Data.Status.Type === 1 || this.Data.Status.Type === 5) {
                            this.Data.TimeOut = ~~(((Data.orderTimeOut || 0) - data._time) / 1000) // 计算过期时间
                            this.Data.TimeOut <= 0 && (this.Data.Status.Type = this.Data.TimeOut = 0) // 超时自动切换成交易关闭
                        } else {
                            this.Data.TimeOut = 0
                        }

                        // 店铺信息
                        this.Data.Store = {
                            Id: Data.mid, // 店铺ID
                            Name: Data.storeName || "没有设置店铺名称" // 店铺名称
                        }

                        return this._UseUpdate(this.Data) // 回参
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) {
                    throw data._msg
                }
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this.Data))) // 回参
        }
    }
}