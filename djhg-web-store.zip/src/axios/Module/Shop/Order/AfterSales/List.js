import base from "@/axios/base.js";

// 全新列表
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init($) {
        this.Page = $?.Page || Number(1) // 页码
        this.Limit = $?.Limit || Number(10) // 每页数量
        this.Keyword = $?.Keyword || String("") // 搜索关键字
        this.Type = $?.Type || undefined // 查询售后类型
        this.Status = $?.Status || undefined // 查询售后状态
        this.Start = $?.start || undefined // 开始时间
        this.End = $?.End || undefined // 结束时间
        this.Max = Boolean(false) // 是否达到获取上限
        this._Data = Object({
            List: Array(0)
        }) // 缓存
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams() {
        var Params = { page: this.Page, limit: this.Limit } // 创建覆盖用的变量
        this.Keyword !== undefined && (Params.keyword = this.Keyword) // 写入关键字
        this.Type !== undefined && (Params.applyType = this.Type) // 写入查询类型
        this.Start !== undefined && (Params.startTime = this.Start) // 写入开始时间
        this.End !== undefined && (Params.endTime = this.End) // 写入结束时间
        this.Status !== undefined && (Params.afterSalesStatus = this.Status) // 查询售后状态
        return Params // 回参
    }

    /**
     * 获取列表
     * @param {*} Update // 更新获取
     */
    GetList(Update = !this.Max, params = this._GetParams()) {
        // 没有缓存从服务器获取
        if (Update || this._Data.length === 0) {
            return this._api({
                label: "获取商品售后列表", // 接口标题
                method: "get", // 接口方法
                url: "/shop/order/refund/list", // 访问地址
                params, // 地址携参
                data: undefined // 传递参数
            }).then(data => {
                this.Max = (data.list?.length || 0) < this.Limit // 数据触底
                if (data._code === 200 && data.list?.length > 0) {
                    var List = data.list // 创建储存
                    try {
                        // 转换数据格式
                        List = List.map($ => {
                            List = {
                                Code: { Order: $.orderCode, Refund: $.refundCode }, // 订单编号和售后编号
                                CreateTime: $.createTime, // 创建时间
                                Currency: "￥", // 货币种类
                                Id: $.id, // 退款记录ID
                                Img: $.proUrl, // 商品图片
                                Name: $.proName || "该商品没有设置名称", // 商品名称
                                Pay: ($.payMoney || 0).toFixed(2), // 支付价格
                                Price: ($.refundMoney || 0).toFixed(2), // 退款
                                Type: $.applyType,
                            }

                            // 订单规格
                            List.Sku = $.proSkuName?.split(",").map((item, index) => {
                                return item + "：" + $.skuValue?.split(",")?.[index] || "数据错误"
                            })?.join("，") || $.skuValue || "数据异常：此商品没有规格"

                            // 订单状态
                            List.Status = {
                                Type: $.afterSalesStatus,
                                Label: (index) => [
                                    "退款关闭",
                                    "商家处理中",
                                    "退款失败",
                                    "退款完成",
                                    "待买家退货",
                                    "待商家收货"
                                ][index] || "状态错误，请联系管理员"
                            }

                            // 店铺信息
                            List.Store = {
                                Id: $.mid, // 店铺ID
                                Name: $.storeName || "缺少店铺信息" // 店铺名称
                            }

                            // 退款方式
                            List.Type = {
                                Value: $.applyType,
                                Label: (index) => [
                                    undefined,
                                    "仅退款",
                                    "退款退货"
                                ][index] || "状态错误，请联系管理员"
                            }

                            return List // 回参
                        })
                        this._Data.List.push(...List) // 缓存数据
                        this.Page++ // 预翻页
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) {
                    throw data._msg
                }
                this._Data.Maps = data.total // 覆盖数量记录
                return this._UseUpdate(this._Data) // 回参
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this._Data))) // 回参
        }
    }

    /**
     * 设置搜索关键字
     * @param {*} Input // 输入信息
     */
    SetKeyword(Input) {
        this.Keyword = String(Input) // 保存关键字
        this.Page = Number(1) // 初始化页码
        this._Data = Object({
            List: Array(0)
        }) // 清空缓存
        this.Max = false
        this.GetList() // 更新列表
        return this // 链式调用
    }

    /**
     * 售后类型
     * @param {*} Input // 输入信息
     */
    SetType(Input) {
        this.Type = Input // 保存关键字
        this.Page = Number(1) // 初始化页码
        this._Data = Object({
            List: Array(0)
        }) // 清空缓存
        this.Max = false
        this.GetList() // 更新列表
        return this // 链式调用
    }

    /**
     * 售后状态
     * @param {*} Input // 输入信息
     */
    SetStatus(Input) {
        this.Status = Input // 保存关键字
        this.Page = Number(1) // 初始化页码
        this._Data = Object({
            List: Array(0)
        }) // 清空缓存
        this.Max = false
        this.GetList() // 更新列表
        return this // 链式调用
    }


    /**
     * 筛选时间
     * @param {*} Start // 开始时间
     * @param {*} End // 结束时间
     */
    SetTime(Start, End) {
        if (!!Start && !!End) {
            this.Start = Start // 保存关键字
            this.End = End // 保存关键字
            this.Page = Number(1) // 初始化页码
            this._Data = Object({
                List: Array(0)
            }) // 清空缓存
            this.Max = false
            // this.GetList() // 更新列表
        }
        return this // 链式调用
    }
}