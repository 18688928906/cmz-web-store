import base from "@/axios/base.js";

// 评价列表
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init($) {
        this.Id = $?.Id || Number(0) // 商品ID
        this.Page = $?.Page || Number(1) // 页码
        this.Limit = $?.Limit || Number(15) // 每页数量
        this.Type = $?.Type || String("all") // 评价类型
        this.Sort = $?.Sort || String("synthetically") // 评价排序
        this.Max = Boolean(false) // 是否达到获取上限
        this.Data = Object({ List: Array(0) }) // 缓存列表
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    GetParams() {
        var Params = { proId: this.Id, page: this.Page, limit: this.Limit, } // 创建覆盖用的变量
        this.Type !== "" && (Params.type = this.Type)
        this.Sort !== "" && (Params.sort = this.Sort)
        return Params
    }

    /**
     * 获取列表
     * @param {*} Update // 更新获取
     */
    GetData(Update = !this.Max, params = this.GetParams()) { // 没有缓存从服务器获取
        if (Update || this.Data.List.length === 0) {
            return this._api({
                label: "获取商品评价列表", // 接口标题
                method: "get", // 接口方法
                url: "/shop/comment/list", // 访问地址
                params, // 地址携参
                data: undefined // 传递参数
            }).then(data => {
                this.Max = (data.data?.length || 0) < this.Limit // 数据触底
                if (data._code === 200 && data.data?.length > 0) {
                    var list = data.data // 创建储存
                    try {
                        this.Data.Avg = data.avg?.toFixed(1) || 0 // 商品评分

                        // 检查并转换标签数组
                        if (!!data.commentLabelNameMap) {
                            this.Data.Tag = Object.keys(data.commentLabelNameMap).map(item => ({
                                Select: false, Label: item, Value: data.commentLabelNameMap[item]
                            }))
                        }

                        // 获取分类页签
                        this.Data.Tabs = [
                            { Label: "全部", Key: "all", Count: data.count?.all },
                            { Label: "图片视频", Key: "imgVideo", Count: data.count?.imgVideo },
                            { Label: "追加", Key: "append", Count: data.count?.append }
                        ]

                        // 转换数据格式
                        list = list.map(item => {
                            var Media = Array(0)

                            // 处理视频
                            if (!!item.vediourl) {
                                Media.push({ Value: item.vediourl, Type: "video" })
                            }

                            // 处理图片部分
                            if (!!item.imgs && item.imgs !== "") {
                                Media.push(...item.imgs.split(",").map($ => ({
                                    Value: $, Type: "img"
                                })))
                            }

                            return {
                                Id: item.id, // 评价ID
                                Avg: item.avg || 0, // 用户评分
                                Time: item.commenttime, // 发布时间
                                Sku: item.skuvalue, // 商品规格
                                Content: item.content || "该用户没有评价", // 评语
                                Media, // 多媒体
                                Like: item.likenum || 0, // 点赞数
                                LikeActive: item.like, // 是否点赞

                                // 用户数据
                                User: {
                                    Id: item.userid, // 用户ID
                                    Name: item.nickname, // 用户名称
                                    Avatar: item.headurl // 用户头像
                                },

                                // 追评
                                Append: item?.appendComment?.map($ => ({
                                    Time: $.commenttime, // 发布时间
                                    Name: $.nickname,
                                    Content: $.content || "评价丢失", // 评语
                                    Imgs: $.imgs?.split(",") || undefined, // 图片
                                }))
                            }
                        })

                        this.Data.List.push(...list) // 缓存列表
                        this.Page++ // 预翻页
                        return this._UseUpdate(this.Data) // 回参
                    } catch (error) {
                        throw error || "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) {
                    throw data._msg
                }
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this.Data))) // 回参
        }
    }

    /**
     * 设置类型
     * @param {*} Input // 输入信息
     */
    SetType(Input) {
        this.Type = String(Input) // 保存类型
        this.Page = Number(1) // 初始化页码
        this.Data = Object({ List: Array(0) })
        this.Max = false
        this.GetData(!this.Max) // 更新列表
        return this // 链式调用
    }

    /**
     * 设置排序
     * @param {*} Input // 输入信息
     */
    SetSort(Input) {
        this.Sort = String(Input) // 保存排序
        this.Page = Number(1) // 初始化页码
        this.Data = Object({ List: Array(0) })
        this.Max = false
        this.GetData(!this.Max) // 更新列表
        return this // 链式调用
    }
}