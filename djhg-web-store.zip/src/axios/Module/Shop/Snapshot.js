import base from "@/axios/base.js";

// 商品详情
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init(Id) {
        this.Id = Id || Number(0) // 商品ID
        this.Data = undefined // 清空缓存
        return this
    }

    /**
     * 拼接参数
     */
    _GetParams() {
        var Params = { orderId: this.Id }
        return Params
    }

    /**
     * 获取列表
     * @param {*} Update // 更新获取
     */
    GetData(Update = false, params = this._GetParams()) {
        // 没有缓存从服务器获取
        if (Update || !this.Data) {
            return this._api({
                label: "交易快照", // 接口标题
                method: "get", // 接口方法
                url: "/shop/pro/info", // 访问地址
                params, // 地址携参
                data: undefined // 传递参数
            }).then(data => {
                if (data._code === 200 && !!data.data) {
                    var Data = data.data // 创建储存
                    Data.productSpecificList = data.specificAttr
                    try {
                        // 转换数据格式
                        this.Data = {
                            Code: Data.orderCode, // 订单编码
                            Currency: "￥", // 货币种类
                            Id: this.Id, // 订单ID
                            Imgs: Data.detailurls?.split(","), // 拆分详情图
                            Name: Data.proName, // 商品名称
                            Parameters: Array(0), // 存放商品参数
                            PickUp: Data.selfmention === 1, // 是否是自提
                            Price: (Data.price || 0).toFixed(2), // 商品价格
                            ProId: Data.proId, // 商品ID
                            Quantity: Data.qty, // 购买数量

                            // 封面
                            Cover: {
                                Video: !!Data.proVideo && Data.proVideo !== "" ? Data.proVideo.split(",") : [], // 视频
                                Imgs: !!Data.proUrl && Data.proUrl !== "" ? Data.proUrl.split(",") : [], // 处理图片
                                List: Array(0) // 队列化
                            },

                            // 快递
                            Express: {
                                FeesExplain: (Data.expMoney || 0).toFixed(2) + "元" // 费用说明
                            },

                            // 服务
                            Serve: Data.servicesList.map((item, index) => ({
                                Label: item.attrName, // 服务说明
                                Value: item.id // 服务值
                            })),

                            // 处理批发
                            Wholesale: {
                                Type: Data.wholesale === 1, // 是否是批发模式
                                Min: Data.wholesaleNum || 0, // 启批数量
                                Max: undefined // 购买上限
                            },
                        }

                        // 整合队列
                        this.Data.Cover.List = [
                            ...this.Data.Cover.Video.map(item => ({
                                src: item, type: "video"
                            })),
                            ...this.Data.Cover.Imgs.map(item => ({
                                src: item, type: "img"
                            }))
                        ]

                        // 处理规格规格
                        if (!!Data.proSkuName && Data.proSkuName !== "") {
                            this.Data.Sku = Object() // 创建储存
                            Data.proSkuName.split(",").forEach((item, index) => {
                                this.Data.Sku[item] = Data.skuValue?.split(",")[index] || "不明规格"
                            })
                        }

                        // 检查商品参数是否正常
                        if (!!Data.productSpecificList && Data.productSpecificList.length > 0) {
                            Data.productSpecificList
                                .sort((a, b) => a.sort - b.sort) // 进行一次排序
                                .forEach((item) => {
                                    // 检查是否存在父类
                                    var index = this.Data.Parameters.findIndex(($) => $.Group == item.attrGroup);

                                    // 不存在父类进行创建
                                    if (index < 0) {
                                        this.Data.Parameters.push({
                                            Group: item.attrGroup,
                                            List: [{ Label: item.attrName, Value: item.attrValue }]
                                        });
                                    }

                                    // 存在父类进行归类
                                    else {
                                        this.Data.Parameters[index].List.push({
                                            Label: item.attrName,
                                            Value: item.attrValue
                                        });
                                    }
                                });
                        }

                        // 新版本覆盖用详情图
                        if (!!Data.details && Data.details.length > 0) {
                            this.Data.Imgs = Data.details.map(item => {
                                // 直接返回图片链接
                                if (item.type === 1) { return item.url }

                                // 文字转换成图片返回
                                else if (item.type === 2) {
                                    return this.TB64({
                                        text: item.url,
                                        color: item.color,
                                        size: item.fontSize,
                                        align: item.textAlign,
                                        width: 900
                                    })
                                }
                            })
                        }

                        return this._UseUpdate(this.Data) // 回参
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) {
                    throw data._msg
                }
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this.Data))) // 回参
        }
    }
}