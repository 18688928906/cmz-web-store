import base from "@/axios/base.js";

// 创建订单
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init($) {
        this.Title = $?.Title // 标题
        this.Content = $?.Content // 简介
        this.Img = $?.Img // 上传图片
        this.Type = $?.Type // 类型
        this.Goods = $?.Goods // 货物
        this.AddressId = $?.AddressId // 省市区
        this.Address = $?.Address // 详细地址
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams() {
        // 创建覆盖用的变量
        var Params = {
            title: String(this.Title),
            content: String(this.Content),
            imgs: String(this.Img),
            donationtype: this.Goods,
            hopetype: String(this.Type),
            address: String(this.AddressId),
            detailedaddress: String(this.Address),
        }
        return Params // 回参
    }

    /**
     * 设置选择
     * @param {*} params // 接口参数
     */
    SetData(params = this._GetParams()) {
        return this._api({
            label: "发布捐助需求", // 接口标题
            method: "post", // 接口方法
            url: "/demand/release/donate", // 访问地址
            params: undefined, // 地址携参
            data: params,// 传递参数
        }).then(data => {
            if (data._code === 200) {
                try {
                    return this._UseUpdate(true) // 回参
                } catch (error) {
                    throw "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) {
                ElMessage.error(data._msg)
                throw data._msg
            }
        })
    }
}