// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._info()
    }

    // 外部初始化
    init() {
        return this._info()
    }

    // 内部初始化
    _info() {
        // 定义参数
        this._Params = {
            Limit: 20, // 长度
            Page: 1, // 页码
            Type: 0, // 类型：0.租赁，1.二手，2.招工，3.场地，4.捐赠，5.助农
        }
        this.Max = Boolean(false) // 是否达到获取上限
        this._Data = undefined // 内部缓存
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams($ = this._Params) {
        var Params = {} // 创建覆盖用的变量
        Params.page = $.Page
        Params.limit = $.Limit
        Params.type = $.Type
        return Params // 回参
    }

    /**
     * 获取数据
     * @param {*} Update // 更新获取
     * @param {*} params // 接口参数
     */
    GetData(Update = !this.Max, params = this._GetParams()) {
        // 没有缓存从服务器获取
        if (Update || !this._Data) {
            return this._api({
                haveToken: true, // 必须携带Token
                label: "个人中心需求列表",  // 接口标题
                method: "get", // 接口方法 
                url: "/user/demand/list", // 访问地址
                params, // 地址携参
                data: undefined // 传递参数
            }).then(data => {
                if (data._code === 200 && data.data?.length > 0) {
                    var Data = data.data // 创建储存
                    try {
                        // 转换数据格式
                        this._Data = Data.map(item => {
                            // 覆盖减少占用
                            Data = {
                                Content: item.content, // 内容
                                Id: item.id, // 需求号
                                Label: item.title, // 标题
                                Time: item.createtime, // 创建时间
                                Type: ["租赁", "二手", "招工", "场地", "捐赠", "助农"][params.type]
                            }

                            // 用户信息
                            Data.User = {
                                Avatar: item.headimg, // 头像
                                Name: item.customerName, // 用户名称
                            }

                            return Data // 回参
                        })

                        return this._UseUpdate(this._Data) // 回参
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) { throw data._msg }
            }).catch(error => error.message !== false && console.log(error))
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this._Data))) // 回参
        }
    }

    /**
     * 设置类型
     * @param {*} Type 类型：0.租赁，1.二手，2.招工，3.场地，4.捐赠，5.助农
     */
    SetType(Type) {
        this._info()
        this._Params.Type = Type
        return this.GetData()
    }
}