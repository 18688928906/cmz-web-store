import base from "@/axios/base.js";

// 创建订单
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init($) {
        this.Posts = $?.Posts // 职位
        this.Type = $?.Type // 职位类型
        this.Quantity = $?.Quantity // 招聘人数
        this.Welfare = $?.Welfare // 福利
        this.Max = $?.Max // 最大薪资
        this.Min = $?.Min // 最低薪资
        this.Degree = $?.Degree // 学历
        this.Content = $?.Content // 简介
        this.Img = $?.Img // 上传图片
        this.AddressId = $?.AddressId // 省市区
        this.Address = $?.Address // 详细地址
        this.Experience = $?.Experience // 工作经验
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams() {
        // 创建覆盖用的变量
        var Params = {
            title: String(this.Posts),
            type: String(this.type),
            number: Number(this.Quantity),
            minsalary: Number(this.Min),
            maxsalary: Number(this.Max),
            other: this.Welfare === "" ? null : String(this.Welfare),
            experience: this.Experience === "" ? null : String(this.Experience),
            address: String(this.AddressId),
            detailedaddress: String(this.Address),
            education: this.Degree === "" ? null : String(this.Degree),
            content: String(this.Content),
            imgs: String(this.Img)
        }
        return Params // 回参
    }

    /**
     * 设置选择
     * @param {*} params // 接口参数
     */
    SetData(params = this._GetParams()) {
        return this._api({
            label: "发布招工需求", // 接口标题
            method: "post", // 接口方法
            url: "/demand/release/job", // 访问地址
            params: undefined, // 地址携参
            data: params,// 传递参数
        }).then(data => {
            if (data._code === 200) {
                try {
                    return this._UseUpdate(true) // 回参
                } catch (error) {
                    throw "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) {
                ElMessage.error(data._msg)
                throw data._msg
            }
        })
    }
}