import base from "@/axios/base.js";

// 创建订单
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init($) {
        this.Brand = $?.Brand // 品牌
        this.Category = $?.Category // 发布类型
        this.Content = $?.Content // 简介
        this.Exp = $?.Exp // 物流方式
        this.Img = $?.Img // 上传图片
        this.Originally = $?.Originally // 原价
        this.Price = $?.Price // jiage
        this.Quality = $?.Quality // 成色
        this.Title = $?.Title // 标题
        this.Video = $?.Video // 上传视频
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams() {
        // 创建覆盖用的变量
        var Params = {
            oneClassifyId: Number(this.Category[0]),
            twoClassifyId: Number(this.Category[1]),
            classifyId: Number(this.Category[2]),
            description: String(this.Content),
            proVideo: String(this.Video),
            salePrice: Number(this.Price),
            proExpType: Number(this.Exp),
            proName: String(this.Title),
            coverImgUrlList: String(this.Img),
            brand: String(this.Brand),
            degreeId: String(this.Quality),
        }
        return Params // 回参
    }

    /**
     * 设置选择
     * @param {*} params // 接口参数
     */
    SetData(params = this._GetParams()) {
        return this._api({
            label: "二手发布", // 接口标题
            method: "post", // 接口方法
            url: "/surplus/pro/save", // 访问地址
            params: undefined, // 地址携参
            data: params,// 传递参数
        }).then(data => {
            if (data._code === 200) {
                try {
                    return this._UseUpdate(true) // 回参
                } catch (error) {
                    throw "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) {
                ElMessage.error(data._msg)
                throw data._msg
            }
        })
    }
}