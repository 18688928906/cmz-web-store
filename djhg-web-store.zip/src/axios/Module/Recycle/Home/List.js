import base from "@/axios/base.js";

// 首页回收列表
export default class extends base {
    /**
    * 构造函数
    * @param {*} baseURL 默认路径
    */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.List = Array(0)
    }

    /**
     * 获取列表
     * @param {*} Update // 更新获取
     */
    GetList() {
        return this._api({
            label: "获取首页回收列表", // 接口标题
            method: "get", // 接口方法
            url: "/recycle/classify/list/index", // 访问地址
            params: undefined, // 地址携参
            data: undefined // 传递参数
        }).then(data => {
            if (data._code === 200 && data.list?.length > 0) {
                var List = data.list // 创建储存
                try {
                    // 转换数据格式
                    this.List = List.map($ => ({
                        Id: $.catId, // 商品ID
                        Price: $.money, // 商品价格
                        Name: $.name, // 商品名称
                        Img: $.icon, // 商品图片
                    }))
                    return this._UseUpdate(this.List) // 回参
                } catch (error) {
                    throw "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) {
                throw data._msg
            }
        })
    }
}