import base from "@/axios/base.js";

// 导出具名类，建议和文件名相同
export default class RecycleList extends base {
    /**
    * 构造函数
    * @param {*} baseURL 默认路径
    */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init($) {
        this.Page = $?.Page || Number(1) // 页码
        this.Limit = $?.Limit || Number(16) // 每页数量
        this.Keyword = $?.Keyword || String("") // 搜索关键字
        this.ClassifyId = $?.ClassifyId || Number(-1) // 所属分类ID
        this.Max = Boolean(false) // 是否达到获取上限
        this.List = Array(0) // 缓存
        return this
    }

    /**
     * 拼接参数
     */
    _GetParams() {
        var Params = { page: this.Page, limit: this.Limit } // 创建覆盖用的变量
        this.Keyword !== "" && (Params.keyword = this.Keyword)
        this.ClassifyId >= 0 && (Params.classifyId = this.ClassifyId)
        return Params
    }

    /**
     * 获取列表
     * @param {*} Update // 更新获取
     */
    GetList(Update = !this.Max, params = this._GetParams()) {
        // 没有缓存从服务器获取
        if (Update || this.List.length === 0) {
            return this._api({
                label: "获取回收列表", // 接口标题
                method: "get", // 接口方法
                url: "", // 访问地址
                params, // 地址携参
                data: undefined // 传递参数
            }).then(data => {
                if (data._code === 200) {
                    try {
                        // 如果接口回参没有长度说明数据触底了
                        if (data?.page?.list?.length > 0) {
                            this.List.push(
                                ...data.page.list.map($ => ({
                                    Id: $.id, // 商品ID
                                    Price: $.minPrice, // 商品价格
                                    Name: $.proName, // 商品名称
                                    Img: $.coverImgurl, // 商品图片
                                    Sales: $.saleCount, // 销量

                                    // 店铺信息
                                    Store: {
                                        name: $.storeName // 店铺名称
                                    }
                                }))
                            )
                            this.Page++
                            return this.List
                        } else {
                            this.Max = true // 数据触底
                        }
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) {
                    throw data._msg
                }
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this.List))) // 回参
        }
    }

    /**
     * 设置搜索关键字
     * @param {*} Input // 输入信息
     */
    SetKeyword(Input) {
        this.Keyword = String(Input) // 保存关键字
        this.Page = Number(1) // 初始化页码
        this.List = Array(0) // 清空缓存
        this.GetList(true) // 更新列表
    }

    /**
     * 所属分类ID
     * @param {*} Input // 输入信息
     */
    SetClassifyId(Input) {
        this.ClassifyId = String(Input) // 保存关键字
        this.Page = Number(1) // 初始化页码
        this.List = Array(0) // 清空缓存
        this.GetList(true) // 更新列表
    }
}