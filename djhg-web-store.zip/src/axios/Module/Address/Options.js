import base from "@/axios/base.js";

export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._key = `${this._ID}-ADDRESS-OPTIONS` // 创建识别键
        this._info().GetData()
    }

    // 外部初始化
    init() {
        return this._init()
    }

    // 内部初始化
    _info() {
        var Data = localStorage.getItem(this._key) // 获取本地储存
        this._Data = !!Data ? JSON.parse(this.AES.decrypt(Data)) : undefined // 内部缓存
        return this // 链式调用
    }

    /**
     * 获取数据
     * @param {*} Update 更新获取
     */
    GetData(Update = false) {
        // 没有缓存从服务器获取
        if (Update || !this._Data) {
            return this._api({
                label: "获取省、市、区、街道", // 接口标题
                method: "get", // 接口方法
                url: "/basics/address", // 访问地址
                params: undefined, // 地址携参
                data: undefined // 传递参数
            }).then(data => {
                if (data._code === 200 && data.addrList?.length > 0) {
                    var Data = data.addrList // 创建储存
                    try {
                        this._Data = Data = this._Streamline(Data || []) // 简化并储存
                        Data = this.AES.encrypt(JSON.stringify(Data)) // 加密数据
                        localStorage.setItem(this._key, Data) // 本地储存
                        return this._UseUpdate(this._Data, true) // 回参
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) { throw data._msg }
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this._Data, true))) // 回参
        }
    }

    /**
     * 拼接省市区
     * @param {*} Ids 地址ID数组
     */
    GetExt(Ids = Array(0)) {
        var List = [...this._Data]
        return Ids.map(item => {
            item = List.find($ => $.value === item)
            item.children?.length > 0 && (List = [...item.children])
            return item.label // 回参
        }).join(",") // 拼接地区
    }

    /**
     * 省市区转回编码
     * @param {*} Ids 地址ID数组
     */
    GetIds(Ext = Array(0)) {
        var List = [...this._Data]
        return Ext.map(item => {
            item = List.find($ => $.label === item)
            item.children?.length > 0 && (List = [...item.children])
            return Number(item.value) // 回参
        }) // 拼接地区
    }

    /**
     * 地址抽取省市区
     * @param {String} Address 地址
     */
    Change(Address, List = [...this._Data]) {
        let Item = List.find(item => {
            let re = new RegExp(`${item.label}`, "g");
            return re.test(Address)
        })
        let Res = []
        !!Item && Res.push({ label: Item.label, value: Item.value })
        !!Item?.children && Res.push(...this.Change(Address, Item.children))
        return Res
    }

    /**
     * 递归简化地址参数
     * @param {*} List 地址列表
     */
    _Streamline(List) {
        // 重新排序并简化处理
        return List.sort((a, b) => {
            var number = a.sort - b.sort
            return number !== NaN ? number : 0
        }).map($ => {
            var data = { label: String($.name), value: Number($.id) }  // 抽取必要参数
            $.children?.length > 0 && (data.children = this._Streamline($.children))  // 递归处理子项
            return data // 回参
        })
    }
}