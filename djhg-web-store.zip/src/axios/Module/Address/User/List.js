// 导入类
import base from "@/axios/Module/User/Address/List.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
    }

    /**
     * 新建地址
     * @param {*} data 新增数据表单
     */
    AddAddress(data) {
        // 参数格式转换
        data = {
            id: data?.Id && Number(data.Id), // 要修改的地址ID
            name: String(data.Name), // 收件人姓名
            phone: String(data.Phone), // 收件电话
            proId: Number(data.AddressId[0]), // 省级ID
            cityId: Number(data.AddressId[1]), // 市级ID
            areaId: Number(data.AddressId[2]), // 区级ID
            streetId: Number(data.AddressId[3]), // 街级ID
            address: String(data.Address), // 详细地址
            def: data.Default ? 1 : 0, // 判断默认地址
            nameExt: String(data.Ext) // 拼接省市区
        }

        return this._api({
            label: "新建地址",  // 接口标题
            method: "post", // 接口方法 
            url: "/customer/received/addr/edit", // 访问地址
            params: undefined, // 地址携参
            data // 传递参数
        }).then(_ => this._init().GetData(true))
    }

    /**
     * 删除地址
     * @param {*} id 删除地址的ID
     */
    DelAddress(id) {
        return this._api({
            label: "删除地址",  // 接口标题
            method: "delete", // 接口方法 
            url: "/customer/received/addr/delete", // 访问地址
            params: { id }, // 地址携参
            data: undefined,
        }).then(_ => this._init().GetData(true))
    }

    /**
     * 默认地址
     * @param {*} id 默认地址的ID
     */
    DefAddress(id) {
        return this._api({
            label: "默认地址",  // 接口标题
            method: "put", // 接口方法 
            url: "/customer/received/addr/default", // 访问地址
            params: { id }, // 地址携参
            data: undefined,
        }).then(_ => this._init().GetData(true))
    }
}