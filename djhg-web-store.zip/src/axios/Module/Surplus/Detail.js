import base from "@/axios/base.js";

// 商品详情
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init(Id) {
        this.Id = Number(Id || 0) // 商品ID
        this._Data = undefined // 清空缓存
        return this
    }

    /**
     * 拼接参数
     */
    _GetParams() {
        var Params = { proId: this.Id }
        return Params
    }

    /**
     * 获取列表
     * @param {*} Update // 更新获取
     */
    GetData(Update = false, params = this._GetParams()) {
        // 没有缓存从服务器获取
        if (Update || !this._Data) {
            return this._api({
                label: "获取二手详情", // 接口标题
                method: "get", // 接口方法
                url: "/surplus/pro/info", // 访问地址
                params, // 地址携参
                data: undefined // 传递参数
            }).then(data => {
                if (data._code === 200 && !!data.surplusPcInfo) {
                    var Data = data.surplusPcInfo // 创建储存
                    try {
                        // 转换数据格式
                        this._Data = {
                            Code: Data.proCode, // 商品编码
                            Currency: "￥", // 货币种类
                            Id: this.Id, // 商品ID
                            Name: Data.proName, // 商品名称
                            Price: (Data.minPrice || 0).toFixed(2), // 商品价格
                            Sale: 0, // 销量
                            SkuId: undefined, // 存放选中的项
                            Quantity: 1, // 购买数量
                            Parameters: Array(0), // 存放商品参数
                            Imgs: Data.detailurls?.split(","), // 拆分详情图
                            Collection: Data.isCollect === 1, // 是否收藏
                            PickUp: Data.selfmention === 1, // 是否支持自提

                            // 封面
                            Cover: {
                                Video: !!Data.proVideo && Data.proVideo !== "" ? Data.proVideo.split(",") : [], // 视频
                                Imgs: !!Data.coverImgurl && Data.coverImgurl !== "" ? Data.coverImgurl.split(",") : [], // 处理图片
                                List: Array(0) // 队列化
                            },

                            // 快递
                            Express: {
                                FeesExplain: Data.freName, // 费用说明
                                Address: [
                                    Data.freightVO?.provinceId || 3630, // 省
                                    Data.freightVO?.cityId || 3631 // 市
                                ],
                                Price: (Data.freightVO?.freight || 0).toFixed(2), // 运费
                            },

                            // 服务
                            Serve: Data.interestName?.map((item) => ({
                                Label: item, // 服务说明
                                Value: item // 服务值
                            })),

                            // 店铺信息
                            Store: {
                                Id: Data.mid, // 店铺ID
                                Name: Data.storeName, // 店铺名称
                                Logo: Data.storeLogo, // 店铺图标
                                Collection: Data.isFollow === 1, // 是否收藏
                            },

                            // 处理批发
                            Wholesale: {
                                Type: Data.wholesale === 1, // 是否是批发模式
                                Min: Data.wholesale === 1 ? Data.wholesaleNum : 1, // 启批数量
                                Inventory: 0, // 库存处理
                                Max: 0 // 购买上限
                            }
                        }

                        // 整合队列
                        this._Data.Cover.List = [
                            ...this._Data.Cover.Video.map(item => ({
                                src: item, type: "video"
                            })),
                            ...this._Data.Cover.Imgs.map(item => ({
                                src: item, type: "img"
                            }))
                        ]

                        // 检查规格参数是否正常
                        if (Data?.skuInfoList?.length > 0 && !!Data.skuName && Data.skuName !== "") {
                            // 处理规格信息
                            this._Data.Sku = {
                                // 规格对照表
                                IdKeys: Data.skuInfoList.map($ => {
                                    $ = {
                                        Id: $.skuId, // 获取规格ID
                                        Price: $.price.toFixed(2), // 规格价格
                                        Sale: $.saleCount, // 销量
                                        Value: $.skuName.split(","), // 拆分规格对照参数
                                        Key: $.skuName.split(",").map(_$ => encodeURI(_$)),  // 使用编码解析成Key
                                        Inventory: $.qty, // 库存上限
                                        Img: $.viewUrl // 规格图片
                                    }
                                    this._Data.Sale += $.Sale
                                    this._Data.Wholesale.Max += ($.Inventory || 0) // 累计全部库存
                                    return $
                                }),

                                // 规格列表
                                List: Data.skuName.split(",").map($ => ({
                                    Select: undefined, // 存放选中
                                    Label: $,// 规格类型标题
                                    Value: Array(0)
                                }))
                            }

                            // 写入规格对应的选项
                            this._Data.Sku.List.forEach((item, index) => {
                                var array = this._Data.Sku.IdKeys.map($ => $.Value[index])
                                item.Value = [...new Set(array)]
                                item.Value = item.Value.map($ => ({
                                    Disabled: false, // 禁止选择
                                    Text: $, // 显示用文字
                                    Key: encodeURI($) // 键值
                                }))
                            });
                        }

                        // 单规格模式
                        else if (Data.skuInfoList?.length > 0) {
                            var sku = Data.skuInfoList[0]
                            this._Data.SkuId = sku.skuId // 单规格ID
                            this._Data.Wholesale.Max = sku.qty // 配置库存上限
                        }

                        // 检查商品参数是否正常
                        if (!!Data.productSpecificList && Data.productSpecificList.length > 0) {
                            // 处理参数
                            var list = Data.productSpecificList
                            list.sort((a, b) => a.sort - b.sort) // 进行一次排序
                            list.forEach((item) => {
                                // 检查是否存在父类
                                var index = this._Data.Parameters.findIndex(($) => $.Group == item.attrGroup);

                                // 不存在父类进行创建
                                if (index < 0) {
                                    this._Data.Parameters.push({
                                        Group: item.attrGroup,
                                        List: [{
                                            Label: item.attrName,
                                            Value: item.attrValue
                                        }],
                                    });
                                }

                                // 存在父类进行归类
                                else {
                                    this._Data.Parameters[index].List.push({
                                        Label: item.attrName,
                                        Value: item.attrValue
                                    });
                                }
                            });
                        }

                        // 新版本覆盖用详情图
                        if (!!Data.details && Data.details.length > 0) {
                            this._Data.Imgs = Data.details.map(item => {
                                // 直接返回图片链接
                                if (item.type === 1) { return item.url }

                                // 文字转换成图片返回
                                else if (item.type === 2) {
                                    return this.TB64({
                                        text: item.url,
                                        color: item.color,
                                        size: item.fontSize,
                                        align: item.textAlign,
                                        width: 900
                                    })
                                }
                            })
                        }

                        // 解除批发
                        if (this._Data.Wholesale.Max < this._Data.Wholesale.Min) {
                            this._Data.Wholesale.Min = 1
                            this._Data.Wholesale.Type = false
                        }

                        return this._UseUpdate(this._Data) // 回参
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) {
                    throw data._msg
                }
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this._Data))) // 回参
        }
    }
}