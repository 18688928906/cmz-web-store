import base from "@/axios/base.js";

// 导出具名类，建议和文件名相同
export default class SurplusList extends base {
    /**
    * 构造函数
    * @param {*} baseURL 默认路径
    */
    constructor(baseURL) {
        super(baseURL) // 继承父级
    }

    // 初始化
    init($) {
        this.Id = Number($.Id) // 页码
        this.Page = 1
        this.Limit = 6
        this.Max = false
        this.List = Array()
        return this
    }

    /**
     * 拼接参数
     */
    _GetParams() {
        // 创建覆盖用的变量
        var Params = { page: this.Page, limit: this.Limit }
        Params.proId = this.Id
        return Params
    }

    /**
     * 获取列表
     * @param {*} Update // 更新获取
     */
    GetList(Update = !this.Max, params = this._GetParams()) {
        // 没有缓存从服务器获取
        if (Update || this.List.length === 0) {
            return this._api({
                label: "获取二手详情相关推荐",  // 接口标题
                method: "get", // 接口方法
                url: "/surplus/pro/similar/recommend", // 访问地址
                params, // 地址携参
                data: undefined // 传递参数
            }).then(data => {
                // this.Max = (data.page?.list?.length || 0) < this.Limit // 数据触底
                if (data._code === 200 && data?.list?.length > 0) {
                    try {
                        let Data = data.list.map($ => ({
                            Id: $.id, // 商品ID
                            Logo: $.coverImgurl, // 商品图标
                            Name: $.proName, // 商品名称
                            Price: ($.minPrice || 0).toFixed(2), // 商品价格
                        }))
                        return this._UseUpdate(Data)
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) {
                    throw data._msg
                }
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this.List))) // 回参
        }
    }
}