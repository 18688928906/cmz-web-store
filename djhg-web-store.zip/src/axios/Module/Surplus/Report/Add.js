import base from "@/axios/base.js";

// 添加收藏
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init($) {
        this.Id = $?.Id || Number(0) // 商品ID
        this.Type = $?.Type || 0
        this.Img = $?.Img
        this.Content = $?.Content
        return this // 链式调用
    }

    /**
     * 设置选择
     * @param {*} Status // 更新获取
     */
    SetData(Status = true) {
        return this._api({
            label: "举报商品", // 接口标题
            method: "post", // 接口方法
            url: "/report/product", // 访问地址
            params: undefined,
            data: {
                proid: this.Id, // 收藏的商品ID
                type: this.Type,
                content: this.Content,
                imgs: this.Imgs,
                protype: 2, // 商品类型定值
            }, // 地址携参 // 传递参数
        }).then(data => {
            if (data._code === 200) {
                try {
                    return Status // 返回输入的值
                } catch (error) {
                    throw "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) {
                throw data._msg
            }
        })
    }
}