// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
    }

    // 外部初始化
    init() {
        return this._init()
    }

    // 内部初始化
    _init() {
        this._Data = undefined // 内部缓存
        return this // 链式调用
    }

    /**
    * 拼接参数
    */
    _GetParams() {
        // 创建覆盖用的变量
        var Params = {
            type: Number(1),
            position: Number(0),
        }
        return Params // 回参
    }

    /**
     * 获取数据
     * @param {*} Update // 更新获取
     * @param {*} params // 接口参数
     */
    GetList(Update = false, params = this._GetParams()) {
        // 没有缓存从服务器获取
        if (Update || !this._Data) {
            return this._api({
                label: "轮播图", // 接口标题
                method: "get", // 接口方法
                url: "/banner/list", // 访问地址
                params,  // 地址携参
                data: undefined // 传递参数
            }).then(data => {
                if (data._code === 200 && data.list?.length > 0) {
                    var Data = data.list.sort((a, b) => { a.sort - b.sort }) // 根据参数重新排序
                    try {
                        this._Data = Data = Data.map($ => ({ Img: $.icon, Link: $.eventId })) // 缓存图片链接
                        return this._UseUpdate(this._Data) // 回参
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) { throw data._msg }
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this._Data))) // 回参
        }
    }
}