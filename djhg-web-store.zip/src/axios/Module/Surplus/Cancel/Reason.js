import base from "@/axios/base.js";

// 全新列表
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init() {
        this._Data = undefined // 订单ID
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams() {
        var Params = { type: 0 } // 创建覆盖用的变量
        return Params // 回参
    }

    /**
     * 获取数据
     * @param {*} Update // 更新获取
     */
    GetData(Update = false, params = this._GetParams()) {
        // 没有缓存从服务器获取
        if (Update || (this._Data?.length || 0) === 0) {
            return this._api({
                label: "订单取消原因", // 接口标题
                method: "get", // 接口方法
                url: "/surplus/Cancellation/paid/list", // 访问地址
                params, // 地址携参
                data: undefined // 传递参数
            }).then(data => {
                if (data?.length > 0) {
                    var Data = data // 创建储存
                    try {
                        this._Data = Data.map($ => ({
                            Label: $.reasons,
                            Value: $.id
                        }))
                        return this._UseUpdate(this._Data) // 回参
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) {
                    throw data._msg
                }
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this._Data))) // 回参
        }
    }
}