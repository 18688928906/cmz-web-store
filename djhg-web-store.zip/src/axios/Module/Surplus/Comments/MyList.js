// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
    }

    // 外部初始化
    init($) {
        this._init()
        Object.keys(this._Params).forEach(key => $?.[key] && (this._Params[key] = $?.[key])) // 写入参数
        return this
    }

    // 内部初始化
    _init() {
        // 定义参数
        this._Params = [
            "Page", // 页码
            "Limit", // 每页数量
        ].reduce((total, key) => (total[key] = undefined, total), Object({}))
        this._Params.Page = 1 // 默认页码
        this._Params.Limit = 10 // 默认数量
        this._Data = Array(0) // 内部缓存
        this._Max = Boolean(false) // 是否达到获取上限
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams($ = this._Params) {
        var Params = {} // 创建覆盖用的变量
        Params.page = Number($.Page)
        Params.limit = Number($.Limit)
        return Params // 回参
    }

    /**
     * 获取列表
     * @param {*} Update // 更新获取
     */
    GetData(Update = !this._Max, params = this._GetParams()) {
        // 没有缓存从服务器获取
        if (Update || !this._Data) {
            return this._api({
                label: "个人中心评价列表",  // 接口标题
                method: "get", // 接口方法
                url: "/surplus/comment/myComment", // 访问地址
                params, // 地址携参
                data: undefined // 传递参数
            }).then(data => {
                this._Max = (data?.list?.length || 0) < params.limit // 数据触底
                if (data._code === 200 && data?.list?.length > 0) {
                    var Data = data.list // 创建储存
                    try {
                        Data = Data.map($ => {
                            // 直接调用现有内存
                            Data = {
                                // 订单信息
                                Order: {
                                    Code: $.orderInfo?.orderCode, // 编号
                                    Id: $.orderInfo?.orderId, // Id
                                    Sku: $.orderInfo?.skuName
                                },
                                Num: $.replyNum, // 评论数量
                                Time: $.commentTime,
                                Like: $.likeNum
                            }

                            // 商品信息
                            !!$.orderInfo && (Data.Product = {
                                Id: $.orderInfo.proId, // 商品Id
                                Logo: $.orderInfo.viewUrl?.split(",")?.[0], // 商品图片
                                Name: $.orderInfo.proName || "商品名称缺失", // 商品名称
                                Sku: $.orderInfo.skuName, // 规格
                            })

                            Data.Reply = $.reply?.map(item => ({
                                Content: item.content,
                                Name: item.nickname,
                                Like: item.likenum,
                                Time: item.commenttime
                            }))

                            // 评论信息
                            Data.Comment = {
                                Content: $.content, // 评论内容
                                Id: $.commentId, // 评价Id
                                Img: $.imgs?.split(","), // 图片
                                IsLike: $.like, // 自己点赞
                                Like: $.likeNum, // 点赞数
                                Reply: $.replyNum, // 回复数
                                Score: $.score, // 评分
                                Time: $.commentTime, // 评论时间
                                Video: $.video?.split(","), // 视频
                            }

                            // 追评
                            !!$.appendComment && (Data.Append = $.appendComment.map(item => ({
                                Content: item.content, // 追评内容
                                Id: item.id, // 商品Id
                                Img: item.imgs?.split(","), // 图片
                                Time: item.commenttime, // 追评时间
                                Name: item.nickname, // 回复名称
                                Apart: this._Apart(item.commenttime, $.commentTime) // 相距天数
                            })))

                            console.log(Data.Append);

                            // 记录商家回复
                            !!Data.Append && (Data.Merchants = Data.Append.find(item => {
                                return item.Name === "商家回复"
                            }))

                            return Data
                        })
                        this._Data.push(...Data)
                        this._Data.Total = data.total // 记录总数
                        this._Params.Page++ // 预翻页
                        return this._UseUpdate(this._Data) // 回参
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) {
                    throw data._msg
                }
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this.List))) // 回参
        }
    }

    /**
     * 计算相差天数
     * @param {*} New 新发布
     * @param {*} Old 创建
     */
    _Apart(New, Old) {
        New = new Date(New).getTime()
        Old = new Date(Old).getTime()
        return ~~((New - Old) / 1000 / 60 / 60 / 24)
    }
}