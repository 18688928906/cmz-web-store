// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
    }

    // 外部初始化
    init($) {
        this._Data = undefined // 内部缓存
        this._Max = false // 是否达到获取上限
        Object.keys(this._Params).forEach(key => $?.[key] && (this._Params[key] = $?.[key])) // 写入参数
        this._Params.Page = Number(this._Params.Page || 1)
        this._Params.Limit = Number(this._Params.Limit || 15)
        return this
    }

    // 内部初始化
    _init() {
        // 定义参数
        this._Params = [
            "Name", // 店铺名称
            "Sort", // 排序
            "Page", // 当前页
            "Limit", // 页面长度
        ].reduce((total, key) => (total[key] = undefined, total), Object({}))
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams($ = this._Params) {
        var Params = {} // 创建覆盖用的变量
        Params.page = Number($.Page) // 页码
        Params.limit = Number($.Limit || 15) // 每页长度
        this._HaveData($.Name) && (Params.storeName = String($.Name)) // 店铺名称
        Params.sort = String($.Sort || "0") // 排序方式：0、综合，1、销量
        return Params // 回参
    }

    /**
     * 设置选择
     * @param {*} Update // 更新获取
     * @param {*} params // 接口参数
     */
    GetData(Update = !this._Max, params = this._GetParams()) {
        // 没有缓存从服务器获取
        if (Update || !this._Data) {
            return this._api({
                label: "店铺搜索", // 接口标题
                method: "get", // 接口方法
                url: "/es/product/search/shop", // 访问地址
                params, // 地址携参
                data: undefined,// 传递参数
            }).then(data => {
                this._Max = (data.list?.length || 0) < params.limit // 数据触底
                if (data._code === 200 && !!data.list) {
                    var List = data.list // 参数映射
                    !this._Data && (this._Data = Object({})) // 数据空缺初始化
                    try {
                        // 数据格式转换
                        List = List.map($ => ({
                            Logo: $.logo, // 店铺图标
                            Name: $.storeName, // 店铺名称
                            StoreId: $.storeId, // 店铺ID

                            // 商品
                            Product: $.productList?.map(item => ({
                                Id: item.id,
                                Img: item.coverImgurl,
                                Price: (item.minPrice).toFixed(2),
                            }))
                        }))

                        this._Data.List = List

                        this._Params.Page++
                        return this._UseUpdate(this._Data)
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) {
                    ElMessage.error(data._msg)
                    throw data._msg
                }
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this._Data))) // 回参
        }
    }
}