// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
    }

    // 外部初始化
    init($) {
        this._Data = undefined // 内部缓存
        this._Max = false // 是否达到获取上限
        Object.keys(this._Params).forEach(key => $?.[key] && (this._Params[key] = $?.[key])) // 写入参数
        this._Params.Page = Number(this._Params.Page || 0)
        this._Params.Limit = Number(this._Params.Limit || 15)
        return this
    }

    // 内部初始化
    _init() {
        // 定义参数
        this._Params = [
            "Page", // 页码
            "Limit", // 每页长度
            "Keyword", // 搜索关键字
            "Classify", // 三级分类Id
            "Delivery", // 发货地，市级Id
            "FreeShipping", // 包邮省级Id
            "Pickup", // 自提：0.否，1.是
            "Sort", // 排序：1.新到旧，2.销量降序，3.价格升序，4.价格降序
            "Serve", // 服务项
            "Min", // 最低价
            "Max", // 最高价
            "Specific", // 特有属性
        ].reduce((total, key) => (total[key] = undefined, total), Object({}))
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams($ = this._Params) {
        var Params = {} // 创建覆盖用的变量
        Params.page = Number($.Page) // 页码
        Params.limit = String($.Limit || 15) // 每页长度
        this._HaveData($.Keyword) && (Params.keyword = String($.Keyword)) // 搜索关键字
        this._HaveData($.Classify) && (Params.classifyId = Number($.Classify)) // 三级分类Id
        this._HaveData($.Delivery) && (Params.deliveryPlaceId = String($.Delivery)) // 发货地，市级Id
        this._HaveData($.FreeShipping) && (Params.freeRegion = String($.FreeShipping)) // 包邮省级Id
        this._HaveData($.Pickup) && (Params.selfmention = Number($.Pickup))// 自提：0.否，1.是
        this._HaveData($.Sort) && (Params.sort = String($.Sort))// 排序：1.新到旧，2.销量降序，3.价格升序，4.价格降序
        this._HaveData($.Serve) && (Params.interest = String($.Serve))
        this._HaveData($.Min) && (Params.minPrice = Number($.Min))// 最低价
        this._HaveData($.Max) && (Params.maxPrice = Number($.Max)) // 最高价
        this._HaveData($.Specific) && (Params.attrValue = String($.Specific))// 最高价
        return Params // 回参
    }

    /**
     * 设置选择
     * @param {*} Update // 更新获取
     * @param {*} params // 接口参数
     */
    GetData(Update = !this._Max, params = this._GetParams()) {
        // 没有缓存从服务器获取
        if (Update || !this._Data) {
            return this._api({
                label: "综合搜索", // 接口标题
                method: "get", // 接口方法
                url: "/es/product/search/complex", // 访问地址
                params, // 地址携参
                data: undefined,// 传递参数
            }).then(data => {
                this._Max = (data.data?.length || 0) < params.limit // 数据触底
                if (data._code === 200 && !!data) {
                    var List = data.data // 参数映射
                    !this._Data && (this._Data = Object({})) // 数据空缺初始化
                    try {
                        // 数据格式转换
                        List = List.map($ => ({
                            Currency: "￥",
                            Id: $.id, // 商品ID
                            Price: $.minPrice, // 商品价格
                            Name: $.proName, // 商品名称
                            Img: $.coverImgurl.split(",").shift(), // 商品图片
                            Sales: $.saleCount, // 销量

                            // 店铺信息
                            Store: {
                                Name: $.shopName // 店铺名称
                            }
                        }))

                        // 处理数据列表
                        this._Data.List ? this._Data.List.push(...List) : this._Data.List = List

                        // 处理服务项
                        this._Data.Serve = data.servicesList.map($ => ({
                            Id: $.id, // 服务选项ID
                            Name: $.attrName, // 服务名称
                            Check: false // 选中状态
                        }))

                        // 合并商品特有属性
                        this._Data.Specific = data.specificList.reduce((list, item) => {
                            list.push(...item.children.map($ => ({
                                Id: $.id, // 属性ID
                                Name: $.attrName, // 属性名称
                                List: $.attrValue !== "" ? $.attrValue.split(",") : Array(), // 属性列表
                            })))
                            return list
                        }, Array(0))
                        this._Params.Page++
                        return this._UseUpdate(this._Data)
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) {
                    ElMessage.error(data._msg)
                    throw data._msg
                }
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this._Data))) // 回参
        }
    }

    // 设置关键字
    SetKeyword(Keyword) {
        var Limit = this._Params.Limit // 提取
        this._init().init({ Keyword }) // 使用初始化方法
        this._Params.Limit = Limit // 回写
        return this.GetData()
    }

    // 设置特有属性
    SetSpecific(Specific) {
        var Limit = this._Params.Limit // 提取
        this._init().init({ Specific }) // 使用初始化方法
        this._Params.Limit = Limit // 回写
        this._Params.Keyword = undefined // 清除关键字
        return this.GetData()
    }

    // 设置服务
    SetServe(Serve) {
        this._Params.Serve = Serve
        this._Params.Keyword = undefined // 清除关键字
        this._Params.Page = 0
        this._Data = undefined
        this._Max = false
        return this.GetData()
    }

    // 设置排序
    SetSort(Sort) {
        this._Params.Sort = Sort
        this._Params.Page = 0
        this._Data = undefined
        this._Max = false
        return this.GetData()
    }

    // 设置价格区间
    SetRange(Min, Max) {
        this._Params.Min = Min
        this._Params.Max = Max
        this._Params.Page = 0
        this._Data = undefined
        this._Max = false
        return this.GetData()
    }

    // 设置包邮省
    SetFreeShipping(Id) {
        this._Params.FreeShipping = Id
        this._Params.Page = 0
        this._Data = undefined
        this._Max = false
        return this.GetData()
    }

    // 设置发货城市
    SetDelivery(Id) {
        this._Params.Delivery = Id
        this._Params.Page = 0
        this._Data = undefined
        this._Max = false
        return this.GetData()
    }

    // 设置三级分类
    SetClassify(Classify) {
        var Limit = this._Params.Limit // 提取
        this._init().init({ Classify }) // 使用初始化方法
        this._Params.Limit = Limit // 回写
        this._Params.Keyword = undefined // 清除关键字
        return this.GetData()
    }
}