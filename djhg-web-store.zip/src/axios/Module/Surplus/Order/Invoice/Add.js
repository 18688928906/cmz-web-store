// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
    }

    // 外部初始化
    init($) {
        Object.keys(this._Params).forEach(key => $?.[key] && (this._Params[key] = $?.[key])) // 写入参数
        return this
    }

    // 内部初始化
    _init() {
        // 定义参数
        this._Params = [
            "Account", // 注册地址
            "Address", // 银行账号
            "Bank", // 开户银行
            "Code", // 订单编号
            "Email", // 邮箱地址
            "Header", // 发票抬头
            "Phone", // 注册电话
            "TaxId", // 税号
            "Type", // 抬头类型：0.个人，1.企业
            "Html", // 携带超文本（邮件内容）
        ].reduce((total, key) => (total[key] = undefined, total), Object({}))
        this._Data = undefined // 内部缓存
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams($ = this._Params) {
        // 创建覆盖用的变量
        var Params = {}
        Params.invoiceType = Number(1) // 发票类型，固定值
        Params.invoiceTitle = Number($.Type) // 抬头类型
        Params.invoiceContent = String($.Header) // 发票抬头
        Params.email = String($.Email)
        $.Type === 1 && !!$.TaxId && (Params.invoiceTaxNo = String($.TaxId)) // 公司税号
        $.Type === 1 && !!$.Address && (Params.vatCompanyAddress = String($.Address)) // 注册地址
        $.Type === 1 && !!$.Phone && (Params.vatTelphone = String($.Phone)) // 注册地址
        $.Type === 1 && !!$.Bank && (Params.vatBankName = String($.Bank)) // 开户银行
        $.Type === 1 && !!$.Account && (Params.vatBankAccount = String($.Account)) // 银行账户
        Params.orderCode = $.Code // 订单
        Params.userType = Number(0)
        Params.html = encodeURIComponent($.Html)
        return Params // 回参
    }

    /**
     * 设置选择
     * @param {*} data // 接口参数
     */
    SetData(params = this._GetParams()) {
        return this._api({
            label: "订单开票", // 接口标题
            method: "post", // 接口方法
            url: "/surplus/invoice/add", // 访问地址
            params: undefined, // 地址携参
            data: params,// 传递参数
        }).then(data => {
            if (data._code === 200) {
                try {
                    ElMessage({
                        message: "订单开票成功",
                        showClose: true,
                        grouping: true,
                        type: "success",
                    })
                    return this._UseUpdate(true) // 回参
                } catch (error) {
                    throw this.DEV ? error : "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) {
                ElMessage({
                    message: data._msg,
                    showClose: true,
                    grouping: true,
                    type: "error",
                })
            }
        })
    }
}