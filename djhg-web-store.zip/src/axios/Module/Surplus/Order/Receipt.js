import base from "@/axios/base.js";

// 确认收货
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
    }

    /**
     * 设置选择
     * @param {*} orderId // 接口参数
     */
    SetData(orderId = String()) {
        return this._api({
            label: "确认收货", // 接口标题
            method: "put", // 接口方法
            url: "/surplus/order/receive", // 访问地址
            params: { orderId }, // 地址携参
            data: undefined,// 传递参数
        }).then(data => {
            if (data._code === 200) {
                return this._UseUpdate(true) // 回参
            } else if (data._code !== 200) {
                throw data._msg
            }
        }).catch((error) => {
            error = error?.response?.data?.message || error
            ElMessage.error(error)
            throw error
        })
    }
}