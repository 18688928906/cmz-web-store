import base from "@/axios/base.js";

// 商品详情
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init($) {
        this.Id = Number($?.Id || 0) // 退款Id
        this.Code = $?.Code || "" // 快递号
        this.Company = $?.Company || "" // 快递公司
        this.CompanyCode = $?.CompanyCode || "" // 快递公司编号
        this.Remark = $?.Remark || "" // 留言
        this.Img = $?.Img || "" // 上传的图片
        return this
    }

    /**
     * 拼接参数
     */
    _GetParams() {
        var Params = {
            refundId: this.Id,
            shipNumber: this.Code,
            shipCompany: this.Company,
            shipCode: this.CompanyCode,
            shipRemark: this.Remark,
            shipImgs: this.Img
        }
        return Params
    }

    /**
     * 获取物流公司
     */
    SetData(params = this._GetParams()) {
        return this._api({
            label: "填写运单号", // 接口标题
            method: "post", // 接口方法
            url: "/surplus/order/ship/number", // 访问地址
            params: undefined, // 地址携参
            data: params // 传递参数
        }).then(data => {
            if (data._code === 200) {
                try {
                    return true
                } catch (error) {
                    throw this.DEV ? error : "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) {
                throw data._msg
            }
        }).catch($ => {
            ElMessage.error($)
        })

    }
}