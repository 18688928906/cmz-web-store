import base from "@/axios/base.js";

// 订单详情
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init(Data) {
        this.Id = Data?.Id || Number(0) // 售后ID
        this._Data = undefined // 清空缓存
        return this
    }

    /**
     * 拼接参数
     */
    _GetParams() {
        var Params = { refundId: this.Id }
        return Params
    }

    /**
     * 获取列表
     * @param {*} Update // 更新获取
     */
    GetData(Update = false, params = this._GetParams()) {
        // 没有缓存从服务器获取
        if (Update || !this._Data) {
            return this._api({
                label: "获取二手售后详情", // 接口标题
                method: "get", // 接口方法
                url: "/surplus/order/refund/info", // 访问地址
                params, // 地址携参
                data: undefined // 传递参数
            }).then(data => {
                if (data._code === 200 && !!data.info) {
                    var Data = data.info // 创建储存
                    try {
                        this._Data = {
                            Code: Data.refundCode, // 售后编号
                            Id: Data.id, // 售后ID
                            Money: Number(Data.refundMoney || 0).toFixed(2), // 退款金额
                            Reason: Data.refundReason, // 申请原因
                            Reject: Number(Data.rejection) || 0, // 商家签收状态：0.签收，1.拒收
                            Remark: Data.refundRemark, // 售后备注
                            OrderCode: Data.orderCode, // 订单编号
                            OrderId: Data.orderId, // 订单ID
                            CloseType: Data.afterSalesCloseType, // 订单关闭状态
                            Type: Data.applyType, // 售后类型：1.仅退款，2.退货退款
                            Revise: Data.modifyApplicationAgain === true, // 是否可以修改申请
                        }

                        // 处理倒计时
                        if (Data.refundTimeOut > 1000) {
                            this._Data.TimeOut = ~~(((Data.refundTimeOut || 0) - data._time) / 1000) // 计算过期时间
                            this._Data.TimeOut <= 0 && (this.Data.TimeOut = 0)
                        }

                        // 操作记录
                        this._Data.Logs = Data.refundClient?.map($ => ({
                            Avatar: $.headurl, // 头像
                            Content: $.content, // 说明
                            Img: $.voucherImg && $.voucherImg !== "" ? $.voucherImg?.split(",") : undefined, // 详情图
                            Name: $.name, // 昵称
                            Time: $.createTime || "时间数据缺失" // 时间
                        }))

                        // 商品
                        this._Data.Product = Data.detailList.map(item => ({
                            Currency: "￥",
                            Name: item.proName,
                            Price: item.price,
                            Sku: item.proSkuName?.split(",").map(($, i) => $ + "：" + (item.skuValue?.split(",")?.[i] || "-")), // 拼接规格名称
                        }))

                        // 售后状态
                        this._Data.Status = {
                            Type: Data.afterSalesStatus, // 售后状态
                            Label: (type) => !!type || type === 0 ? ({
                                0: "退款关闭",
                                1: "商家处理中",
                                3: "退款完成",
                                4: "待买家发货",
                                5: "待商家收货"
                            }[type]) : `参数错误：afterSalesStatus = ${type}`,
                            Title: (type) => !!type || type === 0 ? ({
                                0: "退款关闭", // { 1: "退款取消", 4: "商家拒收" }[Data.afterSalesCloseType] || "退款关闭",
                                1: "等待商家处理",
                                3: "退款成功",
                                4: "商家已同意您的退货退款申请，请在规定时间内填写运单号",
                                5: "等待商家确认收货"
                            }[type]) : `参数错误：afterSalesStatus = ${type}`,
                            Tips: (type) => !!type || type === 0 ? ({
                                0: {
                                    1: "您已撤销了退款申请，可在售后申请时限内重新提交退款申请",
                                    2: "商家拒绝了您的退款申请，可在售后申请时限内重新提交退款申请",
                                    3: "您未在指定时间内退回商品，系统已自动关闭您本次的售后申请",
                                    4: "商家拒绝收货，请联系商家进行协商，寄回商品/平台介入",
                                    5: "您已撤销了退款申请，可在售后申请时限内重新提交退款申请",
                                }[Data.afterSalesCloseType] || "售后已关闭，可在售后申请时限内重新提交退款申请",
                                1: this._Data.TimeOut,
                                3: "退款时间：" + Data.agreedTime,
                                4: this._Data.TimeOut,
                                5: this._Data.TimeOut
                            }[type]) : `参数错误：afterSalesStatus = ${type}`,
                        }

                        // 处理时间
                        this._Data.Time = {
                            Create: Data.createTime, // 申请时间
                            Deal: Data.tradeTime // 成交时间
                        }

                        return this._UseUpdate(this._Data) // 回参
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) {
                    throw data._msg
                }
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this._Data))) // 回参
        }
    }
}