import base from "@/axios/base.js";

// 全新列表
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init($) {
        this.Id = String($?.Id || 0) // 页码
        this.Tag = $?.Tag || null // 选中的评价标签
        this.Content = String($?.Content) // 评价内容
        this.Img = $?.Img || null // 上传图片
        this.Video = $?.Video || null // 上传视频
        this.Avg = Number($?.Avg || 0) // 综合评分
        this.Quality = Number($?.Quality || 0) // 商品品质
        this.Service = Number($?.Service || 0) // 服务态度
        this.Logistics = Number($?.Logistics || 0) // 快递物流
        this._Data = Array(0)
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams() {
        // 创建覆盖用的变量
        var Params = {
            avg: this.Avg,
            orderid: this.Id,
            labelids: this.Tag,
            content: this.Content,
            imgs: this.Img,
            vediourl: this.Video,
            quality: this.Quality,
            service: this.Service,
            logistics: this.Logistics
        }
        return Params // 回参
    }

    /**
     * 
     */
    SetData(params = this._GetParams()) {
        return this._api({
            label: "评价保存", // 接口标题
            method: "post", // 接口方法
            url: "/surplus/comment/save", // 访问地址
            params: undefined, // 地址携参
            data: params // 传递参数
        }).then(data => {
            if (data._code === 200) {
                try {

                } catch (error) {
                    throw this.DEV ? error : "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) {
                ElMessage({
                    message: data._msg,
                    showClose: true,
                    grouping: true,
                    type: "error",
                })
                throw data._msg
            }
            return this._UseUpdate(this._Data) // 回参
        })
    }
}