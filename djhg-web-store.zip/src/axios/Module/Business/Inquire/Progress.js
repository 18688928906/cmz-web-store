// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
    }

    // 外部初始化
    init($) {
        Object.keys(this._Params).forEach(key => $?.[key] && (this._Params[key] = $?.[key])) // 写入参数
        return this
    }

    // 内部初始化
    _init() {
        // 定义参数
        this._Params = [
        ].reduce((total, key) => (total[key] = undefined, total), Object({}))
        this._Data = undefined // 内部缓存
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams() {
        var Params = {} // 创建覆盖用的变量
        Params = undefined
        return Params // 回参
    }

    /**
     * 获取数据
     * @param {*} params // 接口参数
     */
    GetData(params = this._GetParams()) {
        return this._api({
            label: "店铺入驻进度查询", // 接口标题
            method: "get", // 接口方法
            url: "/store/settle/in/process", // 访问地址
            params: undefined, // 地址携参
            data: undefined,// 传递参数
        }).then(data => {
            if (data._code === 200) {
                try {
                    this._Data = {
                        Msg: data.data?.reasons, // 状态信息
                        Type: data.info, // 审核状态
                    }
                    return this._UseUpdate(this._Data) // 回参
                } catch (error) {
                    throw this.DEV ? error : "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) {
                throw data._msg
            }
        })
    }
}