// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
    }

    // 外部初始化
    init($) {
        this._init()
        Object.keys(this._Params).forEach(key => (this._Params[key] = $?.[key])) // 写入参数
        return this
    }

    // 内部初始化
    _init() {
        // 定义参数
        this._Params = [
            "Img", // 兑换信息用的图片
            "Flag", // 正反面：0.国徽，1.人像
        ].reduce((total, key) => (total[key] = undefined, total), Object({}))
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams($ = this._Params) {
        var Params = {} // 创建覆盖用的变量
        Params.imgUrl = $.Img
        Params.flag = $.Flag
        return Params // 回参
    }

    /**
     * 获取列表
     * @param {*} Update // 更新获取
     */
    GetData(params = this._GetParams()) {
        return this._api({
            label: "身份证信息查询",  // 接口标题
            method: "get", // 接口方法
            url: "/store/idCardInfo", // 访问地址
            params, // 地址携参
            data: undefined // 传递参数
        }).then(res => {
            if (res._code === 200 && !!res?.info && res?.info?.advancedInfo === "{}") {
                let data = res.info // 创建储存
                let $data = Object()
                try {
                    !!data.name && ($data.RealName = data.name)
                    !!data.idNum && ($data.ID = data.idNum)
                    if (!!data.validDate) {
                        data.validDate = data.validDate.split("-")
                        $data.Duration = new Date(data.validDate[0].replace(/\./g, "-"))
                        !!data.validDate[1] && data.validDate[1] !== "长期" && ($data.DurationEnd = new Date(data.validDate[1].replace(/\./g, "-")))
                        $data.DurationEu = !!$data.DurationEnd ? 0 : 1
                    }
                    return this._UseUpdate($data) // 回参
                } catch (error) {
                    throw this.DEV ? error : "数据异常，请稍后重试"
                }
            } else if (res._code === 200 && !!res?.info?.advancedInfo) {
                throw res?.info?.advancedInfo
            } else if (res._code !== 200) {
                throw res._msg
            }
        }).catch((error) => {
            error = error?.response?.data?.message || error
            ElMessage.error(error)
            throw error
        })
    }
}