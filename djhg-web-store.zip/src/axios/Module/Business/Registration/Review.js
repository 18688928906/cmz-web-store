import base from "@/axios/base.js";

// 创建订单
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
    }

    // 初始化
    init($) {
        Object.keys(this._Params).forEach(key => this._Params[key] = $[key]) // 写入参数
        return this // 链式调用
    }

    // 内部初始化
    _init() {
        // 定义参数
        this._Params = {
            StoreID: undefined,

            Mobile: "", // 手机号
            Code: "", // 验证码
            Name: "", // 用户名
            Password: "", // 密码
            PasswordV: "", // 校验密码

            ShopLogo: Array(0), // 店铺图标
            ShopName: "", // 店铺名称
            ShopType: undefined, // 店铺类型
            Operation: undefined, // 主营类目
            Introduce: "", // 店铺简介

            Licence: Array(0), // 营业执照
            CompanyName: "", // 公司名称
            ShopScale: 0, // 店铺规模
            USCC: "", // 统一社会信用代码
            USCCS: undefined, // 统一社会信用代码有效期，开始
            USCCD: undefined, // 统一社会信用代码有效期，结束
            LicenAddress: Array(0), // 营业执照所在地
            Address: "", // 住所
            Credentials: Array(0), // 资历
            CardType: 0, // 证件类型

            RealName: "", // 身份证姓名 or 护照姓名
            ID: "", // 身份证号
            Passport: "", // 护照号
            DurationEu: 0, // 身份证有效期控制
            Duration: undefined, // 身份证有效期
            DurationEnd: undefined, // 身份证有效期到期
            ID_Img: Array(0), // 存放身份证照片
            Passport_Img: Array(0), // 护照图片

            ContactName: "", // 联系人姓名
            Email: "", // 联系人邮箱
            ContacPhone: "", // 联系人电话
            ContacValid: "", // 验证码
        }
        this._Data = undefined // 内部缓存
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    GetParams($ = this._Params) {
        // 创建覆盖用的变量
        var Params = {}

        Params.id = $.StoreID

        Params.mobile = String($.Mobile) // 商家手机号
        // Params.merchantAccount = $.Name // 后台账号
        // Params.merchantPassword = Params.confirmpwd = $.Password // 登录密码和确认密码

        Params.logo = $.ShopLogo // 店铺logo
        Params.name = $.ShopName // 店铺名称
        Params.type = Number($.ShopType) // 店铺类型
        Params.category = Number($.Operation) // 主营类目
        Params.description = $.Introduce // 店铺简介

        Params.certificate = $.Licence // 营业执照
        Params.applyName = $.CompanyName // 公司名称
        Params.scale = $.ShopScale // 店铺规模
        Params.creditCode = $.USCC // 统一社会信用代码
        Params.creditCodeDate = $.USCCS
        Params.creditCodeEndDate = $.USCCD
        Params.licenAddress = $.LicenAddress // 营业执照所在地
        Params.residence = $.Address // 住所
        Params.qualifications = $.Credentials // 资质信息
        Params.cardType = Number($.CardType) // 证件类型

        Params.idName = $.RealName // 证件姓名

        // 检查证件类型
        // if ($.CardType > 0) {
        //     Params.passport = $.Passport_Img // 护照图片
        //     Params.idCode = $.Passport // 护照号
        // } else {
        Params.idCode = $.ID // 身份证号
        Params.idDate = $.Duration // 身份证日期
        Params.idEndDate = $.DurationEu > 0 ? "2099-12-31 00:00:00" : $.DurationEnd // 身份证到期
        Params.idCodeUrlFront = $.ID_Img[0] // 身份证正面图片
        Params.idCodeUrlAfter = $.ID_Img[1] // 身份证反面图片
        // }

        Params.user = $.ContactName // 联系人姓名
        Params.email = $.Email // 邮箱
        Params.phone = $.ContacPhone // 联系人电话
        // Params.validCode = $.ContacValid // 验证码
        // Params.phoneValidCode = $.Code // 商家注册的手机号码验证码
        // Params.validCode = $.Code  // 验证码

        return Params // 回参
    }

    /**
     * 设置选择
     * @param {*} params // 接口参数
     */
    SetData(params = this.GetParams()) {
        return this._api({
            label: "门店入驻重新申请", // 接口标题
            method: "post", // 接口方法
            url: "/store/update/register", // 访问地址
            params: undefined, // 地址携参
            data: params,// 传递参数
        }).then(data => {
            if (data._code === 200) {
                try {
                    return this._UseUpdate(true) // 回参
                } catch (error) {
                    throw "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) {
                ElMessage.error(data._msg)
                throw data._msg
            }
        })
    }
}