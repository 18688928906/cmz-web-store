// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
    }

    // 外部初始化
    init($) {
        Object.keys(this._Params).forEach(key => $?.[key] && (this._Params[key] = $?.[key])) // 写入参数
        return this
    }

    // 内部初始化
    _init() {
        // 定义参数
        this._Params = [
            "Name", // 店铺名称
            "Id", // 重新申请店铺ID
        ].reduce((total, key) => (total[key] = undefined, total), Object({}))
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams($ = this._Params) {
        var Params = {} // 创建覆盖用的变量
        Params.name = $.Name // 校验用的名称
        Params.isSkip = !!$.Id // 如果从新申请要判断当前的店铺可以重名
        !!$.Id && (Params.id = Number($.Id))
        return Params // 回参
    }

    /**
     * 获取数据
     * @param {*} params // 接口参数
     */
    GetData(params = this._GetParams()) {
        return this._api({
            label: "判断店铺名称是否被注册", // 接口标题
            method: "get", // 接口方法
            url: "/store/duplicate/field", // 访问地址
            params, // 地址携参
            data: undefined,// 传递参数
        }).then(data => {
            if (data._code === 200) {
                try {
                    return this._UseUpdate(true) // 回参
                } catch (error) {
                    throw this.DEV ? error : "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) {
                throw data._msg
            }
        }).catch((error) => {
            var error = error?.response?.data?.message || error
            ElMessage.error(error)
            throw error
        })
    }
}