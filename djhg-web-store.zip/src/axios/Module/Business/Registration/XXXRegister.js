// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
    }

    // 初始化
    init($) {
        Object.keys(this._Params).forEach(key => $?.[key] && (this._Params[key] = $?.[key])) // 写入参数
        return this
    }

    // 内部初始化
    _init() {
        // 定义参数
        this._Params = [
            "Code", // 验证码
            "ContactName", // 联系人姓名
            "ContacPhone", // 联系人电话
            "Email", // 联系人邮箱
            "Introduce", // 店铺简介
            "Name", // 用户昵称
            "Operation", // 主营类目
            "Password", // 登录密码
            "Phone", // 验证码接收手机号
            "ShopLogo", // 店铺图标
            "ShopType", // 店铺类型
        ].reduce((total, key) => (total[key] = undefined, total), Object({}))
        this._Data = undefined // 内部缓存
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    GetParams() {
        // 创建覆盖用的变量
        var Params = {
            name: String(this._Params.ContactName),
            type: Number(this._Params.ShopType),
            category: Number(this._Params.Operation),
            description: Number(this._Params.Introduce),
            user: String(this._Params.ContactName),
            phone: String(this._Params.ContacPhone),
            logo: String(this._Params.ShopLogo),
            merchantUserEntity: {
                mobile: String(this._Params.Phone),
                code: String(this._Params.Code),
                username: String(this._Params.Name),
                password: String(this._Params.Password),
            }
        }

        !!this._Params.Email && this._Params.Email !== "" && (Params.email = this._Params.Email) // 检查邮箱

        Params.merchantUserEntity.confirmPassword = Params.merchantUserEntity.password

        return Params // 回参
    }

    /**
     * 设置选择
     * @param {*} params // 接口参数
     */
    SetData(params = this.GetParams()) {
        return this._api({
            label: "注册商家账号", // 接口标题
            method: "post", // 接口方法
            url: "/store/register/verification", // 访问地址
            params: undefined, // 地址携参
            data: params,// 传递参数
        }).then(data => {
            if (data._code === 200) {
                try {
                    return this._UseUpdate(true) // 回参
                } catch (error) {
                    throw "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) {
                ElMessage.error(data._msg)
                throw data._msg
            }
        })
    }
}