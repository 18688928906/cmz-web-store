// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
    }

    // 外部初始化
    init($) {
        Object.keys(this._Params).forEach(key => this._Params[key] = $?.[key]) // 写入参数
        return this
    }

    // 内部初始化
    _init() {
        // 定义参数
        this._Params = [
        ].reduce((total, key) => (total[key] = undefined, total), Object({}))
        this._Data = undefined // 内部缓存
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams($ = this._Params) {
        var Params = {} // 创建覆盖用的变量
        return Params // 回参
    }

    /**
     * 获取数据
     * @param {*} Update 更新获取
     * @param {*} params // 接口参数
     */
    GetData(Update = false, params = this._GetParams()) {
        // 没有缓存从服务器获取
        if (Update || !this._Data) {
            return this._api({
                label: "注册商家账号数据回显", // 接口标题
                method: "get", // 接口方法
                url: "/store/register/info", // 访问地址
                params: undefined, // 地址携参
                data: undefined,// 传递参数
            }).then(data => {
                if (data._code === 200 && !!data.info) {
                    var Data = data.info
                    try {
                        this._Data = {} // 初始化缓存
                        this._Data.Mobile = Data.mobile // 手机号
                        this._Data.Code = "" // 验证码
                        this._Data.Name = Data.user // 用户名
                        this._Data.Password = this._Data.PasswordV = "" // 密码

                        this._Data.ShopLogo = Data.logo.split(",") // 店铺Logo
                        this._Data.ShopName = Data.name // 店铺名称
                        this._Data.ShopType = Number(Data.type) // 店铺类型
                        this._Data.Operation = Number(Data.category) // 主营类目
                        this._Data.Introduce = Data.description // 店铺简介

                        this._Data.Licence = Data.certificate.split(",") // 营业执照
                        this._Data.CompanyName = Data.applyName // 公司名称
                        this._Data.ShopScale = Number(Data.scale) // 店铺规模
                        this._Data.USCC = Data.creditCode // 统一社会信用代码
                        this._Data.USCCS = Data.creditCodeDate // 统一社会信用代码有效期
                        this._Data.USCCD = Data.creditCodeEndDate // 统一社会信用代码有效期
                        this._Data.USCCX = Data.creditCodeEndDate === "2099-12-31 00:00:00"
                        this._Data.LicenAddress = Data.licenAddress.split(",") // 营业执照所在地
                        this._Data.Address = Data.residence // 住所
                        this._Data.Credentials = !!Data.qualifications ? Data.qualifications.split(",") : [] // 资历
                        this._Data.CardType = 0 // Number(Data.cardType) // 证件类型

                        this._Data.RealName = Data.idName // 身份证姓名 or 护照姓名
                        this._Data.ID = this._Data.CardType > 0 ? "" : Data.idCode // 身份证号
                        this._Data.Passport = this._Data.CardType > 0 ? Data.idCode : "" // 护照号

                        this._Data.DurationEu = this._Data.CardType > 0 || Data.idDate !== "2099-12-31" ? 0 : 1 // 身份证有效期控制
                        this._Data.Duration = Data.idDate// 身份证日期
                        this._Data.DurationEnd = Data.idEndDate
                        this._Data.ID_Img = [Data.idCodeUrlFront, Data.idCodeUrlAfter].map($ => $.split(",")) // 身份证正反
                        this._Data.Passport_Img = Data.passport?.split(",") || [] // 护照图片

                        this._Data.ContactName = Data.user // 联系人姓名
                        this._Data.Email = Data.email // 联系人邮箱
                        this._Data.ContacPhone = Data.phone // 联系人电话
                        this._Data.ContacValid = "" // 验证码

                        this._Data.StoreID = Data.id // 重新入驻的店铺ID

                        return this._UseUpdate(this._Data) // 回参
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) {
                    ElMessage.error(data._msg)
                    throw data._msg
                }
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this._Data))) // 回参
        }
    }
}