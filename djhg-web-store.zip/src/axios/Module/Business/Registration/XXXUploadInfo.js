import base from "@/axios/base.js";

// 创建订单
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
    }

    // 初始化
    init($) {
        Object.keys(this._Params).forEach(key => this._Params[key] = $?.[key]) // 写入参数
        return this
    }

    // 内部初始化
    _init() {
        // 定义参数
        this._Params = [
            "Address", // 住所
            "CardType", // 证件类型
            "CompanyName", // 公司名称
            "Credentials", // 资历
            "Duration", // 身份证有效期
            "ID", // 身份证号
            "ID_Img", // 存放身份证照片
            "LicenAddressId", // 营业执照所在地
            "Licence", // 营业执照
            "Passport", // 护照号
            "Passport_Img", // 护照图片
            "RealName", // 身份证姓名 or 护照姓名
            "ShopScale", // 店铺规模
            "USCC", // 统一社会信用代码
        ].reduce((total, key) => (total[key] = undefined, total), Object({}))
        this._Data = undefined // 内部缓存
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    GetParams() {
        // 创建覆盖用的变量
        var Params = {
            certificate: this._Params.Licence,
            applyName: this._Params.CompanyName,
            creditCode: this._Params.USCC,
            licenAddress: this._Params.Licence,
            residence: this._Params.Address,
            cardType: this._Params.CardType,
            idName: this._Params.RealName,
            idCode: this._Params.ID,
        }

        Params.qualifications = !!this._Params.Credentials && this._Params.Credentials !== "" ? this._Params.Credentials : null
        Params.idCode = [this._Params.ID, this._Params.Passport][this._Params.CardType]

        // 处理身份证
        if (this._Params.CardType === 0) {
            !!this._Params.Duration && (Params.idDate = this._Params.Duration)
            Params.idCodeUrlFront = this._Params.ID_Img[0]
            Params.idCodeUrlAfter = this._Params.ID_Img[1]
            Params.scale = 0
        } else if (this._Params.CardType === 1) {
            Params.passport = this._Params.Passport_Img
            Params.scale = this._Params.ShopScale
        }

        Params.licenType = 0

        return Params // 回参
    }

    /**
     * 设置选择
     * @param {*} params // 接口参数
     */
    SetData(params = this.GetParams()) {
        return this._api({
            label: "门店入驻申请", // 接口标题
            method: "post", // 接口方法
            url: "/store/register", // 访问地址
            params: undefined, // 地址携参
            data: params,// 传递参数
        }).then(data => {
            if (data._code === 200) {
                try {
                    return this._UseUpdate(true) // 回参
                } catch (error) {
                    throw "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) {
                ElMessage.error(data._msg)
                throw data._msg
            }
        })
    }
}