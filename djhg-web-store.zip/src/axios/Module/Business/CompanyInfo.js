// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
    }

    // 外部初始化
    init($) {
        this._init()
        Object.keys(this._Params).forEach(key => (this._Params[key] = $?.[key])) // 写入参数
        return this
    }

    // 内部初始化
    _init() {
        // 定义参数
        this._Params = [
            "Img", // 兑换信息用的图片
        ].reduce((total, key) => (total[key] = undefined, total), Object({}))
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams($ = this._Params) {
        var Params = {} // 创建覆盖用的变量
        Params.imgUrl = $.Img
        return Params // 回参
    }

    /**
     * 获取列表
     * @param {*} Update // 更新获取
     */
    GetData(params = this._GetParams()) {
        return this._api({
            label: "企业信息查询",  // 接口标题
            method: "get", // 接口方法
            url: "/store/bizLicenseInfo", // 访问地址
            params, // 地址携参
            data: undefined // 传递参数
        }).then(res => {
            if (res._code === 200 && !!res?.info && res.info.errorCode === 0) {
                let data = res.info // 创建储存
                try {
                    data = {
                        CompanyName: data.entname || data.verifyEntname, // 公司名称
                        USCC: data.creditCode || data.verifyRegno, // 统一社会信用代码
                        Address: data.dom || data.verifyDom, // 住所
                        USCCS: !!data.opfrom ? new Date(data.opfrom) : undefined, // 营业执照开始时间
                        USCCD: !!data.opto ? new Date(data.opto) : undefined,
                        USCCX: !data.opto
                    }
                    return this._UseUpdate(data) // 回参
                } catch (error) {
                    throw this.DEV ? error : "数据异常，请稍后重试"
                }
            } else if (res._code === 200 && res?.info?.errorCode !== 0) {
                throw res?.info?.reason
            } else if (res._code !== 200) {
                throw res._msg
            }
        }).catch((error) => {
            error = error?.response?.data?.message || error
            ElMessage.error(error)
            throw error
        })
    }
}