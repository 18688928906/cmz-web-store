import base from "@/axios/base.js";

// 全新列表
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
    }

    // 初始化
    init($) {
        Object.keys(this._Params).forEach(key => $?.[key] && (this._Params[key] = $?.[key])) // 写入参数
        this._Data = undefined // 内部缓存
        return this // 链式调用
    }

    // 内部初始化
    _init() {
        // 定义参数
        this._Params = [
            "Type", // 类型：10.商品，20.租赁，40.二手
            "Keyword", // 关键字搜索
        ].reduce((total, key) => (total[key] = undefined, total), Object({}))
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams($ = this._Params) {
        var Params = {}
        Params.type = Number($.Type) // 类型，10商品，20租赁，40二手
        Params.page = Number(1) // 第几页，默认开始为1
        Params.size = Number(12) // 每页数量
        Params.keyword = String($.Keyword || "") // 关键字搜索
        return Params // 回参
    }

    /**
     * 获取列表
     * @param {*} Update // 更新获取
     */
    GetList(Update = !this.Max, params = this._GetParams()) {
        // 没有缓存从服务器获取
        if (Update || !this._Data) {
            return this._api({
                label: "获取收藏列表", // 接口标题
                method: "get", // 接口方法
                url: "/collect/pro/list", // 访问地址
                params, // 地址携参
                data: undefined // 传递参数
            }).then(data => {
                if (data._code === 200 && data.list) {
                    var Data = data.list // 创建储存
                    try {
                        // this._Data = Data
                        return this._UseUpdate(data) // 回参
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) {
                    throw data._msg
                }
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this._Data))) // 回参
        }
    }
}