// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
    }

    // 外部初始化
    init($) {
        this._init()
        Object.keys(this._Params).forEach(key => $?.[key] && (this._Params[key] = $?.[key])) // 写入参数
        return this // 链式调用
    }


    // 内部初始化
    _init() {
        // 定义参数
        this._Params = [
            "Phone", // 验证码接收手机号
            "Password", // 登录密码
            "Name", // 用户昵称
            "Code", // 验证码
        ].reduce((total, key) => (total[key] = undefined, total), Object({}))
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams($ = this._Params) {
        var Params = {}  // 创建覆盖用的变量
        Params.login = $.Phone
        Params.nickName = $.Name
        Params.validCode = $.Code
        Params.onePassword = Params.towPassword = $.Password
        return Params // 回参
    }

    /**
     * 设置选择
     * @param {*} params // 接口参数
     */
    SetData(params = this._GetParams()) {
        return this._api({
            label: "注册账号", // 接口标题
            method: "post", // 接口方法
            url: "/register", // 访问地址
            params: undefined, // 地址携参
            data: params,// 传递参数
        }).then(data => {
            if (data._code === 200) {
                try {
                    return this._UseUpdate(true) // 回参
                } catch (error) {
                    throw "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) {
                ElMessage.error(data._msg)
                throw data._msg
            }
        }).catch((error) => {
            var error = error?.response?.data?.message || error
            ElMessage.error(error)
            throw error
        })
    }
}