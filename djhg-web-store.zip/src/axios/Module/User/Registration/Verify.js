import base from "@/axios/base.js";

// 创建订单
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init(Phone) {
        this.Phone = Phone // 验证码接收手机号
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    GetParams() {
        // 创建覆盖用的变量
        var Params = {
            login: this.Phone
        }

        return Params // 回参
    }

    /**
     * 设置选择
     * @param {*} params // 接口参数
     */
    SetData(params = this.GetParams()) {
        return this._api({
            label: "发送验证码", // 接口标题
            method: "get", // 接口方法
            url: "/basics/send/register/code", // 访问地址
            params, // 地址携参
            data: undefined,// 传递参数
        }).then(data => {
            if (data._code === 200) {
                try {
                    return this._UseUpdate(true) // 回参
                } catch (error) {
                    throw "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) {
                ElMessage.error(data._msg)
                throw data._msg
            }
        })
    }
}