// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
    }

    // 外部初始化
    init($) {
        Object.keys(this._Params).forEach(key => $?.[key] && (this._Params[key] = $?.[key])) // 写入参数
        return this
    }

    // 内部初始化
    _init() {
        // 定义参数
        this._Params = [
            "Code", // 订单号
        ].reduce((total, key) => (total[key] = undefined, total), Object({}))
        this._Data = undefined // 内部缓存
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams($ = this._Params) {
        // 创建覆盖用的变量
        var Params = {}
        Params.fromChannel = "3"
        Params.orderCode = $.Code // 订单号
        Params.orderType = 40
        Params.payChannel = 1
        Params.payType = 1
        Params.type = 1
        Params.flag = 2
        return Params // 回参
    }

    /**
     * 设置选择
     * @param {*} data // 接口参数
     */
    GetData(params = this._GetParams()) {
        return this._api({
            label: "获取支付信息", // 接口标题
            method: "get", // 接口方法
            url: "/order/pay/order/info", // 访问地址
            params, // 地址携参
            data: undefined,// 传递参数
        }).then(data => {
            if (data._code === 200 && !!data.info) {
                let Data = data.info
                try {
                    if (!Data.expend.pay_info) {
                        Data.expend = Data.expend.replace(/\\/g, "")
                        Data.expend = JSON.parse(Data.expend)
                    }
                    this._Data = {
                        Url: Data.expend.pay_info, // 支付链接
                        Type: Data.payChannel || Data.pay_channel, // 支付类型
                    }
                    return this._UseUpdate(this._Data) // 回参
                } catch (error) {
                    throw this.DEV ? error : "数据异常，请稍后重试"
                }
            }

            else if (data._code === 200 && !!data.map) {
                let Data = data.map
                try {
                    if (!Data.expend.pay_info) {
                        Data.expend = Data.expend.replace(/\\/g, "")
                        Data.expend = JSON.parse(Data.expend)
                    }
                    this._Data = {
                        Url: Data.expend.pay_info, // 支付链接
                        Type: Data.payChannel || Data.pay_channel, // 支付类型
                    }
                    return this._UseUpdate(this._Data) // 回参
                } catch (error) {
                    throw this.DEV ? error : "数据异常，请稍后重试"
                }
            }


            else if (data._code !== 200) {
                throw data._msg
            }
        })
    }
}