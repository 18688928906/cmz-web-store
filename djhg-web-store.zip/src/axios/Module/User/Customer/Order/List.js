// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
    }

    // 外部初始化
    init($) {
        Object.keys(this._Params).forEach(key => $?.[key] && (this._Params[key] = $?.[key])) // 写入参数
        return this
    }

    // 内部初始化
    _init() {
        // 定义参数
        this._Params = [
            "StoreId", // 店铺ID
            "Limit", // 长度
            "Page", // 页码
        ].reduce((total, key) => (total[key] = undefined, total), Object({}))
        this._Params.Page = 1 // 默认页面
        this._Params.Limit = 10 // 默认条数
        this._Max = false // 触底
        this._Data = Array(0) // 内部缓存
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams($ = this._Params) {
        var Params = {} // 创建覆盖用的变量
        Params.storeId = $.StoreId // 店铺ID
        Params.page = Number($.Page || 1)  // 页码
        Params.limit = Number($.Limit || 10) // 页码
        return Params // 回参
    }

    /**
     * 设置选择
     * @param {*} Update // 更新获取
     * @param {*} params // 接口参数
     */
    GetData(Update = !this._Max, params = this._GetParams()) {
        // 没有缓存从服务器获取
        if (Update || !this._Data) {
            return this._api({
                label: "当前客服店铺订单", // 接口标题
                method: "get", // 接口方法
                url: "/store/order/list", // 访问地址
                params, // 地址携参
                data: undefined,// 传递参数
            }).then(data => {
                this._Max = (data.list?.length || 0) < this._Params.Limit // 数据触底
                if (data._code === 200 && data?.list) {
                    var Data = data.list.filter($ => !!$) // 创建储存
                    try {
                        Data = Data.map($ => {
                            Data = {
                                Code: $.orderCode, // 订单编号
                                Id: $.id, // 订单ID
                                Img: $.proUrl, // 封面
                                Name: $.proName, // 商品名称
                                Price: !!$.payMoney && Number($.payMoney || 0).toFixed(2), // 价格
                                Time: $.createTime, // 创建时间
                                Type: $.orderType // 订单类型
                            }

                            // 订单状态
                            Data.Status = {
                                Type: $.orderStatus,
                                Label: (index) => [
                                    "交易关闭",
                                    "待付款",
                                    "待发货",
                                    "待收货",
                                    "已完成",
                                    "待自提"
                                ][index]
                            }

                            Data.$ = $ // 原数据

                            return Data // 回参
                        })
                        this._Data.push(...Data)
                        return this._UseUpdate(this._Data) // 回参
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) {
                    ElMessage.error(data._msg)
                    throw data._msg
                }
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this._Data))) // 回参
        }
    }

    /**
     * 设置店铺ID
     * @param {*} StoreId 
     */
    SetStoreId(StoreId) {
        this._Params.StoreId = StoreId
        this._Params.Page = 1 // 默认页面
        this._Params.Limit = 10 // 默认条数
        this._Max = false // 触底
        this._Data = Array(0) // 清除内部缓存
        return this.GetData()
    }
}