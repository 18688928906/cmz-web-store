// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
        this.index = 3
    }

    // 外部初始化
    init($) {
        // Object.keys(this._Params).forEach(key => $?.[key] && (this._Params[key] = $?.[key])) // 写入参数
        return this
    }

    // 内部初始化
    _init() {
        // 定义参数
        // this._Params = [].reduce((total, key) => (total[key] = undefined, total), Object({}))
        this._ws = undefined // 内部缓存
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams() {
        let Params = [] // 创建覆盖用的变量
        Params[0] = window.$USER$.UserId // 当前登录用户的Id
        Params[1] = 0 // 固定值
        Params[2] = 1 // 默认类型写死
        return Params.join("/") // 回参
    }

    /**
     * 链接
     * @param {*} params // 接口参数
     */
    UseLink(params = this._GetParams()) {
        this._UseUpdate({ Loading: true }) // 回参，先打开加载
        return new Promise((resolve) => {
            let host = process.env.VUE_APP_DEV ? "ws://" + location.host + "/socket" : process.env.VUE_APP_BASE_DWS + "/merchant"
            let ws = host + "/websocket/im/" + params // 拼接地址
            this._ws = new WebSocket(ws) // 实例化WebSocket
            this._ws.onmessage = (data) => this._WsOnMessage(data) // 连接消息
            this._ws.onerror = (data) => this._WsOnError(data) // 连接失败
            this._ws.onclose = (data) => this._WsOnClose(data) // 连接关闭
            this._ws.onopen = (data) => {
                this._WsOnOpen(data, this._ws)
                resolve(this)
            } // 链接成功
        })
    }

    /**
     * 发送消息
     * @param {*} data 
     */
    Send(data) {
        try {
            data = JSON.stringify(data) // 尝试转换JSON字符串
        } catch (_) {
            data = String(data) // 尝试失败直接转成字符串
        }

        // 尝试发送消息，如果无法发送，尝试重连发送
        if (this._ws?.send) {
            this._ws?.send?.(data)
        } else {
            let $ = () => this.Close().UseLink().then(() => this.Send(data))
            setTimeout($, 5000) // 等五秒后重连
        }
    }

    // 主动关闭
    Close() {
        this._ws.close?.(1000)
        return this
    }

    /**
     * 连接成功
     * @param {*} data // 回传数据
     * @param {*} _ws // 实例
     */
    _WsOnOpen(data, _ws) {
        this._UseUpdate({ Loading: false, _ws, Type: "open" }) // 回参，关闭加载
        this._log("客服长连接(成功)", _ws)
        this.QUEUE["WebSocketPing"] = () => {
            if (this.index > 0) {
                --this.index
            } else {
                this.Send("ping")
                this.index = 3
            }
        }
    }

    /**
     * 连接消息
     * @param {*} data // 回传数据
     * @param {*} _ws // 实例
     */
    _WsOnMessage(data, _ws = this._ws) {
        try {
            data = JSON.parse(data.data)
            if (data?.text === "pong") {
                throw undefined
            } else {
                data = this._DisposeType(data)
                // data.Loading = false // 关闭加载
                data._ws = _ws // 保存实例
                this._UseUpdate(data)
            }
        } catch (error) {
            data = error
        }

        data && this._log("客服长连接(消息)", data)
    }

    /**
     * 连接失败
     * @param {*} data 
     */
    _WsOnError(data) {
        delete this.QUEUE["WebSocketPing"]
        this._UseUpdate({ Loading: true }) // 回参，先打开加载
        this._log("客服长连接(失败)", data)
        this._ws = undefined // 清除连接
        ElMessage.error("聊天连接失败，请刷新当前界面");
        // let $ = () => this.UseLink() // 映射方法
        // setTimeout($, 5000) // 等五秒后重连
    }

    /**
     * 连接关闭
     * @param {*} data 
     */
    _WsOnClose(data) {
        delete this.QUEUE["WebSocketPing"]
        this._log("客服长连接(关闭)", data)
        data.code !== 1000 && this._WsOnError(data) // 非正常关闭自动重连
    }

    // 处理类型
    _DisposeType($, Type = Number($.type)) {
        return {
            // 商家后台更换客服
            0: () => { },

            // 获取聊天列表
            3: () => {
                let data = { Type } // 创建储存

                // 获取列表
                data.List = $?.pcConversationList?.map(item => ({
                    Avatar: item.headurl, // 用户头像
                    ChatId: item.cid, // 店铺ID
                    Id: String(item.merchantId), // 客服ID
                    Last: item.lastMessage, // 首条消息
                    Name: item.nickName || "-", // 用户名称
                    StoreId: String(item.storeId), // 店铺ID
                    Time: item.updateTime, // 更新时间
                    Type: item.msgType, // 信息类型
                    Unread: item.unread, // 未读数量
                }))
                return data // 回参
            },

            // 获取聊天记录
            4: () => {
                let data = { Type } // 创建储存
                data.List = $?.chatRecord?.filter(item => !!item.type)
                data.List = data.List.map(item => this._DisposeType(item)) // 处理列表
                data.List = data.List.filter(item => !!item)
                // data.ChatId = $.conversationid // 会话ID
                return data // 回参
            },

            // 接收文字消息
            10: () => {
                // 创建储存
                let data = {
                    Avatar: $?.from?.headurl, // 用户头像
                    Data: $.text, // 显示数据
                    Id: String($.merchantid || $.from?.userId), // 聊天ID
                    Name: $?.from?.nickName, // 用户名称
                    Read: $.userReadStatus === 1, // 已读
                    Time: $?.date, // 发送时间
                    Type, // 类型
                    User: $?.from?.userType === 1, // 是否为自己的消息
                    StoreId: String($.mid), // 店铺ID
                }
                return data // 回参
            },

            // 接收图片消息
            11: () => {
                let data = this._DisposeType($, 10) // 创建储存
                data.Type = Type // 补正类型
                return data // 回参
            },

            // 接收订单消息
            12: () => {
                let data = this._DisposeType($, 10) // 创建储存
                data.Type = Type // 补正类型
                let Data = $?.order // 获取订单
                !!Data && (data.Data = {
                    Code: Data.orderCode, // 订单编号
                    Id: Data.id, // 订单ID
                    Img: Data.proUrl, // 封面
                    Name: Data.proName, // 商品名称
                    Price: !!Data.price && Number(Data.price || 0).toFixed(2), // 价格
                    Pay: !!Data.totalPrice && Number(Data.totalPrice || 0).toFixed(2), // 付款
                    Qty: Data.totalNum, // 购买数量
                    Time: Data.createTime, // 创建时间
                    Type: Data.proType, // 订单类型

                    // 订单状态
                    Status: {
                        Type: Data.orderStatus,
                        Label: (index) => [
                            "交易关闭",
                            "待付款",
                            "待发货",
                            "待收货",
                            "已完成",
                            "待自提"
                        ][index] || Data.orderStatusName
                    },

                    Sku: String(Data.skuValue).split(",").join(" | ")
                })
                return data // 回参
            },

            // 接收商品消息
            13: () => {
                let data = this._DisposeType($, 10) // 创建储存
                data.Type = Type // 补正类型
                let Data = $?.pro // 获取商品
                !!Data && (data.Data = {
                    Id: Data.id, // 商品ID
                    Img: Data.coverImgurl?.split(",")[0], // 商品图片
                    Name: Data.proName, // 商品名称
                    Max: Data.qty || 0, // 库存
                    Price: Data.minPrice, // 售价
                    Sale: Data.saleCount || 0, // 销量
                    Type: Data.proType, // 商品类型
                })
                return data // 回参
            },

            // 订单支付提醒
            2001: () => {
                let data = this._DisposeType($, 2003) // 创建储存 
                data.Type = Type // 补正类型
                data.Data.Status.Type = 1 // 临时订单状态
                return data
            },

            // 核对订单地址
            2002: () => {
                let data = this._DisposeType($, 2003) // 创建储存 
                data.Type = Type // 补正类型
                let Receipt = $.address // 获取收货地址
                data.Receipt = {
                    Address: Receipt?.address, // 收件地址
                    Name: Receipt?.name, // 收件人
                    Phone: Receipt?.phone, // 联系电话
                    Sure: Receipt?.isSure === 1 // 已确认
                }
                return data
            },

            // 接收订单消息
            2003: () => {
                let data = this._DisposeType($, 12) // 创建储存 
                data.Type = Type // 补正类型
                data.$ = $
                return data
            },

            // 接收物流消息
            2004: () => {
                let data = this._DisposeType($, 2003) // 创建储存
                data.Type = Type // 补正类型
                let Exp = $.logistics // 获取物流
                data.Exp = {
                    Code: Exp.expNo, // 物流单号
                    Context: Exp.context, // 物流说明
                    Company: Exp.expName, // 物流公司
                    Status: Exp.status, // 物流状态
                    Time: Exp.time, // 物流时间
                }
                return data // 回参
            },

            // 更新已读消息
            2005: () => {
                return { Type }
            },


            // 3000: () => this._DisposeType($, 2002)
        }[Type]?.()
    }
}