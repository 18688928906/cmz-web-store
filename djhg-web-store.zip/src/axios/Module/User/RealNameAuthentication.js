// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
    }

    // 外部初始化
    init($) {
        Object.keys(this._Params).forEach(key => $?.[key] && (this._Params[key] = $?.[key])) // 写入参数
        return this
    }

    // 内部初始化
    _init() {
        // 定义参数
        this._Params = [
            "Code", // 身份证号
            "Name", // 真实姓名
            "Type", // 有效期方式：1.长期，2.有效期
            "Date", // 身份证有效期
            "File" // 身份证正反面
        ].reduce((total, key) => (total[key] = undefined, total), Object({}))
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams($ = this._Params) {
        // 创建覆盖用的变量
        var Params = {}
        Params.idcard = String($.Code)
        Params.realName = String($.Name)
        Params.validityType = Number($.Type)
        // Params.validDate = String($.Date)
        // Params.idcardfront = String($.File[0])
        // Params.idcardback = String($.File[1])
        return Params // 回参
    }

    /**
     * 设置数据
     */
    GetData(params = this._GetParams()) {
        return this._api({
            label: "身份证实名认证", // 接口标题
            method: "post", // 接口方法
            url: "/customer/idcard/authen", // 访问地址
            params: undefined, // 地址携参
            data: params,// 传递参数
        }).then(data => {
            if (data._code === 200) {
                try {
                    return this._UseUpdate(true) // 回参
                } catch (error) {
                    throw this.DEV ? error : "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) {
                throw data._msg
            }
        }).catch((error) => {
            error = error?.response?.data?.message || error
            ElMessage.error(error)
            throw error
        })
    }
}