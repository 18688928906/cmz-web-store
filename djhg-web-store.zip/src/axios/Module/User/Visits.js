// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
    }

    /**
     * 设置选择
     * @param {*} data // 接口参数
     */
    GetData() {
        return this._api({
            label: "记录访问量", // 接口标题
            method: "get", // 接口方法
            url: "/surplus/pro/view", // 访问地址
            params: undefined, // 地址携参
            data: undefined,// 传递参数
        })
    }
}