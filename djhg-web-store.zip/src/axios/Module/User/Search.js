// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
    }

    // 外部初始化
    init($) {
        Object.keys(this._Params).forEach(key => $?.[key] && (this._Params[key] = $?.[key])) // 写入参数
        return this
    }

    // 内部初始化
    _init() {
        // 定义参数
        this._Params = [
            "Page", // 页码
            "Limit", // 每页长度
            "Keyword", // 搜索关键字
            "Classify", // 三级分类Id
            "Delivery", // 发货地，市级Id
            "Pickup", // 自提：0.否，1.是
            "Sort", // 排序：1.新到旧，2.销量降序，3.价格升序，4.价格降序
            "Min", // 最低价
            "Max", // 最高价
        ].reduce((total, key) => (total[key] = undefined, total), Object({}))
        this._Params.Page = 0
        this._Params.Limit = 15
        this._Data = undefined // 内部缓存
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams($ = this._Params) {
        var Params = {} // 创建覆盖用的变量
        Params.page = Number($.Page) // 页码
        Params.limit = String($.Limit) // 每页长度
        Params.keyword = String($.Keyword) // 搜索关键字
        Params.classifyId = Number($.Classify) // 三级分类Id
        Params.deliveryPlaceId = String($.Delivery) // 发货地，市级Id
        Params.selfmention = Number($.Pickup) // 自提：0.否，1.是
        Params.sort = String($.Sort) // 排序：1.新到旧，2.销量降序，3.价格升序，4.价格降序
        Params.minPrice = Number($.Min) // 最低价
        Params.maxPrice = Number($.Max) // 最高价
        return Params // 回参
    }

    /**
     * 设置选择
     * @param {*} Update // 更新获取
     * @param {*} params // 接口参数
     */
    GetData(Update = !this._Data, params = this._GetParams()) {
        // 没有缓存从服务器获取
        if (Update) {
            return this._api({
                label: "综合搜索", // 接口标题
                method: "get", // 接口方法
                url: "/es/product/search/complex", // 访问地址
                params, // 地址携参
                data: undefined,// 传递参数
            }).then(data => {
                if (data._code === 200 && !!data) {
                    try {
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) {
                    ElMessage.error(data._msg)
                    throw data._msg
                }
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this._Data))) // 回参
        }
    }

    // 设置搜索关键字
    SetKeyword($) {
        this._Params.Page = 0
        this._Params.Keyword = $
        this._Data = undefined
        return this.GetData()
    }
}