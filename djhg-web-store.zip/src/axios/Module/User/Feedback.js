import base from "@/axios/base.js";

// 全新列表
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init($) {
        this.Content = $?.Content // 反馈
        this.Img = $?.Img // 上传图片
        this.Radio = $?.Radio // 协助意愿
        this.Rate = $?.Rate // 评分
        this.Phone = $?.Phone // 手机
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams() {
        // 创建覆盖用的变量
        var Params = {
            content: String(this.Content),
            imgs: String(this.Img),
            assist: Number(this.Radio),
            beauty: Number(this.Rate[0]),
            convenient: Number(this.Rate[1]),
            clarity: Number(this.Rate[2]),
            complete: Number(this.Rate[3]),
            satisfied: Number(this.Rate[4]),
            attractive: Number(this.Rate[5]),
            fresh: Number(this.Rate[6]),
            phone: Number(this.Phone),
        }
        return Params // 回参
    }

    /**
     * 
     */
    SetData(params = this._GetParams()) {
        return this._api({
            label: "反馈调研", // 接口标题
            method: "post", // 接口方法
            url: "/customer/feedback/survey", // 访问地址
            params: undefined, // 地址携参
            data: params // 传递参数
        }).then(data => {
            if (data._code === 200) {
                try {
                    ElMessage({
                        message: data._msg,
                        showClose: true,
                        grouping: true,
                        type: "success",
                    })
                    return this._UseUpdate(true) // 回参
                } catch (error) {
                    throw this.DEV ? error : "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) {
                throw data._msg
            }
        })
    }
}