import info from "./Info.js";

// 登录
export default class extends info {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._key2 = `${this._ID}-TOKEN` // 创建识别键

        this.Account = String("") // 账号或手机号
        this.Password = String("") // 密码

        // 订阅数据更新，没有数据则清除登录，有数据更新用户地址
        this.AddUpdate(this._key2, (value) => {
            value === undefined ? this._DelToken() : this.BUS[`${this._ID}-ADDRESS-USER`]()
        })._info() // 初始化

        window.addEventListener("storage", ({ key }, newValue, oldValue) => {
            if (key === this._key2) {
                location.reload()
            }
        })
    }

    // 内部初始化
    _info() {
        var Data = localStorage.getItem(this._key2) // 获取本地储存
        if (!!Data) {
            Data = JSON.parse(this.AES.decrypt(Data)) // 解密参数
            if (new Date().getTime() > Data.expire) {
                this.Quit() // 登录过期直接登出
            } else {
                window.$TOKEN$ = this.Token = Data // 缓存解密数据
                this._WatchExpire()  // 启动监视器
            }
        } else if (!!window.$TOKEN$) {
            this.Token = window.$TOKEN$
        } else {
            this.Quit() // 登出一次防止数据异常
        }
        return this // 链式调用
    }

    /**
     * 接口方法
     * @param {*} validCode 验证码模式用的验证码
     */
    GetToken(validCode = undefined) {
        return this._api({
            label: validCode ? "验证码登录" : "密码登录", // 接口标题
            method: "post", // 接口方法
            url: validCode ? "/valid/login" : "/login", // 访问地址
            params: undefined, // 地址携参
            data: !!validCode ? {
                checked: Boolean(true), // 同意协议
                login: String(this.Account), // 账号或手机号
                validCode, // 验证码
            } : {
                checked: Boolean(true), // 同意协议
                login: String(this.Account), // 账号或手机号
                password: String(this.Password), // 密码
            } // 传递参数
        }).then(data => {
            if (data._code === 200) {
                var Data = data // 创建储存
                try {
                    Data = {
                        expire: new Date().getTime() - Data._time + Data.expire * 1000, // 计算过期时间
                        token: Data.token,
                    }
                    window.$TOKEN$ = this.Token = Data // 缓存数据
                    Data = JSON.stringify(Data) // 转换成字符串
                    localStorage.setItem(this._key2, this.AES.encrypt(Data)) // 加密储存
                    return this._WatchExpire().GetUserInfo(true) // 启动监视器，返回用户数据
                } catch (error) {
                    throw this.DEV ? error : "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) {
                throw data._msg
            }
        }).catch((error) => {
            throw error?.response?.data?.message || error
        })
    }

    /**
     * 发送验证码
     */
    SendValidCode(login = this.Account) {
        return this._api({
            label: "发送验证码", // 接口标题
            method: "get", // 接口方法
            url: "/basics/send/login/code", // 访问地址
            params: { login }, // 地址携参
            data: undefined // 传递参数
        }).then(data => {
            if (data._code === 200) { return true }
            else { throw data._msg }
        })
    }

    /**
     * 删除登录状态
     */
    _DelToken() {
        localStorage.removeItem(this._key2)  // 清除缓存
        localStorage.removeItem("SaveBusinessOccupancyForm")
        this.Account = String("") // 账号或手机号
        this.Password = String("") // 密码
        this.Token = undefined // 清空
        delete window.$TOKEN$ // 清空
        return this // 链式调用
    }

    // 监视过期
    _WatchExpire() {
        // 注册任务
        this.QUEUE["_WatchExpire"] = (unix) => {
            if (!!this.Token && unix > this.Token.expire) {
                this.Quit() // 过期直接登出
                delete this.QUEUE["_WatchExpire"] // 删除任务
            }
        }
        return this // 链式调用
    }

    // 检查是否处于登录状态
    IsLogin() { return !!window.$TOKEN$ }
}