import base from "@/axios/base.js";

// 全新列表
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init($) {
        this.Avatar = $?.Avatar // 头像
        this.Nick = $?.Nick // 昵称
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams() {
        // 创建覆盖用的变量
        var Params = {
            nickName: this.Nick,
        }
        return Params // 回参
    }

    /**
     * 
     */
    SetData(params = this._GetParams()) {
        return this._api({
            label: "修改个人资料", // 接口标题
            method: "put", // 接口方法
            url: "/customer/info/edit/nickname", // 访问地址
            params: undefined, // 地址携参
            data: params // 传递参数
        }).then(data => {
            if (data._code === 200) {
                try {
                    ElMessage({
                        message: data._msg,
                        showClose: true,
                        grouping: true,
                        type: "success",
                    })
                } catch (error) {
                    throw this.DEV ? error : "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) {
                ElMessage({
                    message: data._msg,
                    showClose: true,
                    grouping: true,
                    type: "error",
                })
            }
        })
    }
}