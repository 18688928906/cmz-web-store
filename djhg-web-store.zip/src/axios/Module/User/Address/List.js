// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._key = `${this._ID}-ADDRESS-USER` // 创建识别键
        this.BUS[this._key] = () => this.GetData() // 订阅获取数据
        this._init()
    }

    // 外部初始化
    init() {
        return this._init()
    }

    // 内部初始化
    _init() {
        var Data = sessionStorage.getItem(this._key) // 获取本地储存
        this._Data = !!Data ? JSON.parse(this.AES.decrypt(Data)) : undefined // 内部缓存
        return this // 链式调用
    }

    _odx() {
        sessionStorage.removeItem(this._key)
        return this._init().GetData()
    }

    /**
     * 拼接参数
     */
    _GetParams() {
        // 创建覆盖用的变量
        var Params = undefined
        return Params // 回参
    }

    /**
     * 获取数据
     * @param {*} Update // 更新获取
     * @param {*} params // 接口参数
     */
    GetData(Update = false, params = this._GetParams()) {
        // 没有缓存从服务器获取
        if (Update || !this._Data) {
            return this._api({
                haveToken: true, // 必须携带Token
                label: "用户地址",  // 接口标题
                method: "get", // 接口方法 
                url: "/customer/received/addr/list", // 访问地址
                params, // 地址携参
                data: undefined // 传递参数
            }).then(data => {
                if (data._code === 200 && data.addrList?.length >= 0) {
                    var Data = data.addrList // 创建储存
                    try {
                        // 转换数据格式
                        this._Data = Data.map(item => {
                            // 覆盖减少占用
                            Data = {
                                Address: item.address, // 详细地址
                                AddressId: [], // 地区ID队列
                                Default: item.def === 1, // 计算默认地址
                                Ext: item.nameExt, // 省市区
                                Id: item.id, // 地址ID
                                Name: item.name, // 收件人姓名
                                Phone: Number(item.mobile), // 联系号码
                                Time: item.createTime, // 创建时间
                            }

                            // 检查并拼接地址ID列
                            {
                                item.proId && Data.AddressId.push(item.proId)
                                item.cityId && Data.AddressId.push(item.cityId)
                                item.areaId && Data.AddressId.push(item.areaId)
                                item.streetId && Data.AddressId.push(item.streetId)
                            }

                            return Data // 回参
                        })

                        Data = this.AES.encrypt(JSON.stringify(this._Data)) // 加密数据
                        sessionStorage.setItem(this._key, Data) // 本地储存
                        return this._UseUpdate(this._Data) // 回参
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) { throw data._msg }
            }).catch(error => error.message !== false && console.log(error))
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this._Data))) // 回参
        }
    }
}