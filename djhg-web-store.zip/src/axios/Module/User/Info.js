// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._key = `${this._ID}-USER-INFO` // 创建识别键
        this._init()
    }

    // 内部初始化
    _init() {
        var Data = localStorage.getItem(this._key) // 获取浏览器缓存
        window.$USER$ = this._data = !!Data ? JSON.parse(this.AES.decrypt(Data)) : undefined // 解密缓存
    }

    /**
     * 接口方法
     * @param {*} Update // 更新获取
     */
    GetUserInfo(Update = false) {
        // 没有缓存从服务器获取
        if (Update || !this._data) {
            return this._api({
                haveToken: true, // 必须携带Token
                label: "获取用户数据", // 接口标题
                method: "get", // 接口方法
                url: "/my/info", // 访问地址
                params: undefined, // 地址携参
                data: undefined // 传递参数
            }).then(data => {
                if (data._code === 200 && !!data.info) {
                    var Data = data.info // 创建储存
                    try {
                        // 转换数据格式
                        Data = {
                            Account: Data.login, // 用户账号
                            Avatar: Data.headurl, // 用户头像
                            Nick: Data.nickName, // 用户昵称
                            Phone: Data.phoneInfo, // 电话号码
                            UserId: Data.id, // 用户ID
                            Authen: Data.authen === 1 // 是否实名
                        }
                        window.$USER$ = this._data = Data // 缓存数据
                        Data = this.AES.encrypt(JSON.stringify(Data)) // 加密数据
                        localStorage.setItem(this._key, Data) // 本地储存
                        sessionStorage.clear() // 清除会话
                        return this._UseUpdate(this._data) // 回参
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) {
                    throw data._msg
                }
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this._data))) // 回参
        }
    }

    // 用户退出
    Quit() {
        localStorage.removeItem(this._key) // 清除用户信息
        sessionStorage.clear() // 清空缓存
        window.$USER$ = this._data = undefined // 清除缓存数据
        this._UseUpdate(undefined) // 调用数据更新方法
        return this // 链式调用
    }

    // 隐藏号码
    HideUserPhone(Phone = this.Data?.Phone || "13900009999") {
        return this.HidePhone(Phone)
    }
}