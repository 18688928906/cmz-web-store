// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
    }

    // 外部初始化
    init($) {
        Object.keys(this._Params).forEach(key => $?.[key] && (this._Params[key] = $?.[key])) // 写入参数
        return this
    }

    // 内部初始化
    _init() {
        // 定义参数
        this._Params = [
            "Id", // 需求ID
        ].reduce((total, key) => (total[key] = undefined, total), Object({}))
        this._Data = undefined // 内部缓存
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams($ = this._Params) {
        var Params = {} // 创建覆盖用的变量
        Params.id = String($.Id) // 强制数据类型装换
        Params.type = 0 // 类型
        return Params // 回参
    }

    /**
     * 筛选选择
     * @param {*} Update // 更新获取
     * @param {*} params // 接口参数
     */
    GetData(Update = !this._Max, params = this._GetParams()) {
        // 没有缓存从服务器获取
        if (Update || !this._Data) {
            return this._api({
                label: "租赁需求", // 接口标题
                method: "get", // 接口方法
                url: "/demand/lease/detail", // 访问地址
                params, // 地址携参
                data: undefined,// 传递参数
            }).then(data => {
                if (data._code === 200 && !!data?.data) {
                    var Data = data.data // 创建储存
                    try {
                        this._Data = {
                            Address: Data.detailedaddress, // 地址
                            Content: Data.content, // 内容
                            Id: Data.id, // 需求ID
                            Imgs: Data?.imgs?.split(","), // 详情图
                            Label: Data.title, // 标题
                            Lease: Data.rentaltime, // 租期
                            Time: Data.createtime, // 创建时间
                            Region: Data.address, // 地区
                            Rent: Number(Data.rent || 0).toFixed(2), // 租金

                            // 用户
                            User: {
                                Avatar: Data.headimg, // 头像
                                Id: Data.customerid, // 用户Id
                                Name: Data.customerName, // 昵称
                            }
                        }
                        return this._UseUpdate(this._Data) // 回参
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) {
                    ElMessage.error(data._msg)
                    throw data._msg
                }
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this._Data))) // 回参
        }
    }
}