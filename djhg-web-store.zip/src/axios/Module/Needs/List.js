// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
    }

    // 外部初始化
    init($) {
        Object.keys(this._Params).forEach(key => $?.[key] && (this._Params[key] = $?.[key])) // 写入参数
        return this
    }

    // 内部初始化
    _init() {
        // 定义参数
        this._Params = [
            "Heat", // 热度排序：正(true)，反(false)
            "Limit", // 每页数量
            "Page", // 页码
            "Sort", // 筛选：综合(comprehensive)，热度(heat)，时间(time)
            "Time", // 时间排序：正(true)，反(false)
            "Type", // 类型：0.租赁，1.二手，2.招工，3.场地，4.捐赠，5.助农
        ].reduce((total, key) => (total[key] = undefined, total), Object({}))
        this._Max = false // 记录触底
        this._Data = Array(0) // 内部缓存
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams($ = this._Params) {
        var Params = {} // 创建覆盖用的变量
        Params.page = String($.Page || 1)
        Params.limit = String($.Limit || 10)
        Params.sort = $.Sort || "comprehensive"
        $.Heat !== undefined && (Params.heatSort = $.Heat ? "desc" : "asc")
        $.Time !== undefined && (Params.heatSort = $.Time ? "desc" : "asc")
        Params.type = String($.Type || 0)
        return Params // 回参
    }

    /**
     * 筛选选择
     * @param {*} Update // 更新获取
     * @param {*} params // 接口参数
     */
    GetData(Update = !this._Max, params = this._GetParams()) {
        // 没有缓存从服务器获取
        if (Update || this._Data?.length === 0) {
            return this._api({
                label: "需求列表", // 接口标题
                method: "get", // 接口方法
                url: "/demand/lease/list", // 访问地址
                params, // 地址携参
                data: undefined,// 传递参数
            }).then(data => {
                this._Max = (data.data?.length || 0) < (this._Params.Limit || 10)// 数据触底
                if (data._code === 200 && data.data?.length > 0) {
                    var Data = data.data // 创建储存
                    try {
                        Data = Data.map($ => {
                            $ = {
                                Content: $.content, // 内容
                                Id: $.id, // 需求ID
                                Label: $.title, // 标题
                                Time: $.createtime, // 创建时间

                                // 用户
                                User: {
                                    Avatar: $.headimg, // 头像
                                    Name: $.customerName, // 昵称
                                }
                            }
                            return $
                        })
                        this._Data.push(...Data)
                        this._Params.Page = Number(params.page) + 1 // 预翻页
                        return this._UseUpdate(this._Data) // 回参
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) {
                    ElMessage.error(data._msg)
                    throw data._msg
                }
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this._Data))) // 回参
        }
    }

    // 筛选热度
    SetHeat($ = Boolean(true)) {
        this._Params.Heat = $ === true

        this._Params.Page = 1
        this._Params.Sort = "heat"
        this._Params.Time = undefined

        this._Max = false
        this._Data = Array(0)

        return this.GetData()
    }

    // 筛选页数
    SetLimit($ = Number(10)) {
        this._Params.Time = $

        this._Params.Page = 1

        this._Max = false
        this._Data = Array(0)

        return this.GetData()
    }

    // 筛选热度
    SetPage($ = Number(1)) {
        this._Params.Page = $

        this._Max = false
        this._Data = Array(0)

        return this.GetData()
    }

    // 默认筛选
    UseComprehensive() {
        this._Params.Sort = undefined

        this._Params.Heat = undefined
        this._Params.Page = 1
        this._Params.Time = undefined

        this._Max = false
        this._Data = Array(0)

        return this.GetData()
    }

    // 筛选时间
    SetTime($ = Boolean(true)) {
        this._Params.Time = $ === true

        this._Params.Heat = undefined
        this._Params.Page = 1
        this._Params.Sort = "time"

        this._Max = false
        this._Data = Array(0)

        return this.GetData()
    }

    // 筛选类型
    SetType($ = Number(0)) {
        this._Params.Type = $

        this._Params.Heat = undefined
        this._Params.Page = 1
        this._Params.Sort = undefined
        this._Params.Time = undefined

        this._Max = false
        this._Data = Array(0)

        return this.GetData()
    }
}