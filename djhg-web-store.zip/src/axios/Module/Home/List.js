// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
    }

    // 外部初始化
    init($) {
        Object.keys(this._Params).forEach(key => this._Params[key] = $[key]) // 写入参数
        return this
    }

    // 内部初始化
    _init() {
        // 定义参数
        this._Params = [
            "Limit", // 页码
            "Page", // 每页数量
        ].reduce((total, key) => (total[key] = undefined, total), Object({}))
        this._Params.Limit = 15
        this._Params.Page = 1
        this._Data = Array(0) // 内部缓存
        this._Max = false // 触底
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams($ = this._Params) {
        var Params = {} // 创建覆盖用的变量
        Params.limit = Number($.Limit || 15)
        Params.page = Number($.Page || 1)
        Params.type = "home"
        return Params // 回参
    }

    /**
     * 接口方法
     * @param {*} Update // 更新获取
     * @param {*} params // 接口参数
     */
    GetData(Update = !this._Max, params = this._GetParams()) {
        // 没有缓存从服务器获取
        if (Update || this._Data.length <= 0) {
            return this._api({
                label: "获取首页列表", // 接口标题
                method: "get", // 接口方法
                url: "/recommend/product", // 访问地址
                params, // 地址携参
                data: undefined, // 传递参数
                UseToken: false // 不需要Token
            }).then(data => {
                this._Max = (data.list?.length || 0) < params.limit // 数据触底
                if (data._code === 200 && data.list?.length > 0) {
                    var Data = data.list // 创建储存
                    try {
                        // 转换数据格式
                        Data = Data.map($ => ({
                            Currency: "￥", // 货币种类
                            Id: $.id, // 商品ID    
                            Img: $.coverImgurl, // 商品图片
                            Name: $.proName || "该商品没有名称", // 商品名称
                            Price: Number($.minPrice || 0).toFixed(2), // 商品价格
                            Sales: Number($.saleCount || 0), // 销量
                            Wholesale: $.wholesale > 0, // 批发

                            // 店铺信息
                            Store: {
                                name: $.storeName // 店铺名称
                            }
                        }))

                        this._Data.push(...Data) // 缓存数据
                        this._Params.Page++ // 预翻页
                        return this._UseUpdate(this._Data) // 回参
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) {
                    throw data._msg
                }
            }).catch((error) => {
                error = error?.response?.data?.message || error
                ElMessage.error(error)
                throw error
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this._Data))) // 回参
        }
    }
}