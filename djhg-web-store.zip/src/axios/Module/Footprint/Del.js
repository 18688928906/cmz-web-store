// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
    }

    // 外部初始化
    init($) {
        Object.keys(this._Params).forEach(key => $?.[key] && (this._Params[key] = $?.[key])) // 写入参数
        return this
    }

    // 内部初始化
    _init() {
        // 定义参数
        this._Params = [
            "Ids", // 订单Id列
        ].reduce((total, key) => (total[key] = undefined, total), Object({}))
        this._Data = undefined // 内部缓存
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams($ = this._Params) {
        // 创建覆盖用的变量
        var Params = {}
        Params.ids = String($.Ids)
        return Params // 回参
    }

    /**
     * 设置选择
     * @param {*} data // 接口参数
     */
    SetData(params = this._GetParams()) {
        return this._api({
            label: "批量删除足迹", // 接口标题
            method: "delete", // 接口方法
            url: "/customer/browse/delete", // 访问地址
            params, // 地址携参
            data: undefined, // 传递参数
        }).then(data => {
            if (data._code === 200) {
                try {
                    return this._UseUpdate(true) // 回参
                } catch (error) {
                    throw this.DEV ? error : "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) {
                ElMessage({
                    message: data._msg,
                    showClose: true,
                    grouping: true,
                    type: "error",
                })
            }
        })
    }
}