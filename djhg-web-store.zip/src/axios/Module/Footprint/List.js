import base from "@/axios/base.js";

// 全新列表
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init($) {
        this.Type = $?.Type || 10
        this._Data = undefined
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams() {
        var Params = {
            type: Number(this.Type), // 类型，10商品，20租赁，40二手
            page: Number(1), // 第几页，默认开始为1
            size: Number(12), // 每页数量
        }
        return Params // 回参
    }

    /**
     * 获取列表
     * @param {*} Update // 更新获取
     */
    GetList(Update = !this.Max, params = this._GetParams()) {
        // 没有缓存从服务器获取
        if (Update || !this._Data) {
            return this._api({
                label: "用户浏览记录", // 接口标题
                method: "get", // 接口方法
                url: "/customer/browse", // 访问地址
                params, // 地址携参
                data: undefined // 传递参数
            }).then(data => {
                if (data._code === 200 && !!data.list) {
                    var Data = data.list // 创建储存
                    try {
                        // this._Data = Data
                        return this._UseUpdate(data) // 回参
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) {
                    throw data._msg
                }
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this._Data))) // 回参
        }
    }
}