import base from "@/axios/base.js";

// 导出具名类，建议和文件名相同
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init() {
        this.Data = undefined // 创建
        return this
    }

    /**
     * 接口方法
     * @param {*} Update // 更新获取
     */
    GetData(Update = false) {
        // 没有缓存从服务器获取
        if (Update || !this.Data) {
            return this._api({
                label: "首页购物车列表", // 接口标题
                method: "get", // 接口方法
                url: "/query/shop/cart/home/list", // 访问地址
                params: undefined, // 地址携参
                data: undefined // 传递参数
            }).then(data => {
                if (data._code === 200) {
                    var Data = Object() // 创建储存
                    try {
                        // 转换数据格式
                        Data = {
                            Count: Number(data.total || 0), // 购物车总数
                            Price: Number(data.totalPrice || 0).toFixed(2), // 购物车价格
                            Currency: "￥", // 货币种类
                            List: Array(0)
                        }

                        // 购物车列表
                        Data.List = data.cartList?.map(item => ({
                            Id: item.proId, // 商品ID
                            Name: item.proName, // 商品名称
                            Time: item.createTime, // 加入时间
                            Price: item.price, // 商品价格
                            Img: item.proUrl, // 商品图片
                            Sku: item.skuName, // 商品规格
                            Count: item.qty, // 商品数量
                            Currency: Data.Currency // 货币种类
                        }))

                        this.Data = Data // 缓存数据
                        return this._UseUpdate(this.Data) // 回参
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) {
                    throw data._msg
                }
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this.Data))) // 回参
        }
    }
}