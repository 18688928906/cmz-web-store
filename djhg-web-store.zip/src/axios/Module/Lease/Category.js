import base from "@/axios/base.js";

// 商品详情
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._init()
    }

    // 初始化
    _init() {
        this._Data = undefined
    }

    /**
     * 获取数据
     * @param {*} Update // 更新获取
     */
    GetData(Update = false) {
        // 没有缓存从服务器获取
        if (Update || !this._Data) {
            return this._api({
                label: "获取租赁分类", // 接口标题
                method: "get", // 接口方法
                url: "/lease/pro/category/tree", // 访问地址
                params: undefined, // 地址携参
                data: undefined // 传递参数
            }).then(data => {
                if (data._code === 200 && data?.list?.length > 0) {
                    var Data = data.list
                    var Fun = (list = Data) => list.map($ => {
                        var item = {
                            Id: $.catId,
                            Img: $.icon,
                            Label: $.name,
                            Level: $.catLevel,
                        }

                        // 处理连级选择器数据
                        item.label = item.Label
                        item.value = item.Id

                        // 递归子项
                        $.children?.length > 0 && (item.children = Fun($.children))

                        return item // 回参
                    })
                    try {
                        this._Data = Fun()
                        return this._UseUpdate(this._Data) // 回参
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) {
                    throw data._msg
                }
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this.Data))) // 回参
        }
    }
}