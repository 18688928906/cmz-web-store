import base from "@/axios/base.js";

// 添加收藏
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init(Id) {
        this.Id = Id || Number(0) // 商品ID
        return this // 链式调用
    }

    /**
     * 设置选择
     * @param {*} Status // 更新获取
     */
    SetData(Status = true) {
        return this._api({
            label: "收藏商品", // 接口标题
            method: "post", // 接口方法
            url: "/collect/pro/add", // 访问地址
            params: {
                proId: this.Id, // 收藏的商品ID
                proType: 20, // 商品类型定值
                status: Status ? 1 : 0 // 收藏或取消
            }, // 地址携参
            data: undefined // 传递参数
        }).then(data => {
            if (data._code === 200) {
                try {
                    ElMessage({
                        message: data._msg,
                        showClose: true,
                        grouping: true,
                        type: "success",
                    })
                    return Status // 返回输入的值
                } catch (error) {
                    throw "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) {
                throw data._msg
            }
        })
    }
}