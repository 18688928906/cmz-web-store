// 导入类
import base from "@/axios/base.js";

// 导出类
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this._key = `${this._ID}-CLASSIFY-LEASE` // 创建识别键
        this._init()
    }

    // 外部初始化
    init() {
        return this // 链式调用
    }

    // 内部初始化
    _init() {
        var Data = localStorage.getItem(this._key) // 获取本地储存
        this._Data = !!Data ? JSON.parse(this.AES.decrypt(Data)) : undefined // 内部缓存
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams() {
        var Params = { type: Number(1) } // 创建覆盖用的变量
        return Params // 回参
    }

    /**
     * 获取数据
     * @param {*} Update // 更新获取
     * @param {*} params // 接口参数
     */
    GetData(Update = false, params = this._GetParams()) {
        // 没有缓存从服务器获取
        if (Update || !this._Data) {
            return this._api({
                label: "分类树", // 接口标题
                method: "get", // 接口方法
                url: "/lease/pro/category/tree", // 访问地址
                params, // 地址携参
                data: undefined // 传递参数
            }).then(data => {
                if (data._code === 200 && data.list?.length > 0) {
                    var Data = data.list // 创建储存
                    var SetData = (list = Data) => list.map(item => {
                        item = {
                            Children: item.children && SetData(item.children), // 递归子项
                            Id: item.catId, // 分类ID
                            Label: item.name, // 显示
                            Logo: item.icon // 图标
                        }
                        return item
                    })
                    try {
                        this._Data = Data = SetData() // 转换数据格式
                        Data = this.AES.encrypt(JSON.stringify(Data)) // 加密数据
                        sessionStorage.setItem(this._key, Data) // 本地储存
                        return this._UseUpdate(this._Data) // 回参
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) { throw data._msg }
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this._Data))) // 回参
        }
    }
}