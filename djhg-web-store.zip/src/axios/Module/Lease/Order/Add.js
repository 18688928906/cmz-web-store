import base from "@/axios/base.js";

// 创建订单
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init($) {
        this.Code = $?.Code // 商品编码
        this.Address = $?.Address // 收件地址
        this.Sku = $?.Sku  // 商品规格
        this.Quantity = Number($?.Quantity || 0) // 购买数量
        this.PickUp = Number($?.PickUp || 0) // 是否自提
        this.Term = Number($?.Term || 0) // 租期
        this.Remark = undefined // 备注
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    GetParams() {
        // 创建覆盖用的变量
        var Params = {
            addrId: Number(this.Address),
            // proCode: String(this.Code),
            qty: Number(this.Quantity),
            skuId: String(this.Sku),
            remark: String(this.Remark),
            pickup: Number(this.PickUp),
            term: Number(this.Term)
            // userType: 2
        }

        return Params // 回参
    }

    /**
     * 设置选择
     * @param {*} data // 接口参数
     */
    SetData(params = this.GetParams()) {
        return this._api({
            label: "创建订单", // 接口标题
            method: "post", // 接口方法
            url: "/lease/single/order", // 访问地址
            params: undefined, // 地址携参
            data: params,// 传递参数
        }).then(data => {
            if (data._code === 200) {
                var Data = data
                try {
                    Data = {
                        Id: Data.orderId, // 订单ID
                        Code: Data.orderCode, // 订单代码
                        Type: 30 // 订单类型
                    }

                    return this._UseUpdate(Data) // 回参
                } catch (error) {
                    throw error || "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) {
                throw data._msg
            }
        })
    }
}