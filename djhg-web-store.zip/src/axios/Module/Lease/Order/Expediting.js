import base from "@/axios/base.js";

// 催发货
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
    }

    /**
     * 设置选择
     * @param {*} orderId // 接口参数
     */
    SetData(orderId = String()) {
        return this._api({
            label: "催发货", // 接口标题
            method: "put", // 接口方法
            url: "/lease/order/remind", // 访问地址
            params: { orderId }, // 地址携参
            data: undefined,// 传递参数
        }).then(data => ElMessage({
            showClose: true,
            message: data._msg,
            type: data._code === 200 ? "success" : "error",
            grouping: true,
        }))
    }
}