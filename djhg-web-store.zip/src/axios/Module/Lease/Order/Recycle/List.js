import base from "@/axios/base.js";

// 全新列表
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init($) {
        this.Page = $?.Page || Number(1) // 页码
        this.Limit = $?.Limit || Number(10) // 每页数量
        this.Keyword = $?.Keyword || String("") // 搜索关键字
        this.Max = Boolean(false) // 是否达到获取上限
        this._Data = Object({
            List: Array(0)
        }) // 缓存
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams() {
        var Params = { page: this.Page, limit: this.Limit } // 创建覆盖用的变量
        this.Keyword !== "" && (Params.keyword = this.Keyword) // 写入关键字
        return Params // 回参
    }

    /**
     * 获取列表
     * @param {*} Update // 更新获取
     */
    GetList(Update = !this.Max, params = this._GetParams()) {
        // 没有缓存从服务器获取
        if (Update || this._Data.length === 0) {
            return this._api({
                label: "获取租赁订单列表", // 接口标题
                method: "get", // 接口方法
                url: "/lease/order/recycle/list", // 访问地址
                params, // 地址携参
                data: undefined // 传递参数
            }).then(data => {
                this.Max = (data.list?.length || 0) < this.Limit // 数据触底
                if (data._code === 200 && data.list?.length > 0) {
                    var List = data.list // 创建储存
                    try {
                        // 转换数据格式
                        List = List.map($ => {
                            List = {
                                Code: $.orderCode, // 订单编号
                                Comment: $.commentStatus || 0, // 评论状态：0.未评价，1.已评价，2.已追评
                                CommentId: $.commentId, // 评论ID
                                CreateTime: $.createTime, // 创建时间
                                Coupon: ($.couponMoney || 0).toFixed(2), // 优惠金额
                                Currency: "￥", // 货币种类
                                Id: $.proId, // 商品ID
                                Img: $.skuPic, // 商品图片
                                Invoice: Object.keys($).findIndex(key => key === "invoiceStatus") < 0 ? undefined : Number($.invoiceStatus), // 开具发票状态：0.已关闭，1.待开票，2.已开票
                                InvoiceIs: $.isInvoiceStatus === 1, // 是否可以开票
                                Name: $.proName || "该商品没有设置名称", // 商品名称
                                Modify: ($.modifyPrice || 0).toFixed(2), // 改价
                                OrderId: $.id, // 订单ID
                                Pay: Number($.payMoney || $.goodMoney || 0).toFixed(2), // 支付价格
                                Price: ($.refundMoney || 0).toFixed(2), // 退款
                                Quantity: $.qty || $.totalNum || "数据缺失", // 购买数量
                            }

                            // 售后状态
                            List.AfterSales = {
                                Id: $.refundId,
                                Type: $.interestStatus,
                                Label: (index) => [
                                    "无售后",
                                    "处理中",
                                    "退款完成",
                                    "退款成功",
                                    "退款失败",
                                    "售后关闭"
                                ][index]
                            }

                            // 物流信息：运费，物流ID
                            List.Exp = { Price: ($.expMoney || 0).toFixed(2), Id: $.expId, Type: 20 }

                            // 订单规格
                            List.Sku = $.proSkuName?.split(",").map((item, index) => {
                                return item + "：" + $.skuValue?.split(",")?.[index] || "数据错误"
                            })?.join("，") || $.skuValue || "数据异常：此商品没有规格"

                            // 订单状态
                            List.Status = {
                                Type: $.orderStatus,
                                Label: (index, key = List.Comment) => [
                                    "交易关闭",
                                    "等待买家付款",
                                    "等待商家发货",
                                    "等待买家自提",
                                    "等待买家收货",
                                    "租用中",
                                    "待归还",
                                    "逾期中",
                                    "交易完成" + (["，待评价", "，去追评", "，已评价"][key] || ""),
                                ][index]
                            }

                            // 店铺信息
                            List.Store = {
                                Id: $.mid, // 店铺ID
                                Name: $.storeName || "该店铺没有名称" // 店铺名称
                            }

                            // 处理需要倒计时的状态
                            if ($.orderStatus === 1 || $.orderStatus === 5) {
                                List.TimeOut = ~~((($.orderTimeOut || 0) - data._time) / 1000) // 计算过期时间
                                List.TimeOut <= 0 && (List.Status.Type = List.TimeOut = 0) // 超时自动切换成交易关闭
                            } else {
                                List.TimeOut = 0
                            }

                            return List // 回参
                        })
                        this._Data.List.push(...List) // 缓存数据
                        this.Page++ // 预翻页
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) {
                    throw data._msg
                }
                this._Data.Maps = data.statusMap // 覆盖数量记录
                return this._UseUpdate(this._Data) // 回参
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this._Data))) // 回参
        }
    }

    /**
     * 设置搜索关键字
     * @param {*} Input // 输入信息
     */
    SetKeyword(Input) {
        this.Keyword = String(Input) // 保存关键字
        this.Page = Number(1) // 初始化页码
        this._Data = Object({
            List: Array(0)
        }) // 清空缓存
        this.Max = false
        this.GetList() // 更新列表
        return this // 链式调用
    }

    /**
     * 所属分类ID
     * @param {*} Input // 输入信息
     */
    SetType(Input) {
        this.Type = Input // 保存关键字
        this.Page = Number(1) // 初始化页码
        this._Data = Object({
            List: Array(0)
        }) // 清空缓存
        this.Max = false
        this.GetList() // 更新列表
        return this // 链式调用
    }
}