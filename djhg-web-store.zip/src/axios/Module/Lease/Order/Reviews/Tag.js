import base from "@/axios/base.js";

// 全新列表
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init($) {
        this.Id = Number($?.Id || 0) // 页码
        this._Data = Array(0)
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams() {
        var Params = { proId: this.Id } // 创建覆盖用的变量
        return Params // 回参
    }

    /**
     * 获取列表
     * @param {*} Update // 更新获取
     */
    GetData(Update = true, params = this._GetParams()) {
        // 没有缓存从服务器获取
        if (Update || this._Data.length === 0) {
            return this._api({
                label: "评价标签查询", // 接口标题
                method: "get", // 接口方法
                url: "/lease/comment/tag/list", // 访问地址
                params, // 地址携参
                data: undefined // 传递参数
            }).then(data => {
                if (data._code === 200 && data.list?.length > 0) {
                    var List = data.list // 创建储存
                    try {
                        // 转换数据格式
                        List = List.map($ => ({
                            Label: $.labelName, // 显示名称
                            Value: $.id, // 回传ID
                            Select: false // 判断是否选中
                        }))

                        this._Data.push(...List) // 缓存数据
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) {
                    throw data._msg
                }
                return this._UseUpdate(this._Data) // 回参
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this._Data))) // 回参
        }
    }
}