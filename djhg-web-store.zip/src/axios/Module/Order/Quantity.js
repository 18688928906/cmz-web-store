import base from "@/axios/base.js";

// 订单详情
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
    }

    /**
     * 获取列表
     * @param {*} Update // 更新获取
     */
    GetData() {
        return this._api({
            label: "全部订单数量", // 接口标题
            method: "get", // 接口方法
            url: "/customer/order/all/qty", // 访问地址
            params: undefined, // 地址携参
            data: undefined // 传递参数
        }).then(data => {
            if (data._code === 200) {
                try {
                    return this._UseUpdate({
                        OrderListShop: data.shop?.qty || 0, // 全新数量
                        OrderListLease: data.lease?.qty || 0, // 租赁数据
                        OrderListSurplus: data.surplus?.qty || 0, // 二手数据
                        OrderListReclaim: data.recycle?.qty || 0, // 回收数据
                    }) // 回参
                } catch (error) {
                    throw this.DEV ? error : "数据异常，请稍后重试"
                }
            }
        })
    }
}