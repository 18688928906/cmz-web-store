import base from "@/axios/base.js";

// 支付
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init($) {
        this.Code = $?.Code // 商品编码
        this.PayWord = "pw123456" // 支付密码
        this.Tye = $?.Type || 1 // 数量模式：1.单商品，2.多商品
        this.OrderType = $?.OrderType // 订单类型：10.商城，20.租赁，30.回收，40.闲置
        this.PayType = $?.PayType // 支付方式：1.支付宝，2.微信，3.钱包
        this.flag = $?.flag || "1111"
        return this // 链式调用
    }

    /**
     * 拼接参数
     */
    _GetParams() {
        var Params = {
            orderCode: String(this.Code),
            payWord: String(this.PayWord),
            type: Number(this.Tye),
            orderType: String(this.OrderType),
            payType: Number(this.PayType),
            payChannel: 1,
            fromChannel: 3,
            flag: String(this.flag)
        } // 创建覆盖用的变量
        return Params
    }

    /**
     * 设置选择
     * @param {*} params // 接口参数
     */
    SetData(data = this._GetParams()) {
        return this._api({
            label: "订单去支付", // 接口标题
            method: "post", // 接口方法
            url: "/order/pay", // 访问地址
            params: undefined, // 地址携参
            data,// 传递参数
        }).then(data => {
            if (data._code === 200) {
                try {
                    return this._UseUpdate(data) // 回参
                } catch (error) {
                    throw "数据异常，请稍后重试"
                }
            } else if (data._code !== 200) {
                throw data._msg
            }
        })
    }
}