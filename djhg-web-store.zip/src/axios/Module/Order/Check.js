import base from "@/axios/base.js";

// 支付
export default class extends base {
    /**
     * 构造函数
     * @param {*} baseURL 默认路径
     */
    constructor(baseURL) {
        super(baseURL) // 继承父级
    }

    /**
     * 设置选择
     * @param {*} orderCode // 接口参数
     */
    GetData(orderCode) {
        return this._api({
            label: "轮询支付状态", // 接口标题
            method: "get", // 接口方法
            url: "/order/pay/check", // 访问地址
            params: { orderCode }, // 地址携参
            data: undefined,// 传递参数
        }).then(data => {
            if (data._code !== 500) {
                try {
                    return this._UseUpdate(data) // 回参
                } catch (error) {
                    throw "数据异常，请稍后重试"
                }
            } else if (data._code === 500) {
                throw data._msg
            }
        })
    }
}