import base from "@/axios/base.js";

// 导出具名类，建议和文件名相同
export default class DemandList extends base {
    /**
    * 构造函数
    * @param {*} baseURL 默认路径
    */
    constructor(baseURL) {
        super(baseURL) // 继承父级
        this.init()
    }

    // 初始化
    init($) {
        this.Page = $?.Page || Number(1) // 页码
        this.Limit = $?.Limit || Number(16) // 每页数量
        this.Sort = $?.Sort || String("comprehensive") // 总排序方式
        this.HeatSort = $?.HeatSort || String("") // 热度排序：desc，asc
        this.TimeSort = $?.TimeSort || String("") // 时间排序：desc，asc
        this.Type = $?.Type || String("0") // 分类枚举：租赁0，二手1，招工2，场地3，捐赠4，助农5
        this.Max = Boolean(false) // 是否达到获取上限
        this.List = Array(0) // 缓存
        return this
    }

    /**
     * 拼接参数
     */
    _GetParams() {
        var Params = {
            page: this.Page,
            limit: this.Limit,
            sort: this.Sort,
            type: this.Type
        } // 创建覆盖用的变量
        this.HeatSort !== "" && (Params.HeatSort = this.HeatSort)
        this.TimeSort !== "" && (Params.TimeSort = this.TimeSort)
        return Params
    }

    /**
     * 获取列表
     * @param {*} Update // 更新获取
     */
    GetList(Update = !this.Max, params = this._GetParams()) {
        // 没有缓存从服务器获取
        if (Update || this.List.length === 0) {
            return this._api({
                label: "获取需求列表", // 接口标题
                method: "get", // 接口方法
                url: "/demand/lease/list", // 访问地址
                params, // 地址携参
                data: undefined // 传递参数
            }).then(data => {
                this.Max = (data.data?.length || 0) < this.Limit // 数据触底
                if (data._code === 200 && data.data?.length > 0) {
                    var List = data.data // 创建储存
                    try {
                        // 转换数据格式
                        List = List.map($ => ({
                            Id: $.id, // 需求ID
                            Label: $.title, // 标题
                            Message: $.content, // 需求消息
                            CreateTime: $.createtime, // 创建时间

                            // 用户数据
                            User: {
                                Name: $.customerName, // 用户昵称
                                Avatar: $.headimg // 用户头像
                            }
                        }))

                        this.List.push(...List) // 缓存数据
                        this.Page++ // 预翻页
                        return this._UseUpdate(this.List) // 回参
                    } catch (error) {
                        throw this.DEV ? error : "数据异常，请稍后重试"
                    }
                } else if (data._code !== 200) {
                    throw data._msg
                }
            })
        }

        // 从缓存中获取
        else {
            return new Promise((resolve) => resolve(this._UseUpdate(this.List))) // 回参
        }
    }

    /**
     * 设置热度排序
     * @param {*} Input // 输入信息
     */
    SetHeatSort(Input) {
        this.HeatSort = String(Input) // 保存热度排序
        this.Page = Number(1) // 初始化页码
        this.List = Array(0) // 清空缓存
        this.Max = Boolean(false) // 是否达到获取上限
        this.GetList(!this.Max) // 更新列表
    }

    /**
     * 设置时间排序
     * @param {*} Input // 输入信息
     */
    SetTimeSort(Input) {
        this.TimeSort = String(Input) // 保存时间排序
        this.Page = Number(1) // 初始化页码
        this.List = Array(0) // 清空缓存
        this.Max = Boolean(false) // 是否达到获取上限
        this.GetList(!this.Max) // 更新列表
    }
}