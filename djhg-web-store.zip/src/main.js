/* ---------- 创建挂载点 ---------- */
const div = document.createElement("div") // 创建Div元素
div.id = process.env.VUE_APP_GUID // 给Div元素添加ID
div.className = "infrastructure" // 给Div元素添加Class
document.body.appendChild(div) // 将Div元素挂载到Body里

/* ---------- 导入通用样式 ---------- */
import "@/main.scss"
import "swiper/css" // 样式已通过CDN加载

/* ---------- 实例化VUE ---------- */
import { createApp } from "vue"
import App from "@/App.vue"
const vue = createApp(App)

/* ---------- 导入所有SVG图标 ---------- */
var svg = require.context("@/assets/svg", true, /\.svg$/) // 获取全部的SVG文件
svg = svg.keys().map($ => [$.split(".svg").shift().split("/").pop(), svg($)]) // 转换成特定数组格式
vue.config.globalProperties.$svg = Object.fromEntries(svg) // 把SVG挂载到原型链

/* ---------- 导入状态管理 ---------- */
import { createPinia } from "pinia"
vue.use(createPinia())

/* ---------- 导入公共接口 ---------- */
import axios from "@/axios/install.js"
vue.use(axios, process.env.VUE_APP_BASE_URL)

/* ---------- 导入公共组件 ---------- */
import component from "@/components/install.js"
vue.use(component)

/* ---------- 导入路由 ---------- */
import router from "@/router/index.js"
vue.use(router)

/* ---------- 导入基础库 ---------- */
import library from "@/library.js"
Object.keys(library).forEach(key => vue.config.globalProperties[key] = library[key])

/* ---------- 记录域名 ---------- */
vue.config.globalProperties.$hostname = window.location.hostname

/* ---------- 导入弹窗 ---------- */
import PopUp from "@/pop-up/install.js"
vue.use(PopUp)

/* ---------- 导入放大镜 ---------- */
import Loupe from "@/loupe/install.js"
vue.use(Loupe)

// 导入表情字符库
import Emoji from "@/emoji.json"
vue.config.globalProperties.$Emoji = Emoji

/* ---------- 挂载VUE ---------- */
vue.mount(`#${process.env.VUE_APP_GUID}`) // 挂载