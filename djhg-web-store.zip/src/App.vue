<template>
  <!-- 主显示区 -->
  <div class="infrastructure">
    <ElConfigProvider :locale="zhCn">
      <RouterViewqQuery />
    </ElConfigProvider>
  </div>

  <!-- 弹窗层 -->
  <div class="pop-up-box">
    <template v-for="(item, index) in list" :key="index">
      <component :is="item" />
    </template>
  </div>

  <!-- 开发信息 -->
  <div v-if="DEV" class="DEV" style="bottom: 0">
    逻辑像素：{{ K }}K，定时误差：{{ T }}ms
  </div>
</template>

<script>
import zhCn from "element-plus/lib/locale/lang/zh-cn";

import AddAddress from "@/components/AddAddress.vue"; // 导入全局弹窗
import ListAddress from "@/components/ListAddress.vue"; // 通用地址选择
import CheckAddress from "@/components/CheckAddress.vue"; // 通用地址选择

/**
 * 这个入口文件同时作为示例使用
 */
export default {
  // 自动路由参数，配置看App.vue
  meta: {
    title: undefined, // 写入浏览器页签
    index: undefined, // 用于排序
    label: undefined, // 显示用的路由名称
    name: undefined, // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(false), // 控制是否需要登录
  },

  // 组件
  components: {},

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    zhCn, // 语言控制

    list: Array(0),

    T: 0, // 定时器误差
    K: 1920 * 1080, // 逻辑像素
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 处理开发模式下的信息显示
    if (this.DEV) {
      // 缓存时间
      var T = 0;

      // 订阅心跳
      this.QUEUE["_QUEUE_CHECKUP_"] = ($) => {
        this.T = $ - T - 1000; // 计算精度
        T = $;
      };

      // 计算逻辑像素
      this.K = (window.screen.height * window.screen.width) / this.K;

      // 保留一位小数
      this.K = this.K.toFixed(1);
    }

    // 挂载弹出框
    this.BUS.AddPopUp = (Key, Component) => {
      this.$options.components[Key] = Component;
      this.list = Object.keys(this.$options.components);
    };

    // 卸载弹出框
    this.BUS.DelPopUp = (Key) => {
      // 批量删除组件的订阅
      this.$options.components[Key].data().BusKey.forEach((item) => {
        delete this.BUS[item];
      });
      delete this.$options.components[Key];
      this.list = Object.keys(this.$options.components);
    };

    // 注册地址弹窗
    this.BUS.AddPopUp("AddAddress", AddAddress);

    // 注册地址列表
    this.BUS.AddPopUp("ListAddress", ListAddress);

    // 注册地址检查
    this.BUS.AddPopUp("CheckAddress", CheckAddress);

    // 记录访问数量
    this.Api.UserVisits.GetData();
  },

  // 生命周期函数：挂载后调用
  mounted() {
    if (!!window.$TOKEN$) {
      this.Api.UserLogin.GetUserInfo(true);
    }
  },

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 生命周期函数：离开后调用
  unmounted() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.pop-up-box {
  // 弹窗容器
  position: fixed;
  z-index: 50;
  height: 0;
  width: 0;
  left: 0;
  top: 0;
}
</style>

<style lang="scss" >
.fade-leave-from {
  opacity: 1;
}

.fade-leave-active {
  transition: opacity 0.1s ease;
}

.fade-leave-to {
  opacity: 0;
}

.fade-enter-from {
  opacity: 0;
}

.fade-enter-active {
  transition: opacity 0.1s ease;
}

.fade-enter-to {
  opacity: 1;
}

.infrastructure {
  * {
    box-sizing: border-box;
  }
}
</style>