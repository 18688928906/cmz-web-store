<template>
  <!-- 用户举报评价 -->
  <transition name="simple">
    <div v-if="show" class="exp-box">
      <!-- 内框 -->
      <div class="exp-box-in">
        <!-- 标题容器 -->
        <div class="title-box">
          <div class="title">物流信息</div>
          <div class="img-box" @click="close()">
            <img class="A" :src="$svg['i-0015']" />
            <img class="B" :src="$svg['i-0015-FF0000']" alt="" />
          </div>
        </div>

        <!-- 物流信息 -->
        <ElRow class="company">
          <div>
            <span>物流公司：</span><span>{{ exp?.Company || "-" }}</span>
          </div>
          <div>
            <span>快递单号：</span><span>{{ exp?.Code || "-" }}</span>
          </div>
        </ElRow>

        <!-- 时间线 -->
        <ElScrollbar style="flex-grow: 1" height="300px">
          <ElTimeline>
            <ElTimelineItem
              v-for="(item, index) in exp?.List"
              :timestamp="item.Time"
              :color="index === 0 ? '#F56602' : undefined"
              :key="index"
            >
              <span :style="index === 0 ? 'color:#F56602' : undefined">{{
                item.Text
              }}</span>
            </ElTimelineItem>
          </ElTimeline>
        </ElScrollbar>
      </div>
    </div>
  </transition>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    show: Boolean(false), // 控制显示
    exp: undefined,
    code: undefined, // 缓存当前物流单号
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 订阅
    bus({ Code }) {
      if (!!Code) {
        this.Api.OrderExpNo.init({ Code })
          .GetData(this.code !== Code) // 对比物流单号，控制直接拿缓存
          .then(($) => {
            this.code = Code; // 物流单号
            this.exp = $;
            this.show = true;
          });
      } else {
        this.close();
      }
    },

    // 关闭操作
    close() {
      this.show = false;
      this.exp = undefined;
    },
  },
};
</script>

<style lang="scss" scoped>
.exp-box {
  // 外框
  background-color: rgba(0, 0, 0, 0.2);
  position: fixed;
  height: 100vh;
  width: 100vw;
  left: 0;
  top: 0;

  .exp-box-in {
    // 内框
    background-color: rgba(255, 255, 255, 1);
    transform: translate(-50%, -50%);
    border-radius: 4px;
    position: absolute;
    padding: 20px 12px;
    width: 620px;
    left: 50%;
    top: 50%;

    .title-box {
      // 标题容器
      align-items: center;
      margin-bottom: 20px;
      display: flex;

      .title {
        box-sizing: border-box;
        text-align: left;
        font-size: 18px;
        line-height: 1;
        flex-grow: 1;
      }

      .img-box {
        flex-shrink: 0;
        height: 24px;
        width: 24px;

        img {
          cursor: pointer;
          height: 24px;
          width: 24px;
        }

        .A {
          display: block;
        }

        .B {
          display: none;
        }

        &:hover {
          .A {
            display: none;
          }

          .B {
            display: block;
          }
        }
      }
    }

    .company {
      // 物流公司信息
      margin-bottom: 20px;

      div + div {
        margin-left: 30px;
      }
    }
  }
}

.exp-leave-from {
  opacity: 1;
}

.exp-leave-active {
  transition: opacity var(--base-transition);
}

.exp-leave-to {
  opacity: 0;
}

.exp-enter-from {
  opacity: 0;
}

.exp-enter-active {
  transition: opacity var(--base-transition);
}

.exp-enter-to {
  opacity: 1;
}
</style>