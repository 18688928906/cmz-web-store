import "./main.scss"

import { createApp } from "vue"
import App from "./App.vue"

import { _bus } from "@/library.js";

const vue = createApp(App) // 实例化VUE
const div = document.createElement("div") // 创建Div元素

div.id = process.env.VUE_APP_GUID + "-POP-UP" // 给Div元素添加ID
div.className = "pop-up" // 给Div元素添加Class

// 导出默认
export default Object({
    // 导出安装方法
    install: ($vue) => {
        document.body.appendChild(div) // 将Div元素挂载到Body里
        $vue.config.globalProperties.PopUp = _bus() // 创建订阅容器
        vue.config.globalProperties = $vue.config.globalProperties // 暴露主级的原型链
        vue.mount(`#${div.id}`) // 挂载
    }
})