<template>
  <!-- 用户举报评价 -->
  <transition name="simple">
    <div v-if="show" class="add-address">
      <!-- 内框 -->
      <div class="add-address-in">
        <!-- 标题容器 -->
        <div class="title-box">
          <div class="title">{{ formData.Id ? "修改" : "添加" }}收货地址</div>
          <div class="img-box" @click="close()">
            <img class="A" :src="$svg['i-0015']" />
            <img class="B" :src="$svg['i-0015-FF0000']" alt="" />
          </div>
        </div>

        <!-- 提交表单 -->
        <ElForm :model="formData" :rules="rules" label-position="top" ref="$">
          <ElFormItem
            prop="Name"
            label="姓名"
            style="display: inline-block; width: calc(50% - 12px)"
          >
            <ElInput v-model="formData.Name" placeholder="请输入收件人姓名" />
          </ElFormItem>

          <ElFormItem
            prop="Phone"
            label="手机号"
            style="
              display: inline-block;
              width: calc(50% - 12px);
              margin-left: 24px;
            "
          >
            <ElInputNumber
              v-model="formData.Phone"
              :controls="false"
              placeholder="请输入收件人手机号"
            />
          </ElFormItem>

          <ElFormItem prop="AddressId" label="所在地区">
            <ElCascader
              v-model="formData.AddressId"
              :options="AddressOptions"
              style="flex-grow: 1"
            />
          </ElFormItem>

          <ElFormItem prop="Address" label="详细地址">
            <ElInput
              v-model="formData.Address"
              :maxlength="100"
              :rows="4"
              placeholder="请输入详细地址"
              type="textarea"
              resize="none"
              show-word-limit
            />
          </ElFormItem>
        </ElForm>

        <ElCheckbox
          v-model="formData.Default"
          style="line-height: auto"
          label="默认地址"
        />

        <div class="button-box">
          <ElButton type="danger" @click="upload()">确定</ElButton>
          <ElButton class="B" @click="close()">取消</ElButton>
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    guid: undefined, // 所属界面的唯一ID，由界面写入

    BusKey: ["OpenAddAddress"], // 订阅名称，组件卸载后清理订阅会用到
    AddressOptions: Array[0],

    show: Boolean(false), // 控制显示

    // 提交的表单
    formData: {
      Name: "",
      Phone: undefined,
      AddressId: Array(0),
      Address: "",
      Default: false,
      Ext: undefined,
    },

    // 校验
    rules: {
      Name: [
        {
          required: true,
          message: "姓名不能为空",
          trigger: "blur",
        },
      ],
      Phone: [
        {
          required: true,
          message: "手机号不能为空",
          trigger: "blur",
        },
        {
          validator: (_, value, callback) =>
            callback(
              /^[1][3,4,5,7,8,9][0-9]{9}$/.test(value)
                ? undefined
                : new Error("请输入正确的手机号")
            ),
          trigger: "blur",
        },
      ],
      AddressId: [
        {
          type: "array",
          required: true,
          message: "所在地区不能为空",
          trigger: "change",
        },
      ],
      Address: [
        {
          required: true,
          message: "详细地址不能为空",
          trigger: "blur",
        },
      ],
    },
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 订阅打开窗口并配置默认选项
    // this.BUS[this.BusKey[0]] = (Default, Id) => {
    //   this.show = true;
    //   this.formData.Default = Default;
    //   // 调用一次地址
    //   this.Api.AddressUserList.GetData().then((list) => {
    //     var from = list.find(($) => $.Id === Id);
    //     // 存在ID则判断为修改
    //     if (!!from) {
    //       this.formData = { ...from }; // 拷贝数据
    //       // 删除两个没用的
    //       delete this.formData.Time;
    //       delete this.formData.Ext;
    //     }
    //   });
    // };
    // 获取地址选择器参数
    // this.Api.AddressOptions.GetData().then(($) => (this.AddressOptions = $));
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 订阅
    bus({ orderId = undefined, pric }) {
      return new Promise((resolve) => {
        if (!!orderId) {
          this.orderId = orderId;
          this.show = true;
          this.pric = pric;
        } else {
          this.close();
        }
      });
    },

    // 上传数据
    upload() {
      this.$refs.$.validate().then(($) => {
        if ($) {
          this.formData.Ext = this.Api.AddressOptions.GetExt(
            this.formData.AddressId
          );
          this.Api.AddressUserList.AddAddress(this.formData).then((_) =>
            this.close()
          );
        }
      });
    },

    // 关闭操作
    close() {
      this.$refs.$.resetFields(); // 清除表单
      delete this.formData.Id; // 清除掉修改用的ID，不然新建会出错
      this.show = false;
    },
  },
};
</script>

<style lang="scss" scoped>
.add-address {
  // 外框
  background-color: rgba(0, 0, 0, 0.2);
  position: fixed;
  height: 100vh;
  width: 100vw;
  left: 0;
  top: 0;

  .add-address-in {
    // 内框
    background-color: rgba(255, 255, 255, 1);
    transform: translate(-50%, -50%);
    border-radius: 4px;
    position: absolute;
    padding: 20px 30px;
    width: 600px;
    left: 50%;
    top: 50%;

    .title-box {
      // 标题容器
      align-items: center;
      display: flex;

      .title {
        box-sizing: border-box;
        padding-left: 24px;
        text-align: center;
        font-size: 18px;
        line-height: 1;
        flex-grow: 1;
      }

      .img-box {
        flex-shrink: 0;
        height: 24px;
        width: 24px;

        img {
          cursor: pointer;
          height: 24px;
          width: 24px;
        }

        .A {
          display: block;
        }

        .B {
          display: none;
        }

        &:hover {
          .A {
            display: none;
          }

          .B {
            display: block;
          }
        }
      }
    }

    .el-form {
      // 顶部间距
      margin-top: 40px;

      .el-input-number {
        // 控制长度
        flex-grow: 1;

        :deep(input) {
          // 覆盖文字对齐方向
          text-align: left;
        }
      }
    }

    .button-box {
      // 按钮组
      justify-content: center;
      margin-top: 15px;
      display: flex;

      .el-button {
        --el-color-danger: red;
        border-radius: 4px;
        height: 40px;
        width: 140px;
      }

      .B {
        --el-color-danger: red;
        --el-button-outline-color: red;
        --el-button-hover-border-color: red;
        --el-button-hover-bg-color: white;
      }
    }
  }
}
</style>