<template>
  <!-- 开具发票 -->
  <transition name="simple">
    <div v-if="show" class="invoice-box">
      <!-- 内框 -->
      <ElRow class="invoice-box-in">
        <!-- 标题容器 -->
        <ElRow class="title-box">
          <div class="title">发票申请</div>
          <div class="img-box" @click="close()">
            <img class="A" :src="$svg['i-0015']" />
            <img class="B" :src="$svg['i-0015-FF0000']" alt="" />
          </div>
        </ElRow>

        <!-- 表单 -->
        <ElForm :model="form" :rules="rules" label-width="auto" ref="$">
          <ElFormItem label="发票类型：" style="margin: 0">
            增值电子普通发票
          </ElFormItem>
          <ElFormItem label="支付金额：" style="margin-bottom: 8px">
            ￥{{ pric }}
          </ElFormItem>

          <!-- 抬头类型 -->
          <ElFormItem label="抬头类型：">
            <ElSelect v-model="form.Type" style="width: 100%">
              <ElOption label="个人" :value="0" />
              <ElOption label="企业" :value="1" />
            </ElSelect>
          </ElFormItem>

          <!-- 发票抬头 -->
          <ElFormItem label="发票抬头：" prop="Header">
            <ElInput v-model="form.Header" placeholder="请输入" />
          </ElFormItem>

          <ElFormItem label="邮箱地址：" prop="Email">
            <ElInput v-model="form.Email" placeholder="请输入" />
          </ElFormItem>

          <template v-if="form.Type === 1">
            <!-- 公司税号 -->
            <ElFormItem label="公司税号：" prop="TaxId">
              <ElInput
                v-model="form.TaxId"
                :maxlength="18"
                placeholder="请输入"
                show-word-limit
              />
            </ElFormItem>

            <!-- 注册地址 -->
            <ElFormItem label="注册地址：">
              <ElInput v-model="form.Address" placeholder="请输入" />
            </ElFormItem>

            <!-- 注册地址 -->
            <ElFormItem label="注册电话：">
              <ElInput v-model="form.Phone" placeholder="请输入" />
            </ElFormItem>

            <!-- 开户银行 -->
            <ElFormItem label="开户银行：">
              <ElInput v-model="form.Bank" placeholder="请输入" />
            </ElFormItem>

            <!-- 银行账号 -->
            <ElFormItem label="银行账号：">
              <ElInput v-model="form.Account" placeholder="请输入" />
            </ElFormItem>
          </template>
        </ElForm>

        <!-- 按钮容器 -->
        <ElRow class="button-box">
          <ElButton type="primary" @click="upload()">提交</ElButton>
          <ElButton @click="close()">取消</ElButton>
        </ElRow>
      </ElRow>
    </div>
  </transition>
</template>

<script>
import { email } from "@/tool-library/_modules/verify.js";
export default {
  // 组件
  components: {},

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    show: Boolean(false), // 控制显示

    pric: 0, // 价格

    form: {
      Type: 0, // 发票抬头类型
      Header: "", // 发票抬头
      TaxId: "", // 税号
      Address: "", // 注册地址
      Phone: "", // 注册电话
      Bank: "", // 开户银行
      Account: "", // 银行账号
      Email: "",
    },

    // 校验
    rules: {
      // 发票抬头
      Header: [
        {
          required: true,
          message: "发票抬头不能为空",
          trigger: "blur",
        },
      ],

      // 邮箱
      Email: [
        {
          required: true,
          message: "邮箱不能为空",
          trigger: "blur",
        },
        {
          validator: (_, value, callback) => {
            callback(email(value) ? undefined : new Error("请输入正确的邮箱"));
          },
          trigger: "blur",
        },
      ],

      // 税号
      TaxId: [
        {
          required: true,
          message: "税号不能为空",
          trigger: "blur",
        },
        {
          validator: (_, value, callback) => {
            callback(
              /^[A-Z0-9]{15}$|^[A-Z0-9]{17}$|^[A-Z0-9]{18}$|^[A-Z0-9]{20}$/.test(
                value
              )
                ? undefined
                : new Error("请输入正确的企业税号")
            );
          },
          trigger: "blur",
        },
      ],
    },

    upload: undefined,
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 订阅
    bus({ orderId = undefined, pric, name, sku }) {
      return new Promise((resolve) => {
        if (!!orderId) {
          this.orderId = orderId;
          this.show = true;
          this.pric = pric;
        } else {
          this.close();
        }

        this.upload = () =>
          this.$refs.$.validate().then(($) => {
            if ($) {
              var form = { Code: this.orderId };
              if (this.form.Type === 1) {
                form = Object.assign(form, this.form);
              } else {
                form.Type = this.form.Type;
                form.Header = this.form.Header;
                form.Email = this.form.Email;
              }

              form.Html = `<div><h1>您好，您的电子发票已经开具成功，发票PDF请查看附件</h1><p>商品名称：${name}</p ><p>商品规格：${sku}</p ><p>订单编号：${orderId}</p ></div>`;

              this.Api.SurplusOrderInvoiceAdd.init(form)
                .SetData()
                .then((_) => {
                  this.close();
                  resolve(true);
                });
            }
          });
      });
    },

    // 关闭操作
    close() {
      this.$refs.$.resetFields(); // 清除表单
      this.form.Type = 0;
      this.show = false;
    },
  },
};
</script>

<style lang="scss" scoped>
.invoice-box {
  // 外框
  background-color: rgba(0, 0, 0, 0.2);
  position: fixed;
  height: 100vh;
  width: 100vw;
  left: 0;
  top: 0;

  .invoice-box-in {
    // 内框
    background-color: rgba(255, 255, 255, 1);
    transform: translate(-50%, -50%);
    flex-direction: column;
    align-items: stretch;
    border-radius: 4px;
    position: absolute;
    flex-wrap: nowrap;
    width: 480px;
    left: 50%;
    top: 50%;

    .title-box {
      // 标题容器
      border-bottom: 1px solid rgba(224, 227, 234, 1);
      align-items: center;
      padding: 0 16px;
      height: 56px;

      .title {
        box-sizing: border-box;
        font-weight: bold;
        text-align: left;
        font-size: 12px;
        line-height: 1;
        flex-grow: 1;
      }

      .img-box {
        flex-shrink: 0;
        height: 10px;
        width: 10px;

        img {
          cursor: pointer;
          height: 10px;
          width: 10px;
        }

        .A {
          display: block;
        }

        .B {
          display: none;
        }

        &:hover {
          .A {
            display: none;
          }

          .B {
            display: block;
          }
        }
      }
    }

    .button-box {
      justify-content: flex-end;
      padding: 20px;
    }
  }

  .el-form {
    padding: 6px 20px 16px;
  }
}
</style>