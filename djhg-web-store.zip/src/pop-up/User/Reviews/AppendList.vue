<template>
  <!-- 用户举报评价 -->
  <transition name="simple">
    <div v-if="show" class="exp-box">
      <!-- 居中显示框 -->
      <div class="exp-box-in">
        <ElRow class="close-box">
          <img :src="$svg['i-0015-9D9D9D']" @click="close()" />
        </ElRow>
        <ApList :query="query" />
      </div>
    </div>
  </transition>
</template>

<script>
import ApList from "@/views/Menu/User/All/Reviews/_components/PopUp/AppendList.vue";
export default {
  // 组件
  components: { ApList },

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    show: Boolean(false), // 控制显示
    query: undefined,
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 订阅
    bus(value) {
      return new Promise((resolve) => {
        this.query = value;
        this.show = !!value;
      });
    },

    // 关闭操作
    close() {
      this.query = undefined;
      this.show = false;
    },
  },
};
</script>

<style lang="scss" scoped>
.exp-box {
  // 外框
  background-color: rgba(0, 0, 0, 0.2);
  position: fixed;
  height: 100vh;
  width: 100vw;
  z-index: 2;
  left: 0;
  top: 0;

  .exp-box-in {
    // 内框
    background-color: rgba(255, 255, 255, 1);
    transform: translate(-50%, -50%);
    flex-direction: column;
    box-sizing: border-box;
    align-items: center;
    border-radius: 10px;
    position: absolute;
    max-height: 80vh;
    overflow: hidden;
    display: flex;
    padding: 30px;
    width: 1200px;
    left: 50%;
    top: 50%;

    .close-box {
      flex-direction: row-reverse;
      align-items: center;
      width: 100%;

      img {
        transform: scale(0.5);
        cursor: pointer;
        height: 30px;
        width: 30px;
      }
    }
  }
}

/* ---------- * ---------- */

.exp-leave-from {
  opacity: 1;
}

.exp-leave-active {
  transition: opacity var(--base-transition);
}

.exp-leave-to {
  opacity: 0;
}

.exp-enter-from {
  opacity: 0;
}

.exp-enter-active {
  transition: opacity var(--base-transition);
}

.exp-enter-to {
  opacity: 1;
}

/* ---------- * ---------- */

.fade1-enter-active,
.fade1-leave-active,
.fade0-enter-active,
.fade0-leave-active {
  transition: all 0.2s var(--el-transition-function-ease-in-out-bezier);
}

/* ---------- * ---------- */

.fade0-leave-from {
  transform: translateX(0%);
}

.fade0-leave-to {
  transform: translateX(100%);
}

.fade0-enter-from {
  transform: translateX(-100%);
}

.fade0-enter-to {
  transform: translateX(0%);
}

/* ---------- * ---------- */

.fade1-leave-from {
  transform: translateX(0%);
}

.fade1-leave-to {
  transform: translateX(-100%);
}

.fade1-enter-from {
  transform: translateX(100%);
}

.fade1-enter-to {
  transform: translateX(0%);
}
</style>