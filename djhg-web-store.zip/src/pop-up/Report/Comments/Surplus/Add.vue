<template>
  <!-- 开具发票 -->
  <transition name="simple">
    <div v-if="show" class="invoice-box">
      <!-- 内框 -->
      <ElRow class="invoice-box-in">
        <!-- 标题容器 -->
        <ElRow class="title-box">
          <div class="title">举报</div>
          <div class="img-box" @click="close()">
            <img class="A" :src="$svg['i-0015']" />
            <img class="B" :src="$svg['i-0015-FF0000']" />
          </div>
        </ElRow>

        <!-- 表单 -->
        <ElForm
          :model="form"
          :rules="rules"
          label-position="top"
          label-width="auto"
          ref="$"
        >
          <ElFormItem prop="Type">
            <ElRow class="list">
              <transition v-for="(item, index) in list" :key="index">
                <div
                  :class="{ active: form.Type === index }"
                  class="list-item"
                  @click="form.Type = index"
                >
                  {{ item }}
                </div>
              </transition>
            </ElRow>
          </ElFormItem>

          <ElFormItem label="举报详情" prop="Content">
            <ElInput
              v-model="form.Content"
              :maxlength="300"
              :rows="3"
              placeholder="请填写举报详情"
              type="textarea"
              resize="none"
              show-word-limit
            />
          </ElFormItem>

          <ElFormItem label="照片凭证">
            <Upload v-model:file="form.Imgs" />
          </ElFormItem>
        </ElForm>

        <!-- 按钮容器 -->
        <ElRow class="button-box">
          <ElButton type="primary" @click="upload()">提交</ElButton>
          <ElButton @click="close()">取消</ElButton>
        </ElRow>
      </ElRow>
    </div>
  </transition>
</template>

<script>
import Upload from "./_components/Upload.vue";
export default {
  // 组件
  components: { Upload },

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    show: Boolean(false), // 控制显示

    list: undefined,

    form: {
      Id: undefined, // 评价ID
      Type: undefined, // 举报类型
      Content: "", // 内容
      Imgs: Array(0), // 图片
    },

    // 校验
    rules: {
      Type: [
        {
          required: true,
          message: "请选择举报类型",
          trigger: "blur",
        },
      ],
      Content: [
        {
          required: true,
          message: "举报内容不能为空",
          trigger: "blur",
        },
      ],
    },

    upload: undefined,
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.list = this.Api.SurplusCommentsReport.TypeList;
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 订阅
    bus(Id = undefined) {
      return new Promise((resolve) => {
        if (!!Id) {
          this.form.Id = Id; // 保存评价ID
          this.show = true;
        } else {
          this.close();
        }

        this.upload = () =>
          this.$refs.$.validate().then(($) => {
            if ($) {
              var form = JSON.parse(JSON.stringify(this.form));
              form.Imgs = this.form.Imgs.map(
                (item) => item.response.data.url
              ).join(",");
              this.Api.SurplusCommentsReport.init(form)
                .SetData()
                .then((_) => {
                  this.close();
                  resolve(true);
                });
            }
          });
      });
    },

    // 关闭操作
    close() {
      this.$refs.$.resetFields(); // 清除表单
      this.form.Type = undefined;
      this.form.Imgs = undefined;
      this.form.Imgs = Array(0);
      this.show = false;
    },
  },
};
</script>

<style lang="scss" scoped>
.invoice-box {
  // 外框
  background-color: rgba(0, 0, 0, 0.2);
  position: fixed;
  height: 100vh;
  width: 100vw;
  left: 0;
  top: 0;

  .invoice-box-in {
    // 内框
    background-color: rgba(255, 255, 255, 1);
    transform: translate(-50%, -50%);
    flex-direction: column;
    align-items: stretch;
    border-radius: 4px;
    position: absolute;
    flex-wrap: nowrap;
    width: 560px;
    left: 50%;
    top: 50%;

    .title-box {
      // 标题容器
      border-bottom: 1px solid rgba(224, 227, 234, 1);
      align-items: center;
      padding: 0 16px;
      height: 56px;

      .title {
        box-sizing: border-box;
        font-weight: bold;
        text-align: left;
        font-size: 16px;
        line-height: 1;
        flex-grow: 1;
      }

      .img-box {
        flex-shrink: 0;
        height: 16px;
        width: 16px;

        img {
          cursor: pointer;
          height: 16px;
          width: 16px;
        }

        .A {
          display: block;
        }

        .B {
          display: none;
        }

        &:hover {
          .A {
            display: none;
          }

          .B {
            display: block;
          }
        }
      }
    }

    .el-form {
      padding-top: 12px;

      .el-form-item > :deep(.el-form-item__label) {
        font-size: 12px;
      }

      .list {
        // 列
        justify-content: space-between;
        width: 100%;

        .list-item {
          // 列条目
          background-color: rgba(246, 247, 251, 1);
          border-radius: 2em;
          text-align: center;
          line-height: 28px;
          font-size: 12px;
          cursor: pointer;
          width: 68px;

          &:hover {
            color: red;
          }
        }

        .active {
          color: red;
        }
      }
    }

    .button-box {
      justify-content: flex-end;
      padding: 20px;
    }
  }

  .el-form {
    padding: 6px 20px 16px;
  }
}
</style>