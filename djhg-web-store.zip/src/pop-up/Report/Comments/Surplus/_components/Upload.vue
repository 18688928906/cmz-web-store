<template>
  <!-- 商品容器 -->
  <div class="upload-box">
    <template v-for="(item, index) in _file" :key="index">
      <!-- 显示图片 -->
      <div class="img-box">
        <!-- 图片展示 -->
        <ElImage
          :src="item.response?.data?.url"
          style="width: 100%; height: 100%"
          fit="contain"
        />

        <!-- 关闭容器 -->
        <div class="close" @click="remove(index)">
          <img class="A" :src="$svg['i-0032']" />
          <img class="B" :src="$svg['i-0032-FF0000']" />
        </div>

        <div class="anew" @click="remove(index)">重新上传图片</div>
      </div>
    </template>

    <!-- 上传功能 -->
    <ElUpload
      v-show="_file.length < 6"
      v-model:file-list="_file"
      :show-file-list="false"
      :before-upload="before"
      :on-progress="progress"
      :on-success="success"
      :action="action"
      :accept="accept"
      :limit="6"
      class="upload"
    >
      <ElRow class="upload-img-box">
        <img :src="$svg['i-0034-057BFF']" />
      </ElRow>

      <div class="upload-tips">上传图片</div>
    </ElUpload>
  </div>
</template>

<script>
import { compressAccurately } from "image-conversion";
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    // 文件对象
    file: {
      type: Array,
      default: () => Array(0),
    },
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    action:
      process.env.VUE_APP_BASE_URL +
      process.env.VUE_APP_OBS +
      "/cmz-img/?token=", // 拼接华为OBS服务器地址
    accept: [".jpg", ".jpeg", ".png"].join(","), // 支持的上传格式

    percent: undefined, // 上传进度

    _file: Array(0), // 映射

    video: false, // 视频模式
    full: false, // 满文件
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.action = this.action + this.Api.UserLogin.Token.token; // 拼接上传路径
    this.accept = [this.accept, this.accept.toUpperCase()].join(","); // 拼接上传格式
    this._file = this.file; // 写入已上传文件
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 上传前检查
    before($) {
      return compressAccurately($, 1024 * 2);
    },

    // 上传时
    progress($) {
      this.percent = ~~$.percent; // 记录上传进度（取整数）
    },

    // 上传成功
    success($) {
      this.percent = undefined; // 上传成功清除进度
      this.$emit("update:file", this._file); // 更新传入数据
    },

    // 删除文件
    remove(index) {
      this._file.splice(index, 1); // 删除数组下标
      this.$emit("update:file", this._file); // 更新传入数据
    },
  },
};
</script>

<style lang="scss" scoped>
.upload-box {
  // 商品容器
  grid-template-columns: repeat(auto-fill, 80px);
  grid-gap: 12px 12px;
  position: relative;
  min-height: 80px;
  display: grid;
  width: 100%;

  .percent {
    // 进度
    border: var(--el-border);
    justify-content: center;
    align-items: center;
    border-radius: 4px;
    display: flex;
    height: 80px;
    width: 80px;
  }

  .img-box {
    // 图片容器
    border: 1px solid rgba(57, 123, 255, 1);
    border-radius: 6px;
    position: relative;
    overflow: hidden;
    height: 80px;
    width: 80px;

    .close {
      // 关闭
      position: absolute;
      cursor: pointer;
      display: none;
      height: 14px;
      width: 14px;
      right: 2px;
      top: 2px;

      img {
        height: inherit;
        width: inherit;
      }

      .A {
        display: block;
      }

      .B {
        display: none;
      }

      &:hover {
        .A {
          display: none;
        }

        .B {
          display: block;
        }
      }
    }

    .anew {
      // 重新
      background-color: rgba(51, 51, 51, 0.5);
      border-radius: 6px 6px 0 0;
      text-align: center;
      position: absolute;
      line-height: 18px;
      font-size: 12px;
      cursor: pointer;
      color: white;
      display: none;
      height: 18px;
      width: 100%;
      bottom: 0;
      left: 0;
    }

    &:hover {
      .close,
      .anew {
        display: block;
      }
    }
  }

  .upload {
    // 上传功能
    transition: var(--base-transition);
    border: 1px solid rgba(96, 98, 102, 1);
    background-color: rgba(243, 243, 243, 1);
    border-style: dashed;
    border-radius: 4px;
    height: 80px;
    width: 80px;

    :deep(.el-upload) {
      // 内部样式覆盖
      justify-content: space-evenly;
      flex-direction: column;
      height: 100%;
      width: 100%;
    }

    .upload-img-box {
      // 上传内部图标容器
      box-shadow: 0px 0px 4px 0px rgba(0, 0, 0, 0.15);
      background-color: white;
      justify-content: center;
      border-radius: 12px;
      align-items: center;
      height: 24px;
      width: 24px;

      img {
        height: 16px;
        width: 16px;
      }
    }

    .upload-tips {
      color: rgba(96, 98, 102, 1);
      font-size: 12px;
      line-height: 1;
    }

    &:hover {
      border-color: var(--el-color-primary);
    }
  }

  .count {
    // 计数
    color: rgba(153, 153, 153, 1);
    align-items: flex-end;
    line-height: 1;
    display: flex;
  }
}
</style>