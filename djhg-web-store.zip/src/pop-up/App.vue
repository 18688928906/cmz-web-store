<template>
  <template v-for="(item, index) in list" :key="index">
    <component :ref="item" :is="item" />
  </template>
</template>

<script>
var File = require.context("./", true, /\.vue/); // 获取全部模块文件

/**
 * 顶层弹窗入口
 */
export default {
  // 组件
  components: {},

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    keys: File.keys().filter(
      ($) => !/_component/.test($) && !/App.vue/.test($)
    ), // 排除组件层和导入
    list: undefined,
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 处理全部模块
    this.list = this.keys.map((key) => {
      var name = key.toLowerCase().replace(/\.vue/, "").replace(/\./, ""); // 路径小写转换
      name = name.split("/"); // 拆分成数组
      name = name.map(($) => $.charAt(0).toUpperCase() + $.slice(1)); // 首字母大写
      name = name.join(""); // 合并字符串
      this.$options.components[name] = File(key).default || File(key); // 实例化组件
      this.PopUp[name] = ($) => this.$refs[name][0].bus($); // 导出主链路弹窗方法
      return name; // 返回组件名
    });
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.pop-up-box {
  // 顶层弹窗容器
  position: fixed;
  height: 100%;
  width: 100%;
  left: 0;
  top: 0;
}
</style>