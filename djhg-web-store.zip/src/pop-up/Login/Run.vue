<template>
  <!-- 用户举报评价 -->
  <transition name="simple">
    <div v-if="show" class="exp-box">
      <!-- 居中显示框 -->
      <div class="exp-box-in">
        <LoginBox @setActive="setName">
          <transition :name="name" mode="out-in">
            <component :is="name" :query="form" />
          </transition>

          <!-- 提示容器 -->
          <div class="tips-box">
            <img v-if="tips" class="closes" :src="closeimg" />
            <div v-if="tips" class="tips">{{ tips }}</div>
          </div>
        </LoginBox>

        <LoginButton @click="login()" />

        <!-- 底部容器 -->
        <div class="bottom-box">
          <div class="A" @click="GoRetrieve">忘记密码</div>
          <div style="flex-grow: 1" />
          <div class="B" @click="GoRegistration">注册账号</div>
        </div>
      </div>

      <div class="close" @click="close()">
        <img :src="$svg['i-0015-FFFFFF']" alt="" />
      </div>
    </div>
  </transition>
</template>

<script>
import Account from "./_components/Account.vue";
import LoginBox from "./_components/LoginBox.vue";
import Valid from "./_components/Valid.vue";
import LoginButton from "@/views/Login/_components/LoginButton.vue";

import closeimg from "@/views/Login/_components/close.png";

export default {
  // 组件
  components: { LoginBox, fade0: Account, fade1: Valid, LoginButton },

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    show: Boolean(false), // 控制显示
    list: [
      {
        label: "密码登录",
        name: "loginA",
      },
      {
        label: "短信登录",
        name: "loginB",
      },
    ], // 模式列表
    name: undefined, // 模式控制
    phone: undefined,
    tips: undefined,
    form: { vaild: undefined },
    closeimg,
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 订阅
    bus() {
      return new Promise((resolve) => {
        this.setName(0);
        this.show = true;
        this.login = () => {
          if (!this.Disabled) {
            this.tips = undefined;
            if (this.name === "fade0") {
              this.Api.UserLogin.GetToken()
                .then((_) => location.reload())
                .catch(($) => {
                  this.tips = $;
                });
            } else if (this.name === "fade1") {
              this.Api.UserLogin.GetToken(this.form.vaild)
                .then((_) => location.reload())
                .catch(($) => {
                  this.tips = $;
                });
            }
          }
          // this.close();
          // resolve(true);
        };
      });
    },

    // 关闭操作
    close() {
      this.show = false;
    },

    setName(index) {
      this.name = "fade" + index;
      this.protocol = false;
    },

    // 跳转注册界面
    GoRegistration() {
      this.$GO({ path: "/menu/registration/valid" }, true);
    },

    // 找回密码
    GoRetrieve() {
      this.$GO({ path: "/menu/retrieve/password/account" }, true);
    },
  },
};
</script>

<style lang="scss" scoped>
.exp-box {
  // 外框
  background-color: rgba(0, 0, 0, 0.2);
  position: fixed;
  height: 100vh;
  width: 100vw;
  z-index: 2;
  left: 0;
  top: 0;

  .exp-box-in {
    // 内框
    background-color: rgba(255, 255, 255, 1);
    transform: translate(-50%, -50%);
    flex-direction: column;
    box-sizing: border-box;
    align-items: center;
    border-radius: 6px;
    position: absolute;
    overflow: hidden;
    padding: 0 32px;
    display: flex;
    width: 360px;
    left: 50%;
    top: 50%;

    .tips-box {
      // 提示容器
      justify-content: flex-start;
      width: calc(100% - 64px);
      align-items: flex-start;
      flex-direction: row;
      margin-left: 32px;
      flex-wrap: nowrap;
      margin-top: 9px;
      display: flex;
      flex-grow: 1;
      height: 14px;

      .closes {
        margin-right: 5px;
        flex-shrink: 0;
        height: 14px;
        width: 14px;
      }

      .tips {
        color: rgba(245, 63, 63, 1);
        line-height: 14px;
        font-size: 12px;
        flex-grow: 1;
      }
    }

    .phone {
      --el-color-primary: rgba(249, 104, 40, 1);
      margin-top: 50px;
    }

    .bottom-box {
      // 底部容器
      justify-content: flex-start;
      flex-direction: row;
      margin-bottom: 40px;
      align-items: center;
      flex-wrap: nowrap;
      margin-top: 28px;
      flex-shrink: 0;
      display: flex;
      width: 100%;

      div {
        transition: var(--el-transition-all);
        align-items: center;
        font-size: 12px;
        display: flex;
        height: 17px;

        &:hover {
          color: rgba(249, 104, 40, 1);
        }
      }

      .A {
        color: rgba(192, 196, 204, 1);
        cursor: pointer;
      }

      .B {
        color: rgba(96, 98, 102, 1);
        cursor: pointer;
      }
    }
  }

  .close {
    background-color: rgba(204, 204, 204, 1);
    border: 3px solid white;
    border-radius: 26px;
    position: absolute;
    cursor: pointer;
    padding: 5px;
    height: 16px;
    width: 16px;
    left: calc(50% + 360px / 2 - 16px);
    top: calc(50% - 16px - 215px);

    img {
      height: 100%;
      width: 100%;
    }
  }
}

/* ---------- * ---------- */

.exp-leave-from {
  opacity: 1;
}

.exp-leave-active {
  transition: opacity var(--base-transition);
}

.exp-leave-to {
  opacity: 0;
}

.exp-enter-from {
  opacity: 0;
}

.exp-enter-active {
  transition: opacity var(--base-transition);
}

.exp-enter-to {
  opacity: 1;
}

/* ---------- * ---------- */

.fade1-enter-active,
.fade1-leave-active,
.fade0-enter-active,
.fade0-leave-active {
  transition: all 0.2s var(--el-transition-function-ease-in-out-bezier);
}

/* ---------- * ---------- */

.fade0-leave-from {
  transform: translateX(0%);
}

.fade0-leave-to {
  transform: translateX(100%);
}

.fade0-enter-from {
  transform: translateX(-100%);
}

.fade0-enter-to {
  transform: translateX(0%);
}

/* ---------- * ---------- */

.fade1-leave-from {
  transform: translateX(0%);
}

.fade1-leave-to {
  transform: translateX(-100%);
}

.fade1-enter-from {
  transform: translateX(100%);
}

.fade1-enter-to {
  transform: translateX(0%);
}
</style>