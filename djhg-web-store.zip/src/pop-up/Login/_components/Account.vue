<template>
  <div class="view">
    <!-- 账号 -->
    <ElInput v-model="Account" placeholder="请输入帐号/手机号" size="large" />

    <!-- 密码 -->
    <ElInput v-model="Password" placeholder="密码" size="large" show-password />
  </div>
</template>

<script>
import close from "@/views/Login/_components/close.png";
import Protocol from "@/views/Login/_components/Protocol.vue";
import LoginButton from "@/views/Login/_components/LoginButton.vue";

export default {
  // 自动路由参数
  meta: {
    title: "密码登录", // 写入浏览器页签
    index: 0, // 用于排序
    label: "密码登录", // 显示用的路由名称
    name: "LoginAccount", // 路由名称

    open: Boolean(false), // 是否在新页面中打开
    token: Boolean(false), // 控制是否需要登录
  },

  // 组件
  components: { Protocol, LoginButton },

  // 接收参数
  props: {
    query: undefined, // 获取解密后的传参
    bus: undefined, // 局域订阅
  },

  // 计算属性
  computed: {
    // 账号
    Account: {
      get() {
        return this.account;
      },
      set(value) {
        this.Api.UserLogin.Account = value;
        this.account = value;
        // this.bus.setPhone(value);
      },
    },

    // 密码
    Password: {
      get() {
        return this.password;
      },
      set(value) {
        this.Api.UserLogin.Password = value;
        this.password = value;
        // this.bus.setPassword(value);
      },
    },
  },

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    account: String(""), // 账号
    password: String(""), // 密码
    tips: undefined, // 提示
    protocol: false,
    close,
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 开发模式默认账号和密码
    if (this.DEV) {
      this.Account = "15177708038";
      this.Password = "pw123456";
    } else {
      this.Account = this.account;
      this.Password = this.password;
    }
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 登录
    login() {
      if (this.protocol) {
        this.tips = undefined;
        this.Api.UserLogin.GetToken()
          .then((_) => {
            this.$router.push({ name: "Home" });
          })
          .catch(($) => {
            this.tips = $;
          })
          .finally((_) => {
            // this.BUS.Loading(false);
          });
      } else {
        this.tips = "请先同意协议";
      }
    },

    // 跳转注册界面
    GoRegistration() {
      this.$GO({ name: "Registration" });
    },

    // 找回密码
    GoRetrieve() {
      this.$GO({ path: "/menu/retrieve/password/account" });
    },
  },
};
</script>

<style lang="scss" scoped>
.view {
  // 容器
  justify-content: flex-start;
  flex-direction: column;
  align-items: stretch;
  padding: 50px 32px 0;
  flex-wrap: nowrap;
  display: flex;
  // height: 100%;
  width: 100%;

  .el-input {
    // 替换颜色
    --el-input-focus-border-color: rgba(249, 104, 40, 1);
    flex-shrink: 0;
    width: calc(100% - 64px);
  }

  .el-input + .el-input {
    // 间距
    margin-top: 16px;
  }
}
</style>