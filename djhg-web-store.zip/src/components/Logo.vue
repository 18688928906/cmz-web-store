<template>
  <img :src="src" @click="GoHome()" />
</template>

<script>
import logo from "@/assets/logo2.png";

/**
 * 项目主图标
 */
export default {
  // 组件名称
  name: "Logo",

  // 组件
  components: {},

  // 接收参数
  props: {
    src: {
      type: String,
      default: logo,
    },
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 打开首页
    GoHome() {
      this.$router.push({ name: "Home" });
    },
  },
};
</script>

<style lang="scss" scoped>
img {
  cursor: pointer;
  height: 1em;
}
</style>