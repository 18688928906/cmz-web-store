<template>
  <!-- 顶栏居中容器 -->
  <div class="top-bar">
    <!-- 顶栏内容器 -->
    <div class="top-bar-in">
      <img v-if="!!src" :src="src" class="logo" />
      <template v-else>
        <!-- 图标 -->
        <Logo class="logo" />

        <!-- 标题 -->
        <div class="label">{{ label }}</div>
      </template>

      <!-- 插槽 -->
      <slot />
    </div>
  </div>
</template>

<script>
/**
 * 通用顶栏
 */
export default {
  // 组件名称
  name: "TopBar",

  // 组件
  components: {},

  // 接收参数
  props: {
    // 标题
    label: {
      type: String,
      default: process.env.VUE_APP_TITLE,
    },

    // 直接使用图片替换
    src: undefined,
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.top-bar {
  // 顶栏
  box-shadow: var(--base-shadow);
  background-color: white;
  justify-content: center;
  display: flex;
  width: 100%;

  .top-bar-in {
    // 顶栏容器
    align-items: center;
    position: relative;
    display: flex;
    height: 100px;
    width: 1200px;

    .logo {
      // 图标
      height: 40px;
      // width: 60px;
    }

    .label {
      color: var(--base-color);
      margin-left: 25px;
      line-height: 1em;
      font-size: 20px;
      flex-grow: 1;
    }
  }
}
</style>