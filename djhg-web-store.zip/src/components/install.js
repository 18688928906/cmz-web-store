// 获取全部vue文件
var file = require.context("@/components", true, /\.vue/)

// 创建全部组件
var component = file.keys()
    .map($ => file($).default || file($)) //实例化
    .filter($ => $.name) // 排除没有名称的组件

// 覆盖获取私有组件
file = require.context("@/views", true, /\.vue/)

// 直接覆盖节省内存
file = file.keys()
    .filter($ => /\_component/.test($)) // 筛选出组件
    .map($ => file($).default || file($)) //实例化
    .filter($ => $.name) // 排除没有名称的组件

// 开发模式下校验组件冲突
if (process.env.VUE_APP_DEV) {
    // 检查重复的部分
    const repeat = file.filter($ => {
        return component.findIndex(item => item.name === $.name) >= 0
    }).map($ => $.name)

    // 发现重复直接报错
    if (repeat.length > 0) {
        throw new ReferenceError(`Component name conflict "${repeat.join(',')}"`)
    }

    // 合并组件
    else { component.push(...file) }
}

// 生产模式直接合并
else { component.push(...file) }

// 导出默认
export default Object({
    // 导出安装方法
    install: (vue) => {
        component.forEach($ => vue.component($.name, $)) // 循环注册组件
    },

    // 单独导出组件
    ...component
})