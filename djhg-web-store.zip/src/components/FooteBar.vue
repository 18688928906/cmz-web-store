<template>
  <div class="foote-bar">
    <div class="link-box">
      <!-- <div class="link">在线客服</div>
      <div class="line" />
      <div class="link">合作招商</div>
      <div class="line" /> -->
      <div class="link" @click="$GO({ path: '/menu/business/welcome' })">
        商家入驻
      </div>
      <div class="line" />
      <div class="link">使用帮助</div>
      <div class="line" />
      <!-- <div class="link">友情链接</div>
      <div class="line" /> -->
      <div class="link" @click="$GO({ path: '/menu/help/feedback' })">
        用户反馈
      </div>
      <div class="line" />
      <div class="link">联系我们</div>
      <div class="line" />
      <div class="link" @click="$GO({ path: '/menu/business/backend' })">
        商家后台
      </div>
      <div class="line" />
      <div class="link">移动端下载</div>
    </div>

    <div class="icp-box" v-if="icp === false">
      <div class="copyright">Copyright © {{ $hostname }} 版权所有</div>
      <div class="icp ox" @click="golicense()">
        增值电信业务经营许可证：粤B2-20220737
      </div>
      <img :src="beian" class="beian" />
      <div class="icp ox" @click="gobeian()">粤公网安备：44190002006954</div>
      <div class="icp" @click="goicp()">粤ICP备2021084699号-5</div>
    </div>
  </div>
</template>

<script>
import beian from "@/assets/警徽.png";

export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    icp: {
      type: Boolean,
      default: false,
    },
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    beian,
  }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    goicp() {
      window.open("https://beian.miit.gov.cn/#/Integrated/index");
    },
    golicense() {
      this.$GO({ path: "/license" }, true);
    },
    gobeian() {
      window.open(
        "https://www.beian.gov.cn/portal/registerSystemInfo?recordcode=44190002006954"
      );
    },
  },
};
</script>

<style lang="scss" scoped>
.foote-bar {
  /* 底栏 */
  background-color: rgba(35, 35, 35, 1);
  justify-content: flex-start;
  flex-direction: column;
  align-items: center;
  position: relative;
  flex-shrink: 0;
  display: flex;
  height: 260px;
  width: 100%;

  .code-box {
    /* 二维码展示 */
    border-bottom: 1px solid rgba(61, 61, 64, 1);
    justify-content: space-around;
    align-items: center;
    display: flex;
    height: 174px;
    width: 1200px;

    div {
      width: 100px;

      img {
        height: 100px;
        width: 100px;
      }

      div {
        color: rgba(255, 255, 255, 1);
        text-align: center;
        line-height: 18px;
        font-size: 14px;
        width: 100px;
      }
    }
  }

  .link-box {
    justify-content: center;
    align-items: center;
    margin-top: 75px;
    display: flex;
    width: 1200px;

    .link {
      color: rgba(204, 204, 204, 1);
      font-size: 14px;
      line-height: 1;
      cursor: pointer;
    }

    .line {
      background-color: rgba(204, 204, 204, 1);
      margin: 0 20px;
      height: 14px;
      width: 1px;
    }
  }

  .icp-box {
    justify-content: center;
    flex-direction: row;
    margin-top: 110px;
    display: flex;
    width: 100%;

    .copyright,
    .icp {
      color: rgba(204, 204, 204, 1);
      font-size: 12px;
    }

    .icp {
      margin-left: 20px;
    }

    .ox {
      cursor: pointer;
      &:hover {
        color: rgba(249, 104, 40, 1);
      }
    }

    .beian {
      margin-right: -15px;
      margin-left: 20px;
      width: 15px;
    }
  }
}
</style>