<template>
  <div class="svg-icon">
    <img :src="$svg[src]" />
  </div>
</template>

<script>
export default {
  // 组件名称
  name: "SvgIcon",

  // 组件
  components: {},

  // 接收参数
  props: {
    // 图片链接
    src: {
      type: String,
      default: undefined,
    },
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.svg-icon {
  --svg-color: rgba(0, 0, 0, 1);
  box-sizing: border-box;
  position: relative;
  font-size: inherit;
  overflow: hidden;
  flex-shrink: 0;
  display: block;
  height: 1em;
  width: 1em;

  img {
    filter: drop-shadow(var(--svg-color) 0 1em);
    transform: translateY(-1em);
    font-size: inherit;
    position: relative;
    display: block;
    height: 1em;
    width: 1em;
  }
}
</style>