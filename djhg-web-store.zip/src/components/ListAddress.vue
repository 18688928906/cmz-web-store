<template>
  <!-- 用户选择地址 -->
  <transition name="address">
    <div v-if="show" class="list-address">
      <!-- 内框 -->
      <div class="list-address-in">
        <!-- 标题容器 -->
        <div class="title-box">
          <div class="title">选择收货地址</div>
          <div class="img-box" @click="close()">
            <img class="A" :src="$svg['i-0015']" />
            <img class="B" :src="$svg['i-0015-FF0000']" alt="" />
          </div>
        </div>

        <ElTable
          :data="list"
          style="width: 100%; margin-top: 20px"
          height="300"
          @row-click="RowClick"
          border
        >
          <ElTableColumn prop="Name" label="收件人" width="150" />
          <ElTableColumn prop="Phone" label="联系号码" width="200" />
          <ElTableColumn prop="Ext" label="地区" />
          <ElTableColumn prop="Address" label="地址" />
        </ElTable>
      </div>
    </div>
  </transition>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    guid: undefined, // 所属界面的唯一ID，由界面写入

    BusKey: ["OpenAddressList"], // 订阅名称，组件卸载后清理订阅会用到
    list: Array(0),
    columns: [
      {
        title: "收件人姓名",
        dataKey: "Name",
        key: "Name",
        width: 200,
      },
      {
        title: "联系号码",
        dataKey: "Phone",
        key: "Phone",
        width: 150,
      },
      {
        title: "地址",
        dataKey: "Ext",
        key: "Ext",
      },
      {
        dataKey: "Address",
        key: "Address",
      },
    ],

    show: Boolean(false), // 控制显示

    UserBack: undefined, // 内部回参
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 订阅打开窗口并配置默认选项
    this.BUS[this.BusKey[0]] = (CallBack = (_) => {}) => {
      this.show = true;

      // 映射异步回参
      return new Promise((resolve) => {
        this.UserBack = ($) => (CallBack($), resolve($));
      });
    };

    // 获取用户地址列表
    this.Api.AddressUserList.AddUpdate(
      this.BusKey[0],
      (list) => (this.list = list)
    ).GetData(true);
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 关闭
    close() {
      this.show = false;
    },

    // 行点击事件
    RowClick(row, column, event) {
      this.UserBack(row);
      this.close();
    },
  },
};
</script>

<style lang="scss" scoped>
.list-address {
  // 外框
  background-color: rgba(0, 0, 0, 0.2);
  position: fixed;
  height: 100vh;
  width: 100vw;
  left: 0;
  top: 0;

  .list-address-in {
    // 内框
    background-color: rgba(255, 255, 255, 1);
    transform: translate(-50%, -50%);
    border-radius: 4px;
    position: absolute;
    padding: 20px 30px;
    width: 1000px;
    left: 50%;
    top: 50%;

    .title-box {
      // 标题容器
      align-items: center;
      display: flex;

      .title {
        box-sizing: border-box;
        padding-left: 24px;
        text-align: center;
        font-size: 18px;
        line-height: 1;
        flex-grow: 1;
      }

      .img-box {
        flex-shrink: 0;
        height: 24px;
        width: 24px;

        img {
          cursor: pointer;
          height: 24px;
          width: 24px;
        }

        .A {
          display: block;
        }

        .B {
          display: none;
        }

        &:hover {
          .A {
            display: none;
          }

          .B {
            display: block;
          }
        }
      }
    }
  }
}

.address-leave-from {
  opacity: 1;
}

.address-leave-active {
  transition: opacity var(--base-transition);
}

.address-leave-to {
  opacity: 0;
}

.address-enter-from {
  opacity: 0;
}

.address-enter-active {
  transition: opacity var(--base-transition);
}

.address-enter-to {
  opacity: 1;
}
</style>