<template>
  <ElScrollbar ref="$" @scroll="$emit('GetTop', $event.scrollTop)">
    <!-- 页面容器 -->
    <div
      v-infinite-scroll="LoadMore"
      class="flex-scroll-box"
      :infinite-scroll-distance="distance"
      :infinite-scroll-immediate="false"
      :class="{ 'no-foot': !foot }"
      :id="guid"
      :style="`padding-bottom:${pb}`"
    >
      <slot />
    </div>

    <!-- 底栏 -->
    <FooteBar v-if="foot !== false" />
  </ElScrollbar>
</template>

<script>
import FooteBar from "@/components/FooteBar.vue";
import { GUID } from "@/library.js";

export default {
  // 组件名称
  name: "ScrollBar",

  // 组件
  components: { FooteBar },

  // 接收参数
  props: {
    // 是否启用底栏
    foot: {
      type: Boolean,
      default: true,
    },

    // 用于触底发布的唯一ID
    guid: {
      type: String,
      default: GUID(), // 默认使用函数生成
    },

    // 触发加载的距离阈值
    distance: {
      type: Number,
      default: 0,
    },

    // 底边距
    pb: {
      type: String,
      default: "28px", // 默认使用函数生成
    },
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {
    this.$emit("guid", this.guid); // 导出唯一ID
    this.BUS[this.guid] = (top) => this.GoTop(top); // 订阅滚动顶部事件
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {
    delete this.BUS[this.guid]; // 取消订阅
  },

  // 组件方法
  methods: {
    // 加载更多（触底事件）
    LoadMore() {
      this.$emit("load", this.guid); // 导出唯一ID
    },

    // 跳转顶部
    GoTop(top = 0) {
      this.$refs.$.scrollTo({ top, behavior: "smooth" });
    },
  },
};
</script>

<style lang="scss" scoped>
.el-scrollbar {
  // 样式覆盖
  background-color: rgba(244, 244, 244, 1);
  box-sizing: border-box;
  position: relative;
  width: 100%;

  .flex-scroll-box {
    // 内部滚动容器
    min-height: calc(100vh - 36px - 260px);
    justify-content: flex-start;
    box-sizing: border-box;
    flex-direction: column;
    // padding-bottom: 28px;
    align-items: center;
    position: relative;
    flex-shrink: 0;
    display: flex;
    width: 100%;
  }

  .no-foot {
    // 没有底栏的情况
    min-height: calc(100vh - 36px);
    padding-bottom: 0;
  }
}
</style>