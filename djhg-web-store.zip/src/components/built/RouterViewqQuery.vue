<template>
  <router-view :query="query || $route.query || undefined" />
</template>

<script>
/**
 * 这个入口文件同时作为示例使用
 */
export default {
  // 组件名称
  name: "RouterViewqQuery",

  // 组件
  components: {},

  // 接收参数
  props: {
    query: undefined, // 向子级界面传递参数，可以通过传递对象的方法将父级变成数据缓存区域，达到多个子页面数据同步的功能
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>