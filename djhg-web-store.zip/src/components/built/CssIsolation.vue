<template>
  <slot />
</template>

<script>
export default { name: "CssIsolation" }; // 组件名称
</script>