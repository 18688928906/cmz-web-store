<template>
  <router-view v-slot="{ Component, route }">
    <!-- 过度效果 -->
    <transition
      :name="transition?.name?.(Component, route) || GetName(Component, route)"
      :mode="transition?.mode?.(Component, route) || GetMode(Component, route)"
    >
      <!-- 需要缓存的页面 -->
      <keep-alive v-if="route.meta.token">
        <component :is="Component" :query="GetQuery(route)" :key="route.path" />
      </keep-alive>

      <!-- 无需缓存的页面 -->
      <component
        v-else
        :is="Component"
        :query="GetQuery(route)"
        :key="route.path"
      />
    </transition>
  </router-view>
</template>

<script>
/**
 * 这个入口文件同时作为示例使用
 */
export default {
  // 组件名称
  name: "RouterViewqAuto",

  // 组件
  components: {},

  // 接收参数
  props: {
    query: undefined, // 向子级界面传递参数，可以通过传递对象的方法将父级变成数据缓存区域，达到多个子页面数据同步的功能
    transition: undefined, // 对外接口
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 配置过度名称
    GetName(Component, route) {
      return Component?.type?.meta?.transition?.name &&
        Component.type.meta.transition.name == route?.meta?.transition?.name
        ? route.meta.transition.name
        : undefined;
    },

    // 配置过度模式
    GetMode(Component, route) {
      return Component?.type?.meta?.transition?.name &&
        Component.type.meta.transition.name == route?.meta?.transition?.name
        ? route.meta.transition.mode
        : undefined;
    },

    // 获取传参
    GetQuery(route) {
      return this.query || route?.query || undefined;
    },
  },
};
</script>