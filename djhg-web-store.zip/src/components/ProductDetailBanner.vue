<template>
  <div class="product-detail-banner">
    <div v-if="sku" class="el-carousel" style="height: 500px">
      <ArLoupe :src="sku" style="height: 100%; width: 100%" />
    </div>

    <!-- 商品轮播图容器 -->
    <ElCarousel
      v-else-if="list"
      :initial-index="0"
      :autoplay="false"
      :loop="false"
      indicator-position="none"
      height="500px"
      ref="el"
      @change="Index = $event"
    >
      <template v-for="(item, index) in list" :key="index">
        <!-- 处理视频标签-->
        <ElCarouselItem v-if="item.type === 'video'">
          <video width="500" height="500" controls muted>
            <source :src="item.src" type="video/mp4" />
          </video>
        </ElCarouselItem>

        <!-- 使用背景优化图片 -->
        <ElCarouselItem v-else-if="item.type === 'img'">
          <ArLoupe :src="item.src" style="height: 100%; width: 100%" />
        </ElCarouselItem>
      </template>
    </ElCarousel>

    <!-- 滑动容器 -->
    <div class="swiper-box">
      <!-- 上一个 -->
      <div class="button" @click="PrevEl()">
        <img class="A" :src="$svg['i-0005-CCCCCC']" />
        <img class="B" :src="$svg['i-0005-CCDDFD']" />
      </div>

      <!-- 滑动 -->
      <Swiper
        ref="$"
        :slidesPerView="6"
        :spaceBetween="12"
        :grabCursor="true"
        :navigation="true"
        :modules="modules"
      >
        <template v-for="(item, index) in list" :key="index">
          <!-- 处理视频-->
          <SwiperSlide
            v-if="item.type === 'video'"
            style="cursor: pointer"
            @click="Change(index)"
          >
            <video width="60" height="60">
              <source :src="item.src" type="video/mp4" />
            </video>
            <img :src="$svg['i-0012-FFFFFF']" />
          </SwiperSlide>

          <!-- 处理图片 -->
          <SwiperSlide v-else-if="item.type === 'img'">
            <ElImage
              class="item"
              :class="{ omit: Index === index && !this.sku }"
              :src="item.src"
              fit="contain"
              @click="Change(index)"
            />
          </SwiperSlide>
        </template>
      </Swiper>

      <!-- 下一个 -->
      <div class="button" @click="NextEl()">
        <img class="A" :src="$svg['i-0006-CCCCCC']" />
        <img class="B" :src="$svg['i-0006-CCDDFD']" />
      </div>
    </div>

    <slot />
  </div>
</template>

<script>
// 导入滚动组件
import { Navigation } from "swiper";
import { Swiper, SwiperSlide } from "swiper/vue";

/**
 * 商品详情轮播图
 */
export default {
  // 组件名称
  name: "ProductDetailBanner",

  // 组件
  components: { Swiper, SwiperSlide },

  // 接收参数
  props: {
    list: undefined, // 列表
    imgs: undefined, // 传入图片列
    loupe: {
      type: Boolean,
      default: true,
    },
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    Index: Number(0), // 选中的项
    sku: undefined,
    modules: [Navigation], // 滚动组件配置
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.BUS.ProductDetailBannerSku = (url) => (this.sku = url);
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 生命周期函数：离开后调用
  unmounted() {},

  // 组件方法
  methods: {
    // 上一个
    PrevEl() {
      if (this.$refs.$.$el.swiper.activeIndex < this.list.length - 5) {
        this.$refs.$.$el.swiper.navigation.prevEl.click(); // 模拟点击
      }

      if (this.$refs.$.$el.swiper.activeIndex >= this.list.length - 7) {
        this.Change(--this.Index);
      } else if (this.list.length > 6) {
        this.Change(this.$refs.$.$el.swiper.activeIndex);
      } else {
        this.Change(this.Index > 0 ? --this.Index : this.Index);
      }
    },

    // 下一个
    NextEl() {
      this.$refs.$.$el.swiper.navigation.nextEl.click(); // 模拟点击

      if (this.$refs.$.$el.swiper.activeIndex >= this.list.length - 7) {
        this.Change(
          this.Index < this.list.length - 1 ? this.Index + 1 : this.Index
        );
      } else if (this.list.length > 6) {
        this.Change(this.$refs.$.$el.swiper.activeIndex);
      } else {
        this.Change(
          this.Index < this.list.length - 1 ? this.Index + 1 : this.Index
        );
      }
    },

    // 手动选择
    Change(index) {
      this.$refs.$.$el.swiper.activeIndex = index;
      this.$refs.el.setActiveItem(index);
      this.Index = index;
      this.sku = undefined;
    },
  },
};
</script>

<style lang="scss" >
.product-detail-banner {
  flex-direction: column;
  align-items: center;
  display: flex;
  width: 500px;

  video {
    background-color: black;
  }

  .el-carousel {
    // 轮播图容器
    background-color: white;
    border-radius: 4px;
    overflow: hidden;
    flex-shrink: 0;
    width: 500px;

    .el-carousel__item {
      // 背景设置
      background-repeat: no-repeat;
      background-size: 100% 100%;
    }
  }

  .swiper-box {
    // 滑动容器
    justify-content: center;
    align-items: center;
    margin-top: 12px;
    display: flex;
    height: 60px;

    .swiper {
      // 滑动
      margin: 0 12px;
      width: 420px;

      :deep(.swiper-button-prev),
      :deep(.swiper-button-next) {
        display: none;
      }

      .item {
        // 单项
        border: 1px solid rgba(0, 0, 0, 0.1);
        border-radius: 4px;
        cursor: pointer;
        height: 60px;
        width: 60px;
      }

      .omit {
        // 选中的项
        border: 1px solid rgba(255, 0, 0, 1);
      }

      video {
        border-radius: 4px;
      }

      video + img {
        position: absolute;
        height: 20px;
        width: 20px;
        left: 20px;
        top: 20px;
      }
    }

    .button {
      // 按钮容器
      background-color: rgba(240, 240, 240, 1);
      justify-content: center;
      border-radius: 28px;
      align-items: center;
      cursor: pointer;
      flex-shrink: 0;
      display: flex;
      height: 28px;
      width: 28px;

      img {
        height: 20px;
        width: 20px;
      }

      .A {
        display: block;
      }

      .B {
        display: none;
      }
    }

    .button:hover {
      .A {
        display: none;
      }

      .B {
        display: block;
      }
    }
  }
}
</style>