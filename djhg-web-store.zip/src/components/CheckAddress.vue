<template>
  <!-- 用户举报评价 -->
  <transition name="address">
    <div v-if="show" class="add-address">
      <!-- 内框 -->
      <div class="add-address-in">
        <!-- 标题容器 -->
        <div class="title-box">
          <div class="title">收货地址</div>
          <div class="img-box" @click="close()">
            <img class="A" :src="$svg['i-0015']" />
            <img class="B" :src="$svg['i-0015-FF0000']" alt="" />
          </div>
        </div>

        <!-- 提示 -->
        <div class="tips">您还没有收货地址，请设置您的收货地址</div>

        <!-- 确认按钮 -->
        <div class="button" @click="open()">确认</div>
      </div>
    </div>
  </transition>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    guid: undefined, // 所属界面的唯一ID，由界面写入

    BusKey: ["CheckAddress"], // 订阅名称，组件卸载后清理订阅会用到

    show: Boolean(false), // 控制显示
  }),

  // 生命周期函数：挂载前调用
  created() {
    // 订阅打开窗口并配置默认选项
    this.BUS[this.BusKey[0]] = () =>
      new Promise((resolve) => {
        this.Api.AddressUserList.GetData(true).then((list) => {
          // 检查用户地址列表，没有地址提醒新建地址
          if (list && list.length > 0) {
            resolve(true);
          } else {
            this.show = true;

            // 打开添加地址
            this.open = () => {
              this.BUS.OpenAddAddress().then(() => resolve(true));
              this.close();
            };
          }
        });
      });
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 关闭操作
    close() {
      this.show = false;
    },

    // 打开添加地址
    // open() {
    //   this.close();
    //   this.BUS.OpenAddAddress();
    // },
  },
};
</script>

<style lang="scss" scoped>
.add-address {
  // 外框
  background-color: rgba(0, 0, 0, 0.2);
  position: fixed;
  height: 100vh;
  width: 100vw;
  left: 0;
  top: 0;

  .add-address-in {
    // 内框
    background-color: rgba(255, 255, 255, 1);
    transform: translate(-50%, -50%);
    border-radius: 4px;
    position: absolute;
    padding: 20px 30px;
    width: 600px;
    left: 50%;
    top: 50%;

    .title-box {
      // 标题容器
      align-items: center;
      display: flex;

      .title {
        box-sizing: border-box;
        padding-left: 24px;
        text-align: center;
        font-size: 18px;
        line-height: 1;
        flex-grow: 1;
      }

      .img-box {
        flex-shrink: 0;
        height: 24px;
        width: 24px;

        img {
          cursor: pointer;
          height: 24px;
          width: 24px;
        }

        .A {
          display: block;
        }

        .B {
          display: none;
        }

        &:hover {
          .A {
            display: none;
          }

          .B {
            display: block;
          }
        }
      }
    }

    .tips,
    .button {
      margin-top: 20px;
      font-size: 16px;
    }

    .button {
      cursor: pointer;

      &:hover {
        color: red;
      }
    }
  }
}

.address-leave-from {
  opacity: 1;
}

.address-leave-active {
  transition: opacity var(--base-transition);
}

.address-leave-to {
  opacity: 0;
}

.address-enter-from {
  opacity: 0;
}

.address-enter-active {
  transition: opacity var(--base-transition);
}

.address-enter-to {
  opacity: 1;
}
</style>