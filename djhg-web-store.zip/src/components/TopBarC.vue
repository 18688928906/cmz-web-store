<template>
  <!-- 顶栏居中容器 -->
  <div class="top-bar">
    <!-- 顶栏内容器 -->
    <div class="top-bar-in">
      <!-- 图标 -->
      <img :src="src || Logo" />

      <!-- 标题 -->
      <!-- <div class="label">{{ label }}</div> -->
    </div>
  </div>
</template>

<script>
import Logo from "@/assets/特殊图标.png";
/**
 * 通用顶栏
 */
export default {
  // 组件名称
  name: "TopBarC",

  // 组件
  components: {},

  // 接收参数
  props: {
    // 标题
    label: {
      type: String,
      default: process.env.VUE_APP_TITLE,
    },

    // 直接使用图片替换
    src: undefined,
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({ Logo }),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" scoped>
.top-bar {
  // 顶栏
  box-shadow: var(--base-shadow);
  background-color: white;
  justify-content: center;
  display: flex;
  width: 100%;

  .top-bar-in {
    // 顶栏容器
    padding-right: 168px;
    align-items: center;
    display: flex;
    height: 100px;
    width: 1200px;

    img {
      // 图标
      height: 40px;
      // width: 168px;
    }

    .label {
      color: var(--base-color);
      text-align: center;
      font-weight: bold;
      line-height: 1em;
      font-size: 20px;
      flex-grow: 1;
    }
  }
}
</style>