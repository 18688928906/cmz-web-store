<template>
  <div class="product-detail-box"><slot /></div>
</template>

<script>
/**
 * 商品详情展示布局（通用）
 */
export default {
  // 组件名称
  name: "ProductDetailBox",

  // 组件
  components: {},

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({}),

  // 生命周期函数：挂载前调用
  created() {},

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 生命周期函数：离开后调用
  unmounted() {},

  // 组件方法
  methods: {},
};
</script>

<style lang="scss" >
.product-detail-box {
  justify-content: space-between;
  align-items: flex-start;
  flex-direction: row;
  display: flex;
  width: 1200px;
}
</style>