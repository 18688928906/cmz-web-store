<template>
  <div v-if="show" :style="style" class="box">
    <img :src="src" :style="img" />
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {},

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    // 高帧率优化
    animation: window.requestAnimationFrame
      ? (fun) => window.requestAnimationFrame(fun)
      : (fun) => fun(),
    show: false,
    style: {},
    img: {},
    src: undefined,
  }),

  // 生命周期函数：挂载前调用
  created() {
    this["arvk-loupe"].set = ($) => {
      this.show = $.show;
      this.src = $.src;
      !!$.refs && this.SetDom($.refs, $.zoom, $.X, $.Y);
    };
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    SetDom(refs, zoom, X, Y) {
      this.animation(() => {
        this.style.height = refs.$.clientHeight + "px"; // 设置高度
        this.style.width = refs.$.clientWidth + "px"; // 设置宽度

        var { x, y } = refs.$.getBoundingClientRect(); // 获取页面真实坐标
        this.style.left = x + refs.$.clientHeight + 20 + "px"; // 设置容器的X坐标
        this.style.top = y + "px"; // 设置容器的Y坐标

        this.img.height = refs.$.clientHeight * zoom + "px"; // 设置高度
        this.img.width = refs.$.clientWidth * zoom + "px"; // 设置宽度

        this.img.left = -X * zoom + "px"; // 反向移动放大后的X坐标
        this.img.top = -Y * zoom + "px"; // 反向移动放大后的Y坐标
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.box {
  border: 1px solid var(--el-color-info-light-7);
  background-color: white;
  overflow: hidden;
  position: fixed;

  img {
    position: absolute;
  }
}
</style>