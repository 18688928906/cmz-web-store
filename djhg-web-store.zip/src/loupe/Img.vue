<template>
  <div
    class="arvk-loupe"
    @mouseenter="show = true"
    @mouseleave="leave()"
    @mousemove="move($event)"
    ref="$"
  >
    <img :src="src" class="arvk-loupe-img" />
    <div
      v-if="show && open"
      class="arvk-loupe-region"
      :style="style"
      ref="region"
    />
  </div>
</template>

<script>
export default {
  // 组件
  components: {},

  // 接收参数
  props: {
    src: undefined, // 图片链接

    // 缩放倍数
    zoom: {
      type: Number,
      default: 1.5,
    },

    // 是否显示
    open: {
      type: Boolean,
      default: true,
    },
  },

  // 计算属性
  computed: {},

  // 观察者
  watch: {},

  // 页面对象
  data: () => ({
    // 高帧率优化
    animation: window.requestAnimationFrame
      ? (fun) => window.requestAnimationFrame(fun)
      : (fun) => fun(),
    show: false,
    style: {},
  }),

  // 生命周期函数：挂载前调用
  created() {
    this.style.height = this.style.width = 100 / this.zoom + "%";
  },

  // 生命周期函数：挂载后调用
  mounted() {},

  // 生命周期函数：离开前调用
  beforeUnmount() {},

  // 组件方法
  methods: {
    // 鼠标移动
    move(event) {
      this.animation(() => {
        var { pageX: X, pageY: Y } = event; // 分离鼠标移动坐标
        var { clientHeight: H, clientWidth: W } = this.$refs.region || {}; // 获取宽高
        var dom = this.$refs.$.getBoundingClientRect(); // 获取主容器信息

        X = X - dom.x; // 计算X轴
        Y = Y - dom.y; // 计算Y轴
        H = H / 2; // 中心坐标
        W = W / 2; // 中心坐标

        // 处理X轴
        if (X < W) {
          X = 0;
        } else if (X > this.$refs.$.clientWidth - W) {
          X = this.$refs.$.clientWidth - W * 2;
        } else {
          X = X - W;
        }
        this.style.left = X + "px";

        // 处理Y轴
        if (Y < H) {
          Y = 0;
        } else if (Y > this.$refs.$.clientHeight - H) {
          Y = this.$refs.$.clientHeight - H * 2;
        } else {
          Y = Y - H;
        }
        this.style.top = Y + "px";

        // 检查显示控制，防止数组滞后
        if (this.show && this.open) {
          this["arvk-loupe"].set({
            show: true,
            refs: this.$refs,
            zoom: this.zoom,
            src: this.src,
            X,
            Y,
          });
        }
      });
    },

    // 鼠标离开
    leave() {
      this.show = false;
      this["arvk-loupe"].set({ show: false });
    },
  },
};
</script>

<style lang="scss" scoped>
.arvk-loupe {
  // 主容器
  position: relative;

  .arvk-loupe-img {
    height: 100%;
    width: 100%;
  }

  .arvk-loupe-region {
    background-image: radial-gradient(#409eff 30%, transparent 0);
    background-size: 3px 3px;
    position: absolute;
    top: 0;
  }
}
</style>