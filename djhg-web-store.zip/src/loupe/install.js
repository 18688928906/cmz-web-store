import "./main.scss"

import { createApp } from "vue"
import Box from "./Box.vue"
import Img from "./Img.vue"

import { _bus } from "@/library.js";

const vue = createApp(Box) // 实例化VUE
const div = document.createElement("div") // 创建Div元素

div.id = "arvk-loupe" // 给Div元素添加ID

// 导出默认
export default Object({
    // 导出安装方法
    install: ($vue) => {
        document.body.appendChild(div) // 将Div元素挂载到Body里
        $vue.config.globalProperties["arvk-loupe"] = _bus() // 创建订阅容器
        $vue.component("ArLoupe", Img) // 注册组件
        vue.config.globalProperties = $vue.config.globalProperties // 暴露主级的原型链
        vue.mount(`#${div.id}`) // 挂载
    }
})