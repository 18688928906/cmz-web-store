module.exports = {
  projectName: "nmzm-pc-ex",
  privateKey: "/Users/xiachutian/.ssh/id_ed25519",
  passphrase: "",
  cluster: [],
  test: {
    name: "开发环境",
    script: "npm run build",
    host: "192.168.10.71",
    port: 22,
    username: "root",
    password: "yuhao123456",
    distPath: "pc",
    webDir: "/usr/local/nginx/html/pc",
    bakDir: "/usr/local/nginx/backup/pc ",
    isRemoveRemoteFile: true,
    isRemoveLocalFile: false,
  },
};
